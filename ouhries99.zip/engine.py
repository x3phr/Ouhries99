"""
Sistema Ouhries V5 - Motor de Trading
Sistema de Niveles de interes compuesto con subniveles (N1, N1+, N1++, ...).
N1 win -> subnivel (capital + 35% profit anterior).
N1+ loss -> reset N1. N1 loss -> queda en N1.
N1+ win -> N1++ (segun niveles configurados).
Stop loss con cap de 15% del balance.
Payout 87+ automatico, expiracion 1 minuto.
Estrategia V3: ADX >= 25, Calidad >= 88%, Solo a favor de tendencia, CERO contra-tendencia.
Notificacion Telegram con emojis al finalizar sesion (stopwin/stoploss/max_ops).
MessageBox en GUI al finalizar sesion con resumen completo.
"""

import time
import random
import json
import os
import threading
from datetime import datetime

from iqoption_patched import IQ_Option_Patched
from scanner import OTCScanner
from instruments import get_otc_instruments
from telegram_notifier import TelegramNotifier
from logger import Logger

STATE_FILE = "session_state.json"


class TradingEngine:
    def __init__(self, config, log_callback=None, status_callback=None,
                 radar_callback=None, trade_callback=None):
        self.config = config
        self.log_cb = log_callback or (lambda x: None)
        self.status = status_callback or (lambda x: None)
        self.radar_cb = radar_callback or (lambda asset, idx, total: None)
        self.trade_cb = trade_callback or (lambda trade_info: None)
        self.api = None
        self.scanner = None
        self.running = False
        self._stop_flag = False
        self._lock = threading.Lock()
        self._trade_in_progress = False
        self._end_reason = None  # 'stopwin', 'stoploss', 'max_trades', 'manual', 'error'
        self._session_end_callback = None  # Callback para GUI al finalizar sesion

        self.logger = Logger()

        self.telegram = TelegramNotifier(
            token=config.get("telegram_token", ""),
            chat_id=config.get("telegram_chat_id", ""),
            enabled=config.get("telegram_enabled", False),
            log_callback=lambda x: None  # Telegram log a archivo, no GUI
        )

        self.balance = 0.0
        self.initial_balance = 0.0
        self.current_level = 1
        self.current_sublevel = 0      # 0=N1, 1=N1+, 2=N1++, etc.
        self.total_trades = 0
        self.total_wins = 0
        self.total_losses = 0
        self.current_profit = 0.0
        self.current_instrument = None
        self.last_trade_amount = 0.0
        self.previous_profits = []
        self.operated_assets = set()

    def log(self, msg):
        self.logger.log(msg)
        try:
            self.log_cb(msg)
        except Exception:
            pass

    # ============================================================
    # PERSISTENCIA
    # ============================================================

    def save_state(self):
        state = {
            "timestamp": datetime.now().isoformat(),
            "balance": self.balance,
            "initial_balance": self.initial_balance,
            "current_level": self.current_level,
            "current_sublevel": self.current_sublevel,
            "total_trades": self.total_trades,
            "total_wins": self.total_wins,
            "total_losses": self.total_losses,
            "current_profit": self.current_profit,
            "current_instrument": self.current_instrument,
            "last_trade_amount": self.last_trade_amount,
            "previous_profits": self.previous_profits,
            "operated_assets": list(self.operated_assets),
        }
        try:
            with open(STATE_FILE, "w") as f:
                json.dump(state, f, indent=2)
            sl_text = self._sublevel_text()
            self.log(f"[Persistencia] Estado guardado ({sl_text} | Ops: {self.total_trades})")
        except Exception as e:
            self.log(f"[Persistencia] Error guardando estado: {e}")

    def load_state(self):
        if not os.path.exists(STATE_FILE):
            self.log("[Persistencia] No hay sesion previa, iniciando nueva")
            return False
        try:
            with open(STATE_FILE, "r") as f:
                state = json.load(f)
            self.balance = state.get("balance", 0.0)
            self.initial_balance = state.get("initial_balance", 0.0)
            self.current_level = state.get("current_level", 1)
            self.current_sublevel = state.get("current_sublevel", 0)
            self.total_trades = state.get("total_trades", 0)
            self.total_wins = state.get("total_wins", 0)
            self.total_losses = state.get("total_losses", 0)
            self.current_profit = state.get("current_profit", 0.0)
            self.current_instrument = state.get("current_instrument", None)
            self.last_trade_amount = state.get("last_trade_amount", 0.0)
            self.previous_profits = state.get("previous_profits", [])
            self.operated_assets = set(state.get("operated_assets", []))
            saved_time = state.get("timestamp", "desconocido")
            sl_text = self._sublevel_text()
            self.log(f"[Persistencia] Sesion previa encontrada: {saved_time}")
            self.log(f"[Persistencia] {sl_text} | Ops: {self.total_trades} | W: {self.total_wins} | L: {self.total_losses}")
            if self.scanner:
                for asset in self.operated_assets:
                    self.scanner.add_operated(asset)
            return True
        except Exception as e:
            self.log(f"[Persistencia] Error cargando estado: {e}")
            return False

    def clear_state(self):
        try:
            if os.path.exists(STATE_FILE):
                os.remove(STATE_FILE)
                self.log("[Persistencia] Estado anterior eliminado")
        except Exception as e:
            self.log(f"[Persistencia] Error eliminando estado: {e}")

    # ============================================================
    # CONEXION
    # ============================================================

    def _ensure_connected(self):
        if self.api is None:
            return False
        try:
            return self.api._ensure_connected()
        except Exception as e:
            self.log(f"[Engine] Error verificando conexion: {e}")
            return False

    def connect(self):
        try:
            self.log("[Engine] Conectando a IQ Option (API Parchada V5)...")
            email = self.config.get("email", "")
            password = self.config.get("password", "")
            self.api = IQ_Option_Patched(email, password)
            check, reason = self.api.connect()
            if not check:
                self.log(f"[Engine] Error de conexion: {reason}")
                return False
            self.log("[Engine] Conexion exitosa!")
            mode = self.config.get("account_mode", "PRACTICE")
            self.api.change_balance(mode)
            self.log(f"[Engine] Modo de cuenta: {mode}")
            self.balance = self.api.get_balance()
            self.initial_balance = self.balance
            self.log(f"[Engine] Balance inicial: ${self.balance:.2f}")
            self.scanner = OTCScanner(self.api, self.config, self.log,
                                      radar_callback=self.radar_cb)
            # Re-crear Telegram con credenciales actualizadas
            self.telegram = TelegramNotifier(
                token=self.config.get("telegram_token", ""),
                chat_id=self.config.get("telegram_chat_id", ""),
                enabled=self.config.get("telegram_enabled", False),
                log_callback=lambda x: self.log(f"[TG] {x}") if False else None
            )
            self.telegram.start()
            # Enviar mensaje de prueba para verificar Telegram
            if self.config.get("telegram_enabled", False):
                self.log("[Engine] Telegram habilitado - enviando notificacion de inicio...")
            return True
        except Exception as e:
            self.log(f"[Engine] Error conectando: {e}")
            return False

    def switch_account(self, mode):
        try:
            if self.api:
                self.api.change_balance(mode)
                self.config["account_mode"] = mode
                self.balance = self.api.get_balance()
                self.log(f"[Engine] Cambiado a cuenta {mode}. Balance: ${self.balance:.2f}")
                self.status(f"Cuenta: {mode} | Balance: ${self.balance:.2f}")
                self.save_state()
                return True
        except Exception as e:
            self.log(f"[Engine] Error cambiando cuenta: {e}")
        return False

    # ============================================================
    # PAYOUT
    # ============================================================

    def _get_instrument_payout(self, instrument_name):
        try:
            all_profit = self.api.get_all_profit()
            if all_profit:
                for name in [instrument_name, instrument_name.upper(),
                             instrument_name.replace("-OTC", "_otc"),
                             instrument_name.replace("-OTC", "-otc")]:
                    if name in all_profit:
                        payout_info = all_profit[name]
                        if isinstance(payout_info, dict):
                            turbo = payout_info.get("turbo", 0)
                            if turbo:
                                return int(float(turbo) * 100)
                            binary = payout_info.get("binary", 0)
                            if binary:
                                return int(float(binary) * 100)
                        elif isinstance(payout_info, (int, float)):
                            return int(float(payout_info) * 100)
        except Exception as e:
            self.log(f"[Payout] Error obteniendo payout de {instrument_name}: {e}")
        return 0

    def _check_payout_min(self, instrument_name):
        payout_min = self.config.get("payout_min", 87)
        payout = self._get_instrument_payout(instrument_name)
        if payout >= payout_min:
            return True
        else:
            self.log(f"[Payout] {instrument_name}: {payout}% < {payout_min}% RECHAZADO")
            return False

    # ============================================================
    # TIMING
    # ============================================================

    def _wait_for_candle_timing(self):
        candle_seconds = 60
        now = time.time()
        seconds_into_candle = now % candle_seconds
        entry_before_close = candle_seconds - 2
        entry_after_open_max = 2
        if seconds_into_candle >= entry_before_close:
            wait_close = candle_seconds - seconds_into_candle
            self.log(f"[Timing] En ventana de cierre. Entrando en {wait_close:.1f}s...")
            if wait_close > 0:
                time.sleep(wait_close)
            time.sleep(random.uniform(1.0, 2.0))
            return
        if seconds_into_candle <= entry_after_open_max:
            remaining = entry_after_open_max - seconds_into_candle
            if remaining > 0:
                time.sleep(random.uniform(0, remaining))
            return
        wait_seconds = entry_before_close - seconds_into_candle
        self.log(f"[Timing] Esperando {wait_seconds:.0f}s hasta ventana de cierre...")
        while wait_seconds > 0 and not self._stop_flag:
            chunk = min(wait_seconds, 5)
            time.sleep(chunk)
            wait_seconds -= chunk
        if self._stop_flag:
            return
        now = time.time()
        seconds_into_candle = now % candle_seconds
        if seconds_into_candle >= entry_before_close:
            wait_close = candle_seconds - seconds_into_candle
            if wait_close > 0:
                time.sleep(wait_close)
            time.sleep(random.uniform(1.0, 2.0))

    # ============================================================
    # MONTO - Sistema de Niveles con Interes Compuesto
    # ============================================================

    def _sublevel_text(self):
        if self.current_sublevel == 0:
            return "N1"
        return "N1" + "+" * self.current_sublevel

    def _get_trade_amount(self):
        base = self.config.get("capital_operacion", 2.50)
        # Si disable_niveles esta activo, siempre usar capital fijo
        if self.config.get("disable_niveles", False):
            amount = base
        elif self.current_sublevel > 0 and self.previous_profits:
            profit_pct = self.config.get("sublevel_profit_pct", 35) / 100.0
            last_profit = self.previous_profits[-1]
            amount = base + (last_profit * profit_pct)
        else:
            amount = base
        amount = round(amount, 2)
        amount = max(amount, 1.0)
        return amount

    # ============================================================
    # SISTEMA DE NIVELES
    # ============================================================

    def _advance_level(self, won):
        max_niveles = self.config.get("niveles", 3)
        if won:
            payout_pct = self._get_instrument_payout(self.current_instrument or "")
            if payout_pct <= 0:
                payout_pct = 86
            profit = self.last_trade_amount * (payout_pct / 100.0)
            self.previous_profits.append(profit)
            if self.current_sublevel >= max_niveles:
                self.log(f"[Niveles] WIN en {self._sublevel_text()} -> Ciclo completado! Reset a N1")
                self.current_sublevel = 0
                self.previous_profits = []
                self._switch_asset()
            else:
                old_text = self._sublevel_text()
                self.current_sublevel += 1
                new_text = self._sublevel_text()
                amount = self._get_trade_amount()
                profit_pct = self.config.get("sublevel_profit_pct", 35)
                self.log(f"[Niveles] WIN en {old_text} -> {new_text} (monto: ${amount:.2f}, {profit_pct}% profit)")
        else:
            if self.current_sublevel > 0:
                self.log(f"[Niveles] LOSS en {self._sublevel_text()} -> Reset a N1")
                self.current_sublevel = 0
                self.previous_profits = []
                self._switch_asset()
            else:
                self.log(f"[Niveles] LOSS en N1 -> Permanece en N1")
        self.status(f"Nivel: {self._sublevel_text()} | Profit: ${self.current_profit:.2f}")
        self.save_state()

    def _switch_asset(self):
        if self.current_instrument:
            if self.scanner:
                self.scanner.add_operated(self.current_instrument)
            self.operated_assets.add(self.current_instrument)
            self.log(f"[Engine] Cambiando de activo (era: {self.current_instrument})")
            self.current_instrument = None
            self.save_state()

    # ============================================================
    # VERIFICACION DE RESULTADO
    # ============================================================

    def _check_win(self, order_id, amount, expiration_min):
        wait_time = expiration_min * 60 + 5
        self.log(f"[Engine] Esperando {wait_time:.0f}s para resultado...")
        time.sleep(wait_time)
        try:
            result = self.api.check_win_v3(order_id)
            if result is not None:
                return result > 0, result
        except Exception as e:
            self.log(f"[Engine] check_win_v3 fallo: {e}")
        try:
            if self._ensure_connected():
                new_balance = self.api.get_balance()
                diff = new_balance - self.balance
                if abs(diff) > 0.01:
                    return diff > 0, diff
        except Exception:
            pass
        self.log("[Engine] No se pudo verificar resultado, asumiendo perdida")
        return False, -amount

    # ============================================================
    # EJECUCION DE OPERACION
    # ============================================================

    def _execute_trade(self, instrument_name, direction, amount):
        with self._lock:
            if self._trade_in_progress:
                self.log("[Engine] Ya hay una operacion en curso")
                return None, None
            self._trade_in_progress = True

        trade_time = datetime.now().strftime("%H:%M:%S")

        try:
            if not self._ensure_connected():
                self.log("[Engine] Sin conexion, no se puede operar")
                return False, 0

            try:
                all_actives = self.api.get_all_ACTIVES_OPCODE()
                if all_actives and instrument_name not in all_actives:
                    self.log(f"[Engine] {instrument_name} no disponible en ACTIVES")
                    return False, 0
            except Exception:
                pass

            if not self._check_payout_min(instrument_name):
                self.log(f"[Engine] {instrument_name} no cumple payout minimo")
                return False, 0

            level_info = self._sublevel_text()
            payout = self._get_instrument_payout(instrument_name)
            self.log(f"[Engine] Operando [{level_info}]: {direction.upper()} {instrument_name} | ${amount:.2f} | Payout: {payout}% | Exp: 1m")

            self.telegram.notify_trade_opened(
                instrument=instrument_name, direction=direction,
                amount=amount, level=self.current_level,
                sublevel=self.current_sublevel, payout=payout,
                trade_time=trade_time
            )

            check, order_id = self.api.buy(amount, instrument_name, direction, 1)

            if not check:
                self.log(f"[Engine] Orden rechazada: {order_id}")
                self.telegram.notify_error(f"Orden rechazada: {instrument_name} {direction.upper()} ${amount:.2f}")
                return False, 0

            self.last_trade_amount = amount
            self.total_trades += 1
            self.current_instrument = instrument_name

            self.trade_cb({
                "num": self.total_trades,
                "activo": instrument_name,
                "direccion": direction.upper(),
                "monto": amount,
                "resultado": "...",
                "profit": 0.0,
                "nivel": level_info,
                "hora": trade_time,
                "status": "open"
            })

            self.save_state()

            won, profit = self._check_win(order_id, amount, 1)

            if self._ensure_connected():
                try:
                    self.balance = self.api.get_balance()
                except Exception:
                    self.balance += profit
            self.current_profit = self.balance - self.initial_balance

            if won:
                self.total_wins += 1
                self.log(f"[Engine] WIN! Profit: +${profit:.2f} | Balance: ${self.balance:.2f}")
            else:
                self.total_losses += 1
                self.log(f"[Engine] LOSS. Perdida: -${abs(profit):.2f} | Balance: ${self.balance:.2f}")

            self.trade_cb({
                "num": self.total_trades,
                "activo": instrument_name,
                "direccion": direction.upper(),
                "monto": amount,
                "resultado": "WIN" if won else "LOSS",
                "profit": profit,
                "nivel": level_info,
                "hora": trade_time,
                "status": "closed"
            })

            self.telegram.notify_trade_result(
                instrument=instrument_name, direction=direction,
                won=won, profit=profit, amount=amount,
                balance=self.balance, level=self.current_level,
                sublevel=self.current_sublevel,
                total_trades=self.total_trades,
                total_wins=self.total_wins,
                total_losses=self.total_losses,
                current_profit=self.current_profit,
                trade_time=trade_time
            )

            self.save_state()
            return won, profit

        except Exception as e:
            self.log(f"[Engine] Error ejecutando operacion: {e}")
            self.telegram.notify_error(f"Error en operacion: {e}")
            self._ensure_connected()
            self.save_state()
            return False, 0
        finally:
            with self._lock:
                self._trade_in_progress = False

    # ============================================================
    # STOPS
    # ============================================================

    def _check_stops(self):
        profit = self.balance - self.initial_balance
        stop_win = self.config.get("stop_win", 7.0)
        stop_loss = self.config.get("stop_loss", 5.0)
        stop_loss_cap_pct = self.config.get("stop_loss_pct_balance", 15) / 100.0
        stop_loss_cap = self.balance * stop_loss_cap_pct
        effective_stop_loss = min(stop_loss, stop_loss_cap)

        # Max trades
        max_trades = self.config.get("max_trades", 0)
        if max_trades > 0 and self.total_trades >= max_trades:
            self.log(f"[Engine] Maximo de operaciones alcanzado ({self.total_trades}/{max_trades})")
            self._end_reason = "max_trades"
            self._stop_flag = True
            return True

        if profit >= stop_win:
            self.log(f"[Engine] STOP WIN alcanzado! Profit: ${profit:.2f} >= ${stop_win:.2f}")
            self.telegram.notify_stop_hit("win", profit, self.balance,
                                           self.total_trades, self.total_wins, self.total_losses)
            self._end_reason = "stopwin"
            self._stop_flag = True
            return True

        if profit <= -effective_stop_loss:
            self.log(f"[Engine] STOP LOSS alcanzado! Perdida: ${profit:.2f} >= ${effective_stop_loss:.2f}")
            self.telegram.notify_stop_hit("loss", profit, self.balance,
                                           self.total_trades, self.total_wins, self.total_losses)
            self._end_reason = "stoploss"
            self._stop_flag = True
            return True

        return False

    # ============================================================
    # LOOP PRINCIPAL
    # ============================================================

    def run(self):
        self.running = True
        self._stop_flag = False

        had_previous_state = self.load_state()

        if not had_previous_state:
            self.current_level = 1
            self.current_sublevel = 0
            self.total_trades = 0
            self.total_wins = 0
            self.total_losses = 0
            self.previous_profits = []
            self.last_trade_amount = 0.0
            self.operated_assets = set()
            if self.scanner:
                self.scanner.reset_operated()
            if self._ensure_connected():
                self.balance = self.api.get_balance()
                self.initial_balance = self.balance
        else:
            if self._ensure_connected():
                self.balance = self.api.get_balance()
                self.current_profit = self.balance - self.initial_balance
            if self.scanner:
                self.scanner.reset_operated()
                for asset in self.operated_assets:
                    self.scanner.add_operated(asset)

        niveles = self.config.get("niveles", 3)
        disable_niveles = self.config.get("disable_niveles", False)
        capital_op = self.config.get("capital_operacion", 2.50)
        stop_win = self.config.get("stop_win", 7.0)
        stop_loss = self.config.get("stop_loss", 5.0)
        sl_cap_pct = self.config.get("stop_loss_pct_balance", 15)
        payout_min = self.config.get("payout_min", 87)
        min_votes = self.config.get("min_strategy_votes", 7)
        min_quality = self.config.get("min_signal_quality", 88)
        max_trades = self.config.get("max_trades", 0)
        use_v3 = self.config.get("use_strategy_v3", True)
        use_v2 = self.config.get("use_strategy_v2", False) if not use_v3 else False

        if use_v3:
            strategy_label = "V3 Alto Winrate"
        elif use_v2:
            strategy_label = "V2 ADX+Calidad"
        else:
            strategy_label = "V1 Basica"

        self.log("[Engine] ========================================")
        self.log("[Engine]   SISTEMA OUHRIES V5 - INICIADO")
        niveles_text = "OFF (Capital fijo)" if disable_niveles else f"{niveles}"
        self.log(f"[Engine]   Niveles: {niveles_text} | Capital Op: ${capital_op}")
        self.log(f"[Engine]   Stop Win: ${stop_win} | Stop Loss: ${stop_loss} (cap {sl_cap_pct}% balance)")
        self.log(f"[Engine]   Payout: {payout_min}%+ | Expiracion: 1m")
        self.log(f"[Engine]   Estrategia: {strategy_label}")
        if use_v3:
            self.log(f"[Engine]   ADX >= 25 | Calidad >= {min_quality}% | Solo a favor de tendencia")
        elif use_v2:
            self.log(f"[Engine]   ADX >= 20 | Calidad >= {min_quality}%")
        self.log(f"[Engine]   Votos min: {min_votes} | Max trades: {max_trades or 'Sin limite'}")
        if not disable_niveles:
            self.log(f"[Engine]   Sub-nivel: {self.config.get('sublevel_profit_pct', 35)}% profit reinvertido")
        self.log(f"[Engine]   Telegram: {'ACTIVO' if self.config.get('telegram_enabled') else 'INACTIVO'}")
        if max_trades > 0:
            self.log(f"[Engine]   Operaciones limite: {max_trades}")
        if had_previous_state:
            self.log(f"[Engine]   ** Sesion recuperada **")
        self.log("[Engine] ========================================")

        self.telegram.notify_session_start(
            config=self.config, balance=self.balance,
            mode=self.config.get("account_mode", "PRACTICE"),
            had_previous=had_previous_state
        )

        while not self._stop_flag:
            try:
                with self._lock:
                    if self._trade_in_progress:
                        time.sleep(5)
                        continue

                if not self._ensure_connected():
                    self.log("[Engine] Sin conexion, reintentando en 10s...")
                    time.sleep(10)
                    continue

                if self._check_stops():
                    break

                strategy_label = "V3 Alto WR" if use_v3 else ("V2 ADX+Calidad" if use_v2 else "V1")
                self.log(f"[Engine] Escaneando ({strategy_label}, votos >= {min_votes}, payout >= {payout_min}%, calidad >= {min_quality}%)")

                instrument, direction = self.scanner.scan_best_signal(
                    min_votes=min_votes,
                    payout_min_func=self._check_payout_min
                )

                if not instrument or not direction:
                    self.log("[Engine] Sin senales. Esperando proxima vela...")
                    self._wait_for_next_candle()
                    continue

                self.log(f"[Engine] Senal encontrada: {instrument} {direction.upper()}")
                self._wait_for_candle_timing()

                if self._stop_flag:
                    break

                amount = self._get_trade_amount()
                self.current_instrument = instrument

                won, profit = self._execute_trade(instrument, direction, amount)

                if won is None:
                    continue

                self._advance_level(won)

                if self._check_stops():
                    break

                delay = random.uniform(
                    self.config.get("delay_between_ops_min", 20),
                    self.config.get("delay_between_ops_max", 60)
                )
                self.log(f"[Engine] Esperando {delay:.0f}s antes de proxima operacion...")
                time.sleep(delay)

            except Exception as e:
                self.log(f"[Engine] Error en loop principal: {e}")
                self.telegram.notify_error(f"Error en loop: {e}")
                self.save_state()
                time.sleep(random.uniform(5, 15))

        self.running = False
        final_profit = self.balance - self.initial_balance
        win_rate = (self.total_wins / self.total_trades * 100) if self.total_trades > 0 else 0

        # Determinar razon de finalizacion si no fue seteada por _check_stops
        if self._end_reason is None:
            if self._stop_flag:
                self._end_reason = "manual"
            else:
                self._end_reason = "error"

        reason_labels = {
            "stopwin": "Stop Win",
            "stoploss": "Stop Loss",
            "max_trades": "Max Operaciones",
            "manual": "Detenido Manualmente",
            "error": "Error",
        }
        reason_label = reason_labels.get(self._end_reason, "Desconocido")

        self.log("[Engine] ========================================")
        self.log("[Engine]   SESION FINALIZADA")
        self.log(f"[Engine]   Razon: {reason_label}")
        self.log(f"[Engine]   Total operaciones: {self.total_trades}")
        self.log(f"[Engine]   Wins: {self.total_wins} | Losses: {self.total_losses}")
        self.log(f"[Engine]   Win rate: {win_rate:.1f}%")
        self.log(f"[Engine]   Profit final: ${final_profit:.2f}")
        self.log("[Engine] ========================================")
        self.status("Sesion finalizada")

        self.telegram.notify_session_end(
            total_trades=self.total_trades,
            total_wins=self.total_wins,
            total_losses=self.total_losses,
            balance=self.balance,
            initial_balance=self.initial_balance,
            current_profit=final_profit,
            end_reason=self._end_reason,
            max_trades_config=self.config.get("max_trades", 0)
        )
        self.telegram.stop()
        self.clear_state()

        # Notificar a la GUI con resumen completo
        if self._session_end_callback:
            try:
                summary = {
                    "reason": self._end_reason,
                    "reason_label": reason_label,
                    "total_trades": self.total_trades,
                    "total_wins": self.total_wins,
                    "total_losses": self.total_losses,
                    "win_rate": win_rate,
                    "profit": final_profit,
                    "balance": self.balance,
                    "initial_balance": self.initial_balance,
                }
                self._session_end_callback(summary)
            except Exception as e:
                self.log(f"[Engine] Error en session_end_callback: {e}")

    def _wait_for_next_candle(self):
        now = time.time()
        seconds_into_candle = now % 60
        wait = 60 - seconds_into_candle + 1
        self.log(f"[Timing] Esperando {wait:.0f}s hasta proxima vela...")
        while wait > 0 and not self._stop_flag:
            chunk = min(wait, 3)
            time.sleep(chunk)
            wait -= chunk

    def stop(self):
        if self._end_reason is None:
            self._end_reason = "manual"
        self._stop_flag = True
        if self.scanner:
            self.scanner.stop()
        self.telegram.stop()
        self.save_state()
        self.log("[Engine] Deteniendo sesion...")

    def get_stats(self):
        profit = self.balance - self.initial_balance
        win_rate = (self.total_wins / self.total_trades * 100) if self.total_trades > 0 else 0
        return {
            "balance": self.balance,
            "initial_balance": self.initial_balance,
            "profit": profit,
            "total_trades": self.total_trades,
            "total_wins": self.total_wins,
            "total_losses": self.total_losses,
            "win_rate": win_rate,
            "current_level": self.current_level,
            "current_sublevel": self.current_sublevel,
            "current_instrument": self.current_instrument or "Ninguno",
            "running": self.running,
            "trade_in_progress": self._trade_in_progress,
            "sublevel_text": self._sublevel_text(),
        }
