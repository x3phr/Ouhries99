"""
Sistema Ouhries V5 - Servidor Web Profesional
FastAPI backend con REST + WebSocket para interfaz web premium.
Sirve la interfaz HTML/CSS/JS con todos los efectos visuales.
Funciona en Windows, Linux y macOS.
"""
import os
import sys
import json
import asyncio
import threading
import time
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

from config import load_config, save_config, DEFAULT_CONFIG

# Lazy import engine to avoid startup errors if dependencies are missing
_TradingEngine = None

def _get_engine_class():
    global _TradingEngine
    if _TradingEngine is None:
        from engine import TradingEngine
        _TradingEngine = TradingEngine
    return _TradingEngine


app = FastAPI(title="Sistema Ouhries V5")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================
# GLOBAL STATE
# ============================================================
engine = None
engine_thread = None
connected = False
trading_active = False
paused = False
active_ws = []
recent_trades = []
MAX_RECENT_TRADES = 50
current_config = load_config()
_log_lines = []
MAX_LOG_LINES = 200
_radar_state = {"asset": "", "idx": 0, "total": 0, "text": "Inactivo", "color": "#6e7681"}
_event_loop = None


# ============================================================
# SAFE ASYNC BROADCAST (from any thread)
# ============================================================
def _schedule_broadcast(data: dict):
    """Thread-safe way to schedule a broadcast on the event loop."""
    global _event_loop
    if _event_loop is None:
        return
    try:
        asyncio.run_coroutine_threadsafe(_broadcast(data), _event_loop)
    except Exception:
        pass


async def _broadcast(data: dict):
    """Send data to all connected WebSocket clients."""
    dead = []
    for ws in active_ws:
        try:
            await ws.send_json(data)
        except Exception:
            dead.append(ws)
    for ws in dead:
        if ws in active_ws:
            active_ws.remove(ws)


# ============================================================
# CALLBACKS (called from engine thread)
# ============================================================
def _ws_log(msg):
    _log_lines.append(f"[{time.strftime('%H:%M:%S')}] {msg}")
    if len(_log_lines) > MAX_LOG_LINES:
        _log_lines.pop(0)
    _schedule_broadcast({"type": "log", "message": msg})


def _ws_status(msg):
    _schedule_broadcast({"type": "status", "message": msg})


def _ws_radar(asset, idx, total):
    global _radar_state
    if idx == 0 and total == 0:
        _radar_state = {"asset": "", "idx": 0, "total": 0, "text": "Escaneo completo", "color": "#448aff"}
    else:
        _radar_state = {"asset": asset, "idx": idx, "total": total,
                        "text": f"Escaneando {asset} ({idx}/{total})", "color": "#00e676"}
    _schedule_broadcast({"type": "radar", **_radar_state})


def _ws_trade(trade_info):
    recent_trades.append(trade_info)
    if len(recent_trades) > MAX_RECENT_TRADES:
        recent_trades.pop(0)
    _schedule_broadcast({"type": "trade", **trade_info})


# ============================================================
# WEBSOCKET ENDPOINT
# ============================================================
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_ws.append(websocket)
    try:
        await _send_initial_state(websocket)
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        if websocket in active_ws:
            active_ws.remove(websocket)


async def _send_initial_state(ws: WebSocket):
    """Send current state to a newly connected client."""
    if engine:
        stats = engine.get_stats()
        await ws.send_json({"type": "stats", **stats})
    else:
        await ws.send_json({
            "type": "stats",
            "balance": 0, "initial_balance": 0, "profit": 0,
            "total_trades": 0, "total_wins": 0, "total_losses": 0,
            "win_rate": 0, "current_level": 1, "current_sublevel": 0,
            "current_instrument": "Ninguno", "running": False,
            "trade_in_progress": False, "sublevel_text": "N1",
        })
    await ws.send_json({"type": "config", **current_config})
    await ws.send_json({"type": "connected", "value": connected})
    await ws.send_json({"type": "trading_active", "value": trading_active})
    await ws.send_json({"type": "radar", **_radar_state})
    # Send last 20 trades
    for trade in recent_trades[-20:]:
        await ws.send_json({"type": "trade", **trade})


# ============================================================
# REST ENDPOINTS
# ============================================================
@app.get("/")
async def root():
    static_dir = Path(__file__).parent / "static"
    return FileResponse(static_dir / "index.html")


@app.get("/api/config")
async def get_config():
    return JSONResponse(current_config)


@app.post("/api/config/update")
async def update_config_value(data: dict):
    global current_config
    for key, value in data.items():
        if key in DEFAULT_CONFIG:
            current_config[key] = value
    save_config(current_config)
    await _broadcast({"type": "config", **current_config})
    return JSONResponse({"ok": True})


@app.post("/api/connect")
async def api_connect():
    global engine, connected

    if connected and engine:
        return JSONResponse({"ok": True, "message": "Ya conectado"})

    def _connect():
        global engine, connected
        try:
            TradingEngine = _get_engine_class()
            e = TradingEngine(
                current_config,
                log_callback=_ws_log,
                status_callback=_ws_status,
                radar_callback=_ws_radar,
                trade_callback=_ws_trade,
            )
            if e.connect():
                engine = e
                connected = True
                _schedule_broadcast({"type": "connected", "value": True})
                stats = e.get_stats()
                _schedule_broadcast({"type": "stats", **stats})
                _ws_log("[Server] Conexion exitosa a IQ Option")
            else:
                connected = False
                _schedule_broadcast({"type": "connected", "value": False})
                _ws_log("[Server] Error conectando a IQ Option")
        except Exception as ex:
            connected = False
            _schedule_broadcast({"type": "connected", "value": False})
            _ws_log(f"[Server] Excepcion conectando: {ex}")

    t = threading.Thread(target=_connect, daemon=True)
    t.start()
    return JSONResponse({"ok": True, "message": "Conectando..."})


@app.post("/api/disconnect")
async def api_disconnect():
    global engine, connected, trading_active
    trading_active = False
    if engine:
        engine.stop()
    connected = False
    engine = None
    await _broadcast({"type": "connected", "value": False})
    await _broadcast({"type": "trading_active", "value": False})
    return JSONResponse({"ok": True})


@app.post("/api/start")
async def api_start():
    global engine, engine_thread, trading_active, paused

    if not connected or not engine:
        return JSONResponse({"ok": False, "message": "No conectado. Conecta primero."})

    trading_active = True
    paused = False

    # Set session end callback
    def _on_session_end(summary):
        global trading_active
        trading_active = False
        _schedule_broadcast({"type": "session_end", **summary})
        _schedule_broadcast({"type": "trading_active", "value": False})

    engine._session_end_callback = _on_session_end

    def _run():
        try:
            engine.run()
        except Exception as ex:
            _ws_log(f"[Server] Error en engine.run(): {ex}")
            global trading_active
            trading_active = False
            _schedule_broadcast({"type": "trading_active", "value": False})

    engine_thread = threading.Thread(target=_run, daemon=True)
    engine_thread.start()

    await _broadcast({"type": "trading_active", "value": True})
    return JSONResponse({"ok": True})


@app.post("/api/pause")
async def api_pause():
    global paused, trading_active
    paused = not paused
    await _broadcast({"type": "paused", "value": paused})
    return JSONResponse({"ok": True, "paused": paused})


@app.post("/api/stop")
async def api_stop():
    global engine, trading_active, paused
    trading_active = False
    paused = False
    if engine:
        engine.stop()
    await _broadcast({"type": "trading_active", "value": False})
    await _broadcast({"type": "paused", "value": False})
    return JSONResponse({"ok": True})


@app.post("/api/strategy/{version}")
async def api_set_strategy(version: str):
    global current_config
    if version == "v3":
        current_config["use_strategy_v3"] = True
        current_config["use_strategy_v2"] = False
    elif version == "v2":
        current_config["use_strategy_v3"] = False
        current_config["use_strategy_v2"] = True
    else:
        current_config["use_strategy_v3"] = False
        current_config["use_strategy_v2"] = False
    save_config(current_config)
    await _broadcast({"type": "config", **current_config})
    return JSONResponse({"ok": True})


@app.post("/api/switch-account/{mode}")
async def api_switch_account(mode: str):
    global engine
    if engine:
        def _switch():
            engine.switch_account(mode)
            stats = engine.get_stats()
            _schedule_broadcast({"type": "stats", **stats})
        t = threading.Thread(target=_switch, daemon=True)
        t.start()
    current_config["account_mode"] = mode
    save_config(current_config)
    return JSONResponse({"ok": True})


@app.get("/api/stats")
async def api_stats():
    if engine:
        return JSONResponse(engine.get_stats())
    return JSONResponse({
        "balance": 0, "initial_balance": 0, "profit": 0,
        "total_trades": 0, "total_wins": 0, "total_losses": 0,
        "win_rate": 0, "current_level": 1, "current_sublevel": 0,
        "current_instrument": "Ninguno", "running": False,
        "trade_in_progress": False, "sublevel_text": "N1",
    })


@app.get("/api/trades")
async def api_trades():
    return JSONResponse(recent_trades[-MAX_RECENT_TRADES:])


@app.get("/api/logs")
async def api_logs():
    return JSONResponse(_log_lines[-100:])


# ============================================================
# STATS PUSHER (periodic WebSocket push)
# ============================================================
async def stats_pusher():
    """Periodically push stats via WebSocket when engine is running."""
    while True:
        await asyncio.sleep(2)
        if engine and trading_active:
            try:
                stats = engine.get_stats()
                await _broadcast({"type": "stats", **stats})
            except Exception:
                pass


# ============================================================
# MAIN
# ============================================================
def main():
    global _event_loop, current_config

    _event_loop = asyncio.new_event_loop()
    asyncio.set_event_loop(_event_loop)

    # Load config
    current_config = load_config()

    # Mount static files
    static_dir = Path(__file__).parent / "static"
    if static_dir.exists():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

    # Start stats pusher
    _event_loop.create_task(stats_pusher())

    # Support port from environment variable (for Electron)
    port = int(os.environ.get("OUHRIES_PORT", 8585))
    host = os.environ.get("OUHRIES_HOST", "0.0.0.0")

    config = uvicorn.Config(app, host=host, port=port, log_level="warning")
    server = uvicorn.Server(config)

    print("")
    print("=" * 50)
    print("  SISTEMA OUHRIES V5 - SERVIDOR WEB")
    print("=" * 50)
    print(f"  Interfaz: http://localhost:{port}")
    print("=" * 50)
    print("")

    _event_loop.run_until_complete(server.serve())


if __name__ == "__main__":
    main()
