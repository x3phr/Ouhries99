# Solo dos estrategias disponibles:
# - OTCEspecializada V1 (principal): 7 fuentes + meta-learning (strategies_otc)
# - V2.1 Mejorada (backup): 31 patrones + 5 indicadores (strategies_v2)
from strategies.strategies_otc import analyze_candles_otc, STRONG_ONLY_PATTERNS, meta_learner
from strategies.strategies_v2 import analyze_candles_v2
