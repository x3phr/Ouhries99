"""
Sistema Ouhries V5 - Estrategia OTCEspecializada V1

Optimizada para mercados OTC con 7 fuentes de senal + meta-aprendizaje adaptativo:

 1. Patrones de velas FUERTES (8 patrones, peso adaptativo base 0.5)
 2. Indicadores OTC (Bollinger + Stochastic, peso adaptativo base 2.0)
 3. Ciclos OTC - Autocorrelacion multi-lag (peso adaptativo base 3.0)
 4. Posicion en rango + Regimen de mercado (peso adaptativo base 2.5)
 5. Direccion consecutiva + Simetria algoritmica (peso adaptativo base 2.0)
 6. Secuencia historica - Pattern matching (peso adaptativo base 2.5)
 7. Micro-estructura de vela (peso adaptativo base 1.5)

 + Meta-aprendizaje: ajusta pesos segun aciertos recientes
 + Confluencia sinergica: multiplicadores por combinaciones
 + Confluencia minima: 4 de 7 (57%), 5/7 en regimen impulso

Formato de velas: [open, high, low, close] (arrays, NO dicts)
Patrones retornan: 1 (alcista), -1 (bajista), 0 (neutral)
Estrategia retorna: dict con 'direction', 'quality', 'votes_detail' o None
"""

import numpy as np
import threading

# ============================================================
# PATRONES FUERTES (8 - los mas confiables para OTC)
# ============================================================

def _body(o, c):
    return abs(c - o)

def _upper_shadow(o, c, h):
    return h - max(o, c)

def _lower_shadow(o, c, l):
    return min(o, c) - l

def _is_green(o, c):
    return c > o

def _is_red(o, c):
    return c < o

def _avg_body(candles, n=5):
    bodies = [abs(c[3] - c[0]) for c in candles[-n:]]
    return np.mean(bodies) if bodies else 0.0001


def bullish_engulfing(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if _is_red(prev[0], prev[3]) and _is_green(curr[0], curr[3]):
        if curr[0] <= prev[3] and curr[3] >= prev[0]: return 1
    return 0

def morning_star(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_red(c1[0], c1[3]) and _body(c2[0], c2[3]) < _body(c1[0], c1[3]) * 0.3:
        if _is_green(c3[0], c3[3]) and c3[3] > (c1[0] + c1[3]) / 2: return 1
    return 0

def three_white_soldiers(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if all(_is_green(c[0], c[3]) for c in [c1, c2, c3]):
        if c1[3] < c2[3] < c3[3] and c2[0] > c1[0] and c3[0] > c2[0]: return 1
    return 0

def piercing_line(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if _is_red(prev[0], prev[3]) and _is_green(curr[0], curr[3]):
        mid = (prev[0] + prev[3]) / 2
        if curr[0] < prev[3] and curr[3] > mid: return 1
    return 0

def bearish_engulfing(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if _is_green(prev[0], prev[3]) and _is_red(curr[0], curr[3]):
        if curr[0] >= prev[3] and curr[3] <= prev[0]: return -1
    return 0

def evening_star(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_green(c1[0], c1[3]) and _body(c2[0], c2[3]) < _body(c1[0], c1[3]) * 0.3:
        if _is_red(c3[0], c3[3]) and c3[3] < (c1[0] + c1[3]) / 2: return -1
    return 0

def three_black_crows(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if all(_is_red(c[0], c[3]) for c in [c1, c2, c3]):
        if c1[3] > c2[3] > c3[3] and c2[0] < c1[0] and c3[0] < c2[0]: return -1
    return 0

def dark_cloud_cover(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if _is_green(prev[0], prev[3]) and _is_red(curr[0], curr[3]):
        mid = (prev[0] + prev[3]) / 2
        if curr[0] > prev[3] and curr[3] < mid: return -1
    return 0


STRONG_ONLY_PATTERNS = [
    bullish_engulfing, morning_star, three_white_soldiers, piercing_line,
    bearish_engulfing, evening_star, three_black_crows, dark_cloud_cover,
]


# ============================================================
# INDICADORES (Bollinger + Stochastic unicamente)
# ============================================================

def calc_bollinger(closes, period=20, std_mult=2):
    if len(closes) < period: return None, None, None
    slice_c = closes[-period:]
    middle = np.mean(slice_c)
    std = np.std(slice_c)
    return middle - std_mult * std, middle, middle + std_mult * std

def calc_stochastic(candles, period=14):
    if len(candles) < period: return 50
    recent = candles[-period:]
    highs = [c[1] for c in recent]; lows = [c[2] for c in recent]; closes = [c[3] for c in recent]
    highest = max(highs); lowest = min(lows)
    if highest == lowest: return 50
    return ((closes[-1] - lowest) / (highest - lowest)) * 100


# ============================================================
# HELPERS OTC V1
# ============================================================

def _calc_multilag_autocorrelation(closes, max_lag=3):
    if len(closes) < 30: return 0, 0.0, 0
    returns = np.diff(closes[-40:])
    if len(returns) < 5: return 0, 0.0, 0
    returns_mean = np.mean(returns); returns_centered = returns - returns_mean
    variance = np.var(returns)
    if variance < 1e-10: return 0, 0.0, 0

    best_autocorr = 0; best_lag = 0
    for lag in range(1, max_lag + 1):
        if len(returns_centered) <= lag: continue
        n = len(returns_centered) - lag
        autocorr = np.sum(returns_centered[:n] * returns_centered[lag:lag+n]) / (variance * n)
        if abs(autocorr) > abs(best_autocorr):
            best_autocorr = autocorr; best_lag = lag

    last_return = closes[-1] - closes[-2]
    if best_autocorr < -0.15:
        strength = min(abs(best_autocorr) * 3, 1.0)
        if best_lag == 1:
            return (-1 if last_return > 0 else 1), strength, best_lag
        else:
            if len(closes) >= best_lag + 1:
                lagged_return = closes[-best_lag] - closes[-best_lag - 1]
                return (-1 if lagged_return > 0 else 1), strength * 0.9, best_lag
            return (-1 if last_return > 0 else 1), strength, best_lag
    elif best_autocorr > 0.15:
        strength = min(best_autocorr * 3, 1.0)
        return (1 if last_return > 0 else -1), strength, best_lag
    return 0, 0.0, best_lag


def _detect_market_regime(candles, period=20):
    if len(candles) < period: return 'rango', 0.5
    recent = candles[-period:]
    range_high = max(c[1] for c in recent); range_low = min(c[2] for c in recent)
    price_range = range_high - range_low
    if price_range <= 0: return 'rango', 0.5

    mid = (range_high + range_low) / 2
    half_directions = [1 if c[3] > mid else -1 for c in recent]
    max_streak = 1; current_streak = 1
    for i in range(1, len(half_directions)):
        if half_directions[i] == half_directions[i-1]:
            current_streak += 1; max_streak = max(max_streak, current_streak)
        else: current_streak = 1

    closes = [c[3] for c in recent]
    directional_move = abs(closes[-1] - closes[0])
    directional_ratio = directional_move / price_range if price_range > 0 else 0

    if max_streak >= 7 or directional_ratio > 0.7:
        return 'impulso', min(max_streak / 10.0, 1.0)
    elif max_streak <= 4 and directional_ratio < 0.4: return 'rango', 0.8
    return 'rango', 0.5


def _calc_direction_stats(candles):
    if len(candles) < 10: return 0, 0.0
    directions = [1 if c[3] > c[0] else -1 for c in candles[-15:]]
    last_dir = directions[-1]; consec = 1
    for i in range(len(directions) - 2, -1, -1):
        if directions[i] == last_dir: consec += 1
        else: break
    if consec >= 4: return -last_dir, 0.9
    elif consec == 3: return -last_dir, 0.7
    elif consec == 2: return -last_dir, 0.4
    return 0, 0.0


def _detect_symmetry(candles, lookback=10):
    if len(candles) < lookback: return 0, 0.0
    dirs = [1 if c[3] > c[0] else -1 for c in candles[-lookback:]]
    alternating = sum(1 for i in range(1, len(dirs)) if dirs[i] != dirs[i-1])
    alt_ratio = alternating / (len(dirs) - 1) if len(dirs) > 1 else 0

    if alt_ratio >= 0.75 and len(dirs) >= 6:
        return -dirs[-1], min(alt_ratio * 1.1, 0.9)

    pairs_consistent = 0
    for i in range(0, len(dirs) - 3, 2):
        if dirs[i] == dirs[i+1] and dirs[i+2] == dirs[i+3] and dirs[i] != dirs[i+2]:
            pairs_consistent += 1

    if pairs_consistent >= 2 and len(dirs) >= 6:
        if len(dirs) >= 2 and dirs[-1] == dirs[-2]: return -dirs[-1], 0.7
        elif len(dirs) >= 2 and dirs[-1] != dirs[-2]: return dirs[-1], 0.5

    last_dir = dirs[-1]; block_len = 1
    for i in range(len(dirs) - 2, -1, -1):
        if dirs[i] == last_dir: block_len += 1
        else: break
    if block_len >= 3: return -last_dir, 0.6 + min(block_len * 0.05, 0.3)
    return 0, 0.0


def _calc_range_position_signal(candles, period=50):
    if len(candles) < 10: return 0, 0.0
    p = min(period, len(candles)); recent = candles[-p:]
    highs = [c[1] for c in recent]; lows = [c[2] for c in recent]; current = candles[-1][3]
    range_high = max(highs); range_low = min(lows); price_range = range_high - range_low
    if price_range <= 0: return 0, 0.0
    position = (current - range_low) / price_range
    if position < 0.25: return 1, 0.9
    elif position < 0.35: return 1, 0.5
    elif position < 0.65: return 0, 0.0
    elif position < 0.75: return -1, 0.5
    return -1, 0.9


def _calc_sequence_match(candles, lookback=5):
    if len(candles) < lookback * 3: return 0, 0.0
    dirs = [1 if c[3] > c[0] else -1 for c in candles]
    current_seq = tuple(dirs[-lookback:])
    match_call = 0; match_put = 0
    for i in range(len(dirs) - lookback - 1):
        seq = tuple(dirs[i:i+lookback])
        if seq == current_seq:
            next_dir = dirs[i + lookback] if (i + lookback) < len(dirs) else 0
            if next_dir == 1: match_call += 1
            elif next_dir == -1: match_put += 1
    total = match_call + match_put
    if total < 3: return 0, 0.0
    call_pct = match_call / total
    if call_pct >= 0.65: return 1, min((call_pct - 0.5) * 2, 1.0)
    elif call_pct <= 0.35: return -1, min((0.5 - call_pct) * 2, 1.0)
    return 0, 0.0


def _calc_microstructure(candles):
    if len(candles) < 2: return 0, 0.0
    last = candles[-1]; body_range = last[1] - last[2]
    if body_range <= 0: return 0, 0.0
    close_position = (last[3] - last[2]) / body_range
    if close_position >= 0.8: return -1, (close_position - 0.5) * 2
    elif close_position <= 0.2: return 1, (0.5 - close_position) * 2
    return 0, 0.0


# ============================================================
# META-APRENDIZAJE ADAPTATIVO
# ============================================================

class OTCMetaLearner:
    BASE_WEIGHTS = {
        'patterns': 0.5, 'indicators': 2.0, 'cycles': 3.0,
        'range_regime': 2.5, 'direction_symmetry': 2.0,
        'sequence': 2.5, 'microstructure': 1.5,
    }
    MIN_WEIGHT = 0.2; MAX_WEIGHT = 5.0

    def __init__(self):
        self.weights = dict(self.BASE_WEIGHTS)
        self.history = []
        self.last_analysis = None
        self._lock = threading.Lock()

    def get_weights(self):
        with self._lock: return dict(self.weights)

    def store_analysis(self, direction, source_directions):
        with self._lock:
            self.last_analysis = {'direction': direction, 'source_directions': dict(source_directions)}

    def record_result(self, actual_direction):
        with self._lock:
            if not self.last_analysis: return
            self.history.append({
                'predicted': self.last_analysis['direction'],
                'actual': actual_direction,
                'sources': dict(self.last_analysis['source_directions']),
            })
            if len(self.history) > 50: self.history = self.history[-30:]
            self._adapt_weights()
            self.last_analysis = None

    def _adapt_weights(self):
        if len(self.history) < 5: return
        recent = self.history[-20:]
        source_stats = {}
        for record in recent:
            for source, source_dir in record['sources'].items():
                if source not in source_stats: source_stats[source] = {'correct': 0, 'total': 0}
                source_stats[source]['total'] += 1
                if source_dir == record['actual']: source_stats[source]['correct'] += 1
        for source, stats in source_stats.items():
            if stats['total'] >= 3 and source in self.weights:
                accuracy = stats['correct'] / stats['total']
                base = self.BASE_WEIGHTS.get(source, 1.0)
                if accuracy > 0.65:
                    boost = 1.0 + (accuracy - 0.5) * 0.8
                    self.weights[source] = min(base * boost, self.MAX_WEIGHT)
                elif accuracy < 0.35:
                    penalty = 0.5 + accuracy
                    self.weights[source] = max(base * penalty, self.MIN_WEIGHT)
                else:
                    self.weights[source] = base

    def get_stats(self):
        with self._lock:
            return {'weights': dict(self.weights), 'history_size': len(self.history),
                    'has_pending': self.last_analysis is not None}

meta_learner = OTCMetaLearner()


# ============================================================
# CONFLUENCIA SINERGICA
# ============================================================

SYNERGIC_COMBOS = {
    frozenset(['cycles', 'range_regime', 'direction_symmetry']): 1.5,
    frozenset(['sequence', 'direction_symmetry']): 1.3,
    frozenset(['cycles', 'range_regime']): 1.25,
}


# ============================================================
# ESTRATEGIA OTCEspecializada V1 - Analisis principal
# ============================================================

def analyze_candles_otc(candles, min_votes=2):
    """
    Analisis OTCEspecializada V1 - 7 fuentes + meta-aprendizaje.
    Retorna: dict con 'direction', 'quality', 'votes_detail' o None
    (compatible con el formato de V2/V3 usado por el scanner)
    """
    if len(candles) < 10: return None
    closes = np.array([c[3] for c in candles])
    weights = meta_learner.get_weights()

    detail = {
        "patterns_call": 0, "patterns_put": 0,
        "indicators_call": 0, "indicators_put": 0,
        "trend": "none", "adx": 0, "quality": 0,
        "filters_passed": [], "filters_failed": [],
    }

    # Fuente 1: Patrones FUERTES
    pattern_call = 0.0; pattern_put = 0.0
    for pattern_fn in STRONG_ONLY_PATTERNS:
        try:
            result = pattern_fn(candles)
            if result == 1: pattern_call += weights['patterns']; detail["patterns_call"] += 1
            elif result == -1: pattern_put += weights['patterns']; detail["patterns_put"] += 1
        except: continue

    # Fuente 2: Indicadores OTC (Bollinger + Stochastic)
    ind_call = 0.0; ind_put = 0.0; ind_dir = 0
    try:
        lower, middle, upper = calc_bollinger(closes)
        if lower is not None:
            if closes[-1] <= lower: ind_call += weights['indicators']; ind_dir = 1; detail["indicators_call"] += 1
            elif closes[-1] >= upper: ind_put += weights['indicators']; ind_dir = -1; detail["indicators_put"] += 1
    except: pass
    try:
        stoch = calc_stochastic(candles)
        if stoch < 20: ind_call += weights['indicators']; ind_dir = ind_dir or 1; detail["indicators_call"] += 1
        elif stoch > 80: ind_put += weights['indicators']; ind_dir = ind_dir or -1; detail["indicators_put"] += 1
    except: pass

    # Fuente 3: Ciclos OTC - Autocorrelacion multi-lag
    cycle_dir, cycle_strength, best_lag = _calc_multilag_autocorrelation(closes)
    cycle_call = weights['cycles'] * cycle_strength if cycle_dir == 1 else 0.0
    cycle_put = weights['cycles'] * cycle_strength if cycle_dir == -1 else 0.0

    # Fuente 4: Posicion en rango + Regimen
    range_dir, range_strength = _calc_range_position_signal(candles)
    regime, regime_strength = _detect_market_regime(candles)
    range_regime_call = 0.0; range_regime_put = 0.0; range_regime_dir = 0
    if regime == 'rango':
        range_regime_call = weights['range_regime'] * range_strength if range_dir == 1 else 0.0
        range_regime_put = weights['range_regime'] * range_strength if range_dir == -1 else 0.0
        range_regime_dir = range_dir
        detail["trend"] = "rango"
    else:
        range_regime_call = weights['range_regime'] * range_strength * 0.3 if range_dir == 1 else 0.0
        range_regime_put = weights['range_regime'] * range_strength * 0.3 if range_dir == -1 else 0.0
        range_regime_dir = range_dir
        detail["trend"] = "impulso"

    # Fuente 5: Direccion + Simetria
    stats_dir, stats_conf = _calc_direction_stats(candles)
    sym_dir, sym_conf = _detect_symmetry(candles)
    dir_sym_dir = 0; dir_sym_conf = 0.0
    if stats_dir != 0 and sym_dir != 0 and stats_dir == sym_dir:
        dir_sym_dir = stats_dir; dir_sym_conf = max(stats_conf, sym_conf) * 1.2
    elif stats_dir != 0: dir_sym_dir = stats_dir; dir_sym_conf = stats_conf
    elif sym_dir != 0: dir_sym_dir = sym_dir; dir_sym_conf = sym_conf
    dir_sym_call = weights['direction_symmetry'] * dir_sym_conf if dir_sym_dir == 1 else 0.0
    dir_sym_put = weights['direction_symmetry'] * dir_sym_conf if dir_sym_dir == -1 else 0.0

    # Fuente 6: Secuencia historica
    seq_dir, seq_conf = _calc_sequence_match(candles, lookback=5)
    seq_call = weights['sequence'] * seq_conf if seq_dir == 1 else 0.0
    seq_put = weights['sequence'] * seq_conf if seq_dir == -1 else 0.0

    # Fuente 7: Micro-estructura
    micro_dir, micro_conf = _calc_microstructure(candles)
    micro_call = weights['microstructure'] * micro_conf if micro_dir == 1 else 0.0
    micro_put = weights['microstructure'] * micro_conf if micro_dir == -1 else 0.0

    # Votos ponderados
    total_call = pattern_call + ind_call + cycle_call + range_regime_call + dir_sym_call + seq_call + micro_call
    total_put = pattern_put + ind_put + cycle_put + range_regime_put + dir_sym_put + seq_put + micro_put

    # Confluencia
    sources_call = 0; sources_put = 0; source_directions = {}
    if pattern_call > pattern_put: sources_call += 1; source_directions['patterns'] = 'call'
    elif pattern_put > pattern_call: sources_put += 1; source_directions['patterns'] = 'put'
    if ind_call > ind_put: sources_call += 1; source_directions['indicators'] = 'call'
    elif ind_put > ind_call: sources_put += 1; source_directions['indicators'] = 'put'
    if cycle_dir == 1: sources_call += 1; source_directions['cycles'] = 'call'
    elif cycle_dir == -1: sources_put += 1; source_directions['cycles'] = 'put'
    if range_regime_dir == 1: sources_call += 1; source_directions['range_regime'] = 'call'
    elif range_regime_dir == -1: sources_put += 1; source_directions['range_regime'] = 'put'
    if dir_sym_dir == 1: sources_call += 1; source_directions['direction_symmetry'] = 'call'
    elif dir_sym_dir == -1: sources_put += 1; source_directions['direction_symmetry'] = 'put'
    if seq_dir == 1: sources_call += 1; source_directions['sequence'] = 'call'
    elif seq_dir == -1: sources_put += 1; source_directions['sequence'] = 'put'
    if micro_dir == 1: sources_call += 1; source_directions['microstructure'] = 'call'
    elif micro_dir == -1: sources_put += 1; source_directions['microstructure'] = 'put'

    # Sinergia
    synergic_multiplier = 1.0
    for combo, mult in SYNERGIC_COMBOS.items():
        if combo.issubset(source_directions.keys()):
            combo_dirs = set(source_directions[s] for s in combo if s in source_directions)
            if len(combo_dirs) == 1: synergic_multiplier = max(synergic_multiplier, mult)

    if total_call > total_put: total_call *= synergic_multiplier
    elif total_put > total_call: total_put *= synergic_multiplier

    # Confluencia minima
    min_confluence = max(4, min_votes)
    if regime == 'impulso': min_confluence = max(min_confluence, 5)
    weighted_threshold = min_votes * 1.5

    direction = None
    signal_votes = 0
    against_votes = 0
    if total_call > total_put and total_call >= weighted_threshold and sources_call >= min_confluence:
        direction = 'call'
        signal_votes = sources_call
        against_votes = sources_put
    elif total_put > total_call and total_put >= weighted_threshold and sources_put >= min_confluence:
        direction = 'put'
        signal_votes = sources_put
        against_votes = sources_call

    if not direction:
        return None

    # Store for meta-learning
    meta_learner.store_analysis(direction, source_directions)

    # Calcular calidad (0-100)
    total_sources = signal_votes + against_votes
    signal_strength = signal_votes / total_sources if total_sources > 0 else 0

    quality = min(100, int(
        signal_strength * 45 +
        (signal_votes - against_votes) * 5 +
        min(sources_call + sources_put, 7) / 7.0 * 20 +
        (1 if regime == 'rango' else 0.5) * 10 +
        synergic_multiplier * 5
    ))

    detail["quality"] = quality
    detail["votes_call"] = total_call
    detail["votes_put"] = total_put
    detail["signal_strength"] = signal_strength
    detail["filters_passed"].append(f"OTC V1 confluencia: {signal_votes}/{7} fuentes")
    detail["filters_passed"].append(f"Regimen: {regime}")
    detail["filters_passed"].append(f"Sinergia: x{synergic_multiplier}")

    return {
        "direction": direction,
        "quality": quality,
        "votes_detail": detail,
        "total_votes": total_sources,
        "signal_votes": signal_votes,
        "against_votes": against_votes,
    }
