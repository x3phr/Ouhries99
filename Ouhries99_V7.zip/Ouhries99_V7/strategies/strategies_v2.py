"""
Sistema Ouhries V5 - Motor de Estrategia V2.1 (MEJORADA)
Analisis multitimeframe + tendencia + confirmacion + calidad de senal
Objetivo: winrate moderado-alto, mas operaciones que V3

Mejoras V2.1 sobre V2 original:
1. ADX >= 20 (filtro de tendencia moderada)
2. Min votos 5 (antes 3) - mas confirmacion
3. Senal fuerza minima 55%
4. Contra-tendencia permitida si fuerza >= 58%
5. RSI zonas 25/75 (estandar)
6. DI+/DI- como voto bonus (no obligatorio)
7. Momentum como voto bonus con filtro debil
8. Penalizacion contra-tendencia -15
9. EMA tendencia peso 4 - mas peso a tendencia
10. Calidad minima 70%

Backup de OTCEspecializada V1 cuando no hay suficientes senales.
"""

import numpy as np

# ============================================================
# HELPERS
# ============================================================

def _body(o, c):
    return abs(c - o)

def _upper_shadow(o, c, h):
    return h - max(o, c)

def _lower_shadow(o, c, l):
    return min(o, c) - l

def _is_green(o, c):
    return c > o

def _is_red(o, c):
    return c < o

def _avg_body(candles, n=5):
    bodies = [abs(c[3] - c[0]) for c in candles[-n:]]
    return np.mean(bodies) if bodies else 0.0001

def calc_di_direction(candles, period=14):
    """Calcula DI+ y DI- (Directional Indicator) localmente."""
    if len(candles) < period + 1:
        return 0, 0
    try:
        closes = np.array([c[3] for c in candles])
        highs = np.array([c[1] for c in candles])
        lows = np.array([c[2] for c in candles])
        plus_dm = np.zeros(len(candles))
        minus_dm = np.zeros(len(candles))
        tr = np.zeros(len(candles))
        for i in range(1, len(candles)):
            up_move = highs[i] - highs[i-1]
            down_move = lows[i-1] - lows[i]
            plus_dm[i] = up_move if up_move > down_move and up_move > 0 else 0
            minus_dm[i] = down_move if down_move > up_move and down_move > 0 else 0
            tr[i] = max(highs[i] - lows[i], abs(highs[i] - closes[i-1]), abs(lows[i] - closes[i-1]))
        atr = np.mean(tr[-period:]) if np.sum(tr[-period:]) > 0 else 0.0001
        plus_di = 100 * np.mean(plus_dm[-period:]) / atr
        minus_di = 100 * np.mean(minus_dm[-period:]) / atr
        return plus_di, minus_di
    except Exception:
        return 0, 0

# ============================================================
# PATRONES ALCISTAS (11) - Peso 1 voto
# ============================================================

def hammer(candles):
    if len(candles) < 2: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    lshadow = _lower_shadow(o, c, l)
    ushadow = _upper_shadow(o, c, h)
    if lshadow >= body * 2 and ushadow <= body * 0.3 and body > 0: return 1
    return 0

def inverted_hammer(candles):
    if len(candles) < 2: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    lshadow = _lower_shadow(o, c, l)
    ushadow = _upper_shadow(o, c, h)
    if ushadow >= body * 2 and lshadow <= body * 0.3 and body > 0: return 1
    return 0

def bullish_engulfing(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if _is_red(prev[0], prev[3]) and _is_green(curr[0], curr[3]):
        if curr[0] <= prev[3] and curr[3] >= prev[0]: return 1
    return 0

def morning_star(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_red(c1[0], c1[3]) and _body(c2[0], c2[3]) < _body(c1[0], c1[3]) * 0.3:
        if _is_green(c3[0], c3[3]) and c3[3] > (c1[0] + c1[3]) / 2: return 1
    return 0

def three_white_soldiers(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if all(_is_green(c[0], c[3]) for c in [c1, c2, c3]):
        if c1[3] < c2[3] < c3[3] and c2[0] > c1[0] and c3[0] > c2[0]: return 1
    return 0

def piercing_line(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if _is_red(prev[0], prev[3]) and _is_green(curr[0], curr[3]):
        mid = (prev[0] + prev[3]) / 2
        if curr[0] < prev[3] and curr[3] > mid: return 1
    return 0

def tweezers_bottom(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if abs(prev[2] - curr[2]) < _avg_body(candles) * 0.1:
        if _is_red(prev[0], prev[3]) and _is_green(curr[0], curr[3]): return 1
    return 0

def three_inside_up(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_red(c1[0], c1[3]) and _is_green(c2[0], c2[3]):
        if c2[0] > c1[3] and c2[3] < c1[0]:
            if _is_green(c3[0], c3[3]) and c3[3] > c1[0]: return 1
    return 0

def three_outside_up(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if bullish_engulfing(candles[-2:]) == 1:
        if _is_green(c3[0], c3[3]) and c3[3] > c2[3]: return 1
    return 0

def abandoned_baby_bottom(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_red(c1[0], c1[3]) and _body(c2[0], c2[3]) < _body(c1[0], c1[3]) * 0.1:
        if _is_green(c3[0], c3[3]):
            if c2[1] < c1[2] and c2[1] < c3[2]: return 1
    return 0

def dragonfly_doji(candles):
    if len(candles) < 1: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    if body < _avg_body(candles) * 0.1:
        if _lower_shadow(o, c, l) > body * 3 and _upper_shadow(o, c, h) < body * 0.5: return 1
    return 0

# ============================================================
# PATRONES BAJISTAS (11)
# ============================================================

def hanging_man(candles):
    if len(candles) < 2: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    lshadow = _lower_shadow(o, c, l)
    ushadow = _upper_shadow(o, c, h)
    if lshadow >= body * 2 and ushadow <= body * 0.3:
        prev = candles[-2]
        if _is_green(prev[0], prev[3]): return -1
    return 0

def shooting_star(candles):
    if len(candles) < 2: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    ushadow = _upper_shadow(o, c, h)
    lshadow = _lower_shadow(o, c, l)
    if ushadow >= body * 2 and lshadow <= body * 0.3: return -1
    return 0

def bearish_engulfing(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if _is_green(prev[0], prev[3]) and _is_red(curr[0], curr[3]):
        if curr[0] >= prev[3] and curr[3] <= prev[0]: return -1
    return 0

def evening_star(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_green(c1[0], c1[3]) and _body(c2[0], c2[3]) < _body(c1[0], c1[3]) * 0.3:
        if _is_red(c3[0], c3[3]) and c3[3] < (c1[0] + c1[3]) / 2: return -1
    return 0

def three_black_crows(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if all(_is_red(c[0], c[3]) for c in [c1, c2, c3]):
        if c1[3] > c2[3] > c3[3] and c2[0] < c1[0] and c3[0] < c2[0]: return -1
    return 0

def dark_cloud_cover(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if _is_green(prev[0], prev[3]) and _is_red(curr[0], curr[3]):
        mid = (prev[0] + prev[3]) / 2
        if curr[0] > prev[3] and curr[3] < mid: return -1
    return 0

def tweezers_top(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if abs(prev[1] - curr[1]) < _avg_body(candles) * 0.1:
        if _is_green(prev[0], prev[3]) and _is_red(curr[0], curr[3]): return -1
    return 0

def three_inside_down(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_green(c1[0], c1[3]) and _is_red(c2[0], c2[3]):
        if c2[0] < c1[3] and c2[3] > c1[0]:
            if _is_red(c3[0], c3[3]) and c3[3] < c1[0]: return -1
    return 0

def three_outside_down(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if bearish_engulfing(candles[-2:]) == -1:
        if _is_red(c3[0], c3[3]) and c3[3] < c2[3]: return -1
    return 0

def abandoned_baby_top(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_green(c1[0], c1[3]) and _body(c2[0], c2[3]) < _body(c1[0], c1[3]) * 0.1:
        if _is_red(c3[0], c3[3]):
            if c2[2] > c1[1] and c2[2] > c3[1]: return -1
    return 0

def gravestone_doji(candles):
    if len(candles) < 1: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    if body < _avg_body(candles) * 0.1:
        if _upper_shadow(o, c, h) > body * 3 and _lower_shadow(o, c, l) < body * 0.5: return -1
    return 0

# ============================================================
# PATRONES NEUTRALES / MIXTOS (9)
# ============================================================

def doji(candles):
    if len(candles) < 3: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    if body < _avg_body(candles) * 0.1:
        prev_trend = sum(1 if candles[i][3] > candles[i][0] else -1 for i in range(-3, 0))
        if prev_trend > 0: return -1
        elif prev_trend < 0: return 1
    return 0

def spinning_top(candles):
    if len(candles) < 3: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    avg = _avg_body(candles)
    if body < avg * 0.3:
        ushadow = _upper_shadow(o, c, h)
        lshadow = _lower_shadow(o, c, l)
        if ushadow > body and lshadow > body:
            prev_trend = sum(1 if candles[i][3] > candles[i][0] else -1 for i in range(-3, 0))
            return -1 if prev_trend > 0 else 1
    return 0

def harami_cross(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    prev_body = _body(prev[0], prev[3])
    curr_body = _body(curr[0], curr[3])
    if curr_body < prev_body * 0.1:
        if curr[0] < max(prev[0], prev[3]) and curr[3] > min(prev[0], prev[3]):
            if _is_green(prev[0], prev[3]): return -1
            elif _is_red(prev[0], prev[3]): return 1
    return 0

def belt_hold_bullish(candles):
    if len(candles) < 1: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    if _is_green(o, c) and o == l: return 1
    return 0

def belt_hold_bearish(candles):
    if len(candles) < 1: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    if _is_red(o, c) and o == h: return -1
    return 0

def marubozu_green(candles):
    if len(candles) < 1: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    if _is_green(o, c) and o == l and c == h: return 1
    return 0

def marubozu_red(candles):
    if len(candles) < 1: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    if _is_red(o, c) and o == h and c == l: return -1
    return 0


PATTERN_FUNCTIONS = [
    hammer, inverted_hammer, bullish_engulfing, morning_star,
    three_white_soldiers, piercing_line, tweezers_bottom,
    three_inside_up, three_outside_up, abandoned_baby_bottom,
    dragonfly_doji,
    hanging_man, shooting_star, bearish_engulfing, evening_star,
    three_black_crows, dark_cloud_cover, tweezers_top,
    three_inside_down, three_outside_down, abandoned_baby_top,
    gravestone_doji,
    doji, spinning_top, harami_cross,
    belt_hold_bullish, belt_hold_bearish,
    marubozu_green, marubozu_red,
]

# ============================================================
# INDICADORES TECNICOS (5) - Peso 2 votos
# ============================================================

def calc_rsi(closes, period=14):
    if len(closes) < period + 1: return 50
    deltas = np.diff(closes[-(period + 1):])
    gains = np.where(deltas > 0, deltas, 0)
    losses = np.where(deltas < 0, -deltas, 0)
    avg_gain = np.mean(gains)
    avg_loss = np.mean(losses)
    if avg_loss == 0: return 100
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def calc_bollinger(closes, period=20, std_mult=2):
    if len(closes) < period: return None, None, None
    slice_c = closes[-period:]
    middle = np.mean(slice_c)
    std = np.std(slice_c)
    return middle - std_mult * std, middle, middle + std_mult * std

def calc_ma_cross(closes, fast=5, slow=20):
    if len(closes) < slow: return 0
    ma_fast = np.mean(closes[-fast:])
    ma_slow = np.mean(closes[-slow:])
    if ma_fast > ma_slow: return 1
    elif ma_fast < ma_slow: return -1
    return 0

def calc_macd(closes, fast=12, slow=26, signal=9):
    if len(closes) < slow + signal: return 0, 0
    ema_fast = _ema(closes, fast)
    ema_slow = _ema(closes, slow)
    macd_line = ema_fast - ema_slow
    macd_values = []
    for i in range(slow, len(closes)):
        ef = _ema(closes[:i+1], fast)
        es = _ema(closes[:i+1], slow)
        macd_values.append(ef - es)
    if len(macd_values) >= signal:
        signal_line = np.mean(macd_values[-signal:])
    else:
        signal_line = macd_line
    return macd_line, signal_line

def calc_stochastic(candles, period=14):
    if len(candles) < period: return 50
    recent = candles[-period:]
    highs = [c[1] for c in recent]
    lows = [c[2] for c in recent]
    closes = [c[3] for c in recent]
    highest = max(highs)
    lowest = min(lows)
    if highest == lowest: return 50
    return ((closes[-1] - lowest) / (highest - lowest)) * 100

def _ema(data, period):
    if len(data) < period: return np.mean(data)
    multiplier = 2 / (period + 1)
    ema = np.mean(data[:period])
    for price in data[period:]:
        ema = (price - ema) * multiplier + ema
    return ema

# ============================================================
# NUEVOS INDICADORES V2 - Analisis Avanzado
# ============================================================

def calc_adx(candles, period=14):
    """Average Directional Index - mide fuerza de tendencia."""
    if len(candles) < period * 2: return 0
    highs = [c[1] for c in candles]
    lows = [c[2] for c in candles]
    closes = [c[3] for c in candles]

    plus_dm = []
    minus_dm = []
    tr_list = []

    for i in range(1, len(candles)):
        high_diff = highs[i] - highs[i-1]
        low_diff = lows[i-1] - lows[i]

        plus_dm.append(high_diff if high_diff > low_diff and high_diff > 0 else 0)
        minus_dm.append(low_diff if low_diff > high_diff and low_diff > 0 else 0)

        tr = max(highs[i] - lows[i], abs(highs[i] - closes[i-1]), abs(lows[i] - closes[i-1]))
        tr_list.append(tr)

    if len(tr_list) < period:
        return 0

    atr = np.mean(tr_list[-period:])
    if atr == 0:
        return 0

    plus_di = (np.mean(plus_dm[-period:]) / atr) * 100
    minus_di = (np.mean(minus_dm[-period:]) / atr) * 100

    di_sum = plus_di + minus_di
    if di_sum == 0:
        return 0

    dx = abs(plus_di - minus_di) / di_sum * 100
    return dx


def calc_ema_trend(closes, period=21):
    """Determina la tendencia usando EMA de 21 periodos."""
    if len(closes) < period: return 0
    ema_val = _ema(closes, period)
    current = closes[-1]
    prev = closes[-2] if len(closes) >= 2 else current

    # Direccion de la EMA
    if current > ema_val and prev > ema_val * 0.999:
        return 1  # Tendencia alcista
    elif current < ema_val and prev < ema_val * 1.001:
        return -1  # Tendencia bajista
    return 0  # Sin tendencia clara


def calc_support_resistance(candles, lookback=20):
    """Detecta si el precio esta cerca de soporte o resistencia."""
    if len(candles) < lookback: return 0, 0
    recent = candles[-lookback:]
    highs = [c[1] for c in recent]
    lows = [c[2] for c in recent]
    closes = [c[3] for c in recent]

    current = closes[-1]
    resistance = max(highs)
    support = min(lows)

    range_val = resistance - support
    if range_val == 0: return 0, 0

    # Que tan cerca esta del soporte (0-1) y resistencia (0-1)
    near_support = (current - support) / range_val  # 0 = en soporte, 1 = en resistencia
    near_resistance = (resistance - current) / range_val

    return near_support, near_resistance


def calc_candle_momentum(candles, n=3):
    """Calcula el momentum de las ultimas N velas."""
    if len(candles) < n: return 0
    recent = candles[-n:]
    total_body = sum(c[3] - c[0] for c in recent)
    avg_body = _avg_body(candles, 10)
    if avg_body == 0: return 0
    return total_body / avg_body  # >0 = momentum alcista, <0 = bajista


def calc_volume_profile(candles):
    """Analiza el perfil de las velas - velas largas vs cortas recientes."""
    if len(candles) < 10: return 0
    recent_bodies = [abs(c[3] - c[0]) for c in candles[-5:]]
    older_bodies = [abs(c[3] - c[0]) for c in candles[-10:-5]]
    avg_recent = np.mean(recent_bodies) if recent_bodies else 0
    avg_older = np.mean(older_bodies) if older_bodies else 0.0001
    if avg_older == 0: return 1
    return avg_recent / avg_older  # >1 = volatilidad aumentando


# ============================================================
# ANALISIS COMBINADO V2 - Con filtro de tendencia y calidad
# ============================================================

def analyze_candles(candles, min_votes=2):
    """
    Analisis V1 basico - compatible con scanner original.
    Retorna: 'call', 'put', o None
    """
    if len(candles) < 5: return None

    votes_call = 0
    votes_put = 0

    # Patrones (peso 1)
    for pattern_fn in PATTERN_FUNCTIONS:
        try:
            result = pattern_fn(candles)
            if result == 1: votes_call += 1
            elif result == -1: votes_put += 1
        except Exception:
            continue

    # Indicadores (peso 2)
    closes = np.array([c[3] for c in candles])

    try:
        rsi = calc_rsi(closes)
        if rsi < 30: votes_call += 2
        elif rsi > 70: votes_put += 2
    except Exception: pass

    try:
        lower, middle, upper = calc_bollinger(closes)
        if lower is not None:
            if closes[-1] <= lower: votes_call += 2
            elif closes[-1] >= upper: votes_put += 2
    except Exception: pass

    try:
        ma_signal = calc_ma_cross(closes)
        if ma_signal == 1: votes_call += 2
        elif ma_signal == -1: votes_put += 2
    except Exception: pass

    try:
        macd_line, signal_line = calc_macd(closes)
        if macd_line > signal_line: votes_call += 2
        elif macd_line < signal_line: votes_put += 2
    except Exception: pass

    try:
        stoch = calc_stochastic(candles)
        if stoch < 20: votes_call += 2
        elif stoch > 80: votes_put += 2
    except Exception: pass

    if votes_call >= min_votes and votes_call > votes_put: return "call"
    elif votes_put >= min_votes and votes_put > votes_call: return "put"
    return None


def analyze_candles_v2(candles, min_votes=5):
    """
    Analisis V2.1 AVANZADO - Filtros multiples para mayor winrate.

    Mejoras sobre V2 original:
    1. Tendencia EMA (peso 4) - mas peso a la tendencia
    2. ADX >= 20 (filtro) - tendencia moderada requerida
    3. Soporte/Resistencia (peso 2) - confirmacion en niveles clave
    4. Momentum (peso 2) - voto bonus + filtro debil contra-tendencia
    5. DI+/DI- (peso 1) - voto bonus a favor de tendencia
    6. RSI con zonas (25/75) - mas estandar
    7. Senal fuerza minima 55%
    8. Contra-tendencia solo si fuerza >= 58%
    9. Penalizacion contra-tendencia -15
    10. Min votos 5 (mas confirmacion que V2 original)

    Relacion con V3: V2.1 es MENOS selectiva que V3 (ADX 20 vs 25,
    calidad 70% vs 88%, permite contra-tendencia con fuerza suficiente)
    pero MAS selectiva que V2 original.

    Retorna: dict con 'direction', 'quality', 'votes_detail' o None
    """
    if len(candles) < 20: return None

    votes_call = 0
    votes_put = 0
    detail = {"patterns_call": 0, "patterns_put": 0, "indicators_call": 0, "indicators_put": 0,
              "trend": "none", "adx": 0, "quality": 0}

    closes = np.array([c[3] for c in candles])

    # ============================================================
    # FILTRO 1: ADX >= 22 - Fuerza de tendencia (antes 20)
    # Si ADX < 22, mercado lateral, NO operar
    # ============================================================
    adx = calc_adx(candles)
    detail["adx"] = adx

    # ADX filtro - menos estricto que V3 (25) pero filtra mercado lateral
    if len(candles) >= 28 and adx > 0 and adx < 20:
        return None  # ADX demasiado bajo, mercado sin tendencia clara

    # ============================================================
    # FILTRO 2: Tendencia EMA (peso 4 - el mas importante, antes 3)
    # Solo operar A FAVOR de la tendencia
    # ============================================================
    ema_trend = calc_ema_trend(closes, 21)
    if ema_trend == 1:
        votes_call += 4
        detail["trend"] = "bullish"
    elif ema_trend == -1:
        votes_put += 4
        detail["trend"] = "bearish"

    # ============================================================
    # PATRONES DE VELAS (peso 1 a favor de tendencia, 0.5 contra)
    # V3 los ignora contra tendencia; V2.1 los reduce a la mitad
    # ============================================================
    for pattern_fn in PATTERN_FUNCTIONS:
        try:
            result = pattern_fn(candles)
            if result == 1:
                # Si tendencia bajista, patron alcista pesa menos
                if detail["trend"] == "bearish":
                    votes_call += 0  # Ignorar patron contra-tendencia (como V3)
                else:
                    votes_call += 1
                    detail["patterns_call"] += 1
            elif result == -1:
                # Si tendencia alcista, patron bajista pesa menos
                if detail["trend"] == "bullish":
                    votes_put += 0  # Ignorar patron contra-tendencia (como V3)
                else:
                    votes_put += 1
                    detail["patterns_put"] += 1
        except Exception:
            continue

    # ============================================================
    # INDICADORES TECNICOS (peso 2 a favor, peso 1 contra tendencia)
    # V3 ignora contra-tendencia; V2.1 reduce peso a la mitad
    # ============================================================

    # RSI con zonas estandar (25/75)
    try:
        rsi = calc_rsi(closes)
        if rsi < 25:
            if detail["trend"] == "bearish":
                votes_call += 1  # Contra-tendencia: peso reducido
            else:
                votes_call += 2
                detail["indicators_call"] += 1
        elif rsi > 75:
            if detail["trend"] == "bullish":
                votes_put += 1  # Contra-tendencia: peso reducido
            else:
                votes_put += 2
                detail["indicators_put"] += 1
        elif rsi < 32:
            if detail["trend"] != "bearish":
                votes_call += 1
        elif rsi > 68:
            if detail["trend"] != "bullish":
                votes_put += 1
    except Exception: pass

    # Bollinger Bands
    try:
        lower, middle, upper = calc_bollinger(closes)
        if lower is not None:
            if closes[-1] <= lower:
                if detail["trend"] == "bearish":
                    votes_call += 1  # Contra-tendencia: peso reducido
                else:
                    votes_call += 2
                    detail["indicators_call"] += 1
            elif closes[-1] >= upper:
                if detail["trend"] == "bullish":
                    votes_put += 1  # Contra-tendencia: peso reducido
                else:
                    votes_put += 2
                    detail["indicators_put"] += 1
    except Exception: pass

    # MA Cross
    try:
        ma_signal = calc_ma_cross(closes)
        if ma_signal == 1:
            if detail["trend"] == "bearish":
                votes_call += 1  # Contra-tendencia
            else:
                votes_call += 2
                detail["indicators_call"] += 1
        elif ma_signal == -1:
            if detail["trend"] == "bullish":
                votes_put += 1  # Contra-tendencia
            else:
                votes_put += 2
                detail["indicators_put"] += 1
    except Exception: pass

    # MACD
    try:
        macd_line, signal_line = calc_macd(closes)
        if macd_line > signal_line:
            if detail["trend"] == "bearish":
                votes_call += 1
            else:
                votes_call += 2
                detail["indicators_call"] += 1
        elif macd_line < signal_line:
            if detail["trend"] == "bullish":
                votes_put += 1
            else:
                votes_put += 2
                detail["indicators_put"] += 1
    except Exception: pass

    # Stochastic
    try:
        stoch = calc_stochastic(candles)
        if stoch < 20:
            if detail["trend"] == "bearish":
                votes_call += 1
            else:
                votes_call += 2
                detail["indicators_call"] += 1
        elif stoch > 80:
            if detail["trend"] == "bullish":
                votes_put += 1
            else:
                votes_put += 2
                detail["indicators_put"] += 1
    except Exception: pass

    # ============================================================
    # NUEVOS INDICADORES V2
    # ============================================================

    # Soporte/Resistencia (peso 2 a favor, 1 contra)
    try:
        near_support, near_resistance = calc_support_resistance(candles)
        if near_support < 0.2:  # Cerca de soporte
            if detail["trend"] == "bearish":
                votes_call += 1
            else:
                votes_call += 2
                detail["indicators_call"] += 1
        elif near_resistance < 0.2:  # Cerca de resistencia
            if detail["trend"] == "bullish":
                votes_put += 1
            else:
                votes_put += 2
                detail["indicators_put"] += 1
    except Exception: pass

    # Momentum (peso 2 a favor, filtro contra-tendencia)
    try:
        momentum = calc_candle_momentum(candles, 3)
        if momentum > 0.4:
            if detail["trend"] == "bearish":
                votes_call += 1  # Contra-tendencia
                if momentum > 0.8:
                    detail["trend_momentum_conflict"] = True
            else:
                votes_call += 2
        elif momentum < -0.4:
            if detail["trend"] == "bullish":
                votes_put += 1  # Contra-tendencia
                if momentum < -0.8:
                    detail["trend_momentum_conflict"] = True
            else:
                votes_put += 2
    except Exception: pass

    # DI+/DI- como voto bonus (solo a favor de tendencia)
    try:
        plus_di, minus_di = calc_di_direction(candles)
        if detail["trend"] == "bullish" and plus_di > minus_di:
            votes_call += 1
            detail["indicators_call"] += 1
        elif detail["trend"] == "bearish" and minus_di > plus_di:
            votes_put += 1
            detail["indicators_put"] += 1
    except Exception: pass

    # ============================================================
    # FILTROS DE CALIDAD
    # ============================================================

    total_votes = votes_call + votes_put
    if total_votes == 0:
        return None

    # Calcular calidad de senal
    if votes_call > votes_put:
        direction = "call"
        signal_strength = votes_call / total_votes
        signal_votes = votes_call
        against_votes = votes_put
    elif votes_put > votes_call:
        direction = "put"
        signal_strength = votes_put / total_votes
        signal_votes = votes_put
        against_votes = votes_call
    else:
        return None  # Empate = no operar

    # ============================================================
    # FILTRO 3: Contradiccion con tendencia (mas estricto)
    # Si la senal va CONTRA la tendencia, requerir mas fuerza
    # Solo permitir contra-tendencia si fuerza >= 58%
    # ============================================================
    against_trend = False
    if detail["trend"] == "bullish" and direction == "put":
        against_trend = True
        if signal_strength < 0.58:
            return None
    if detail["trend"] == "bearish" and direction == "call":
        against_trend = True
        if signal_strength < 0.58:
            return None
    # Filtro de momentum contra-tendencia fuerte
    if against_trend and detail.get("trend_momentum_conflict"):
        return None  # Momentum fuerte contra tendencia = no operar

    # ============================================================
    # FILTRO 4: Minimo de votos (relajado)
    # ============================================================
    if signal_votes < min_votes:
        return None

    # ============================================================
    # FILTRO 5: Mayoridad calificada (55%+ de votos a favor)
    # ============================================================
    if signal_strength < 0.55:
        return None

    # ============================================================
    # FILTRO 6: ADX CRITICO - Ya filtrado arriba (ADX < 20)
    # Verificacion adicional si ADX esta entre 20-23 (zona gris)
    # En zona gris, requerir mayor calidad
    # ============================================================
    if len(candles) >= 28 and 20 <= adx < 23:
        # ADX en zona gris - requerir al menos 6 votos (mas confirmacion)
        if signal_votes < 6:
            return None

    # Calcular calidad final (0-100) - ajustado para mejor diferenciacion
    quality = min(100, int(
        signal_strength * 55 +            # 55% peso a fuerza de senal (antes 60)
        (signal_votes - against_votes) * 4 +  # 4pts por voto neto (antes 5)
        min(adx, 50) / 50 * 15 +             # 15% peso a ADX (cap 50)
        (1 if not against_trend else 0) * 10   # Bonus de 10 si a favor de tendencia
    ))
    if against_trend:
        quality = max(0, quality - 15)  # Penalizar contra-tendencia (menos que V3)

    detail["quality"] = quality
    detail["votes_call"] = votes_call
    detail["votes_put"] = votes_put
    detail["signal_strength"] = signal_strength

    return {
        "direction": direction,
        "quality": quality,
        "votes_detail": detail,
        "total_votes": total_votes,
        "signal_votes": signal_votes,
        "against_votes": against_votes,
    }
