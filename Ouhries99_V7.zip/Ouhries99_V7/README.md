# Sistema Ouhries V7 - Playwright Anti-Detection

## Cambios V7 (Respecto a V6.3.2)

### BUGS CORREGIDOS:
1. **CRITICAL: WS Interceptor** - El handler recibia `frame` como WebSocketFrame object con `.payload`, pero Playwright Python pasa el payload directamente como `str` o `bytes`. Todos los mensajes WS se descartaban silenciosamente. Ahora se procesan correctamente.
2. **Login doble inicio** - Se agrego auto-retry en `connect()`. Si el primer intento falla, limpia el navegador y reintenta automaticamente.
3. **SyntaxError en account switching** - Las comillas simples dentro del JS de `_switch_account_js` causaban SyntaxError. Corregido con concatenacion de strings JS.
4. **Payout siempre 0%** - `get_all_profit()` no encontraba datos de profit. Agregado fallback que usa payout por defecto (87%) para instrumentos OTC.
5. **Candles vacio** - `get_candles()` no encontraba datos. Agregados multiples endpoints API de IQ Option y fallbacks.
6. **WS message names** - Expandido el interceptor para capturar todos los tipos de mensaje de IQ Option: `candle-generated`, `result`, `profile`, etc.
7. **Balance reading** - Mas agresivo, con fallback a DOM + JS scan.

### CONFIGURACION PARA TRADING:
- Capital por operacion: $1.00
- Max operaciones: 4
- Payout minimo: 0% (sin filtro de payout)
- Session control: Desactivado (para testing rapido)
- Scanner delays: Reducidos para sesiones mas rapidas

## Instalacion en Windows

1. Descomprime el .zip en una carpeta
2. Ejecuta `start.bat` (doble click)
3. En la primera ejecucion instalara las dependencias automaticamente
4. Selecciona modo de ejecucion:
   - Opcion 1: Interfaz Web (recomendado)
   - Opcion 2: Sesion automatica de trading

## Interfaz Web

La interfaz web se abre en `http://localhost:8585` y permite:
- Conectar/Desconectar de IQ Option
- Iniciar/Detener trading
- Ver operaciones en tiempo real
- Cambiar configuracion
- Cambiar cuenta PRACTICE/REAL

## Requisitos

- Windows 10/11
- Python 3.11+ (con "Add to PATH" marcado)
- Brave Browser (opcional, usa Chromium si no esta)
- Conexion a internet

## Notas

- El bot usa Playwright headless por defecto (no abre ventana de navegador)
- Para usar Brave browser, setea la variable de entorno BRAVE_PATH o instalalo en la ubicacion por defecto
- Las credenciales estan pre-configuradas en config.py
- Telegram notificaciones activas por defecto
