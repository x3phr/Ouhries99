"""
Sistema Ouhries V5 - Instrumentos OTC
Obtiene instrumentos OTC operables.
Solo incluye instrumentos presentes en ACTIVES_OPCODE.
Filtra por payout minimo usando get_all_profit().
"""

OTC_FALLBACK = {
    "EURUSD-OTC": "EURUSD-OTC",
    "GBPUSD-OTC": "GBPUSD-OTC",
    "USDJPY-OTC": "USDJPY-OTC",
    "AUDUSD-OTC": "AUDUSD-OTC",
    "USDCAD-OTC": "USDCAD-OTC",
    "USDCHF-OTC": "USDCHF-OTC",
    "EURGBP-OTC": "EURGBP-OTC",
    "EURJPY-OTC": "EURJPY-OTC",
    "GBPJPY-OTC": "GBPJPY-OTC",
    "AUDJPY-OTC": "AUDJPY-OTC",
    "EURAUD-OTC": "EURAUD-OTC",
    "EURCHF-OTC": "EURCHF-OTC",
    "GBPAUD-OTC": "GBPAUD-OTC",
    "GBPCAD-OTC": "GBPCAD-OTC",
    "GBPCHF-OTC": "GBPCHF-OTC",
    "AUDCAD-OTC": "AUDCAD-OTC",
    "AUDCHF-OTC": "AUDCHF-OTC",
    "CADCHF-OTC": "CADCHF-OTC",
    "NZDJPY-OTC": "NZDJPY-OTC",
    "EURNZD-OTC": "EURNZD-OTC",
    "GBPNZD-OTC": "GBPNZD-OTC",
    "AUDNZD-OTC": "AUDNZD-OTC",
    "CADJPY-OTC": "CADJPY-OTC",
    "CHFJPY-OTC": "CHFJPY-OTC",
    "NZDCAD-OTC": "NZDCAD-OTC",
    "NZDCHF-OTC": "NZDCHF-OTC",
    "USDSGD-OTC": "USDSGD-OTC",
    "USDHKD-OTC": "USDHKD-OTC",
    "USDZAR-OTC": "USDZAR-OTC",
    "USDMXN-OTC": "USDMXN-OTC",
    "USDNOK-OTC": "USDNOK-OTC",
    "USDSEK-OTC": "USDSEK-OTC",
    "USDDKK-OTC": "USDDKK-OTC",
    "USDPLN-OTC": "USDPLN-OTC",
    "EURPLN-OTC": "EURPLN-OTC",
    "EURSEK-OTC": "EURSEK-OTC",
    "EURNOK-OTC": "EURNOK-OTC",
    "EURDKK-OTC": "EURDKK-OTC",
    "EURHUF-OTC": "EURHUF-OTC",
    "GBPSGD-OTC": "GBPSGD-OTC",
    "AUDSGD-OTC": "AUDSGD-OTC",
    "EURAED-OTC": "EURAED-OTC",
    "USDCNH-OTC": "USDCNH-OTC",
    "USDCZK-OTC": "USDCZK-OTC",
    "USDHUF-OTC": "USDHUF-OTC",
    "XAUUSD-OTC": "XAUUSD-OTC",
    "XAGUSD-OTC": "XAGUSD-OTC",
}


def _get_payout_for_instrument(all_profit, name_str):
    """Obtiene el payout turbo de un instrumento desde all_profit."""
    for name in [name_str, name_str.upper(),
                 name_str.replace("-OTC", "_otc"),
                 name_str.replace("-OTC", "-otc")]:
        if name in all_profit:
            info = all_profit[name]
            if isinstance(info, dict):
                turbo = info.get("turbo", 0)
                if turbo:
                    return int(float(turbo) * 100)
                binary = info.get("binary", 0)
                if binary:
                    return int(float(binary) * 100)
            elif isinstance(info, (int, float)):
                return int(float(info) * 100)
    return 0


def get_otc_instruments(api, payout_min=0):
    """
    Obtiene instrumentos OTC operables desde la API.
    Solo incluye instrumentos que estan en ACTIVES_OPCODE (verificados operables)
    y filtra por payout minimo usando get_all_profit().
    """
    instruments = {}
    all_profit = {}
    try:
        all_profit = api.get_all_profit() or {}
    except Exception:
        pass

    # Instrumentos excluidos
    EXCLUDED = {"NZDUSD-OTC"}

    # Metodo 1: ACTIVES_OPCODE
    try:
        all_actives = api.get_all_ACTIVES_OPCODE()
        if all_actives:
            for name in all_actives.keys():
                name_str = str(name)
                if "otc" not in name_str.lower():
                    continue
                if name_str in EXCLUDED:
                    continue
                if payout_min > 0:
                    payout = _get_payout_for_instrument(all_profit, name_str)
                    if payout < payout_min and payout > 0:
                        continue
                instruments[name_str] = name_str
            if instruments:
                return instruments
    except Exception:
        pass

    # Metodo 2: Fallback estatico
    for name in OTC_FALLBACK.keys():
        if name in EXCLUDED:
            continue
        if payout_min > 0 and all_profit:
            payout = _get_payout_for_instrument(all_profit, name)
            if payout < payout_min and payout > 0:
                continue
        instruments[name] = name
    return instruments


def get_active_id(api, instrument_name):
    """Obtiene el ID de un instrumento especifico."""
    try:
        all_actives = api.get_all_ACTIVES_OPCODE()
        if all_actives and instrument_name in all_actives:
            return all_actives[instrument_name]
    except Exception:
        pass
    return OTC_FALLBACK.get(instrument_name, None)
