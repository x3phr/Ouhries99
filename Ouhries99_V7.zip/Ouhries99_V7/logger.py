"""
Sistema Ouhries V5 - Logger a Archivo
Escribe logs a archivo en la carpeta del bot.
Rotacion diaria automatica.
"""

import os
import time
from datetime import datetime


class Logger:
    """Logger que escribe a archivo con rotacion diaria."""

    def __init__(self, log_dir="logs"):
        self.log_dir = log_dir
        try:
            os.makedirs(log_dir, exist_ok=True)
        except Exception:
            pass

    def _get_log_file(self):
        today = datetime.now().strftime("%Y-%m-%d")
        return os.path.join(self.log_dir, f"ouhries_{today}.log")

    def log(self, message):
        timestamp = time.strftime("%H:%M:%S")
        line = f"[{timestamp}] {message}\n"
        try:
            with open(self._get_log_file(), "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:
            pass
