"""
Sistema Ouhries V6.3.2 - Configuracion Global (Anti-Detection v5 + Playwright)
Capital de operacion, Niveles de interes compuesto, stops.
Payout 87+ automatico, expiracion siempre 1.
Estrategia V3 con ADX >= 25 y calidad >= 88%.
Notificaciones Telegram con emojis.
Anti-Detection v5: Playwright headless, TLS real, WS real, mouse real.
V6.3.2: Brave support, JS account switch, improved WS interceptor.
V6: Session control (max 2 sesiones/dia, no 24/7), SW bajo = SL.
"""
import json
import os

CONFIG_FILE = "config.json"

DEFAULT_CONFIG = {
    # Cuenta
    "email": "deadly.x@hotmail.com",
    "password": "Shinigami1",
    "account_mode": "PRACTICE",

    # Gestion - Capital y Niveles
    "capital_operacion": 1.00,
    "niveles": 0,
    "disable_niveles": True,
    # V7: Stop Win y Loss ajustados para 4 ops de $1
    "stop_win": 4.00,
    "stop_loss": 4.00,

    # Sub-nivel (interes compuesto) - 0 = sin reinvertir
    "sublevel_profit_pct": 35,
    "sublevel_min_votes": 3,
    "sublevel_payout_min": 87,

    # Estrategia (OTC V1 es la default - optimizada para OTC)
    "min_strategy_votes": 4,
    "use_strategy_v2": False,
    "use_strategy_otc": True,
    "min_signal_quality": 88,
    "payout_min": 0,

    # V6: Maximo de operaciones por sesion - al menos 10
    "max_trades": 4,

    # Scanner
    "scanner_max_instruments": 35,

    # Delays anti-deteccion (segundos)
    "delay_between_ops_min": 10,
    "delay_between_ops_max": 30,
    "delay_thinking_min": 1,
    "delay_thinking_max": 3,
    "delay_scanner_min": 0.5,
    "delay_scanner_max": 1.5,

    # Anti-deteccion v3 - Todas funcionales
    "human_action_pct": 15,
    "amount_noise_pct": 2.0,
    "noise_browsing_pct": 30,
    "entry_hesitation_pct": 5,

    # V7: Control de sesiones - desactivado para testing rapido
    "max_sessions_per_day": 99,       # Sin limite para testing
    "session_cooldown_min": 1,       # 1 min cooldown para testing
    "auto_session_control": False,    # Desactivado para testing

    # Telegram Notificaciones
    "telegram_enabled": True,
    "telegram_token": "8580761533:AAEunrfQWHKCNbN5wNENr0hba6qZ0TFL_5c",
    "telegram_chat_id": "7985764642",

    # Repetir Win
    "repeat_win": False,
    "broker_delay_enabled": True,
    "broker_delay": 4.0,
}


def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                saved = json.load(f)
            merged = {**DEFAULT_CONFIG, **saved}
            return merged
        except Exception:
            return DEFAULT_CONFIG.copy()
    return DEFAULT_CONFIG.copy()


def save_config(cfg):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)
