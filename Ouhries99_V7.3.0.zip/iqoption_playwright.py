"""
Sistema Ouhries V7.3.0 Playwright Edition - IQ Option API Wrapper (Anti-Detection V6)
REEMPLAZO DROP-IN para iqoption_patched.py

V6.3.2 CRITICAL FIXES:
- FIX #1: AsyncBridge timeout mejorado (60s change_balance, mejor error logging con tipo)
- FIX #2: Account switching PRACTICE/REAL usa JavaScript evaluation en vez de CSS selectors
- FIX #3: Brave browser support (canal "brave" primero, BRAVE_PATH env variable)
- FIX #4: Headless=True por defecto (parametro _headless en __init__)
- FIX #5: WS interception robusto (direct method binding, framesent debug, message counter)
- FIX #6: Login flow optimizado (waits reducidos manteniendo simulacion humana)
- FIX #7: Balance reading via JavaScript agresivo + WS intercept mas agresivo
- FIX #8: Trade execution timeout aumentado a 90s, pasos mas eficientes

ARQUITECTURA HIBRIDA - Indetectable por IQ Option:
- Login: Playwright (navegador real, TLS real, cookies reales)
- Datos: Intercepcion WebSocket del navegador real (mismo formato que SDK JavaScript)
- Trading: Clicks reales en CALL/PUT (eventos DOM reales con movimiento de mouse)
- Balance: Lectura del DOM + WS intercept (como un usuario real lo ve)
- Anti-deteccion: Stealth patches, mouse real, scroll real, actividad fuera de trading

VENTAJAS sobre iqoptionapi:
- TLS fingerprint de Chrome REAL (no simulado con curl_cffi)
- Formato de mensajes WS identico al SDK JavaScript (iqoptionapi usa formato diferente)
- Eventos de mouse/scroll reales generados por el navegador
- Heartbeat/telemetria automatica (el navegador los envia naturalmente)
- Canvas/WebGL fingerprints reales
- Ninguna anomalia detectable en el protocolo

MISMA INTERFAZ que IQ_Option_Patched:
- engine.py NO necesita cambios (excepto el import)
- scanner.py NO necesita cambios
- config.py NO necesita cambios
"""

import asyncio
import json
import logging
import os
import random
import re
import threading
import time
import traceback
from datetime import datetime
from typing import Optional, Tuple, Dict, List, Any

logger = logging.getLogger("iq_playwright")

# ============================================================
# SELECTOR MAP - IQ Option DOM Selectors
# Actualizable via selector_map.json sin cambiar codigo
# ============================================================
DEFAULT_SELECTORS = {
    "login": {
        "page_url": "https://login.iqoption.com/en/login",
        "email_input": 'input[name="identifier"]',
        "password_input": 'input[name="password"]',
        "submit_button": 'button.Button_green.Button_big, button[type="submit"]:has-text("Log In"), #login-submit-button',
        "form": '#login-form',
    },
    "dashboard": {
        "traderoom_url_pattern": "**/traderoom**",
        "balance_container": '[class*="balance"], [class*="Balance"], [data-test*="balance"]',
        "practice_button": 'button:has-text("Practice"), [class*="practice"], [class*="Practice"]',
        "real_button": 'button:has-text("Real"), [class*="real-"], [class*="Real"]',
        "account_switch": '[class*="account-switch"], [class*="AccountSwitch"], [class*="toggle"]',
    },
    "trading": {
        "asset_selector_button": '[class*="asset-selector"], [class*="instrument"], [class*="AssetSelector"], [class*="current-asset"]',
        "asset_search_input": 'input[class*="search"], input[placeholder*="Search"], input[placeholder*="search"]',
        "otc_tab": 'button:has-text("OTC"), [class*="otc"], [class*="OTC"], [data-test*="otc"]',
        "asset_item": '[class*="asset-item"], [class*="instrument-item"], [class*="AssetItem"]',
        "amount_input": 'input[class*="amount"], input[name*="amount"], [class*="amount-input"], [class*="AmountInput"]',
        "call_button": 'button:has-text("CALL"), [class*="call-btn"], [class*="btn-call"], [class*="CallButton"], [class*="up-btn"]',
        "put_button": 'button:has-text("PUT"), [class*="put-btn"], [class*="btn-put"], [class*="PutButton"], [class*="down-btn"]',
        "expiration_selector": '[class*="expiration"], [class*="expiry"], [class*="Expiration"]',
        "expiration_1min": 'button:has-text("1 min"), [class*="1m"], [data-test*="1min"]',
        "trade_confirmation": '[class*="confirmation"], [class*="result"], [class*="trade-result"]',
        "close_confirmation": 'button:has-text("OK"), button:has-text("Close"), [class*="close"]',
    },
    "navigation": {
        "deposit_link": 'a:has-text("Deposit"), button:has-text("Deposit"), [class*="deposit"]',
        "settings_link": 'a:has-text("Settings"), [class*="settings"], [class*="Settings"]',
        "history_link": 'a:has-text("History"), [class*="history"], [class*="History"]',
    }
}

# ============================================================
# STEALTH JAVASCRIPT - Anti-Detection Patches
# Se inyectan en el navegador antes de cargar cualquier pagina
# ============================================================
STEALTH_JS = """
// 1. Ocultar navigator.webdriver
Object.defineProperty(navigator, 'webdriver', {
    get: () => undefined,
    configurable: true
});

// 2. Agregar chrome.runtime (ausente en Playwright)
if (!window.chrome) window.chrome = {};
if (!window.chrome.runtime) {
    window.chrome.runtime = {
        connect: function() {},
        sendMessage: function() {},
        onMessage: { addListener: function() {} },
        id: undefined
    };
}

// 3. Corregir Permissions API
const originalQuery = window.navigator.permissions.query;
window.navigator.permissions.query = (parameters) => (
    parameters.name === 'notifications' ?
        Promise.resolve({ state: Notification.permission }) :
        originalQuery(parameters)
);

// 4. Agregar plugins realistas
Object.defineProperty(navigator, 'plugins', {
    get: () => [
        { name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer' },
        { name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai' },
        { name: 'Native Client', filename: 'internal-nacl-plugin' }
    ],
    configurable: true
});

// 5. Corregir languages
Object.defineProperty(navigator, 'languages', {
    get: () => ['en-US', 'en', 'es'],
    configurable: true
});

// 6. Prevenir deteccion de automation via CDP
window.cdc_adoQpoasnfa76pfcZLmcfl_Array = undefined;
window.cdc_adoQpoasnfa76pfcZLmcfl_Promise = undefined;
window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol = undefined;

// 7. Corregir iframe contentWindow
const origAttachShadow = Element.prototype.attachShadow;
Element.prototype.attachShadow = function() {
    const shadowRoot = origAttachShadow.apply(this, arguments);
    shadowRoot.querySelector = new Proxy(shadowRoot.querySelector, {
        apply: function(target, thisArg, args) {
            return target.apply(thisArg, args);
        }
    });
    return shadowRoot;
};

// 8. WebGL vendor/renderer realistas
const getParameter = WebGLRenderingContext.prototype.getParameter;
WebGLRenderingContext.prototype.getParameter = function(param) {
    if (param === 37445) return 'Google Inc. (NVIDIA)';
    if (param === 37446) return 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1060, OpenGL 4.5)';
    return getParameter.call(this, param);
};

// 9. Mouse movement tracking (para simular actividad humana)
window.__ouhries_mouse_positions = [];
document.addEventListener('mousemove', (e) => {
    if (window.__ouhries_mouse_positions.length > 100) {
        window.__ouhries_mouse_positions.shift();
    }
    window.__ouhries_mouse_positions.push({
        x: e.clientX, y: e.clientY,
        t: Date.now()
    });
});

// 10. Prevenir deteccion de headless
Object.defineProperty(navigator, 'maxTouchPoints', {
    get: () => 0,
    configurable: true
});

// 11. Corregir hairline detection
if (window.devicePixelRatio !== undefined) {
    Object.defineProperty(window, 'devicePixelRatio', {
        get: () => 1,
        configurable: true
    });
}
"""

# ============================================================
# CHROME USER AGENTS (2025/2026)
# ============================================================
CHROME_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
]


# ============================================================
# ASYNC BRIDGE - Conecta el engine sincronico con Playwright async
# ============================================================
class _AsyncBridge:
    """Puente entre el engine.py sincronico y Playwright async.
    Ejecuta un event loop en un thread daemon separado.

    V6.3.2 FIX #1: Mejor error logging con tipo de excepcion.
    Timeouts por defecto mas generosos."""

    def __init__(self):
        self._loop = None
        self._thread = None
        self._started = threading.Event()
        self._lock = threading.Lock()

    def start(self):
        with self._lock:
            if self._loop is not None and self._loop.is_running():
                return
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()
            self._started.wait(timeout=10)

    def _run(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._started.set()
        self._loop.run_forever()

    def run(self, coro, timeout=180):
        """Ejecuta una corutina async desde codigo sincronico.

        V6.3.2: Error logging incluye tipo de excepcion y traceback corto.
        """
        self.start()
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        try:
            return future.result(timeout=timeout)
        except asyncio.TimeoutError:
            logger.error(f"[AsyncBridge] Timeout ({timeout}s) ejecutando corutina "
                         f"- la operacion tardo demasiado. "
                         f"Considere aumentar el timeout.")
            raise
        except Exception as e:
            exc_type = type(e).__name__
            logger.error(f"[AsyncBridge] Error ejecutando corutina: "
                         f"[{exc_type}] {e}")
            logger.debug(f"[AsyncBridge] Traceback: {traceback.format_exc()}")
            raise

    def stop(self):
        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)


# ============================================================
# WEBSOCKET INTERCEPTOR - Captura datos del WS real del navegador
# ============================================================
class _WSInterceptor:
    """Intercepta mensajes WebSocket del navegador real.
    IQ Option envia todos los datos (candles, profit, actives, timesync)
    a traves del WebSocket. Interceptamos estos mensajes para obtener
    los mismos datos que la interfaz web muestra al usuario.

    V6.3.2 FIX #5:
    - Direct method binding (no lambda wrapper)
    - _message_count para verificar actividad WS
    - _ssid para almacenar session ID
    - framesent handler para debug
    - is_connected() verifica _connected Y _message_count > 0
    """

    def __init__(self):
        self._ws = None
        self._messages = {}
        self._actives = {}
        self._profit = {}
        self._candles_cache = {}
        self._balance = 0.0
        self._server_timestamp = time.time()
        self._trade_results = {}
        self._lock = threading.Lock()
        self._last_timesync = time.time()
        self._connected = False
        # V6.3.2: Track total messages received for connectivity verification
        self._message_count = 0
        # V6.3.2: Store session ID from WS
        self._ssid = None
        # V6.3.2: Track last few message names for debug
        self._recent_messages = []
        # V7.3 CRITICAL FIX: IQ Option's balance type mapping:
        # type=1 = REAL account (dinero real)
        # type=4 = PRACTICE account (dinero demo)
        # Previous code had these REVERSED, causing balance display swap!
        #
        # Evidence: User reports Practice: $0.87 / Real: $25.12 estan al reves.
        # The ssid message sends: balances: [{id: X, type: 1, amount: 25.12},
        #                                     {id: Y, type: 4, amount: 0.87}]
        # type=1 with $25.12 = that's the REAL money account
        # type=4 with $0.87 = that's the PRACTICE demo account
        self._practice_balance = 0.0
        self._real_balance = 0.0
        self._practice_balance_id = None
        self._real_balance_id = None
        self._active_balance_id = None  # Current active balance_id

    def on_ws_created(self, ws):
        """Llamado cuando el navegador crea una conexion WebSocket."""
        logger.info(f"[WS] Conexion WebSocket detectada: {ws.url}")
        self._ws = ws
        self._connected = True
        # V6.3.2 FIX #5: Direct method binding - Playwright Python passes
        # single WebSocketFrame argument to the handler
        ws.on("framereceived", self._on_frame_received)
        # V6.3.2: Also intercept sent frames for debugging
        ws.on("framesent", self._on_frame_sent)
        ws.on("close", self._on_ws_close)

    def _on_ws_close(self):
        """Llamado cuando el WebSocket se cierra."""
        logger.info("[WS] Conexion WebSocket cerrada")
        self._connected = False
        self._ws = None

    def _on_frame_sent(self, payload):
        """Intercepta frames enviados por el navegador (para debug).

        V7 FIX: Playwright Python API passes payload directly (str or bytes),
        NOT a WebSocketFrame object. The event handler receives:
        - str for text frames (opcode 1)
        - bytes for binary frames (opcode 2, base64 decoded)
        """
        try:
            if isinstance(payload, bytes):
                try:
                    payload = payload.decode('utf-8')
                except (UnicodeDecodeError, AttributeError):
                    return
            if isinstance(payload, str) and len(payload) < 500:
                logger.debug(f"[WS-SENT] {payload[:200]}")
        except Exception:
            pass

    def _on_frame_received(self, payload):
        """Procesa cada frame recibido del WebSocket.

        V7 CRITICAL FIX: Playwright Python API passes the payload directly
        as a str (text frames, opcode 1) or bytes (binary frames, opcode 2,
        base64 decoded by Playwright internally). It does NOT pass a
        WebSocketFrame object with a .payload attribute.

        Previous code: frame.payload -> always failed, all WS messages dropped!
        Fixed code: payload is already the str/bytes data we need.

        Soporta ambos formatos de mensaje IQ Option:
        - Formato dict: {"name": "timeSync", "msg": {...}}
        - Formato array: ["timeSync", {...}]
        """
        try:
            # V6.3.2: Increment message counter for connectivity verification
            self._message_count += 1
            # Any message = alive
            self._last_timesync = time.time()

            # V7 FIX: payload is already str or bytes, not a frame object
            if not payload:
                return
            # IQ Option puede enviar frames binarios (opcode=2) o texto (opcode=1)
            if isinstance(payload, bytes):
                try:
                    payload = payload.decode('utf-8')
                except (UnicodeDecodeError, AttributeError):
                    return  # Ignorar frames binarios que no son JSON
            if not isinstance(payload, str):
                return

            # Los mensajes de IQ Option son JSON
            try:
                data = json.loads(payload)
            except (json.JSONDecodeError, ValueError):
                return

            # IQ Option usa dos formatos de mensaje:
            # 1. Formato dict: {"name": "timeSync", "msg": {...}}
            # 2. Formato array: ["timeSync", {...}]
            if isinstance(data, list) and len(data) >= 2:
                msg_name = data[0] if isinstance(data[0], str) else ""
                msg = data[1]
                data = {"name": msg_name, "msg": msg}
            elif not isinstance(data, dict):
                return

            msg_name = data.get("name", "")

            # V6.3.2: Track recent message names for debugging
            if len(self._recent_messages) > 50:
                self._recent_messages = self._recent_messages[-25:]
            self._recent_messages.append(f"{msg_name}@{int(time.time())}")

            # Log periodicamente para verificar actividad
            if self._message_count % 100 == 0:
                logger.info(f"[WS] {self._message_count} mensajes procesados "
                            f"(ultimo: {msg_name})")

            # V7: Log first few message names at debug level for protocol discovery
            if self._message_count <= 30:
                logger.debug(f"[WS-DISC] msg#{self._message_count} name={msg_name} "
                             f"payload_len={len(payload)}")

            # ============================================================
            # TimeSync - actualizar timestamp del servidor
            # ============================================================
            if msg_name == "timeSync":
                msg = data.get("msg", 0)
                if isinstance(msg, (int, float)) and msg > 0:
                    self._server_timestamp = msg / 1000.0

            # ============================================================
            # V7.2: Session ID / ssid / init message - CRITICAL for balance!
            # IQ Option sends ["ssid", {ssid: "...", balances: [...],
            #   balance: ..., balance_id: ...}] as the FIRST message.
            # V7.2: Also handle "init", "session", "frontend-init" names
            # since the session data may come under different names.
            # ============================================================
            elif msg_name in ("ssid", "init", "session", "frontend-init"):
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    ssid_val = msg.get("ssid", None)
                    if ssid_val:
                        self._ssid = ssid_val
                        logger.info(f"[WS] SSID capturado: {ssid_val[:20]}...")

                    # V7.1 CRITICAL FIX: Parse balance data from ssid message
                    # IQ Option sends ALL account info in the ssid message:
                    # {ssid: "...", balance: 10000.0, balance_id: 12345,
                    #  balances: [{id: 12345, type: 1, amount: 10000.0},
                    #             {id: 12346, type: 4, amount: 5.0}]}
                    # type=1 = Practice, type=4 = Real
                    self._process_balance_from_ssid(msg)

                    # Also process actives/profit from ssid if present
                    actives_list = msg.get("actives", msg.get("instruments", []))
                    if isinstance(actives_list, (list, dict)):
                        self._process_actives_data(actives_list)

            elif msg_name in ("profile", "session", "result"):
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    ssid_val = msg.get("ssid", None)
                    if ssid_val:
                        self._ssid = ssid_val
                        logger.info(f"[WS] SSID capturado: {ssid_val[:20]}...")

                    # V7: Result messages often contain profit/actives data
                    self._process_result_message(msg_name, data)

                    # V7.1: Also process balance from profile/session messages
                    self._process_balance_from_ssid(msg)

            # ============================================================
            # V7: Profile message contains balance + actives + profit
            # ============================================================
            elif msg_name in ("profile", "user-profile", "userProfile"):
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    # Balance from profile
                    for field in ("balance", "amount", "current_balance"):
                        amount = msg.get(field, 0)
                        if amount and float(amount) > 0:
                            with self._lock:
                                self._balance = float(amount)
                            break
                    # Actives from profile
                    actives_list = msg.get("actives", msg.get("instruments", []))
                    if isinstance(actives_list, (list, dict)):
                        self._process_actives_data(actives_list)
                    # Balance list from profile
                    balances = msg.get("balances", [])
                    if isinstance(balances, list):
                        for b in balances:
                            if isinstance(b, dict):
                                btype = b.get("type", "")
                                bamt = b.get("amount", 0)
                                # V7.3: Only update active balance from the matching account
                                if bamt and (btype == 1 or btype == 4):
                                    with self._lock:
                                        self._balance = float(bamt)

            # ============================================================
            # Balance update
            # ============================================================
            elif msg_name == "balance":
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    amount = msg.get("amount", 0)
                    if amount:
                        with self._lock:
                            old_balance = self._balance
                            self._balance = float(amount)
                        if abs(self._balance - old_balance) > 0.01:
                            logger.info(f"[WS] Balance actualizado: "
                                        f"${old_balance:.2f} -> ${self._balance:.2f}")
                # V7: Balance can also be a simple number
                elif isinstance(msg, (int, float)) and msg > 0:
                    with self._lock:
                        old_balance = self._balance
                        self._balance = float(msg)

            # V7.2: available-balances - ALL account balance data
            # IQ Option sends this as msg#24 with all balance types:
            # {"name": "available-balances", "msg": [
            #   {"id": 1240156475, "type": 1, "amount": 10000.0},
            #   {"id": ..., "type": 4, "amount": 0.87}]}
            elif msg_name in ("available-balances", "balances"):
                msg = data.get("msg", {})
                if isinstance(msg, list):
                    # Format: [{"id": 1240156475, "type": 1, "amount": 10000.0}, ...]
                    for b in msg:
                        if isinstance(b, dict):
                            self._process_balance_from_ssid(b)
                elif isinstance(msg, dict):
                    self._process_balance_from_ssid(msg)

            # V7: More aggressive balance interception
            elif msg_name in ("balance-changed", "user-balance",
                              "account-balance", "position-changed",
                              "fired-balance"):
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    for field in ("amount", "balance", "current_balance",
                                  "value", "equity"):
                        amount = msg.get(field, 0)
                        if amount and float(amount) > 0:
                            with self._lock:
                                self._balance = float(amount)
                            break

            # ============================================================
            # V7: Profit/Payout data - expanded message names
            # ============================================================
            elif msg_name in ("profit", "turbo-profit", "profit-all",
                              "instrument-quotation", "quote",
                              "option-type-profit", "payout"):
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    with self._lock:
                        self._profit.update(msg)
                elif isinstance(msg, list):
                    with self._lock:
                        for item in msg:
                            if isinstance(item, dict):
                                name = item.get("name", item.get("instrument", ""))
                                if name:
                                    self._profit[name] = item

            # ============================================================
            # V7: Actives/Instruments - expanded message names
            # ============================================================
            elif msg_name in ("actives", "instruments", "instrument-list",
                              "getAllInstruments", "get_all_ACTIVES_OPCODE",
                              "instrument", "active"):
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    self._process_actives_data(msg)
                elif isinstance(msg, list):
                    self._process_actives_data(msg)

            # ============================================================
            # V7: Candle data - expanded to capture all candle messages
            # ============================================================
            elif msg_name in ("candles", "candle", "get-candles",
                              "candle-generated", "candle-generated-new"):
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    # Try multiple key names for instrument identification
                    instrument = (msg.get("instrument") or msg.get("active")
                                  or msg.get("active_id") or msg.get("name")
                                  or msg.get("pair") or "")
                    candles = (msg.get("candles") or msg.get("data")
                               or msg.get("items") or [])
                    if instrument and candles and isinstance(candles, list):
                        with self._lock:
                            existing = self._candles_cache.get(str(instrument), [])
                            # Append new candles (most recent at end)
                            combined = existing + candles
                            # Keep only last 200 candles per instrument
                            self._candles_cache[str(instrument)] = combined[-200:]
                            logger.debug(f"[WS] Candles cached for {instrument}: "
                                         f"{len(combined)} total")
                    # V7: candle-generated is a single candle update
                    elif instrument and not candles:
                        # This is a single candle update, not a list
                        # Store it as the latest candle for this instrument
                        single_candle = {k: v for k, v in msg.items()
                                         if k in ("open", "max", "min", "close",
                                                  "from", "to", "time", "volume",
                                                  "id")}
                        if single_candle.get("close") is not None:
                            with self._lock:
                                key = str(instrument)
                                if key in self._candles_cache:
                                    self._candles_cache[key].append(single_candle)
                                    self._candles_cache[key] = self._candles_cache[key][-200:]
                                else:
                                    self._candles_cache[key] = [single_candle]
                elif isinstance(msg, list) and len(msg) > 0:
                    # Sometimes candles come as a direct list
                    # Try to find the instrument from the data
                    first = msg[0] if isinstance(msg[0], dict) else {}
                    instrument = (first.get("instrument") or first.get("active")
                                  or first.get("pair") or "")
                    if instrument:
                        with self._lock:
                            self._candles_cache[str(instrument)] = msg[-200:]

            # ============================================================
            # V7: Trade result - expanded message names
            # ============================================================
            elif msg_name in ("option-closed", "order-result", "trade-result",
                              "digital-option-placed", "option-closed-new",
                              "finished", "option-finished"):
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    order_id = msg.get("id", msg.get("order_id",
                                    msg.get("option_id", "")))
                    profit = msg.get("profit", msg.get("win",
                                msg.get("amount", 0)))
                    if order_id:
                        with self._lock:
                            self._trade_results[str(order_id)] = float(profit)
                        logger.info(f"[WS] Trade result: id={order_id}, "
                                    f"profit={profit}")

            # ============================================================
            # V7: Unknown message types - try to extract useful data
            # ============================================================
            else:
                # For unknown message types, try to extract actives/profit data
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    # Check if it contains actives-like data
                    if any(k in msg for k in ("actives", "instruments",
                                               "active_list")):
                        self._process_actives_data(
                            msg.get("actives", msg.get("instruments", [])))
                    # Check if it contains profit-like data
                    if any(k in msg for k in ("profit", "payout", "turbo")):
                        with self._lock:
                            self._profit.update(msg)

        except Exception as e:
            logger.debug(f"[WS] Error procesando frame: {e}")

    def get_balance(self):
        with self._lock:
            return self._balance

    def get_server_timestamp(self):
        return self._server_timestamp

    def is_connected(self):
        """V6.3.2 FIX #5: Verifica conexion WS usando _connected flag
        Y _message_count > 0 para confirmar que realmente se reciben datos."""
        if not self._connected:
            return False
        # Si nunca recibimos ningun mensaje en 5 minutos, desconectar
        if time.time() - self._last_timesync > 300:
            logger.warning("[WS] No se recibieron mensajes WS en 5 minutos")
            return False
        # V6.3.2: Verificar que realmente estamos recibiendo mensajes
        if self._message_count == 0:
            logger.debug("[WS] WS conectado pero 0 mensajes recibidos")
        return True

    @property
    def message_count(self):
        """V6.3.2: Retorna el total de mensajes WS recibidos."""
        return self._message_count

    def get_actives(self):
        with self._lock:
            return self._actives.copy()

    def get_profit(self):
        with self._lock:
            return self._profit.copy()

    def get_candles(self, instrument):
        with self._lock:
            return self._candles_cache.get(instrument, [])

    def get_trade_result(self, order_id):
        with self._lock:
            return self._trade_results.pop(str(order_id), None)

    # ============================================================
    # V7.1: Process balance data from ssid/profile/init messages
    # ============================================================
    def _process_balance_from_ssid(self, msg):
        """V7.1 CRITICAL FIX: Extract balance data from ssid/init messages.

        IQ Option sends ALL account data in the ssid message:
        {
          "ssid": "...",
          "balance": 10000.0,           # Current active balance
          "balance_id": 12345,          # Current active balance_id
          "balances": [
            {"id": 12345, "type": 1, "amount": 10000.0},  # Practice
            {"id": 12346, "type": 4, "amount": 5.0}       # Real
          ]
        }

        Also handles the profile message format:
        {
          "balances": [...],
          "balance_id": 12345,
          ...
        }

        And the balance-changed/update format:
        {
          "id": 12345,
          "amount": 9995.0,
          "type": 1
        }
        """
        try:
            if not isinstance(msg, dict):
                return

            # Extract balance_id (tells us which account is active)
            bid = msg.get("balance_id", None)
            if bid:
                self._active_balance_id = bid
                logger.debug(f"[WS] Active balance_id: {bid}")

            # Extract current balance from top-level field
            current_balance = msg.get("balance", 0)
            if current_balance and float(current_balance) > 0:
                with self._lock:
                    old = self._balance
                    self._balance = float(current_balance)
                if abs(self._balance - old) > 0.01:
                    logger.info(f"[WS] Balance actualizado (top-level): "
                                f"${old:.2f} -> ${self._balance:.2f}")

            # Extract balances array (contains BOTH Practice and Real)
            balances = msg.get("balances", [])
            if isinstance(balances, list):
                for b in balances:
                    if not isinstance(b, dict):
                        continue
                    bid = b.get("id", None)
                    btype = b.get("type", 0)
                    bamt = b.get("amount", 0)

                    # V7.3 CRITICAL FIX: type=1 = REAL, type=4 = PRACTICE
                    # IQ Option's WS protocol:
                    #   type 1 = Real money account
                    #   type 4 = Practice/Demo account
                    if btype == 4:
                        self._practice_balance_id = bid
                        self._practice_balance = float(bamt) if bamt else 0.0
                        logger.info(f"[WS] Practice balance (type=4): "
                                    f"${self._practice_balance:.2f} "
                                    f"(id={bid})")
                    elif btype == 1:
                        self._real_balance_id = bid
                        self._real_balance = float(bamt) if bamt else 0.0
                        logger.info(f"[WS] Real balance (type=1): "
                                    f"${self._real_balance:.2f} "
                                    f"(id={bid})")

                # Update active balance based on balance_id
                if self._active_balance_id:
                    for b in balances:
                        if isinstance(b, dict) and b.get("id") == self._active_balance_id:
                            bamt = b.get("amount", 0)
                            if bamt:
                                with self._lock:
                                    old = self._balance
                                    self._balance = float(bamt)
                                if abs(self._balance - old) > 0.01:
                                    logger.info(f"[WS] Balance activo "
                                                f"(id={self._active_balance_id}): "
                                                f"${old:.2f} -> ${self._balance:.2f}")

            # Also check for single balance update (e.g., after trade)
            # Format: {"id": 12345, "amount": 9995.0, "type": 1}
            # V7.3: type=1=Real, type=4=Practice
            if "amount" in msg and "id" in msg and "type" in msg:
                bid = msg.get("id")
                btype = msg.get("type", 0)
                bamt = msg.get("amount", 0)
                if bamt:
                    if btype == 4:
                        self._practice_balance = float(bamt)
                        self._practice_balance_id = bid
                    elif btype == 1:
                        self._real_balance = float(bamt)
                        self._real_balance_id = bid
                    # If this is the active balance, update
                    if bid == self._active_balance_id:
                        with self._lock:
                            old = self._balance
                            self._balance = float(bamt)
                        if abs(self._balance - old) > 0.01:
                            logger.info(f"[WS] Balance activo actualizado: "
                                        f"${old:.2f} -> ${self._balance:.2f}")

        except Exception as e:
            logger.debug(f"[WS] Error processing balance from ssid: {e}")

    def get_practice_balance(self):
        """V7.1: Returns the Practice account balance."""
        with self._lock:
            return self._practice_balance

    def get_real_balance(self):
        """V7.1: Returns the Real account balance."""
        with self._lock:
            return self._real_balance

    def get_balance_id(self, mode="PRACTICE"):
        """V7.1: Returns the balance_id for the specified account mode."""
        if mode == "PRACTICE":
            return self._practice_balance_id
        return self._real_balance_id

    def get_active_balance_id(self):
        """V7.1: Returns the currently active balance_id."""
        return self._active_balance_id

    # ============================================================
    # V7: Helper methods for processing complex WS data
    # ============================================================
    def _process_actives_data(self, data):
        """Process actives/instruments data from any WS message format."""
        try:
            if isinstance(data, dict):
                with self._lock:
                    self._actives.update(data)
                # Also try to extract as list of dicts
                for key in ("actives", "instruments", "items", "list"):
                    items = data.get(key, [])
                    if isinstance(items, list):
                        for item in items:
                            if isinstance(item, dict):
                                name = item.get("name", item.get("instrument", ""))
                                aid = item.get("id", item.get("active_id",
                                          item.get("activeId", "")))
                                if name:
                                    with self._lock:
                                        self._actives[name] = aid
            elif isinstance(data, list):
                for item in data:
                    if isinstance(item, dict):
                        name = item.get("name", item.get("instrument", ""))
                        aid = item.get("id", item.get("active_id",
                                  item.get("activeId", "")))
                        if name:
                            with self._lock:
                                self._actives[name] = aid
        except Exception as e:
            logger.debug(f"[WS] Error processing actives data: {e}")

    def _process_result_message(self, msg_name, full_data):
        """V7.2: Process result messages which often contain requested data.
        IQ Option uses request-response over WS:
        Client sends: ["sendMessage", {"name": "request-name", "msg": {...}}]
        Server responds: ["result", {"id": request_id, "msg": {...}}]
        """
        try:
            msg = full_data.get("msg", {})
            if not isinstance(msg, dict):
                return

            # V7.2: Extract active_id to instrument name mapping
            # Result messages for instrument queries contain this data
            if "active_id" in msg and "active_name" in msg:
                active_name = msg.get("active_name", "")
                active_id = msg.get("active_id", "")
                if active_name and active_id:
                    with self._lock:
                        self._actives[active_name] = active_id
                    # Also store with -OTC suffix if not present
                    if "-OTC" in active_name.upper() or "_otc" in active_name.lower():
                        otc_name = active_name.upper().replace("_OTC", "-OTC") if "_otc" in active_name.lower() else active_name
                        with self._lock:
                            self._actives[otc_name] = active_id

            # V7.2: Extract actives from trading-settings result messages
            # Format: {"actives": [{"active_id": 2328, "name": "EURUSD", ...}, ...]}
            for key in ("actives", "instruments", "active_list"):
                if key in msg:
                    items = msg[key]
                    if isinstance(items, list):
                        for item in items:
                            if isinstance(item, dict):
                                name = item.get("name", item.get("active_name", ""))
                                aid = item.get("id", item.get("active_id", item.get("activeId", "")))
                                if name and aid:
                                    with self._lock:
                                        self._actives[name] = aid
                                    # Store normalized OTC name
                                    if "-OTC" in str(name).upper() or "_otc" in str(name).lower():
                                        otc_name = str(name).upper().replace("_OTC", "-OTC") if "_otc" in str(name).lower() else str(name)
                                        with self._lock:
                                            self._actives[otc_name] = aid
                    elif isinstance(items, dict):
                        self._process_actives_data(items)

            # Also check for instruments list in result
            instruments = msg.get("instruments", msg.get("actives", []))
            if isinstance(instruments, list):
                for inst in instruments:
                    if isinstance(inst, dict):
                        name = inst.get("name", inst.get("active_name", ""))
                        aid = inst.get("id", inst.get("active_id", inst.get("activeId", "")))
                        if name and aid:
                            with self._lock:
                                self._actives[name] = aid
                            # Store normalized name
                            if "-OTC" in str(name).upper() or "_otc" in str(name).lower():
                                otc_name = str(name).upper().replace("_OTC", "-OTC") if "_otc" in str(name).lower() else str(name)
                                with self._lock:
                                    self._actives[otc_name] = aid

            # Check for actives data in result
            if any(k in msg for k in ("actives", "instruments",
                                       "active_list")):
                self._process_actives_data(
                    msg.get("actives", msg.get("instruments", {})))

            # Check for profit data in result
            for key in ("profit", "turbo", "binary", "payout"):
                if key in msg:
                    profit_data = msg[key]
                    if isinstance(profit_data, dict):
                        with self._lock:
                            self._profit.update(profit_data)
                    elif isinstance(profit_data, list):
                        for item in profit_data:
                            if isinstance(item, dict):
                                name = item.get("name",
                                        item.get("instrument", ""))
                                if name:
                                    with self._lock:
                                        self._profit[name] = item

            # Check for instrument-specific profit in result
            # Format: {"name": "EURUSD-OTC", "profit": {"turbo": 0.87, ...}}
            name = msg.get("name", msg.get("instrument", ""))
            if name and any(k in msg for k in ("turbo", "binary", "profit")):
                with self._lock:
                    self._profit[name] = msg

        except Exception as e:
            logger.debug(f"[WS] Error processing result message: {e}")


# ============================================================
# IQ_OPTION_PLAYWRIGHT - Reemplazo Drop-In para IQ_Option_Patched
# ============================================================
class IQ_Option_Patched:
    """
    Wrapper de IQ Option usando Playwright para automatizacion de navegador real.
    INDETECTABLE: Usa navegador Chrome real, TLS real, WS real, mouse real.

    V6.3.2 FIXES:
    - _headless=True por defecto (FIX #4)
    - Brave browser support (FIX #3)
    - JS-based account switching (FIX #2)
    - Aggressive balance reading (FIX #7)
    - WS message counter (FIX #5)

    MISMA INTERFAZ que iqoption_patched.py:
    - connect() -> (bool, str|None)
    - check_connect() -> bool
    - _ensure_connected() -> bool
    - get_all_ACTIVES_OPCODE() -> dict
    - get_candles(ACTIVES, interval, count, endtime) -> list
    - buy(price, ACTIVES, ACTION, expirations) -> (bool, id)
    - check_win_v3(id_number) -> float
    - get_balance() -> float
    - get_balance_safe() -> float
    - get_all_profit() -> dict
    - change_balance(Balance_MODE) -> None
    - get_server_timestamp() -> float
    - get_async_order(id_number) -> dict
    - close() -> None
    """

    def __init__(self, email, password, _headless=True):
        """V6.3.2 FIX #4: _headless parameter default True."""
        self._email = email
        self._password = password
        self._headless = _headless
        self._bridge = _AsyncBridge()
        self._browser = None
        self._context = None
        self._page = None
        self._ws_interceptor = _WSInterceptor()
        self._connected = False
        self._connect_time = 0
        self._actives_cache = {}
        self._actives_cache_time = 0
        self._profit_cache = {}
        self._profit_cache_time = 0
        self._profit_cache_ttl = 300  # 5 minutos
        self._balance_id = None
        self._ssid = None
        # V7.3: Track which account mode is currently active (PRACTICE or REAL)
        # This is critical for returning the correct balance from get_balance()
        self._active_account_mode = "PRACTICE"  # Default to Practice
        self._last_balance_read = 0.0
        self._pending_trades = {}  # order_id -> {pre_balance, timestamp, ...}
        self._trade_counter = 0
        self._lock = threading.Lock()
        self._reconnect_count = 0
        self._max_reconnect = 5
        self._selectors = self._load_selectors()
        self._mouse_activity_thread = None
        self._mouse_activity_stop = threading.Event()
        self._ws_poller_stop = threading.Event()
        self._ws_poller_thread = None

    # ============================================================
    # SELECTOR MANAGEMENT
    # ============================================================
    def _load_selectors(self):
        """Carga selectores desde archivo JSON o usa los defaults."""
        selector_file = os.path.join(os.path.dirname(__file__), "selector_map.json")
        if os.path.exists(selector_file):
            try:
                with open(selector_file, "r") as f:
                    custom = json.load(f)
                # Merge con defaults (custom sobreescribe)
                merged = {}
                for key in DEFAULT_SELECTORS:
                    merged[key] = {**DEFAULT_SELECTORS[key], **custom.get(key, {})}
                return merged
            except Exception as e:
                logger.warning(f"[Selector] Error cargando selector_map.json: {e}")
        return DEFAULT_SELECTORS.copy()

    # ============================================================
    # BROWSER LIFECYCLE
    # ============================================================
    async def _launch_browser(self):
        """Lanza el navegador con stealth patches.

        V6.3.2 FIX #3: Intenta canales en orden: brave, chrome, chromium.
        Soporta BRAVE_PATH env variable.
        V6.3.2 FIX #4: Usa self._headless (default True).
        """
        try:
            from playwright.async_api import async_playwright

            self._playwright = await async_playwright().start()

            launch_args = [
                '--disable-blink-features=AutomationControlled',
                '--disable-features=IsolateOrigins,site-per-process',
                '--disable-site-isolation-trials',
                '--no-first-run',
                '--no-default-browser-check',
                '--disable-background-timer-throttling',
                '--disable-backgrounding-occluded-windows',
                '--disable-renderer-backgrounding',
                '--disable-component-update',
                '--disable-default-apps',
                '--disable-hang-monitor',
                '--disable-prompt-on-repost',
                '--disable-sync',
                '--metrics-recording-only',
                '--password-store=basic',
                '--use-mock-keychain',
            ]

            # V6.3.2 FIX #3: Support BRAVE_PATH env variable
            brave_path = os.environ.get("BRAVE_PATH", "")
            if brave_path and os.path.exists(brave_path):
                launch_args.append(f'--browser-path={brave_path}')

            # V6.3.2 FIX #3: Try channels in order: brave, chrome, chromium
            browser_launched = False
            for channel in ["brave", "chrome", None]:
                try:
                    kwargs = {
                        "headless": self._headless,
                        "args": launch_args,
                        "timeout": 30000,
                    }
                    if channel:
                        kwargs["channel"] = channel
                    self._browser = await self._playwright.chromium.launch(**kwargs)
                    channel_name = channel or "Chromium"
                    logger.info(f"[Playwright] {channel_name} lanzado "
                                f"(headless={self._headless})")
                    browser_launched = True
                    break
                except Exception as e:
                    channel_name = channel or "Chromium"
                    logger.debug(f"[Playwright] Canal {channel_name} no disponible: "
                                 f"{type(e).__name__}: {e}")
                    continue

            if not browser_launched:
                logger.error("[Playwright] No se pudo lanzar ningun navegador")
                return False

            # Crear contexto con fingerprint realista
            ua = random.choice(CHROME_USER_AGENTS)
            self._context = await self._browser.new_context(
                viewport={'width': 1920, 'height': 1080},
                user_agent=ua,
                locale='en-US',
                timezone_id='America/Argentina/Buenos_Aires',
                color_scheme='dark',
                device_scale_factor=1.0,
                has_touch=False,
                java_script_enabled=True,
                no_viewport=False,
            )

            # Inyectar stealth patches ANTES de cualquier pagina
            await self._context.add_init_script(STEALTH_JS)

            # V7.1: Inyectar WS sniffer que captura TODOS los mensajes
            # y los expone via window.__ouhries_ws_messages
            await self._context.add_init_script("""
                // WS Sniffer - Captura todos los mensajes WS desde dentro del navegador
                // Esto es mas confiable que Playwright CDP frame interception
                // porque captura incluso mensajes que CDP podria perder
                window.__ouhries_ws_messages = [];
                window.__ouhries_ws_sent = [];
                window.__ouhries_ws_instance = null;

                const OriginalWebSocket = window.WebSocket;
                window.WebSocket = function(...args) {
                    const ws = new OriginalWebSocket(...args);
                    window.__ouhries_ws_instance = ws;

                    ws.addEventListener('message', function(event) {
                        try {
                            const data = event.data;
                            if (typeof data === 'string') {
                                // Store last 500 messages for Python to read
                                window.__ouhries_ws_messages.push({
                                    data: data,
                                    time: Date.now()
                                });
                                if (window.__ouhries_ws_messages.length > 500) {
                                    window.__ouhries_ws_messages.shift();
                                }
                            }
                        } catch(e) {}
                    });

                    ws.addEventListener('open', function() {
                        console.log('[Ouhries] WS Opened:', ws.url);
                    });

                    // Also intercept send() to send messages for account switching
                    const originalSend = ws.send.bind(ws);
                    ws.send = function(data) {
                        try {
                            if (typeof data === 'string') {
                                window.__ouhries_ws_sent.push({
                                    data: data,
                                    time: Date.now()
                                });
                                if (window.__ouhries_ws_sent.length > 100) {
                                    window.__ouhries_ws_sent.shift();
                                }
                            }
                        } catch(e) {}
                        return originalSend(data);
                    };

                    return ws;
                };
                window.WebSocket.prototype = OriginalWebSocket.prototype;
                window.WebSocket.CONNECTING = OriginalWebSocket.CONNECTING;
                window.WebSocket.OPEN = OriginalWebSocket.OPEN;
                window.WebSocket.CLOSING = OriginalWebSocket.CLOSING;
                window.WebSocket.CLOSED = OriginalWebSocket.CLOSED;
            """)

            # Crear pagina principal
            self._page = await self._context.new_page()

            # Configurar timeout por defecto
            self._page.set_default_timeout(30000)
            self._page.set_default_navigation_timeout(60000)

            # Interceptar WebSocket
            self._page.on("websocket", self._ws_interceptor.on_ws_created)

            # Interceptar requests para debug
            self._page.on("request", self._on_request)
            self._page.on("response", self._on_response)

            logger.info(f"[Playwright] Navegador listo (UA: Chrome/"
                        f"{ua.split('Chrome/')[1].split(' ')[0]})")
            return True

        except Exception as e:
            logger.error(f"[Playwright] Error lanzando navegador: {e}")
            logger.debug(traceback.format_exc())
            return False

    def _on_request(self, request):
        """Intercepta requests HTTP para descubrir API endpoints."""
        url = request.url
        # Solo loggear endpoints de API relevantes
        if any(kw in url for kw in ['/api/', '/echo/', 'websocket', 'candles', 'instruments']):
            logger.debug(f"[HTTP] {request.method} {url[:120]}")

    def _on_response(self, response):
        """Intercepta responses HTTP para extraer datos utiles."""
        url = response.url
        status = response.status
        # Loggear redirects y errores
        if status >= 300:
            logger.debug(f"[HTTP] {status} {url[:120]}")

    # ============================================================
    # LOGIN
    # ============================================================
    async def _login(self):
        """Realiza login en IQ Option usando el navegador real.

        V6.3.2 FIX #6: Waits reducidos manteniendo simulacion humana.
        Flujo mas eficiente con menos sleep acumulativo.
        """
        try:
            sel = self._selectors["login"]
            login_url = sel["page_url"]

            logger.info(f"[Login] Navegando a {login_url}...")
            await self._page.goto(login_url, wait_until='domcontentloaded',
                                  timeout=60000)
            await asyncio.sleep(random.uniform(1.5, 2.5))

            # Esperar a que el formulario de login cargue
            email_input = None
            for selector in [sel["email_input"], 'input[name="identifier"]',
                             '#login-email-input', 'input[type="email"]',
                             'input[placeholder*="Email"]']:
                try:
                    email_input = await self._page.wait_for_selector(
                        selector, timeout=5000)
                    if email_input:
                        logger.info(f"[Login] Email input encontrado: {selector}")
                        break
                except Exception:
                    continue

            if not email_input:
                # Intentar landing page login
                logger.info("[Login] Formulario no encontrado, "
                            "intentando pagina principal...")
                await self._page.goto("https://iqoption.com/en",
                                      wait_until='domcontentloaded',
                                      timeout=60000)
                await asyncio.sleep(random.uniform(1.5, 2.5))

                # Buscar boton de login
                for btn_sel in ['button:has-text("Log in")',
                                'a:has-text("Log in")',
                                '[class*="login"]', 'button.link-ghost']:
                    try:
                        btn = await self._page.wait_for_selector(
                            btn_sel, timeout=5000)
                        if btn:
                            await btn.click()
                            await asyncio.sleep(random.uniform(1.5, 2.5))
                            break
                    except Exception:
                        continue

                # Re-buscar formulario
                for selector in [sel["email_input"],
                                 'input[name="identifier"]',
                                 '#login-email-input']:
                    try:
                        email_input = await self._page.wait_for_selector(
                            selector, timeout=5000)
                        if email_input:
                            break
                    except Exception:
                        continue

            if not email_input:
                logger.error("[Login] No se encontro el campo de email")
                return False, "Login form not found"

            # Simular actividad humana antes de escribir
            await self._human_mouse_move()
            await asyncio.sleep(random.uniform(0.3, 0.8))

            # Llenar email con simulacion de tipeo humano
            logger.info("[Login] Ingresando email...")
            await email_input.click()
            await asyncio.sleep(random.uniform(0.2, 0.5))
            await self._human_type(email_input, self._email)
            await asyncio.sleep(random.uniform(0.3, 0.8))

            # Llenar password
            logger.info("[Login] Ingresando password...")
            pw_input = None
            for selector in [sel["password_input"], 'input[name="password"]',
                             '#login-password-input', 'input[type="password"]']:
                try:
                    pw_input = await self._page.wait_for_selector(
                        selector, timeout=5000)
                    if pw_input:
                        break
                except Exception:
                    continue

            if not pw_input:
                logger.error("[Login] No se encontro el campo de password")
                return False, "Password field not found"

            await pw_input.click()
            await asyncio.sleep(random.uniform(0.2, 0.5))
            await self._human_type(pw_input, self._password)
            await asyncio.sleep(random.uniform(0.3, 0.8))

            # Click en submit
            logger.info("[Login] Enviando formulario...")
            submit_btn = None
            for selector in [sel["submit_button"], '#login-submit-button',
                             'button.Button_green', 'button[type="submit"]',
                             'button:has-text("Log In")',
                             'button:has-text("Log in")']:
                try:
                    submit_btn = await self._page.wait_for_selector(
                        selector, timeout=5000)
                    if submit_btn:
                        break
                except Exception:
                    continue

            if not submit_btn:
                logger.error("[Login] No se encontro el boton de submit")
                return False, "Submit button not found"

            # Mover el mouse al boton y hacer click
            await self._human_move_to_element(submit_btn)
            await asyncio.sleep(random.uniform(0.1, 0.3))
            await submit_btn.click()

            # Esperar redireccion al traderoom
            logger.info("[Login] Esperando redireccion al traderoom...")
            try:
                await self._page.wait_for_url("**/traderoom**", timeout=30000)
                logger.info("[Login] Redireccion al traderoom exitosa!")
            except Exception:
                # Verificar si estamos en la pagina correcta de todas formas
                current_url = self._page.url
                if "traderoom" in current_url or "trade" in current_url:
                    logger.info(f"[Login] En traderoom: {current_url}")
                else:
                    logger.warning(f"[Login] URL inesperada: {current_url}")
                    # Verificar si hay errores en la pagina
                    error_el = await self._page.query_selector(
                        '[class*="error"], [class*="Error"]')
                    if error_el:
                        error_text = await error_el.text_content()
                        logger.error(f"[Login] Error en pagina: {error_text}")
                        return False, f"Login error: {error_text}"

            # Esperar a que la pagina cargue (reducido de 5-8s a 3-5s)
            await asyncio.sleep(random.uniform(3.0, 5.0))
            try:
                await self._page.wait_for_load_state('load', timeout=15000)
            except Exception:
                logger.debug("[Login] wait_for_load_state timeout "
                             "(ignorable, WS persistente)")

            # Esperar a que aparezca el WebSocket (indicador de dashboard cargado)
            ws_wait_start = time.time()
            for _ in range(30):
                if self._ws_interceptor.is_connected():
                    break
                await asyncio.sleep(1.0)

            ws_wait_elapsed = time.time() - ws_wait_start
            if not self._ws_interceptor.is_connected():
                logger.warning("[Login] WebSocket no detectado, "
                               "pero procediendo...")
            else:
                logger.info(f"[Login] WebSocket conectado despues de "
                            f"{ws_wait_elapsed:.1f}s "
                            f"(msgs: {self._ws_interceptor.message_count})")

            # Leer balance inicial del DOM
            await asyncio.sleep(1.5)
            balance = await self._read_balance_from_dom()
            if balance > 0:
                self._ws_interceptor._balance = balance
                logger.info(f"[Login] Balance inicial (DOM): ${balance:.2f}")
            else:
                # Intentar desde WS interceptor
                balance = self._ws_interceptor.get_balance()
                if balance > 0:
                    logger.info(f"[Login] Balance inicial (WS): ${balance:.2f}")
                else:
                    logger.info("[Login] Balance inicial: pendiente de deteccion")

            # V7.2: Aggressive balance polling - wait up to 15s for balance data
            for balance_attempt in range(5):
                await self._process_js_ws_messages()
                ws_balance = self._ws_interceptor.get_balance()
                practice_bal = self._ws_interceptor.get_practice_balance()
                real_bal = self._ws_interceptor.get_real_balance()
                if ws_balance > 0 or practice_bal > 0 or real_bal > 0:
                    break
                await asyncio.sleep(3.0)
            
            # V7.2: Also try reading balance from DOM if WS didn't provide it
            if ws_balance == 0 and practice_bal == 0 and real_bal == 0:
                dom_balance = await self._read_balance_from_dom()
                if dom_balance > 0:
                    self._ws_interceptor._balance = dom_balance
                    ws_balance = dom_balance
                    logger.info(f"[Login] Balance leido del DOM: ${dom_balance:.2f}")
            
            # V7.2: As last resort, try fetching balance from API
            if ws_balance == 0 and practice_bal == 0 and real_bal == 0:
                try:
                    api_balance = await self._page.evaluate("""
                        async () => {
                            try {
                                const r = await fetch('https://iqoption.com/api/profile', {
                                    credentials: 'include'
                                });
                                if (r.ok) {
                                    const d = await r.json();
                                    if (d && d.result) {
                                        const balances = d.result.balances || [];
                                        for (const b of balances) {
                                            if (b.amount > 0) return b.amount;
                                        }
                                        if (d.result.balance > 0) return d.result.balance;
                                    }
                                }
                            } catch(e) {}
                            return 0;
                        }
                    """)
                    if api_balance and api_balance > 0:
                        self._ws_interceptor._balance = float(api_balance)
                        ws_balance = float(api_balance)
                        logger.info(f"[Login] Balance leido de API: ${api_balance:.2f}")
                except Exception as e:
                    logger.debug(f"[Login] API balance fetch error: {e}")

            if ws_balance > 0 or practice_bal > 0 or real_bal > 0:
                logger.info(f"[Login] Balances detectados - "
                            f"Activo: ${ws_balance:.2f}, "
                            f"Practice: ${practice_bal:.2f}, "
                            f"Real: ${real_bal:.2f}")
            else:
                logger.info("[Login] Balances no detectados via WS aun")

            # Descubrir selectores del dashboard
            await self._discover_dashboard_selectors()

            # V7.2: Extract instrument mapping from DOM
            await self._extract_instrument_mapping_from_dom()

            # V7.3: Request instruments list via WS for active_id mapping
            # This is CRITICAL for candle data - we need numeric active_ids
            try:
                # First, process any WS messages that arrived since DOM extraction
                await self._process_js_ws_messages()

                # Request trading settings which contain active_id lists
                # We request both turbo-option and binary-option types
                # Also request with OTC type to get OTC-specific instruments
                ws_instrument_result = await self._page.evaluate("""
                    async () => {
                        return new Promise((resolve) => {
                            try {
                                const ws = window.__ouhries_ws_instance;
                                if (!ws || ws.readyState !== WebSocket.OPEN) {
                                    resolve(null);
                                    return;
                                }

                                const allInstruments = {};
                                let pendingRequests = 3;
                                const timeout = setTimeout(() => resolve(allInstruments), 15000);

                                const handler = (event) => {
                                    try {
                                        const data = JSON.parse(event.data);
                                        let msg = null;
                                        let reqId = null;

                                        if (Array.isArray(data) && data.length >= 2 && data[0] === 'result') {
                                            reqId = data[1]?.id;
                                            msg = data[1]?.msg;
                                        } else if (data && data.name === 'result') {
                                            reqId = data.msg?.id;
                                            msg = data.msg;
                                        }

                                        if (msg && typeof msg === 'object') {
                                            // Extract instruments from the response
                                            const extractInstruments = (obj) => {
                                                if (!obj || typeof obj !== 'object') return;
                                                for (const key of ['actives', 'instruments', 'active_list']) {
                                                    if (obj[key] && Array.isArray(obj[key])) {
                                                        for (const inst of obj[key]) {
                                                            if (inst.name && (inst.active_id || inst.id)) {
                                                                allInstruments[inst.name] = inst.active_id || inst.id;
                                                            }
                                                        }
                                                    }
                                                }
                                            };
                                            extractInstruments(msg);
                                        }

                                        // Check if this is a response to our requests
                                        if (reqId && (reqId.startsWith('ouhries_inst_'))) {
                                            pendingRequests--;
                                            if (pendingRequests <= 0) {
                                                clearTimeout(timeout);
                                                ws.removeEventListener('message', handler);
                                                resolve(allInstruments);
                                            }
                                        }
                                    } catch(e) {}
                                };

                                ws.addEventListener('message', handler);

                                // Send requests for different instrument types
                                ws.send(JSON.stringify([
                                    "sendMessage",
                                    {name: "trading-settings.get-trading-group-params",
                                     version: "2.0",
                                     body: {instrument_type: "turbo-option"},
                                     id: "ouhries_inst_turbo"}
                                ]));
                                ws.send(JSON.stringify([
                                    "sendMessage",
                                    {name: "trading-settings.get-trading-group-params",
                                     version: "2.0",
                                     body: {instrument_type: "binary-option"},
                                     id: "ouhries_inst_binary"}
                                ]));
                                // Also request digital options
                                ws.send(JSON.stringify([
                                    "sendMessage",
                                    {name: "trading-settings.get-trading-group-params",
                                     version: "2.0",
                                     body: {instrument_type: "digital-option"},
                                     id: "ouhries_inst_digital"}
                                ]));
                            } catch(e) {
                                resolve(null);
                            }
                        });
                    }
                """)

                if ws_instrument_result and isinstance(ws_instrument_result, dict):
                    count_added = 0
                    for name, aid in ws_instrument_result.items():
                        if isinstance(aid, (int, float)) and int(aid) > 0:
                            self._ws_interceptor._actives[name] = int(aid)
                            count_added += 1
                            # Also store normalized OTC name
                            if "otc" in name.lower():
                                otc_name = str(name).upper().replace("_OTC", "-OTC") if "_otc" in name.lower() else str(name)
                                self._ws_interceptor._actives[otc_name] = int(aid)
                    otc_count = sum(1 for k in ws_instrument_result if "otc" in k.lower())
                    logger.info(f"[Login] Instrumentos via WS: {count_added} "
                                f"({otc_count} OTC)")

                # Also process any messages that arrived during the request
                await self._process_js_ws_messages()

                # V7.3: Log the total active_ids we have for OTC instruments
                actives = self._ws_interceptor.get_actives()
                otc_with_id = sum(1 for k, v in actives.items()
                                 if "otc" in k.lower() and
                                 isinstance(v, (int, float)) and int(v) > 0)
                logger.info(f"[Login] OTC instruments con active_id numerico: "
                            f"{otc_with_id}")
            except Exception as e:
                logger.debug(f"[Login] Instruments request error: {e}")

            # Iniciar simulacion de actividad de mouse
            self._start_mouse_activity()

            # V7.2: Iniciar WS poller dedicado para capturar balances
            self._start_ws_poller()

            logger.info("[Login] LOGIN EXITOSO - Dashboard cargado "
                        f"(WS msgs: {self._ws_interceptor.message_count})")
            return True, None

        except Exception as e:
            logger.error(f"[Login] Error: {e}")
            logger.debug(traceback.format_exc())
            return False, str(e)

    async def _discover_dashboard_selectors(self):
        """Descubre y mapea selectores del dashboard automaticamente.
        Guarda los selectores encontrados en selector_map_discovered.json."""
        try:
            logger.info("[Discovery] Mapeando elementos del dashboard...")

            discovered = {}

            # Buscar elementos clave por texto
            text_searches = {
                "call_button": ["CALL", "Call", "call", "Higher"],
                "put_button": ["PUT", "Put", "put", "Lower"],
                "amount_input": None,  # Buscar por tipo
                "balance_container": None,
            }

            for key, texts in text_searches.items():
                if texts:
                    for text in texts:
                        try:
                            el = await self._page.query_selector(
                                f'button:has-text("{text}")')
                            if el:
                                tag = await el.evaluate("el => el.tagName")
                                classes = await el.evaluate("el => el.className")
                                discovered[key] = {
                                    "text": text,
                                    "tag": tag,
                                    "classes": classes,
                                }
                                logger.info(f"[Discovery] {key}: text='{text}', "
                                            f"class='{classes[:80]}'")
                                break
                        except Exception:
                            continue

            # Buscar inputs
            inputs = await self._page.query_selector_all('input')
            for inp in inputs:
                try:
                    input_type = await inp.evaluate("el => el.type")
                    input_name = await inp.evaluate("el => el.name")
                    input_class = await inp.evaluate("el => el.className")
                    input_placeholder = await inp.evaluate("el => el.placeholder")
                    input_value = await inp.evaluate("el => el.value")

                    logger.debug(f"[Discovery] Input: type={input_type}, "
                                 f"name={input_name}, "
                                 f"class={input_class[:50]}, "
                                 f"placeholder={input_placeholder}, "
                                 f"value={input_value[:30]}")

                    # Detectar input de amount
                    if any(kw in (input_class + input_name +
                                  input_placeholder).lower()
                           for kw in ['amount', 'investment', 'price',
                                      'stake']):
                        discovered["amount_input"] = {
                            "name": input_name,
                            "class": input_class,
                            "placeholder": input_placeholder,
                        }
                        logger.info(f"[Discovery] amount_input: "
                                    f"class='{input_class[:80]}'")

                except Exception:
                    continue

            # Guardar selectores descubiertos
            if discovered:
                discover_file = os.path.join(os.path.dirname(__file__),
                                             "selector_map_discovered.json")
                with open(discover_file, "w") as f:
                    json.dump(discovered, f, indent=2)
                logger.info(f"[Discovery] Selectores guardados en "
                            f"{discover_file}")

        except Exception as e:
            logger.warning(f"[Discovery] Error: {e}")

    async def _extract_instrument_mapping_from_dom(self):
        """V7.2: Extract active_id to instrument name mapping from the 
        asset selector in the DOM. This is the most reliable way to get
        the mapping since HTTP APIs return 404 and WS messages only have
        numeric active_ids."""
        try:
            logger.info("[Mapping] Extrayendo mapeo de instrumentos del DOM...")
            
            # First, try to extract from the page's internal JS state
            mapping = await self._page.evaluate("""
                () => {
                    const mapping = {};
                    
                    // Method A: Look for instrument data in MobX stores
                    // IQ Option uses MobX, data might be in __mobxGlobals
                    try {
                        // Check for any global state with instrument data
                        const rootEl = document.getElementById('root');
                        if (rootEl) {
                            const fiberKey = Object.keys(rootEl).find(
                                k => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$')
                            );
                            if (fiberKey) {
                                let fiber = rootEl[fiberKey];
                                // Walk fiber tree looking for instrument data
                                const visited = new Set();
                                const queue = [fiber];
                                let found = 0;
                                while (queue.length > 0 && found < 300) {
                                    const node = queue.shift();
                                    if (!node || visited.has(node)) continue;
                                    visited.add(node);
                                    
                                    // Check memoizedProps for instrument data
                                    if (node.memoizedProps) {
                                        const props = node.memoizedProps;
                                        if (props.instruments && Array.isArray(props.instruments)) {
                                            for (const inst of props.instruments) {
                                                if (inst.active_id && inst.name) {
                                                    mapping[inst.name] = inst.active_id;
                                                    found++;
                                                }
                                                if (inst.id && inst.name) {
                                                    mapping[inst.name] = inst.id;
                                                    found++;
                                                }
                                            }
                                        }
                                        if (props.actives && Array.isArray(props.actives)) {
                                            for (const a of props.actives) {
                                                if (a.id && a.name) {
                                                    mapping[a.name] = a.id;
                                                    found++;
                                                }
                                            }
                                        }
                                    }
                                    
                                    // Check memoizedState
                                    if (node.memoizedState && typeof node.memoizedState === 'object') {
                                        let state = node.memoizedState;
                                        for (let i = 0; i < 10 && state; i++) {
                                            if (state.queue && state.queue.lastRenderedState) {
                                                const rs = state.queue.lastRenderedState;
                                                if (rs && rs.instruments && Array.isArray(rs.instruments)) {
                                                    for (const inst of rs.instruments) {
                                                        if ((inst.active_id || inst.id) && inst.name) {
                                                            mapping[inst.name] = inst.active_id || inst.id;
                                                            found++;
                                                        }
                                                    }
                                                }
                                            }
                                            state = state.next;
                                        }
                                    }
                                    
                                    // Add children to queue
                                    if (node.child) queue.push(node.child);
                                    if (node.sibling) queue.push(node.sibling);
                                    if (node.return) queue.push(node.return);
                                }
                            }
                        }
                    } catch(e) {}
                    
                    return mapping;
                }
            """)
            
            if mapping and len(mapping) > 0:
                # Store in WS interceptor's actives cache
                for name, aid in mapping.items():
                    self._ws_interceptor._actives[name] = aid
                    # Also store normalized OTC names
                    if "otc" in name.lower():
                        otc_name = name.upper().replace("_OTC", "-OTC") if "_otc" in name.lower() else name
                        self._ws_interceptor._actives[otc_name] = aid
                
                otc_count = sum(1 for k in mapping if "otc" in k.lower())
                logger.info(f"[Mapping] Extraidos {len(mapping)} instrumentos del DOM "
                           f"({otc_count} OTC)")
                return True
            
            # Method B: If DOM extraction failed, try opening asset selector
            logger.info("[Mapping] DOM extraction no encontro datos, "
                       "intentando via selector de assets...")
            
            # Click the asset selector button to open the instrument list
            for selector in ['[class*="asset-selector"]', '[class*="current-asset"]',
                           '[class*="instrument"]', '[class*="AssetSelector"]']:
                try:
                    el = await self._page.wait_for_selector(selector, timeout=3000)
                    if el:
                        await el.click()
                        await asyncio.sleep(2.0)
                        break
                except Exception:
                    continue
            
            # Try to read instrument names from the opened selector
            instruments = await self._page.evaluate("""
                () => {
                    const items = [];
                    // Find all instrument items in the asset selector
                    const elements = document.querySelectorAll(
                        '[class*="asset-item"], [class*="instrument-item"], '
                        + '[class*="AssetItem"], [class*="row"]'
                    );
                    for (const el of elements) {
                        const text = el.textContent?.trim() || '';
                        const dataId = el.getAttribute('data-id') 
                                    || el.getAttribute('data-active-id')
                                    || el.getAttribute('data-asset-id');
                        if (text && dataId) {
                            items.push({name: text, id: dataId});
                        }
                    }
                    return items;
                }
            """)
            
            # Close the selector
            await self._page.keyboard.press("Escape")
            await asyncio.sleep(0.5)
            
            if instruments and isinstance(instruments, list):
                for item in instruments:
                    name = item.get("name", "")
                    aid = item.get("id", "")
                    if name and aid:
                        self._ws_interceptor._actives[name] = aid
                        if "otc" in name.lower():
                            otc_name = name.upper().replace("_OTC", "-OTC") if "_otc" in name.lower() else name
                            self._ws_interceptor._actives[otc_name] = aid
                
                otc_count = sum(1 for k in self._ws_interceptor._actives if "otc" in k.lower())
                logger.info(f"[Mapping] Extraidos {len(instruments)} instrumentos del selector "
                           f"({otc_count} OTC)")
                return True
            
            logger.warning("[Mapping] No se pudieron extraer instrumentos del DOM")
            return False
            
        except Exception as e:
            logger.warning(f"[Mapping] Error: {e}")
            return False

    # ============================================================
    # HUMAN SIMULATION - Movimientos de mouse, tipeo, scroll
    # ============================================================
    async def _human_mouse_move(self):
        """Simula movimiento aleatorio de mouse por la pagina."""
        try:
            for _ in range(random.randint(2, 5)):
                x = random.randint(200, 1700)
                y = random.randint(200, 800)
                await self._page.mouse.move(x, y,
                                             steps=random.randint(5, 15))
                await asyncio.sleep(random.uniform(0.05, 0.2))
        except Exception:
            pass

    async def _human_move_to_element(self, element):
        """Mueve el mouse a un elemento con trayectoria humana."""
        try:
            box = await element.bounding_box()
            if not box:
                await element.click()
                return

            # Centro del elemento con pequena variacion
            target_x = box['x'] + box['width'] / 2 + random.uniform(-5, 5)
            target_y = box['y'] + box['height'] / 2 + random.uniform(-5, 5)

            # Movimiento en pasos (como un humano)
            steps = random.randint(10, 25)
            await self._page.mouse.move(target_x, target_y, steps=steps)
            await asyncio.sleep(random.uniform(0.1, 0.3))
        except Exception:
            try:
                await element.click()
            except Exception:
                pass

    async def _human_type(self, element, text):
        """Escribe texto simulando tipeo humano con delays variables."""
        try:
            await element.click()
            await asyncio.sleep(random.uniform(0.1, 0.3))
            # Limpiar campo existente
            await element.fill("")
            await asyncio.sleep(random.uniform(0.1, 0.3))

            for char in text:
                await element.type(char, delay=random.randint(30, 150))
                # Pausa mas larga en algunos caracteres (como pensamiento)
                if random.random() < 0.1:
                    await asyncio.sleep(random.uniform(0.2, 0.5))
        except Exception:
            # Fallback: fill directo
            try:
                await element.fill(text)
            except Exception:
                pass

    async def _human_scroll(self, direction="down", amount=3):
        """Simula scroll humano en la pagina."""
        try:
            delta_y = 300 if direction == "down" else -300
            for _ in range(amount):
                await self._page.mouse.wheel(
                    0, delta_y + random.randint(-50, 50))
                await asyncio.sleep(random.uniform(0.3, 0.8))
        except Exception:
            pass

    def _start_mouse_activity(self):
        """Inicia thread que simula actividad periodica de mouse.
        Hace que la sesion parezca activa incluso cuando el bot no
        esta operando."""
        if self._mouse_activity_thread and self._mouse_activity_thread.is_alive():
            return

        self._mouse_activity_stop.clear()

        def _activity_loop():
            logger.info("[MouseActivity] Iniciado - simulando actividad humana")
            while not self._mouse_activity_stop.is_set():
                try:
                    self._mouse_activity_stop.wait(
                        timeout=random.uniform(5, 10))
                    if self._mouse_activity_stop.is_set():
                        break

                    if not self._page or not self._connected:
                        continue

                    # V7.1: Poll JS WS messages to capture any missed messages
                    self._poll_js_ws_messages()

                    # Ejecutar actividad aleatoria
                    async def _do_activity():
                        actions = [
                            self._human_mouse_move,
                            self._noise_browse_instruments,
                        ]
                        action = random.choice(actions)
                        try:
                            if asyncio.iscoroutinefunction(action):
                                await action()
                        except Exception:
                            pass
                        # Scroll
                        try:
                            if random.random() < 0.5:
                                await self._human_scroll(
                                    "down", random.randint(1, 3))
                            elif random.random() < 0.3:
                                await self._human_scroll(
                                    "up", random.randint(1, 2))
                        except Exception:
                            pass

                    try:
                        self._bridge.run(_do_activity(), timeout=15)
                    except Exception:
                        pass

                except Exception:
                    pass

            logger.info("[MouseActivity] Detenido")

        self._mouse_activity_thread = threading.Thread(
            target=_activity_loop, daemon=True)
        self._mouse_activity_thread.start()

    def _start_ws_poller(self):
        """V7.2: Dedicated thread to poll JS WS messages frequently.
        This ensures balance updates are captured even when mouse activity is idle."""
        if hasattr(self, '_ws_poller_thread') and self._ws_poller_thread and self._ws_poller_thread.is_alive():
            return

        self._ws_poller_stop.clear()

        def _poll_loop():
            logger.info("[WS-Poller] Iniciado - polling de mensajes WS cada 3-5s")
            while not self._ws_poller_stop.is_set():
                try:
                    self._ws_poller_stop.wait(timeout=random.uniform(3, 5))
                    if self._ws_poller_stop.is_set():
                        break
                    if not self._page or not self._connected:
                        continue
                    self._poll_js_ws_messages()
                except Exception:
                    pass
            logger.info("[WS-Poller] Detenido")

        self._ws_poller_thread = threading.Thread(target=_poll_loop, daemon=True)
        self._ws_poller_thread.start()

    def _stop_mouse_activity(self):
        """Detiene la simulacion de actividad de mouse."""
        self._mouse_activity_stop.set()
        if hasattr(self, '_ws_poller_stop'):
            self._ws_poller_stop.set()

    # ============================================================
    # NOISE BROWSING - Actividad fuera de trading
    # ============================================================
    async def _noise_browse_instruments(self):
        """Simula navegacion por instrumentos (como un usuario explorando)."""
        try:
            # Intentar abrir el selector de assets
            sel = self._selectors["trading"]
            for selector in [sel["asset_selector_button"],
                             '[class*="asset"]',
                             '[class*="instrument"]']:
                try:
                    el = await self._page.wait_for_selector(
                        selector, timeout=3000)
                    if el:
                        await self._human_move_to_element(el)
                        await el.click()
                        await asyncio.sleep(random.uniform(1.0, 2.5))

                        # Scroll por la lista
                        await self._human_scroll("down",
                                                 random.randint(2, 5))
                        await asyncio.sleep(random.uniform(1.0, 3.0))

                        # Cerrar selector (presionar Escape)
                        await self._page.keyboard.press("Escape")
                        await asyncio.sleep(random.uniform(0.5, 1.0))
                        break
                except Exception:
                    continue
        except Exception as e:
            logger.debug(f"[Noise] browse_instruments: {e}")

    # ============================================================
    # V7.1: JS WS MESSAGE PROCESSING - Backup sniffer
    # ============================================================
    async def _process_js_ws_messages(self):
        """V7.2: Lee mensajes WS capturados por el sniffer JavaScript.
        Also extracts balance data directly from JS for reliability."""
        try:
            result = await self._page.evaluate("""
                () => {
                    const msgs = window.__ouhries_ws_messages || [];
                    window.__ouhries_ws_messages = [];
                    
                    // V7.2: Also try to extract balance directly from the page
                    let balanceInfo = null;
                    try {
                        // Try to find balance from any element with $ sign
                        const allEls = document.querySelectorAll('*');
                        for (const el of allEls) {
                            if (el.children.length > 3) continue;
                            const text = (el.textContent || '').trim();
                            const m = text.match(/[$]\\s*([\\d,]+\\.\\d{2})/);
                            if (m) {
                                const val = parseFloat(m[1].replace(/,/g, ''));
                                if (val > 0 && val < 1000000) {
                                    balanceInfo = val;
                                    break;
                                }
                            }
                        }
                    } catch(e) {}
                    
                    return {
                        messages: msgs.map(m => m.data),
                        balance: balanceInfo
                    };
                }
            """)
            if not result:
                return
            
            messages = result.get("messages", [])
            js_balance = result.get("balance", 0)
            
            if messages and isinstance(messages, list):
                count = len(messages)
                if count > 0:
                    logger.debug(f"[JS-WS] Procesando {count} mensajes capturados")
                    for msg_data in messages:
                        if isinstance(msg_data, str):
                            self._ws_interceptor._on_frame_received(msg_data)
            
            # V7.2: If JS found a balance directly and WS doesn't have it yet
            if js_balance and js_balance > 0:
                current_ws_balance = self._ws_interceptor.get_balance()
                if current_ws_balance == 0:
                    self._ws_interceptor._balance = float(js_balance)
                    logger.info(f"[JS-WS] Balance detectado desde DOM: ${js_balance:.2f}")
        except Exception as e:
            logger.debug(f"[JS-WS] Error procesando mensajes JS: {e}")

    def _poll_js_ws_messages(self):
        """V7.1: Polling periodico de mensajes WS desde el sniffer JS.
        Se llama periodicamente para capturar mensajes que CDP pierde.
        """
        try:
            async def _poll():
                await self._process_js_ws_messages()

            self._bridge.run(_poll(), timeout=5)
        except Exception:
            pass

    # ============================================================
    # BALANCE READING
    # ============================================================
    async def _read_balance_from_dom(self):
        """Lee el balance del DOM de la pagina.

        V7.1: Multiple strategies including IQ Option's internal state:
        1. Redux store (__store__) - most reliable
        2. CSS selectors (balance container)
        3. Text pattern search
        4. Aggressive JS scan of all elements
        5. Currency pattern in text nodes
        """
        try:
            # V7.1 Strategy 0: Read from IQ Option's internal Redux store
            # This is the MOST reliable method because IQ Option stores
            # the current balance in its React/Redux state
            try:
                balance = await self._page.evaluate("""
                    () => {
                        // Method 0: Try Redux store
                        try {
                            // IQ Option uses Redux in its traderoom app
                            // The store is accessible via window.__store__
                            // or via React fiber nodes
                            if (window.__store__) {
                                const state = window.__store__.getState();
                                if (state) {
                                    // Try common Redux state paths for balance
                                    for (const key of ['balance', 'user',
                                                        'account', 'portfolio']) {
                                        if (state[key]) {
                                            const sub = state[key];
                                            if (typeof sub.balance === 'number' && sub.balance > 0)
                                                return sub.balance;
                                            if (sub.currentBalance > 0)
                                                return sub.currentBalance;
                                            if (sub.amount > 0)
                                                return sub.amount;
                                        }
                                    }
                                }
                            }
                        } catch(e) {}

                        // Method 0b: Try React fiber nodes
                        try {
                            const rootEl = document.getElementById('root')
                                || document.getElementById('app')
                                || document.querySelector('[data-reactroot]');
                            if (rootEl) {
                                const fiberKey = Object.keys(rootEl)
                                    .find(k => k.startsWith('__reactFiber$')
                                             || k.startsWith('__reactInternalInstance$'));
                                if (fiberKey) {
                                    let fiber = rootEl[fiberKey];
                                    // Walk up fiber tree to find state with balance
                                    for (let i = 0; i < 20 && fiber; i++) {
                                        if (fiber.memoizedState) {
                                            const state = fiber.memoizedState;
                                            if (typeof state === 'object') {
                                                for (const key of ['balance',
                                                                    'currentBalance',
                                                                    'amount']) {
                                                    if (state[key] && Number(state[key]) > 0)
                                                        return Number(state[key]);
                                                }
                                            }
                                        }
                                        fiber = fiber.return;
                                    }
                                }
                            }
                        } catch(e) {}

                        return 0;
                    }
                """)
                if balance and balance > 0:
                    logger.info(f"[Balance] Leido de Redux/React: ${balance:.2f}")
                    return float(balance)
            except Exception as e:
                logger.debug(f"[Balance] Redux/React read error: {e}")

            sel = self._selectors["dashboard"]

            # Estrategia 1: Selector conocido
            for selector in [sel["balance_container"],
                             '[class*="balance-amount"]',
                             '[class*="Balance"]',
                             '[class*="user-balance"]',
                             '[data-test*="balance"]']:
                try:
                    el = await self._page.wait_for_selector(
                        selector, timeout=3000)
                    if el:
                        text = await el.text_content()
                        if text:
                            # Parsear numero del texto
                            cleaned = re.sub(r'[^\d.,\-]', '', text)
                            cleaned = cleaned.replace(',', '.')
                            if cleaned:
                                val = float(cleaned)
                                if val > 0:
                                    return val
                except Exception:
                    continue

            # Estrategia 2: Buscar por texto con patron de moneda
            try:
                elements = await self._page.query_selector_all('span, div, p')
                for el in elements:
                    try:
                        text = await el.text_content()
                        if text and re.match(
                                r'^\$?\d{1,3}[.,]?\d{0,2}$',
                                text.strip()):
                            cleaned = re.sub(r'[^\d.,]', '', text.strip())
                            cleaned = cleaned.replace(',', '.')
                            if cleaned and float(cleaned) > 0:
                                return float(cleaned)
                    except Exception:
                        continue
            except Exception:
                pass

            # V6.3.2 FIX #7: Estrategia 3: JavaScript agresivo que escanea
            # todos los elementos y nodos de texto
            try:
                balance = await self._page.evaluate("""
                    () => {
                        // Method A: Common balance containers
                        const selectors = [
                            '[class*="balance"]', '[class*="Balance"]',
                            '[class*="amount"]', '[data-test*="balance"]',
                            '[class*="user-balance"]',
                            '[class*="account-balance"]'
                        ];
                        for (const sel of selectors) {
                            const els = document.querySelectorAll(sel);
                            for (const el of els) {
                                const text = el.textContent?.trim() || '';
                                const match = text.match(
                                    /[\\$\\u20AC]?\\s*([\\d,]+\\.?\\d{0,2})/
                                );
                                if (match) {
                                    const val = parseFloat(
                                        match[1].replace(/,/g, '')
                                    );
                                    if (val > 0 && val < 1000000) return val;
                                }
                            }
                        }

                        // Method B: Scan all visible text nodes
                        const walker = document.createTreeWalker(
                            document.body, NodeFilter.SHOW_TEXT, null, false
                        );
                        while (walker.nextNode()) {
                            const text = walker.currentNode.textContent.trim();
                            const match = text.match(
                                /^\\s*[\\$\\u20AC]?\\s*([\\d,]+\\.?\\d{2})\\s*$/
                            );
                            if (match) {
                                const val = parseFloat(
                                    match[1].replace(/,/g, '')
                                );
                                if (val > 0 && val < 1000000) return val;
                            }
                        }

                        // Method C: Look for currency-formatted values
                        // in any element with few children
                        const allEls = document.querySelectorAll('*');
                        for (const el of allEls) {
                            if (el.children.length > 2) continue;
                            const text = el.textContent?.trim() || '';
                            // Match patterns like $1,234.56 or 1234.56
                            const match = text.match(
                                /[\\$\\u20AC]\\s*([\\d,]+\\.\\d{2})/
                            );
                            if (match) {
                                const val = parseFloat(
                                    match[1].replace(/,/g, '')
                                );
                                if (val > 0 && val < 1000000) return val;
                            }
                        }

                        return 0;
                    }
                """)
                if balance and balance > 0:
                    return float(balance)
            except Exception as e:
                logger.debug(f"[Balance] JS scan error: {e}")

            return 0.0

        except Exception as e:
            logger.debug(f"[Balance] Error leyendo del DOM: {e}")
            return 0.0

    # ============================================================
    # TRADE EXECUTION
    # ============================================================
    async def _navigate_to_asset(self, instrument_name):
        """Navega a un activo especifico en la interfaz de trading."""
        try:
            sel = self._selectors["trading"]

            # Si ya estamos en el activo correcto, no hacer nada
            current_asset = await self._get_current_asset()
            if current_asset and instrument_name.upper() in current_asset.upper():
                logger.debug(f"[Trade] Ya en {instrument_name}")
                return True

            # Abrir selector de assets
            for selector in [sel["asset_selector_button"],
                             '[class*="asset-selector"]',
                             '[class*="current-asset"]',
                             '[class*="instrument"]']:
                try:
                    el = await self._page.wait_for_selector(
                        selector, timeout=3000)
                    if el:
                        await self._human_move_to_element(el)
                        await el.click()
                        await asyncio.sleep(random.uniform(1.0, 2.0))
                        break
                except Exception:
                    continue

            # Si es OTC, intentar filtrar
            if "-OTC" in instrument_name.upper():
                for selector in [sel["otc_tab"],
                                 'button:has-text("OTC")',
                                 '[class*="otc"]', '[class*="OTC"]']:
                    try:
                        el = await self._page.wait_for_selector(
                            selector, timeout=3000)
                        if el:
                            await self._human_move_to_element(el)
                            await el.click()
                            await asyncio.sleep(random.uniform(0.5, 1.5))
                            break
                    except Exception:
                        continue

            # Buscar el activo
            for selector in [sel["asset_search_input"],
                             'input[class*="search"]',
                             'input[placeholder*="Search"]']:
                try:
                    search_input = await self._page.wait_for_selector(
                        selector, timeout=3000)
                    if search_input:
                        # Limpiar y escribir nombre del activo
                        await search_input.click()
                        await asyncio.sleep(0.3)
                        await search_input.fill("")
                        # Escribir sin el sufijo -OTC para mejor busqueda
                        search_name = instrument_name.replace(
                            "-OTC", "").replace("_otc", "")
                        await self._human_type(search_input, search_name)
                        await asyncio.sleep(random.uniform(1.0, 2.0))
                        break
                except Exception:
                    continue

            # Click en el activo de la lista de resultados
            asset_found = False
            # Buscar por texto del nombre del activo
            for text_variant in [instrument_name,
                                 instrument_name.replace("-OTC", ""),
                                 instrument_name.replace("-", " "),
                                 instrument_name.upper()]:
                try:
                    el = await self._page.wait_for_selector(
                        f'text="{text_variant}"', timeout=3000)
                    if el:
                        await self._human_move_to_element(el)
                        await el.click()
                        asset_found = True
                        await asyncio.sleep(random.uniform(1.0, 2.5))
                        break
                except Exception:
                    continue

            if not asset_found:
                # Intentar buscar en la lista de assets visibles
                try:
                    items = await self._page.query_selector_all(
                        '[class*="asset-item"], '
                        '[class*="instrument-item"]')
                    for item in items:
                        text = await item.text_content()
                        if text and instrument_name.replace(
                                "-OTC", "") in text.upper():
                            await self._human_move_to_element(item)
                            await item.click()
                            asset_found = True
                            await asyncio.sleep(random.uniform(1.0, 2.5))
                            break
                except Exception:
                    pass

            if not asset_found:
                logger.warning(f"[Trade] No se pudo navegar a "
                               f"{instrument_name}")
                return False

            logger.info(f"[Trade] Navegado a {instrument_name}")
            return True

        except Exception as e:
            logger.error(f"[Trade] Error navegando a "
                         f"{instrument_name}: {e}")
            return False

    async def _get_current_asset(self):
        """Obtiene el nombre del activo actualmente seleccionado."""
        try:
            sel = self._selectors["trading"]
            for selector in [sel["asset_selector_button"],
                             '[class*="current-asset"]',
                             '[class*="asset-name"]']:
                try:
                    el = await self._page.wait_for_selector(
                        selector, timeout=2000)
                    if el:
                        text = await el.text_content()
                        if text:
                            return text.strip()
                except Exception:
                    continue
            return None
        except Exception:
            return None

    async def _set_amount(self, amount):
        """Establece el monto de la operacion."""
        try:
            sel = self._selectors["trading"]

            # Buscar input de amount
            amount_input = None
            for selector in [sel["amount_input"],
                             'input[class*="amount"]',
                             'input[name*="amount"]',
                             'input[class*="investment"]',
                             'input[class*="stake"]']:
                try:
                    amount_input = await self._page.wait_for_selector(
                        selector, timeout=3000)
                    if amount_input:
                        break
                except Exception:
                    continue

            if not amount_input:
                logger.warning("[Trade] No se encontro input de amount")
                return False

            # Click, limpiar y escribir el monto
            await self._human_move_to_element(amount_input)
            await amount_input.click()
            await asyncio.sleep(random.uniform(0.2, 0.5))

            # Seleccionar todo y borrar
            await self._page.keyboard.press("Control+a")
            await asyncio.sleep(0.1)

            # Escribir monto
            await self._human_type(amount_input, f"{amount:.2f}")
            await asyncio.sleep(random.uniform(0.3, 0.8))

            # Tab para salir del campo
            await self._page.keyboard.press("Tab")
            await asyncio.sleep(0.3)

            return True

        except Exception as e:
            logger.error(f"[Trade] Error estableciendo monto: {e}")
            return False

    async def _set_expiration(self, expiration_minutes):
        """Establece el tiempo de expiracion."""
        if expiration_minutes == 1:
            # 1 minuto es generalmente el default para opciones binarias turbo
            return True

        try:
            sel = self._selectors["trading"]
            for selector in [sel["expiration_selector"],
                             '[class*="expiration"]',
                             '[class*="expiry"]']:
                try:
                    el = await self._page.wait_for_selector(
                        selector, timeout=3000)
                    if el:
                        await el.click()
                        await asyncio.sleep(0.5)

                        # Buscar la opcion de 1 minuto
                        for min_selector in [sel["expiration_1min"],
                                             'button:has-text("1 min")',
                                             'text="1m"', 'text="1 min"']:
                            try:
                                opt = await self._page.wait_for_selector(
                                    min_selector, timeout=2000)
                                if opt:
                                    await opt.click()
                                    await asyncio.sleep(0.5)
                                    return True
                            except Exception:
                                continue
                except Exception:
                    continue
        except Exception:
            pass

        return True  # Default es 1 min generalmente

    async def _click_call_or_put(self, direction):
        """Hace click en CALL o PUT con movimiento de mouse realista."""
        try:
            sel = self._selectors["trading"]

            if direction.lower() == "call":
                selectors = [sel["call_button"],
                             'button:has-text("CALL")',
                             '[class*="call-btn"]',
                             '[class*="btn-call"]',
                             '[class*="CallButton"]',
                             '[class*="up-btn"]',
                             'button[class*="green"]']
            else:
                selectors = [sel["put_button"],
                             'button:has-text("PUT")',
                             '[class*="put-btn"]',
                             '[class*="btn-put"]',
                             '[class*="PutButton"]',
                             '[class*="down-btn"]',
                             'button[class*="red"]']

            for selector in selectors:
                try:
                    el = await self._page.wait_for_selector(
                        selector, timeout=3000)
                    if el:
                        # Verificar que es visible y clickeable
                        is_visible = await el.is_visible()
                        if not is_visible:
                            continue

                        # Movimiento de mouse hacia el boton (HUMANO)
                        await self._human_move_to_element(el)

                        # Pequena hesitacion antes del click
                        await asyncio.sleep(random.uniform(0.05, 0.2))

                        # CLICK REAL
                        await el.click()

                        logger.info(f"[Trade] Click en {direction.upper()} "
                                    f"ejecutado")
                        return True
                except Exception:
                    continue

            logger.error(f"[Trade] No se encontro boton {direction.upper()}")
            return False

        except Exception as e:
            logger.error(f"[Trade] Error en click {direction}: {e}")
            return False

    async def _wait_for_trade_confirmation(self, timeout=10):
        """Espera la confirmacion de la operacion."""
        try:
            sel = self._selectors["trading"]

            # Buscar popup de confirmacion
            for selector in [sel["trade_confirmation"],
                             '[class*="confirmation"]',
                             '[class*="result"]',
                             '[class*="trade-result"]',
                             '[class*="order-open"]']:
                try:
                    el = await self._page.wait_for_selector(
                        selector, timeout=timeout * 1000)
                    if el:
                        await asyncio.sleep(1.0)
                        # Cerrar la confirmacion si es necesario
                        for close_sel in [sel["close_confirmation"],
                                          'button:has-text("OK")',
                                          'button:has-text("Close")']:
                            try:
                                close_btn = await self._page.wait_for_selector(
                                    close_sel, timeout=2000)
                                if close_btn:
                                    await close_btn.click()
                                    await asyncio.sleep(0.5)
                                    break
                            except Exception:
                                continue
                        return True
                except Exception:
                    continue

            # Si no hay confirmacion visible, asumir que la orden fue colocada
            return True

        except Exception:
            return True

    # ============================================================
    # ACCOUNT SWITCHING - V6.3.2 FIX #2: JavaScript-based approach
    # ============================================================
    async def _switch_account_js(self, mode):
        """Switch account using JavaScript evaluation.

        V6.3.2 FIX #2: Reemplaza CSS selectors con JavaScript que escanea
        todos los elementos clickeables buscando texto Practice/Real.
        Mas robusto porque IQ Option cambia sus clases CSS frecuentemente.
        """
        mode_lower = mode.lower()

        # Method 1: Find and click using JavaScript - scan all elements
        mode_upper = mode.upper()
        logger.info(f"[Account] Intentando cambio a {mode_upper} "
                    f"via JavaScript...")

        result = await self._page.evaluate("""(mode) => {
            // Search all clickable elements for Practice/Real text
            const allElements = document.querySelectorAll(
                'button, a, div, span, [role="button"], [role="tab"]'
            );
            const targetTexts = mode === 'practice' ?
                ['Practice', 'PRACTICE', 'practice', 'Demo', 'DEMO', 'demo'] :
                ['Real', 'REAL', 'real'];

            for (const el of allElements) {
                const text = el.textContent?.trim() || '';
                const ariaLabel = el.getAttribute('aria-label') || '';
                const title = el.getAttribute('title') || '';
                const dataTip = el.getAttribute('data-tip') || '';
                const combined = text + ' ' + ariaLabel + ' ' + title
                                 + ' ' + dataTip;

                for (const target of targetTexts) {
                    if (combined.includes(target) &&
                        el.offsetParent !== null) {
                        el.click();
                        return {found: true, method: 'text_search',
                                text: text.substring(0, 50)};
                    }
                }
            }
            return {found: false, method: 'text_search'};
        }""", mode_lower)

        if result and result.get("found"):
            logger.info(f"[Account] Cambio via JS text_search: "
                        f"{result.get('text', '')}")
            await asyncio.sleep(2.0)
            return True

        # Method 2: Try toggle element (account switch toggle)
        logger.info("[Account] Intentando toggle de cuenta...")
        result2 = await self._page.evaluate("""
            (mode) => {
                // Look for toggle/switch elements
                const toggles = document.querySelectorAll(
                    '[class*="toggle"], [class*="switch"], '
                    + '[class*="Toggle"], [class*="Switch"], '
                    + '[role="switch"], [role="tab"], '
                    + '[class*="account-switch"], [class*="AccountSwitch"]'
                );
                for (const el of toggles) {
                    // Check if this toggle relates to account type
                    const text = (el.textContent || '').toLowerCase();
                    if (text.includes('practice') || text.includes('real') ||
                        text.includes('demo')) {
                        el.click();
                        return {found: true, method: 'toggle'};
                    }
                }

                // Method 2b: Look for parent container with both options
                const containers = document.querySelectorAll(
                    '[class*="account"], [class*="balance-type"]'
                );
                for (const container of containers) {
                    const children = container.querySelectorAll('*');
                    for (const child of children) {
                        const childText = (child.textContent || '').trim();
                        const targetTexts = mode === 'practice' ?
                            ['Practice', 'DEMO', 'Demo'] :
                            ['Real', 'REAL'];
                        for (const target of targetTexts) {
                            if (childText === target &&
                                child.offsetParent !== null) {
                                child.click();
                                return {found: true, method: 'container_child',
                                        text: childText};
                            }
                        }
                    }
                }
                return {found: false, method: 'toggle'};
            }
        """, mode_lower)

        if result2 and result2.get("found"):
            logger.info(f"[Account] Cambio via toggle: "
                        f"{result2.get('text', '')}")
            await asyncio.sleep(2.0)
            return True

        # Method 3: Fallback CSS selector approach (original, kept as last resort)
        sel = self._selectors["dashboard"]
        if mode_lower == "practice":
            css_selectors = [sel["practice_button"],
                             'button:has-text("Practice")',
                             '[class*="practice"]', '[class*="demo"]',
                             '[class*="Demo"]']
        else:
            css_selectors = [sel["real_button"],
                             'button:has-text("Real")',
                             '[class*="real-"]',
                             '[class*="Real"]']

        for selector in css_selectors:
            try:
                el = await self._page.wait_for_selector(selector, timeout=3000)
                if el:
                    is_visible = await el.is_visible()
                    if is_visible:
                        await self._human_move_to_element(el)
                        await el.click()
                        logger.info(f"[Account] Cambio via CSS: {selector}")
                        await asyncio.sleep(2.0)
                        return True
            except Exception:
                continue

        # Method 4: Last resort - try clicking by coordinate if we know
        # the typical position of the account toggle
        # V7.2: Try clicking the balance display element 
        # which usually opens an account switcher dropdown
        logger.info("[Account] Intentando click en balance display...")
        try:
            result3 = await self._page.evaluate("""
                (mode) => {
                    // Find balance display elements and click them
                    const balanceEls = document.querySelectorAll(
                        '[class*="balance"], [class*="Balance"], [data-test*="balance"]'
                    );
                    for (const el of balanceEls) {
                        if (el.offsetParent !== null && el.textContent) {
                            // Click it to open dropdown
                            el.click();
                            return {found: true, method: 'balance_display_click',
                                    text: el.textContent.substring(0, 50)};
                        }
                    }
                    return {found: false, method: 'balance_display_click'};
                }
            """, mode_lower)
            
            if result3 and result3.get("found"):
                await asyncio.sleep(1.5)
                # Now try to find and click Practice/Real in the opened dropdown
                result4 = await self._page.evaluate("""
                    (mode) => {
                        // Look for dropdown items
                        const items = document.querySelectorAll(
                            '[class*="dropdown"] *, [class*="menu"] *, [class*="popup"] *, [role="option"], [role="menuitem"]'
                        );
                        const targetTexts = mode === 'practice' ?
                            ['Practice', 'PRACTICE', 'Demo', 'DEMO'] :
                            ['Real', 'REAL'];
                        for (const item of items) {
                            const text = (item.textContent || '').trim();
                            for (const t of targetTexts) {
                                if (text.includes(t) && item.offsetParent !== null) {
                                    item.click();
                                    return {found: true, method: 'dropdown_item',
                                            text: text.substring(0, 50)};
                                }
                            }
                        }
                        return {found: false, method: 'dropdown_item'};
                    }
                """, mode_lower)
                
                if result4 and result4.get("found"):
                    logger.info(f"[Account] Cambio via dropdown: "
                                f"{result4.get('text', '')}")
                    await asyncio.sleep(2.0)
                    return True
                else:
                    # Close dropdown by pressing Escape
                    await self._page.keyboard.press("Escape")
        except Exception as e:
            logger.debug(f"[Account] Balance display click error: {e}")

        logger.warning(f"[Account] Todos los metodos fallaron para "
                       f"cambiar a {mode_upper}")
        return False

    # ============================================================
    # CANDLE DATA VIA INTERNAL API
    # ============================================================
    async def _fetch_candles_via_browser(self, instrument_name, interval,
                                          count, endtime):
        """Obtiene datos de velas usando el navegador como proxy.
        Usa page.evaluate() para hacer fetch desde el navegador real,
        lo que significa que la request tiene TLS, cookies y headers reales."""

        try:
            # Intentar via API interna del navegador
            candles = await self._page.evaluate("""
                async (params) => {
                    try {
                        const url = `/api/candles?active_id=${params.active_id}`
                            + `&size=${params.interval}`
                            + `&count=${params.count}`
                            + `&endtime=${params.endtime}`;
                        const response = await fetch(url, {
                            credentials: 'include',
                            headers: {
                                'Accept': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        });
                        if (response.ok) {
                            const data = await response.json();
                            return data;
                        }
                    } catch (e) {}

                    // Fallback: buscar datos en WS cache del navegador
                    try {
                        const url2 = `/api/candles/${params.active_id}/`
                            + `${params.interval}?count=${params.count}`;
                        const response2 = await fetch(url2, {
                            credentials: 'include'
                        });
                        if (response2.ok) {
                            return await response2.json();
                        }
                    } catch (e) {}

                    return null;
                }
            """, {
                "active_id": instrument_name,
                "interval": interval,
                "count": count,
                "endtime": endtime
            })

            if candles and isinstance(candles, list):
                return candles
            elif candles and isinstance(candles, dict):
                # Buscar el array de candles en la respuesta
                for key in ['candles', 'data', 'result', 'msg']:
                    if key in candles and isinstance(candles[key], list):
                        return candles[key]

            return None

        except Exception as e:
            logger.debug(f"[Candles] Error via browser fetch: {e}")
            return None

    # ============================================================
    # PUBLIC API - Drop-in replacement methods
    # ============================================================
    def connect(self):
        """Conecta a IQ Option usando navegador real.
        Returns: (bool, str|None) - Mismo formato que IQ_Option_Patched

        V7 FIX: Auto-retry logic for login. IQ Option sometimes needs
        a second attempt to complete the login redirect. We now retry
        up to 2 times automatically, with proper cleanup between attempts.
        """
        max_attempts = 2
        for attempt in range(max_attempts):
            try:
                logger.info(f"[Connect] Intento {attempt + 1}/{max_attempts} "
                            "de conexion Playwright...")

                async def _do_connect():
                    # Lanzar navegador
                    if not await self._launch_browser():
                        return False, "Failed to launch browser"

                    # Login
                    check, reason = await self._login()
                    if not check:
                        return False, reason

                    return True, None

                result = self._bridge.run(_do_connect(), timeout=180)

                if result[0]:
                    self._connected = True
                    self._connect_time = time.time()
                    self._reconnect_count = 0
                    logger.info("[Connect] Conexion exitosa "
                                "(Playwright Anti-Detection V7) "
                                f"(WS msgs: {self._ws_interceptor.message_count})")
                    return result
                else:
                    self._connected = False
                    logger.warning(f"[Connect] Intento {attempt + 1} fallo: "
                                   f"{result[1]}")

                    # Clean up browser before retry
                    if attempt < max_attempts - 1:
                        logger.info("[Connect] Limpiando y reintentando...")
                        try:
                            self._stop_mouse_activity()
                            async def _cleanup():
                                try:
                                    if self._page and not self._page.is_closed():
                                        await self._page.close()
                                except Exception:
                                    pass
                                try:
                                    if self._context:
                                        await self._context.close()
                                except Exception:
                                    pass
                                try:
                                    if self._browser:
                                        await self._browser.close()
                                except Exception:
                                    pass
                                try:
                                    if hasattr(self, '_playwright') and self._playwright:
                                        await self._playwright.stop()
                                except Exception:
                                    pass
                            self._bridge.run(_cleanup(), timeout=15)
                        except Exception:
                            pass
                        # Reset WS interceptor for fresh start
                        self._ws_interceptor = _WSInterceptor()
                        time.sleep(2)

            except Exception as e:
                logger.error(f"[Connect] Excepcion en intento {attempt + 1}: {e}")
                self._connected = False
                if attempt < max_attempts - 1:
                    time.sleep(3)
                else:
                    return False, str(e)

        self._connected = False
        return False, "Connection failed after all attempts"

    def check_connect(self):
        """Verifica si la conexion esta activa.
        Returns: bool"""
        if not self._connected:
            return False

        try:
            # Verificar que el navegador y la pagina siguen activos
            async def _check():
                try:
                    if not self._page or self._page.is_closed():
                        return False
                    # Verificar que no fuimos redirigidos al login
                    url = self._page.url
                    if "login" in url and "traderoom" not in url:
                        return False
                    # V6.3.2 FIX #5: Verificar WS con message_count
                    if self._ws_interceptor.is_connected():
                        return True
                    # Si no hay WS, verificar que la pagina responde
                    title = await self._page.title()
                    return bool(title)
                except Exception:
                    return False

            return self._bridge.run(_check(), timeout=10)
        except Exception:
            return False

    def _ensure_connected(self, max_attempts=3):
        """Asegura que la conexion esta activa, reconecta si es necesario.
        Returns: bool"""
        if self.check_connect():
            return True

        for attempt in range(max_attempts):
            logger.warning(f"[Reconnect] Intento {attempt + 1}/{max_attempts}")
            try:
                # Intentar reconectar
                result = self.connect()
                if result[0]:
                    return True
            except Exception as e:
                logger.error(f"[Reconnect] Error: {e}")

            # Backoff con jitter
            backoff = min(2 ** attempt, 10) + random.uniform(1.0, 3.0)
            time.sleep(backoff)

        self._connected = False
        return False

    def get_all_ACTIVES_OPCODE(self):
        """Obtiene lista de instrumentos disponibles.
        Returns: dict - {instrument_name: active_id}"""
        try:
            # Intentar desde cache
            now = time.time()
            if self._actives_cache and (now - self._actives_cache_time) < 600:
                return self._actives_cache

            # Desde WS interceptor
            actives = self._ws_interceptor.get_actives()
            if actives:
                self._actives_cache = actives
                self._actives_cache_time = now
                return actives

            # V7.2: Request instruments via WS before falling back to HTTP
            async def _request_actives_ws():
                try:
                    result = await self._page.evaluate("""
                        async () => {
                            return new Promise((resolve) => {
                                try {
                                    const ws = window.__ouhries_ws_instance;
                                    if (!ws || ws.readyState !== WebSocket.OPEN) {
                                        resolve(null);
                                        return;
                                    }

                                    const requestId = 'actives_req_' + Date.now();
                                    const timeout = setTimeout(() => resolve(null), 10000);

                                    const handler = (event) => {
                                        try {
                                            const data = JSON.parse(event.data);
                                            let resultId = null;
                                            let resultMsg = null;
                                            if (Array.isArray(data) && data.length >= 2 && data[0] === 'result') {
                                                resultId = data[1]?.id;
                                                resultMsg = data[1];
                                            } else if (data && data.name === 'result') {
                                                resultId = data.msg?.id;
                                                resultMsg = data.msg;
                                            }
                                            if (resultId === requestId) {
                                                clearTimeout(timeout);
                                                ws.removeEventListener('message', handler);
                                                resolve(resultMsg);
                                            }
                                        } catch(e) {}
                                    };

                                    ws.addEventListener('message', handler);

                                    ws.send(JSON.stringify([
                                        "sendMessage",
                                        {
                                            name: "trading-settings.get-trading-group-params",
                                            version: "2.0",
                                            body: {instrument_type: "turbo-option"},
                                            id: requestId
                                        }
                                    ]));
                                } catch(e) {
                                    resolve(null);
                                }
                            });
                        }
                    """)
                    return result
                except Exception:
                    return None

            ws_result = self._bridge.run(_request_actives_ws(), timeout=15)
            if ws_result and isinstance(ws_result, dict):
                # Extract active data from trading group params
                msg_data = ws_result.get("msg", ws_result)
                if isinstance(msg_data, dict):
                    actives_list = msg_data.get("actives",
                                                msg_data.get("instruments", []))
                    if isinstance(actives_list, list):
                        for item in actives_list:
                            if isinstance(item, dict):
                                name = item.get("name",
                                                item.get("active_name", ""))
                                aid = item.get("id",
                                               item.get("active_id",
                                                        item.get("activeId", "")))
                                if name and aid:
                                    self._actives_cache[name] = aid
                    if self._actives_cache:
                        self._actives_cache_time = now
                        return self._actives_cache

            # Fallback: obtener via browser
            async def _get_actives():
                try:
                    result = await self._page.evaluate("""
                        async () => {
                            // V7.2: Try multiple API endpoints for instruments
                            // Method A: /api/instruments
                            try {
                                const r1 = await fetch('/api/instruments', {
                                    credentials: 'include',
                                    headers: {'Accept': 'application/json'}
                                });
                                if (r1.ok) {
                                    const d1 = await r1.json();
                                    if (d1) return d1;
                                }
                            } catch(e) {}
                            
                            // Method B: /api/v1/instruments  
                            try {
                                const r2 = await fetch('/api/v1/instruments', {
                                    credentials: 'include'
                                });
                                if (r2.ok) {
                                    const d2 = await r2.json();
                                    if (d2) return d2;
                                }
                            } catch(e) {}
                            
                            // Method C: Try getting actives from the page's JS state
                            try {
                                if (window.__store__) {
                                    const state = window.__store__.getState();
                                    if (state && state.instruments) return state.instruments;
                                    if (state && state.actives) return state.actives;
                                }
                            } catch(e) {}
                            
                            return null;
                        }
                    """)
                    return result
                except Exception:
                    return None

            result = self._bridge.run(_get_actives(), timeout=15)
            if result and isinstance(result, dict):
                self._actives_cache = result
                self._actives_cache_time = now
                return result
            elif result and isinstance(result, list):
                actives_dict = {}
                for item in result:
                    if isinstance(item, dict):
                        name = item.get("name",
                                        item.get("instrument", ""))
                        aid = item.get("id",
                                       item.get("active_id", ""))
                        if name:
                            actives_dict[name] = aid
                if actives_dict:
                    self._actives_cache = actives_dict
                    self._actives_cache_time = now
                    return actives_dict

            return self._actives_cache or {}

        except Exception as e:
            logger.error(f"[Actives] Error: {e}")
            return self._actives_cache or {}

    def get_candles(self, ACTIVES, interval, count, endtime):
        """Obtiene datos de velas OHLC.
        Args: ACTIVES (str), interval (int), count (int), endtime (int)
        Returns: list - Lista de candles

        V7.3 CRITICAL FIX: Complete rewrite of candle fetching.
        The main issues were:
        1. active_id resolution failed because OTC_FALLBACK returns string
           names (not numeric IDs), causing parseInt() to return NaN
        2. The WS candle request format was incorrect
        3. Navigation-based candle capture was unreliable

        New approach:
        1. Try WS interceptor cache first
        2. Resolve numeric active_id from actives cache, DOM, or API
        3. Request candles via WS with correct format
        4. Parse and normalize candle format for scanner compatibility
        5. Navigate to asset as last resort
        """
        try:
            # Step 0: Check WS interceptor cache (check multiple key formats)
            for key in [ACTIVES, ACTIVES.upper(), ACTIVES.replace("-OTC", ""),
                        ACTIVES.replace("-OTC", "_otc"),
                        ACTIVES.replace("-OTC", "-otc")]:
                cached = self._ws_interceptor.get_candles(key)
                if cached and len(cached) >= count:
                    logger.debug(f"[Candles] Cache hit for {ACTIVES}: "
                                 f"{len(cached)} candles")
                    return self._normalize_candles(cached)[-count:]

            # Also check all candles in cache by iterating keys
            all_candles_cache = self._ws_interceptor._candles_cache
            for key, cdata in all_candles_cache.items():
                if cdata and len(cdata) >= count:
                    # Check if this key matches our instrument
                    key_upper = str(key).upper()
                    actives_upper = ACTIVES.upper()
                    if (actives_upper in key_upper or
                        key_upper in actives_upper or
                        actives_upper.replace("-OTC", "") in key_upper):
                        self._ws_interceptor._candles_cache[ACTIVES] = cdata
                        return self._normalize_candles(cdata)[-count:]

            # V7.3: Step 1 - Resolve numeric active_id for this instrument
            # This is CRITICAL - without a numeric active_id, WS candle
            # requests return nothing (parseInt of non-numeric string = NaN)
            active_id = self._resolve_active_id(ACTIVES)
            if active_id:
                logger.info(f"[Candles] active_id resuelto para "
                            f"{ACTIVES}: {active_id}")

                # V7.3: Step 2 - Request candles via WS with the numeric ID
                async def _fetch_candles_ws():
                    try:
                        result = await self._page.evaluate("""
                            async (params) => {
                                return new Promise((resolve) => {
                                    try {
                                        const ws = window.__ouhries_ws_instance;
                                        if (!ws || ws.readyState !== WebSocket.OPEN) {
                                            resolve(null);
                                            return;
                                        }

                                        const requestId = params.request_id;
                                        const timeout = setTimeout(() => resolve(null), 15000);

                                        const handler = (event) => {
                                            try {
                                                const data = JSON.parse(event.data);
                                                let resultId = null;
                                                let resultMsg = null;

                                                // V7.3: IQ Option WS uses ARRAY format:
                                                // ["result", {"id": "req_id", "msg": {...}}]
                                                if (Array.isArray(data) && data.length >= 2) {
                                                    if (data[0] === 'result') {
                                                        resultId = data[1]?.id;
                                                        resultMsg = data[1]?.msg;
                                                    }
                                                    // Some responses come as ["candles", {data: [...]}]
                                                    if (data[0] === 'quotes-history.get-candles') {
                                                        clearTimeout(timeout);
                                                        ws.removeEventListener('message', handler);
                                                        resolve(data[1] || data);
                                                        return;
                                                    }
                                                } else if (data && typeof data === 'object') {
                                                    // Dict format
                                                    if (data.name === 'result') {
                                                        resultId = data.msg?.id;
                                                        resultMsg = data.msg;
                                                    } else if (data.name === 'quotes-history.get-candles') {
                                                        clearTimeout(timeout);
                                                        ws.removeEventListener('message', handler);
                                                        resolve(data.msg || data);
                                                        return;
                                                    }
                                                }

                                                if (resultId === requestId) {
                                                    clearTimeout(timeout);
                                                    ws.removeEventListener('message', handler);
                                                    resolve(resultMsg);
                                                }
                                            } catch(e) {}
                                        };

                                        ws.addEventListener('message', handler);

                                        // V7.3: Send candle request in correct format
                                        // The "body" field must contain the request params
                                        // "size" is the candle size in SECONDS
                                        // Scanner passes interval=60 for 1-minute candles
                                        ws.send(JSON.stringify([
                                            "sendMessage",
                                            {
                                                name: "quotes-history.get-candles",
                                                version: "2.0",
                                                body: {
                                                    active_id: parseInt(params.active_id),
                                                    size: params.interval,  // Already in seconds (60 = 1min)
                                                    count: params.count,
                                                    to: params.endtime
                                                },
                                                id: requestId
                                            }
                                        ]));
                                    } catch(e) {
                                        resolve(null);
                                    }
                                });
                            }
                        """, {
                            "active_id": active_id,
                            "interval": interval,
                            "count": count,
                            "endtime": endtime,
                            "request_id": f"candle_{ACTIVES}_{int(time.time())}"
                        })

                        if result is not None:
                            # V7.3: Parse the result - IQ Option returns candles in various formats
                            candles = self._parse_candle_response(result, ACTIVES)
                            if candles and len(candles) > 0:
                                return candles
                        return None
                    except Exception as e:
                        logger.debug(f"[Candles] WS fetch error: {e}")
                        return None

                candles = self._bridge.run(_fetch_candles_ws(), timeout=25)
                if candles and isinstance(candles, list) and len(candles) > 0:
                    # Cache the result
                    self._ws_interceptor._candles_cache[ACTIVES] = candles[-200:]
                    logger.info(f"[Candles] Obtenidas {len(candles)} velas "
                                f"via WS para {ACTIVES}")
                    return candles[-count:]

            # V7.3: Step 3 - Navigate to the asset and capture WS candle messages
            # This is the fallback: navigate to the instrument in the browser,
            # which triggers the browser to subscribe to candle data via WS.
            async def _fetch_candles_via_navigation():
                try:
                    navigated = await self._navigate_to_asset(ACTIVES)
                    if navigated:
                        # Wait for candle data to arrive via WS
                        await asyncio.sleep(4.0)

                        # Poll JS WS messages to capture any new candles
                        await self._process_js_ws_messages()

                        # Check candle cache with multiple key formats
                        for key in [ACTIVES, ACTIVES.upper(),
                                    ACTIVES.replace("-OTC", ""),
                                    str(ACTIVES)]:
                            cached = self._ws_interceptor.get_candles(key)
                            if cached and len(cached) >= 3:
                                return self._normalize_candles(cached)

                        # Also check all keys in candles cache
                        all_candles = self._ws_interceptor._candles_cache
                        if all_candles:
                            for key, cdata in all_candles.items():
                                if cdata and len(cdata) >= 3:
                                    self._ws_interceptor._candles_cache[ACTIVES] = cdata
                                    return self._normalize_candles(cdata)
                    return None
                except Exception as e:
                    logger.debug(f"[Candles] Navigation fetch error: {e}")
                    return None

            candles = self._bridge.run(_fetch_candles_via_navigation(), timeout=25)
            if candles and isinstance(candles, list) and len(candles) > 0:
                self._ws_interceptor._candles_cache[ACTIVES] = candles[-200:]
                return candles[-count:]

            # V7.3: Step 4 - Try fetching from chart data in the page
            async def _fetch_from_chart():
                try:
                    result = await self._page.evaluate("""
                        () => {
                            // Try to find candle data in page's JS state
                            try {
                                if (window.__store__) {
                                    const state = window.__store__.getState();
                                    if (state && state.candles) return state.candles;
                                }
                            } catch(e) {}
                            return null;
                        }
                    """)
                    return result
                except Exception:
                    return None

            chart_data = self._bridge.run(_fetch_from_chart(), timeout=10)
            if chart_data and isinstance(chart_data, list):
                return self._normalize_candles(chart_data)[-count:]

            logger.debug(f"[Candles] No se pudieron obtener velas para "
                         f"{ACTIVES}")
            return []

        except Exception as e:
            logger.error(f"[Candles] Error obteniendo velas para "
                         f"{ACTIVES}: {e}")
            return []

    def _resolve_active_id(self, instrument_name):
        """V7.3: Resolve numeric active_id for an instrument name.
        Tries multiple sources in order:
        1. WS interceptor actives cache (from ssid/trading-settings messages)
        2. DOM React fiber extraction
        3. API endpoint
        Returns: int or None
        """
        try:
            # Method 1: Check WS interceptor's actives cache
            actives = self._ws_interceptor.get_actives()
            for key in [instrument_name, instrument_name.upper(),
                        instrument_name.replace("-OTC", "_otc"),
                        instrument_name.replace("-OTC", "-otc"),
                        instrument_name.replace("-OTC", "")]:
                if key in actives:
                    aid = actives[key]
                    # V7.3: Must be numeric - if it's a string name, it's not a real active_id
                    if isinstance(aid, int) and aid > 0:
                        return aid
                    if isinstance(aid, str) and aid.isdigit():
                        return int(aid)

            # Method 2: Try to resolve from browser's JS state
            try:
                async def _resolve_from_js():
                    return await self._page.evaluate("""
                        (instrumentName) => {
                            // Try multiple methods to find the active_id

                            // Method A: React fiber tree
                            try {
                                const rootEl = document.getElementById('root');
                                if (rootEl) {
                                    const fiberKey = Object.keys(rootEl).find(
                                        k => k.startsWith('__reactFiber$') ||
                                             k.startsWith('__reactInternalInstance$')
                                    );
                                    if (fiberKey) {
                                        let fiber = rootEl[fiberKey];
                                        const visited = new Set();
                                        const queue = [fiber];
                                        const maxIter = 500;
                                        let iter = 0;
                                        while (queue.length > 0 && iter < maxIter) {
                                            iter++;
                                            const node = queue.shift();
                                            if (!node || visited.has(node)) continue;
                                            visited.add(node);

                                            // Check for instruments array in props
                                            const checkProps = (props) => {
                                                if (!props) return null;
                                                for (const key of ['instruments', 'actives', 'items']) {
                                                    if (props[key] && Array.isArray(props[key])) {
                                                        for (const inst of props[key]) {
                                                            if (inst.name === instrumentName ||
                                                                inst.active_name === instrumentName ||
                                                                inst.name === instrumentName.replace('-OTC', '_otc') ||
                                                                inst.name === instrumentName.replace('-OTC', '-otc')) {
                                                                return inst.active_id || inst.id;
                                                            }
                                                        }
                                                    }
                                                }
                                                return null;
                                            };

                                            let found = checkProps(node.memoizedProps);
                                            if (found) return found;

                                            // Check state
                                            if (node.memoizedState) {
                                                let state = node.memoizedState;
                                                for (let i = 0; i < 15 && state; i++) {
                                                    if (state.queue && state.queue.lastRenderedState) {
                                                        found = checkProps(state.queue.lastRenderedState);
                                                        if (found) return found;
                                                    }
                                                    state = state.next;
                                                }
                                            }

                                            if (node.child) queue.push(node.child);
                                            if (node.sibling) queue.push(node.sibling);
                                        }
                                    }
                                }
                            } catch(e) {}

                            // Method B: Check __store__ (Redux/MobX)
                            try {
                                if (window.__store__) {
                                    const state = window.__store__.getState();
                                    if (state) {
                                        for (const key of ['instruments', 'actives', 'trading']) {
                                            if (state[key]) {
                                                const data = state[key];
                                                if (Array.isArray(data)) {
                                                    for (const inst of data) {
                                                        if (inst.name === instrumentName) {
                                                            return inst.active_id || inst.id;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } catch(e) {}

                            return null;
                        }
                    """, instrument_name)

                result = self._bridge.run(_resolve_from_js(), timeout=10)
                if result and isinstance(result, (int, float)):
                    aid = int(result)
                    if aid > 0:
                        # Cache it for future use
                        self._ws_interceptor._actives[instrument_name] = aid
                        return aid
            except Exception:
                pass

            # Method 3: Try API endpoint for instrument mapping
            try:
                async def _resolve_from_api():
                    result = await self._page.evaluate("""
                        async (instrumentName) => {
                            try {
                                const r = await fetch('/api/v1/instruments', {
                                    credentials: 'include'
                                });
                                if (r.ok) {
                                    const data = await r.json();
                                    if (data && data.result) {
                                        const instruments = data.result.instruments ||
                                                           data.result.actives ||
                                                           data.result;
                                        if (Array.isArray(instruments)) {
                                            for (const inst of instruments) {
                                                if (inst.name === instrumentName) {
                                                    return inst.active_id || inst.id;
                                                }
                                            }
                                        }
                                    }
                                }
                            } catch(e) {}
                            return null;
                        }
                    """, instrument_name)
                    return result

                result = self._bridge.run(_resolve_from_api(), timeout=10)
                if result and isinstance(result, (int, float)):
                    aid = int(result)
                    if aid > 0:
                        self._ws_interceptor._actives[instrument_name] = aid
                        return aid
            except Exception:
                pass

            logger.debug(f"[Candles] No se pudo resolver active_id para "
                         f"{instrument_name}")
            return None

        except Exception as e:
            logger.debug(f"[Candles] Error resolviendo active_id: {e}")
            return None

    def _normalize_candles(self, candles_raw):
        """V7.3: Normalize candle data to the format expected by scanner.
        Scanner expects: [{"open": X, "max": Y, "min": Z, "close": W}, ...]
        IQ Option WS returns various formats, this normalizes them all.
        """
        normalized = []
        for c in candles_raw:
            if isinstance(c, dict):
                # Extract OHLC values with multiple key name support
                open_val = (c.get("open") or c.get("open_price") or
                           c.get("openPrice") or 0)
                high_val = (c.get("max") or c.get("high") or
                           c.get("max_price") or c.get("highest") or 0)
                low_val = (c.get("min") or c.get("low") or
                          c.get("min_price") or c.get("lowest") or 0)
                close_val = (c.get("close") or c.get("close_price") or
                            c.get("closePrice") or c.get("close_price") or 0)

                if open_val and close_val:
                    normalized.append({
                        "open": float(open_val),
                        "max": float(high_val),
                        "min": float(low_val),
                        "close": float(close_val)
                    })
            elif isinstance(c, (list, tuple)) and len(c) >= 4:
                # Format: [open, high, low, close, ...]
                normalized.append({
                    "open": float(c[0]),
                    "max": float(c[1]),
                    "min": float(c[2]),
                    "close": float(c[3])
                })
        return normalized

    def _parse_candle_response(self, result, instrument_name):
        """V7.3: Parse candle data from WS response.
        IQ Option returns candles in various nested formats.
        Returns a normalized list of candles or None.
        """
        try:
            candles = None

            if isinstance(result, dict):
                # Format 1: {"candles": [...]}
                if "candles" in result:
                    candles = result["candles"]
                # Format 2: {"msg": {"candles": [...]}}
                elif "msg" in result and isinstance(result["msg"], dict):
                    candles = result["msg"].get("candles",
                                result["msg"].get("data",
                                result["msg"].get("items")))
                # Format 3: {"data": [...]}
                elif "data" in result:
                    candles = result["data"]
                # Format 4: {"items": [...]}
                elif "items" in result:
                    candles = result["items"]
            elif isinstance(result, list):
                candles = result

            if candles and isinstance(candles, list) and len(candles) > 0:
                normalized = self._normalize_candles(candles)
                if normalized:
                    # Cache under instrument name
                    self._ws_interceptor._candles_cache[instrument_name] = normalized[-200:]
                    return normalized

            return None
        except Exception as e:
            logger.debug(f"[Candles] Error parsing response: {e}")
            return None

    def buy(self, price, ACTIVES, ACTION, expirations):
        """Ejecuta una operacion de trading via click real en el navegador.
        Args: price (float), ACTIVES (str), ACTION (str), expirations (int)
        Returns: (bool, str) - (exito, order_id o error_msg)

        V6.3.2 FIX #8: Timeout aumentado a 90s.
        """
        try:
            self._trade_counter += 1
            order_id = f"pw_{int(time.time())}_{self._trade_counter}"

            # Registrar balance antes del trade
            pre_balance = self.get_balance()

            async def _do_buy():
                # 1. Navegar al activo
                if not await self._navigate_to_asset(ACTIVES):
                    return False, f"Asset {ACTIVES} not found"

                # 2. Establecer monto
                if not await self._set_amount(price):
                    # Si no se puede setear el monto via DOM, continuar
                    logger.warning("[Buy] No se pudo setear monto via DOM, "
                                   "continuando...")

                # 3. Establecer expiracion
                await self._set_expiration(expirations)

                # 4. Jitter humano antes del click
                jitter = random.uniform(0.05, 0.6)
                await asyncio.sleep(jitter)

                # 5. Click en CALL o PUT
                if not await self._click_call_or_put(ACTION):
                    return False, f"{ACTION.upper()} button not found"

                # 6. Esperar confirmacion
                await self._wait_for_trade_confirmation(timeout=10)

                return True, order_id

            # V6.3.2 FIX #8: Increased timeout from 60s to 90s
            result = self._bridge.run(_do_buy(), timeout=90)

            if result[0]:
                # Registrar trade pendiente para check_win_v3
                with self._lock:
                    self._pending_trades[order_id] = {
                        "pre_balance": pre_balance,
                        "timestamp": time.time(),
                        "instrument": ACTIVES,
                        "direction": ACTION,
                        "amount": price,
                        "expiration": expirations,
                    }
                logger.info(f"[Buy] {ACTION.upper()} {ACTIVES} "
                            f"${price:.2f} - Order: {order_id}")
            else:
                logger.error(f"[Buy] Fallo: {result[1]}")

            return result

        except Exception as e:
            logger.error(f"[Buy] Excepcion: {e}")
            return False, str(e)

    def check_win_v3(self, id_number, timeout=120):
        """Verifica el resultado de una operacion.
        Usa balance diff como metodo principal.
        Returns: float - Profit (positivo=win, negativo=loss)"""
        try:
            order_id = str(id_number)

            # Buscar en pending trades
            trade_info = None
            with self._lock:
                trade_info = self._pending_trades.pop(order_id, None)

            if not trade_info:
                logger.warning(f"[CheckWin] Trade {order_id} no encontrado "
                               f"en pendientes")
                return 0.0

            # Esperar que pase el tiempo de expiracion
            expiration_sec = trade_info.get("expiration", 1) * 60 + 5
            jitter = random.uniform(-3.0, 3.0)
            wait_time = expiration_sec + jitter

            logger.info(f"[CheckWin] Esperando {wait_time:.0f}s para "
                        f"resultado de {order_id}...")
            time.sleep(wait_time)

            # Metodo 1: Verificar via WS interceptor
            ws_result = self._ws_interceptor.get_trade_result(order_id)
            if ws_result is not None:
                logger.info(f"[CheckWin] Resultado WS: {ws_result}")
                return float(ws_result)

            # Metodo 2: Balance diff
            pre_balance = trade_info.get("pre_balance", 0)
            amount = trade_info.get("amount", 0)

            # Leer balance actual
            post_balance = self.get_balance()

            if pre_balance > 0 and post_balance > 0:
                diff = post_balance - pre_balance

                # Si la diferencia es significativa, es el resultado
                if abs(diff) > 0.01:
                    logger.info(f"[CheckWin] Balance diff: ${diff:.2f} "
                                f"(pre: ${pre_balance:.2f}, "
                                f"post: ${post_balance:.2f})")
                    return diff

            # Metodo 3: Si no se puede determinar, asumir perdida
            logger.warning(f"[CheckWin] No se pudo verificar resultado, "
                           f"asumiendo perdida")
            return -amount

        except Exception as e:
            logger.error(f"[CheckWin] Error: {e}")
            return -trade_info.get("amount", 0) if trade_info else 0.0

    def get_balance(self):
        """Obtiene el balance de la cuenta.
        Returns: float

        V7.3 CRITICAL FIX: Returns the balance for the CURRENTLY ACTIVE
        account mode (PRACTICE or REAL), not just the top-level balance
        from the ssid message. The ssid 'balance' field always reflects
        whichever account IQ Option defaulted to (usually Real), so we
        must check our active_account_mode and return the right one.
        """
        try:
            # V7.3: FIRST check the active account mode and return the
            # corresponding balance. This fixes the swapped balance bug.
            mode = self._active_account_mode
            practice_bal = self._ws_interceptor.get_practice_balance()
            real_bal = self._ws_interceptor.get_real_balance()

            if mode == "PRACTICE" and practice_bal > 0:
                self._last_balance_read = practice_bal
                self._ws_interceptor._balance = practice_bal
                return practice_bal
            elif mode == "REAL" and real_bal > 0:
                self._last_balance_read = real_bal
                self._ws_interceptor._balance = real_bal
                return real_bal

            # V7.3: If mode-specific balance is 0, try using balance_id matching
            active_bid = self._ws_interceptor.get_active_balance_id()
            if active_bid:
                practice_bid = self._ws_interceptor._practice_balance_id
                real_bid = self._ws_interceptor._real_balance_id
                if active_bid == practice_bid and practice_bal > 0:
                    self._last_balance_read = practice_bal
                    self._ws_interceptor._balance = practice_bal
                    return practice_bal
                elif active_bid == real_bid and real_bal > 0:
                    self._last_balance_read = real_bal
                    self._ws_interceptor._balance = real_bal
                    return real_bal

            # Fallback: Use WS interceptor's general balance
            ws_balance = self._ws_interceptor.get_balance()
            if ws_balance > 0:
                self._last_balance_read = ws_balance
                return ws_balance

            # Leer del DOM con JS agresivo
            async def _read():
                return await self._read_balance_from_dom()

            balance = self._bridge.run(_read(), timeout=10)
            if balance and balance > 0:
                self._last_balance_read = balance
                self._ws_interceptor._balance = balance
                return balance

            # V6.3.2 FIX #7: Intentar leer balance via JS directo
            # como ultimo recurso antes de devolver cache
            try:
                async def _js_balance():
                    return await self._page.evaluate("""
                        () => {
                            // Try to find balance in any element
                            const allEls = document.querySelectorAll('*');
                            for (const el of allEls) {
                                if (el.children.length > 3) continue;
                                const text = (el.textContent || '').trim();
                                // Match $X,XXX.XX or X,XXX.XX
                                const m = text.match(
                                    /[\\$]\\s*([\\d,]+\\.\\d{2})/
                                );
                                if (m) {
                                    const val = parseFloat(
                                        m[1].replace(/,/g, '')
                                    );
                                    if (val > 0 && val < 1000000) return val;
                                }
                            }
                            return 0;
                        }
                    """)

                js_bal = self._bridge.run(_js_balance(), timeout=8)
                if js_bal and js_bal > 0:
                    self._last_balance_read = js_bal
                    self._ws_interceptor._balance = js_bal
                    return js_bal
            except Exception:
                pass

            # V7.2: Final attempt - poll JS WS messages for balance
            try:
                self._poll_js_ws_messages()
                ws_bal = self._ws_interceptor.get_balance()
                if ws_bal > 0:
                    self._last_balance_read = ws_bal
                    return ws_bal
                # Check practice/real balance
                practice_bal = self._ws_interceptor.get_practice_balance()
                real_bal = self._ws_interceptor.get_real_balance()
                active_bid = self._ws_interceptor.get_active_balance_id()
                if active_bid == self._ws_interceptor._practice_balance_id and practice_bal > 0:
                    self._last_balance_read = practice_bal
                    self._ws_interceptor._balance = practice_bal
                    return practice_bal
                elif active_bid == self._ws_interceptor._real_balance_id and real_bal > 0:
                    self._last_balance_read = real_bal
                    self._ws_interceptor._balance = real_bal
                    return real_bal
                elif practice_bal > 0:
                    self._last_balance_read = practice_bal
                    self._ws_interceptor._balance = practice_bal
                    return practice_bal
            except Exception:
                pass

            # Retornar ultimo balance conocido
            return self._last_balance_read

        except Exception as e:
            logger.debug(f"[Balance] Error: {e}")
            return self._last_balance_read

    def get_balance_safe(self):
        """Obtiene el balance con reintentos.
        Returns: float"""
        for attempt in range(3):
            try:
                balance = self.get_balance()
                if balance > 0:
                    return balance
            except Exception:
                pass
            time.sleep(random.uniform(1.0, 3.0))
        return self._last_balance_read

    def get_all_profit(self, force_refresh=False):
        """Obtiene datos de payout/profit de todos los instrumentos.
        Returns: dict

        V7 FIX: Uses WS request-response protocol via browser JS.
        IQ Option's WS protocol requires sending a request message
        and waiting for a result response. We do this via page.evaluate()
        which has access to the browser's WebSocket connection.
        """
        try:
            now = time.time()

            # Usar cache si es reciente
            if (not force_refresh and self._profit_cache and
                    (now - self._profit_cache_time) < self._profit_cache_ttl):
                return self._profit_cache

            # Desde WS interceptor cache first
            profit = self._ws_interceptor.get_profit()
            if profit and len(profit) > 3:
                # V7: Check if we have OTC profit data
                has_otc = any("otc" in k.lower() for k in profit.keys())
                if has_otc:
                    self._profit_cache = profit
                    self._profit_cache_time = now
                    return profit

            # V7: Request profit data via browser's internal API
            async def _request_profit():
                try:
                    # Method 1: Try IQ Option's internal API
                    result = await self._page.evaluate("""
                        async () => {
                            try {
                                // Try the internal API
                                const response = await fetch(
                                    'https://iqoption.com/api/v1/instruments',
                                    {credentials: 'include'}
                                );
                                if (response.ok) {
                                    const data = await response.json();
                                    return data;
                                }
                            } catch(e) {}

                            try {
                                const response = await fetch(
                                    'https://iqoption.com/api/profit',
                                    {credentials: 'include'}
                                );
                                if (response.ok) {
                                    return await response.json();
                                }
                            } catch(e) {}

                            return null;
                        }
                    """)
                    return result
                except Exception:
                    return None

            result = self._bridge.run(_request_profit(), timeout=15)
            if result:
                if isinstance(result, dict):
                    # Look for profit data in various formats
                    for key in ('result', 'data', 'msg', 'instruments'):
                        if key in result and isinstance(result[key], (dict, list)):
                            sub = result[key]
                            if isinstance(sub, dict):
                                self._profit_cache = sub
                                break
                            elif isinstance(sub, list):
                                profit_dict = {}
                                for item in sub:
                                    if isinstance(item, dict):
                                        name = item.get("name",
                                                item.get("instrument",
                                                item.get("active_name", "")))
                                        if name:
                                            profit_dict[name] = item
                                if profit_dict:
                                    self._profit_cache = profit_dict
                                    break
                    else:
                        self._profit_cache = result
                elif isinstance(result, list):
                    profit_dict = {}
                    for item in result:
                        if isinstance(item, dict):
                            name = item.get("name",
                                            item.get("instrument", ""))
                            if name:
                                profit_dict[name] = item
                    if profit_dict:
                        self._profit_cache = profit_dict

                self._profit_cache_time = now
                if self._profit_cache:
                    return self._profit_cache

            # V7: If still no profit data, construct from OTC instrument list
            # with default payout info (87% for OTC pairs)
            if not self._profit_cache:
                default_payout = 0.87  # 87% default for OTC
                from instruments import OTC_FALLBACK
                profit_dict = {}
                for name in OTC_FALLBACK.keys():
                    profit_dict[name] = {"turbo": default_payout, "binary": default_payout}
                self._profit_cache = profit_dict
                self._profit_cache_time = now
                logger.info(f"[Profit] Usando payout por defecto ({int(default_payout*100)}%) "
                            f"para {len(profit_dict)} instrumentos OTC")

            return self._profit_cache or {}

        except Exception as e:
            logger.error(f"[Profit] Error: {e}")
            return self._profit_cache or {}

    def change_balance(self, Balance_MODE):
        """Cambia entre cuenta Practice y Real.
        Args: Balance_MODE (str) - "PRACTICE" o "REAL"

        V7.3 CRITICAL FIX: Also updates _active_account_mode so get_balance()
        returns the correct balance for the active account mode.

        V7.1 CRITICAL FIX: Use WS sendMessage to switch account, like the
        JavaScript SDK does. IQ Option switches accounts by sending:
        ["sendMessage", {"name": "set-balance-id", "msg": {"id": balance_id}}]
        This is more reliable than clicking DOM elements.

        Falls back to DOM click if WS method fails.
        """
        # V7.3: Update active account mode FIRST so get_balance() uses it
        self._active_account_mode = Balance_MODE.upper()
        logger.info(f"[Account] Modo activo establecido a: {self._active_account_mode}")
        try:
            # V7.1: Method 1 - Send WS message via browser (like JS SDK)
            # This is how the IQ Option web app switches accounts internally
            target_bid = self._ws_interceptor.get_balance_id(Balance_MODE)
            # V7.2: Always try the WS method first if we have a balance_id
            # But also try DOM method even without balance_id
            if target_bid:
                logger.info(f"[Account] Enviando set-balance-id via WS: "
                            f"id={target_bid} ({Balance_MODE})")

                async def _ws_switch():
                    try:
                        # Determine if we're switching to Practice or Real
                        is_practice = Balance_MODE.upper() == "PRACTICE"
                        result = await self._page.evaluate("""
                            ([balanceId, isPractice]) => {
                                // V7.1: Send set-balance-id via the page's WebSocket
                                // IQ Option uses: ["sendMessage", {"name": "set-balance-id", "msg": {"id": balanceId}}]

                                // Method A: Use the WS instance captured by our sniffer
                                try {
                                    const ws = window.__ouhries_ws_instance;
                                    if (ws && ws.readyState === WebSocket.OPEN) {
                                        const msg = JSON.stringify([
                                            "sendMessage",
                                            {"name": "set-balance-id",
                                             "msg": {"id": balanceId}}
                                        ]);
                                        ws.send(msg);
                                        return {sent: true, method: 'ws_send_direct'};
                                    }
                                } catch(e) {}

                                // Method B: Try Redux dispatch
                                try {
                                    if (window.__store__) {
                                        window.__store__.dispatch({
                                            type: 'SET_BALANCE_ID',
                                            payload: {id: balanceId}
                                        });
                                        return {sent: true, method: 'redux_dispatch'};
                                    }
                                } catch(e) {}

                                // Method C: DOM click fallback
                                const allEls = document.querySelectorAll(
                                    'button, a, div, span, [role="button"], [role="tab"]'
                                );

                                for (const el of allEls) {
                                    const text = el.textContent?.trim() || '';
                                    const ariaLabel = el.getAttribute('aria-label') || '';
                                    const combined = text + ' ' + ariaLabel;

                                    if (isPractice) {
                                        for (const t of ['Practice', 'PRACTICE', 'Demo', 'DEMO']) {
                                            if (combined.includes(t) && !combined.includes('Real')
                                                && el.offsetParent !== null) {
                                                el.click();
                                                return {sent: true, method: 'dom_click_practice',
                                                        text: text.substring(0, 50)};
                                            }
                                        }
                                    } else {
                                        for (const t of ['Real', 'REAL']) {
                                            if (combined.includes(t) && !combined.includes('Practice')
                                                && el.offsetParent !== null) {
                                                el.click();
                                                return {sent: true, method: 'dom_click_real',
                                                        text: text.substring(0, 50)};
                                            }
                                        }
                                    }
                                }

                                return {sent: false, method: 'none'};
                            }
                        """, [target_bid, is_practice])
                        return result
                    except Exception as e:
                        logger.debug(f"[Account] WS switch error: {e}")
                        return None

                ws_result = self._bridge.run(_ws_switch(), timeout=30)
                if ws_result and ws_result.get("sent"):
                    logger.info(f"[Account] Cambio via WS/DOM: "
                                f"method={ws_result.get('method')}, "
                                f"text={ws_result.get('text', '')}")
                    # Update active balance_id
                    self._ws_interceptor._active_balance_id = target_bid
                    # Wait for balance update
                    time.sleep(random.uniform(2.0, 4.0))
                    # Force read balance
                    balance = self.get_balance()
                    logger.info(f"[Account] Cambiado a {Balance_MODE}. "
                                f"Balance: ${balance:.2f}")
                    return
                else:
                    logger.warning(f"[Account] WS/DOM switch fallo, "
                                   f"intentando metodo JS alternativo...")

            # Method 2: Fallback - Use the original JS account switch
            async def _switch():
                return await self._switch_account_js(Balance_MODE)

            # V6.3.2 FIX #1: Timeout aumentado a 60s
            result = self._bridge.run(_switch(), timeout=60)

            if result:
                logger.info(f"[Account] Cambiado a {Balance_MODE}")
                # Esperar un poco y verificar balance
                time.sleep(random.uniform(1.0, 2.0))
                balance = self.get_balance()
                logger.info(f"[Account] Balance despues de cambio: "
                            f"${balance:.2f}")
            else:
                logger.warning(f"[Account] No se pudo cambiar a "
                               f"{Balance_MODE}")

        except Exception as e:
            exc_type = type(e).__name__
            logger.error(f"[Account] Error cambiando a {Balance_MODE}: "
                         f"[{exc_type}] {e}")

    def get_server_timestamp(self):
        """Obtiene timestamp del servidor.
        Returns: float"""
        ts = self._ws_interceptor.get_server_timestamp()
        if ts > 0:
            return ts
        # Fallback: usar hora del navegador
        try:
            async def _get_time():
                return await self._page.evaluate("Date.now() / 1000")
            ts = self._bridge.run(_get_time(), timeout=5)
            if ts:
                return ts
        except Exception:
            pass
        return time.time()

    def get_async_order(self, id_number):
        """Obtiene informacion de una orden.
        Returns: dict"""
        # Buscar en WS interceptor
        result = self._ws_interceptor.get_trade_result(str(id_number))
        if result is not None:
            return {"id": id_number, "profit": result}

        # Buscar en pendientes
        with self._lock:
            trade = self._pending_trades.get(str(id_number))
            if trade:
                return {"id": id_number, "status": "pending", **trade}

        return {"id": id_number, "status": "unknown"}

    def close(self):
        """Cierra la conexion y el navegador."""
        try:
            self._connected = False
            self._stop_mouse_activity()

            async def _close():
                try:
                    if self._page and not self._page.is_closed():
                        await self._page.close()
                except Exception:
                    pass
                try:
                    if self._context:
                        await self._context.close()
                except Exception:
                    pass
                try:
                    if self._browser:
                        await self._browser.close()
                except Exception:
                    pass
                try:
                    if hasattr(self, '_playwright') and self._playwright:
                        await self._playwright.stop()
                except Exception:
                    pass

            try:
                self._bridge.run(_close(), timeout=15)
            except Exception:
                pass

            self._bridge.stop()

            logger.info("[Close] Navegador cerrado")

        except Exception as e:
            logger.debug(f"[Close] Error: {e}")

    # ============================================================
    # ACTIVITY SIMULATION - Actividad fuera de trading
    # ============================================================
    def simulate_deposit_visit(self):
        """Simula una visita a la pagina de deposito
        (actividad fuera de trading)."""
        try:
            async def _visit():
                sel = self._selectors["navigation"]
                for selector in [sel["deposit_link"],
                                 'a:has-text("Deposit")',
                                 'button:has-text("Deposit")']:
                    try:
                        el = await self._page.wait_for_selector(
                            selector, timeout=3000)
                        if el:
                            await self._human_move_to_element(el)
                            await el.click()
                            await asyncio.sleep(
                                random.uniform(3.0, 8.0))
                            # Volver atras
                            await self._page.go_back()
                            await asyncio.sleep(
                                random.uniform(1.0, 3.0))
                            return
                    except Exception:
                        continue
            self._bridge.run(_visit(), timeout=20)
        except Exception:
            pass

    def simulate_settings_visit(self):
        """Simula una visita a la pagina de ajustes."""
        try:
            async def _visit():
                sel = self._selectors["navigation"]
                for selector in [sel["settings_link"],
                                 'a:has-text("Settings")',
                                 '[class*="settings"]']:
                    try:
                        el = await self._page.wait_for_selector(
                            selector, timeout=3000)
                        if el:
                            await self._human_move_to_element(el)
                            await el.click()
                            await asyncio.sleep(
                                random.uniform(3.0, 8.0))
                            await self._page.go_back()
                            await asyncio.sleep(
                                random.uniform(1.0, 3.0))
                            return
                    except Exception:
                        continue
            self._bridge.run(_visit(), timeout=20)
        except Exception:
            pass

    def simulate_scroll_chart(self):
        """Simula scroll en el grafico
        (como un usuario revisando el historial)."""
        try:
            async def _scroll():
                # Click en el area del grafico
                chart_area = await self._page.query_selector(
                    '[class*="chart"], [class*="Chart"], canvas')
                if chart_area:
                    box = await chart_area.bounding_box()
                    if box:
                        # Mover mouse al centro del grafico
                        center_x = box['x'] + box['width'] / 2
                        center_y = box['y'] + box['height'] / 2
                        await self._page.mouse.move(
                            center_x, center_y, steps=10)

                        # Scroll horizontal (como viendo historial)
                        for _ in range(random.randint(2, 5)):
                            await self._page.mouse.wheel(
                                random.randint(-200, -100), 0)
                            await asyncio.sleep(
                                random.uniform(0.3, 1.0))

                        # Scroll de vuelta
                        for _ in range(random.randint(1, 3)):
                            await self._page.mouse.wheel(
                                random.randint(100, 200), 0)
                            await asyncio.sleep(
                                random.uniform(0.3, 0.8))
            self._bridge.run(_scroll(), timeout=15)
        except Exception:
            pass

    # ============================================================
    # SELECTOR DISCOVERY MODE
    # ============================================================
    def discover_selectors(self):
        """Modo de descubrimiento: mapea todos los elementos interactivos
        del dashboard y los guarda en selector_map_discovered.json.
        Ejecutar DESPUES de conectar exitosamente."""
        try:
            async def _discover():
                result = {}

                # Obtener todos los elementos interactivos
                elements = await self._page.evaluate("""
                    () => {
                        const elements = [];
                        const tags = ['button', 'input', 'select', 'a',
                                      '[role="button"]'];
                        for (const tag of tags) {
                            for (const el of document.querySelectorAll(tag)) {
                                const rect = el.getBoundingClientRect();
                                if (rect.width > 0 && rect.height > 0) {
                                    elements.push({
                                        tag: el.tagName,
                                        id: el.id,
                                        classes: el.className?.substring?.(
                                            0, 100),
                                        text: el.textContent?.substring?.(
                                            0, 80),
                                        type: el.type,
                                        name: el.name,
                                        placeholder: el.placeholder,
                                        href: el.href,
                                        role: el.role ||
                                              el.getAttribute('role'),
                                        x: Math.round(rect.x),
                                        y: Math.round(rect.y),
                                        width: Math.round(rect.width),
                                        height: Math.round(rect.height),
                                    });
                                }
                            }
                        }
                        return elements;
                    }
                """)

                result["elements"] = elements
                result["url"] = self._page.url
                result["timestamp"] = datetime.now().isoformat()
                # V6.3.2: Include WS message count for debug
                result["ws_message_count"] = \
                    self._ws_interceptor.message_count
                result["ws_connected"] = \
                    self._ws_interceptor.is_connected()

                # Guardar
                discover_file = os.path.join(
                    os.path.dirname(__file__),
                    "selector_map_discovered.json")
                with open(discover_file, "w") as f:
                    json.dump(result, f, indent=2)

                logger.info(f"[Discovery] {len(elements)} elementos "
                            f"encontrados guardados en {discover_file}")
                return len(elements)

            return self._bridge.run(_discover(), timeout=30)

        except Exception as e:
            logger.error(f"[Discovery] Error: {e}")
            return 0

    # ============================================================
    # SCREENSHOT & DEBUG
    # ============================================================
    def take_screenshot(self, filename="screenshot.png"):
        """Toma una captura de pantalla del navegador."""
        try:
            filepath = os.path.join(os.path.dirname(__file__), filename)
            async def _screenshot():
                await self._page.screenshot(
                    path=filepath, full_page=False)
                return filepath
            return self._bridge.run(_screenshot(), timeout=15)
        except Exception as e:
            logger.error(f"[Screenshot] Error: {e}")
            return None

    def get_page_html(self):
        """Obtiene el HTML de la pagina actual (para debug)."""
        try:
            async def _html():
                return await self._page.content()
            return self._bridge.run(_html(), timeout=15)
        except Exception as e:
            logger.error(f"[Debug] Error: {e}")
            return None
