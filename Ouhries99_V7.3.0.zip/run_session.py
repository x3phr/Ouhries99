#!/usr/bin/env python3
"""
Sistema Ouhries V7.3.0 - Script de Sesion de Trading
Ejecuta una sesion de N operaciones y reporta resultados via Telegram.
Uso: python3 run_session.py
"""
import sys
import os
import time
import logging
import json
from datetime import datetime

# Setup logging to console + file
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('/home/z/my-project/download/session.log', mode='w')
    ]
)
logger = logging.getLogger("session")

# Add current dir to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import load_config, save_config
from engine import TradingEngine
from telegram_notifier import TelegramNotifier


def main():
    print("\n" + "=" * 60)
    print("  SISTEMA OUHRIES V7 - SESION DE TRADING")
    print("=" * 60)
    print(f"  Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60 + "\n")

    # Load config
    config = load_config()
    logger.info(f"[Session] Configuracion cargada")
    logger.info(f"[Session] Capital: ${config.get('capital_operacion', 1.0):.2f}")
    logger.info(f"[Session] Max trades: {config.get('max_trades', 4)}")
    logger.info(f"[Session] Cuenta: {config.get('account_mode', 'PRACTICE')}")
    logger.info(f"[Session] Telegram: {'ON' if config.get('telegram_enabled') else 'OFF'}")

    # Clear any previous state
    for f in ['session_state.json', 'session_log.json']:
        try:
            os.remove(f)
        except Exception:
            pass

    # Initialize Telegram for early notifications
    telegram = TelegramNotifier(
        token=config.get("telegram_token", ""),
        chat_id=config.get("telegram_chat_id", ""),
        enabled=config.get("telegram_enabled", False),
        log_callback=lambda x: None
    )
    telegram.start()
    telegram.send("🚀 INICIANDO SESION DE TRADING - V7 (4 ops x $1)")

    # Create engine with callbacks
    def log_cb(msg):
        print(f"  {msg}")

    def status_cb(msg):
        logger.info(f"[Status] {msg}")

    def radar_cb(asset, idx, total):
        if idx > 0:
            logger.info(f"[Radar] {asset} ({idx}/{total})")

    def trade_cb(trade_info):
        result = trade_info.get("resultado", "")
        if result == "WIN":
            logger.info(f"[TRADE] ✅ WIN! {trade_info.get('activo')} "
                       f"{trade_info.get('direccion')} +${trade_info.get('profit', 0):.2f}")
        elif result == "LOSS":
            logger.info(f"[TRADE] ❌ LOSS {trade_info.get('activo')} "
                       f"{trade_info.get('direccion')} -${abs(trade_info.get('profit', 0)):.2f}")
        elif result == "...":
            logger.info(f"[TRADE] 🔄 Abriendo: {trade_info.get('activo')} "
                       f"{trade_info.get('direccion')} ${trade_info.get('monto', 0):.2f}")

    engine = TradingEngine(
        config,
        log_callback=log_cb,
        status_callback=status_cb,
        radar_callback=radar_cb,
        trade_callback=trade_cb
    )

    # Set session end callback
    def on_session_end(summary):
        logger.info(f"[Session] SESION FINALIZADA: {summary}")
        telegram.notify_session_end(
            total_trades=engine.total_trades,
            total_wins=engine.total_wins,
            total_losses=engine.total_losses,
            balance=engine.balance,
            initial_balance=engine.initial_balance,
            current_profit=engine.current_profit,
            end_reason=summary.get("reason", "unknown"),
            max_trades_config=config.get("max_trades", 4)
        )

    engine._session_end_callback = on_session_end

    # STEP 1: Connect
    logger.info("[Session] Paso 1: Conectando a IQ Option...")
    if not engine.connect():
        logger.error("[Session] FALLO la conexion!")
        telegram.notify_error("Fallo la conexion a IQ Option")
        return False

    logger.info(f"[Session] Conectado! Balance: ${engine.balance:.2f}")

    # STEP 2: Run trading session
    logger.info("[Session] Paso 2: Iniciando sesion de trading...")
    logger.info(f"[Session] Ejecutando hasta {config.get('max_trades', 4)} operaciones...")

    try:
        engine.run()
    except KeyboardInterrupt:
        logger.info("[Session] Sesion interrumpida por usuario")
        engine.stop()
    except Exception as e:
        logger.error(f"[Session] Error en sesion: {e}")
        telegram.notify_error(f"Error en sesion: {e}")

    # STEP 3: Report results
    logger.info("\n" + "=" * 60)
    logger.info("  RESULTADOS DE LA SESION")
    logger.info("=" * 60)
    logger.info(f"  Operaciones: {engine.total_trades}")
    logger.info(f"  Wins: {engine.total_wins}")
    logger.info(f"  Losses: {engine.total_losses}")
    win_rate = (engine.total_wins / engine.total_trades * 100) if engine.total_trades > 0 else 0
    logger.info(f"  Win Rate: {win_rate:.1f}%")
    logger.info(f"  Balance Final: ${engine.balance:.2f}")
    logger.info(f"  Profit: ${engine.current_profit:.2f}")
    logger.info("=" * 60)

    # Cleanup
    try:
        if engine.api:
            engine.api.close()
    except Exception:
        pass

    logger.info("[Session] Sesion completada")
    return True


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
