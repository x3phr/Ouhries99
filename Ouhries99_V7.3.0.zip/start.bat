@echo off
title Sistema Ouhries V7.3 - Trading Bot
echo ========================================================
echo   SISTEMA OUHRIES V7.3 - Playwright Anti-Detection
echo ========================================================
echo.

:: Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python no esta instalado o no esta en PATH
    echo Descarga Python 3.11+ de https://www.python.org/downloads/
    echo Asegurate de marcar "Add Python to PATH" durante la instalacion
    pause
    exit /b 1
)

:: Check if first run (need to install dependencies)
if not exist ".installed" (
    echo [SETUP] Primera ejecucion - Instalando dependencias...
    echo.
    
    pip install playwright fastapi uvicorn websockets requests numpy
    
    echo.
    echo [SETUP] Instalando navegador Chromium para Playwright...
    playwright install chromium
    
    echo.
    echo [SETUP] Buscando Brave browser...
    :: Try to find Brave browser
    set "BRAVE_FOUND=0"
    if exist "C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe" (
        set "BRAVE_PATH=C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe"
        set "BRAVE_FOUND=1"
        echo [SETUP] Brave encontrado: !BRAVE_PATH!
    )
    if exist "C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe" (
        set "BRAVE_PATH=C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe"
        set "BRAVE_FOUND=1"
        echo [SETUP] Brave encontrado: !BRAVE_PATH!
    )
    
    echo. > .installed
    echo [SETUP] Instalacion completada!
    echo.
)

:: Set Brave path if found
if defined BRAVE_PATH (
    set "BRAVE_PATH=!BRAVE_PATH!"
    echo [CONFIG] Usando Brave: !BRAVE_PATH!
) else (
    echo [CONFIG] Brave no encontrado, usando Chromium
)

echo.
echo ========================================================
echo   Selecciona modo de ejecucion:
echo ========================================================
echo   1. Interfaz Web (Recomendado - http://localhost:8585)
echo   2. Sesion automatica de trading (4 ops x $1)
echo   3. Instalar dependencias
echo   4. Salir
echo ========================================================
echo.
set /p choice="Selecciona (1-4): "

if "%choice%"=="1" goto web_ui
if "%choice%"=="2" goto auto_session
if "%choice%"=="3" goto setup
if "%choice%"=="4" exit /b 0
goto end

:web_ui
echo.
echo [START] Iniciando interfaz web en http://localhost:8585 ...
echo Abre tu navegador en esa URL para controlar el bot.
echo Presiona Ctrl+C para detener.
echo.
python server.py
goto end

:auto_session
echo.
echo [START] Iniciando sesion de trading automatica...
echo Presiona Ctrl+C para detener.
echo.
python run_session.py
goto end

:setup
del .installed 2>nul
echo [SETUP] Se reinstalaran las dependencias en el proximo inicio.
goto end

:end
pause
