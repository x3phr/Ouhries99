"""
Sistema Ouhries V5 - Notificador Telegram
Envia notificaciones de sesion, operaciones y resultados via Telegram Bot API.
Incluye hora de operacion en cada notificacion.
Todas las notificaciones se envian sync para garantizar entrega inmediata.
Notificaciones con emojis para mejor legibilidad.
"""

import requests
import threading
import time
from datetime import datetime


class TelegramNotifier:
    """Notificador via Telegram Bot API con envio inmediato, timestamps y emojis."""

    def __init__(self, token="", chat_id="", enabled=False, log_callback=None):
        self.token = token
        self.chat_id = chat_id
        self.enabled = enabled
        self.log = log_callback or (lambda x: None)
        self._running = False
        self._last_error_time = 0
        self._send_count = 0

    def configure(self, token=None, chat_id=None, enabled=None):
        if token is not None: self.token = token
        if chat_id is not None: self.chat_id = chat_id
        if enabled is not None: self.enabled = enabled

    def start(self):
        self._running = True
        # Enviar mensaje de verificacion
        if self.enabled and self.token and self.chat_id:
            self._send_message("✅ Sistema Ouhries V5 - Notificaciones ACTIVAS")

    def stop(self):
        self._running = False

    def _send_message(self, text):
        """Envio directo e inmediato - sin cola async que pueda perder mensajes."""
        if not self.token or not self.chat_id or not self.enabled:
            return
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        payload = {"chat_id": self.chat_id, "text": text, "parse_mode": "HTML"}
        try:
            response = requests.post(url, json=payload, timeout=15)
            if response.status_code == 200:
                result = response.json()
                if not result.get("ok"):
                    now = time.time()
                    if now - self._last_error_time > 60:
                        self.log(f"[Telegram] Error API: {result.get('description', 'desconocido')}")
                        self._last_error_time = now
                else:
                    self._send_count += 1
            else:
                now = time.time()
                if now - self._last_error_time > 60:
                    self.log(f"[Telegram] Error HTTP {response.status_code}")
                    self._last_error_time = now
        except requests.exceptions.Timeout:
            now = time.time()
            if now - self._last_error_time > 60:
                self.log("[Telegram] Timeout enviando mensaje")
                self._last_error_time = now
        except requests.exceptions.ConnectionError:
            now = time.time()
            if now - self._last_error_time > 60:
                self.log("[Telegram] Error de conexion")
                self._last_error_time = now
        except Exception as e:
            now = time.time()
            if now - self._last_error_time > 60:
                self.log(f"[Telegram] Error enviando: {e}")
                self._last_error_time = now

    def send(self, text):
        """Envio inmediato."""
        if not self.enabled or not self.token or not self.chat_id: return
        self._send_message(text)

    def send_sync(self, text):
        """Envio sincrono - mismo que send ahora."""
        if not self.enabled or not self.token or not self.chat_id: return
        self._send_message(text)

    def notify_session_start(self, config, balance, mode, had_previous=False):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        mode_text = "\U0001f3b2 DEMO" if mode == "PRACTICE" else "\U0001f4b0 REAL"
        previous_text = "\n\U0001f504 Sesion recuperada" if had_previous else "\n\U0001f195 Sesion nueva"
        use_v3 = config.get("use_strategy_v3", True)
        strategy_text = "V3 (Alto Winrate)" if use_v3 else "V2 (ADX+Calidad)"
        niveles_val = config.get('niveles', 3)
        niveles_text = "\u274c OFF (Capital fijo)" if config.get('disable_niveles') else f"\U0001f538 {niveles_val} niveles"
        max_trades_val = config.get('max_trades', 0)
        max_trades_text = str(max_trades_val) if max_trades_val > 0 else "Sin limite"
        msg = (
            f"\U0001f680 SISTEMA OUHRIES V5 - INICIADO\n"
            f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
            f"\U0001f4c5 Fecha: {now}\n"
            f"\U0001f4bc Cuenta: {mode_text}\n"
            f"\U0001f4b5 Balance: ${balance:.2f}\n"
            f"\U0001f4b3 Capital Op: ${config.get('capital_operacion', 2.50):.2f}\n"
            f"\U0001f522 Niveles: {niveles_text}\n"
            f"\U0001f3af Stop Win: ${config.get('stop_win', 7.0):.2f}\n"
            f"\U0001f6d1 Stop Loss: ${config.get('stop_loss', 5.0):.2f}\n"
            f"\U0001f4c8 Payout: {config.get('payout_min', 87)}%+\n"
            f"\U0001f9e0 Estrategia: {strategy_text}\n"
            f"\U0001f5f3 Votos min: {config.get('min_strategy_votes', 7)}\n"
            f"\U0001f4ca Calidad min: {config.get('min_signal_quality', 88)}%\n"
            f"\U0001f522 Max trades: {max_trades_text}"
            f"{previous_text}"
        )
        self.send_sync(msg)

    def notify_trade_opened(self, instrument, direction, amount, level, sublevel, payout, trade_time=None):
        level_text = f"N1{'+'*sublevel}" if sublevel > 0 else "N1"
        direction_text = "\U0001f7e2 CALL\u2b06" if direction.lower() == "call" else "\U0001f534 PUT\u2b07"
        hora = trade_time or datetime.now().strftime("%H:%M:%S")
        fecha = datetime.now().strftime("%Y-%m-%d")
        msg = (
            f"\U0001f4e2 OPERACION ABIERTA\n"
            f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
            f"{direction_text} {instrument}\n"
            f"\U0001f4b0 Monto: ${amount:.2f}\n"
            f"\U0001f538 Nivel: {level_text}\n"
            f"\U0001f4c8 Payout: {payout}%\n"
            f"\u23f1 Expiracion: 1min\n"
            f"\U0001f552 Hora de entrada: {fecha} {hora}"
        )
        self.send(msg)

    def notify_trade_result(self, instrument, direction, won, profit, amount, balance,
                            level, sublevel, total_trades, total_wins, total_losses,
                            current_profit, trade_time=None):
        if won:
            result_text = "\u2705 WIN"
            profit_text = f"\U0001f4b8 +${profit:.2f}"
        else:
            result_text = "\u274c LOSS"
            profit_text = f"\U0001f4b9 -${abs(profit):.2f}"

        direction_text = "\U0001f7e2 CALL\u2b06" if direction.lower() == "call" else "\U0001f534 PUT\u2b07"
        level_text = f"N1{'+'*sublevel}" if sublevel > 0 else "N1"
        win_rate = (total_wins / total_trades * 100) if total_trades > 0 else 0
        profit_sign = "+" if current_profit >= 0 else ""
        profit_emoji = "\U0001f4c8" if current_profit >= 0 else "\U0001f4c9"
        hora = trade_time or datetime.now().strftime("%H:%M:%S")
        msg = (
            f"{result_text}\n"
            f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
            f"{direction_text} {instrument}\n"
            f"\U0001f4b0 Monto: ${amount:.2f}\n"
            f"{profit_text}\n"
            f"\U0001f538 Nivel: {level_text}\n"
            f"\U0001f4b5 Balance: ${balance:.2f}\n"
            f"{profit_emoji} Profit sesion: {profit_sign}${current_profit:.2f}\n"
            f"\U0001f552 Hora operacion: {hora}\n"
            f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
            f"\U0001f4ca Ops: {total_trades} | \u2705 W: {total_wins} | \u274c L: {total_losses}\n"
            f"\U0001f3af Win rate: {win_rate:.1f}%"
        )
        self.send(msg)

    def notify_session_end(self, total_trades, total_wins, total_losses,
                           balance, initial_balance, current_profit,
                           end_reason="manual", max_trades_config=0):
        """Notificacion de fin de sesion con razon y resumen completo.
        
        end_reason: 'stopwin', 'stoploss', 'max_trades', 'manual', 'error'
        max_trades_config: valor configurado de max_trades (0=sin limite)
        """
        win_rate = (total_wins / total_trades * 100) if total_trades > 0 else 0
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        profit_sign = "+" if current_profit >= 0 else ""
        
        # Razon de finalizacion con emojis
        reason_texts = {
            "stopwin": "\U0001f3c6 STOP WIN ALCANZADO",
            "stoploss": "\U0001f6d1 STOP LOSS ALCANZADO",
            "max_trades": f"\U0001f522 MAX OPERACIONES ALCANZADO ({total_trades}/{max_trades_config})",
            "manual": "\u270b DETENIDO MANUALMENTE",
            "error": "\u26a0\ufe0f ERROR EN EL SISTEMA",
        }
        reason_text = reason_texts.get(end_reason, "\u2753 RAZON DESCONOCIDA")
        
        # Emoji segun resultado
        if current_profit > 0:
            result_icon = "\U0001f3c6 SESION GANADORA \U0001f4c8"
        elif current_profit == 0:
            result_icon = "\U0001f4ca SESION NEUTRA \u2796"
        else:
            result_icon = "\U0001f4c9 SESION PERDEDORA \u274c"
        
        profit_emoji = "\U0001f4b8" if current_profit >= 0 else "\U0001f4b9"
        
        msg = (
            f"\U0001f6a9 SESION FINALIZADA\n"
            f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
            f"{result_icon}\n"
            f"\U0001f4cb Razon: {reason_text}\n"
            f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
            f"\U0001f4c5 Fecha: {now}\n"
            f"\U0001f4ca Total operaciones: {total_trades}\n"
            f"\u2705 Wins: {total_wins} | \u274c Losses: {total_losses}\n"
            f"\U0001f3af Win rate: {win_rate:.1f}%\n"
            f"\U0001f4b5 Balance final: ${balance:.2f}\n"
            f"\U0001f4b3 Balance inicial: ${initial_balance:.2f}\n"
            f"{profit_emoji} Profit total: {profit_sign}${current_profit:.2f}"
        )
        self.send(msg)

    def notify_error(self, error_msg):
        now = datetime.now().strftime("%H:%M:%S")
        msg = f"\u26a0\ufe0f ERROR [{now}]\n\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n\u274c {error_msg}"
        self.send(msg)

    def notify_stop_hit(self, stop_type, profit, balance,
                        total_trades=0, total_wins=0, total_losses=0):
        now = datetime.now().strftime("%H:%M:%S")
        if stop_type == "win":
            text = "\U0001f3c6 STOP WIN ALCANZADO \U0001f4c8"
        else:
            text = "\U0001f6d1 STOP LOSS ALCANZADO \U0001f4c9"
        profit_sign = "+" if profit >= 0 else ""
        profit_emoji = "\U0001f4b8" if profit >= 0 else "\U0001f4b9"
        win_rate = (total_wins / total_trades * 100) if total_trades > 0 else 0
        msg = (
            f"{text}\n"
            f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
            f"\U0001f552 Hora: {now}\n"
            f"\U0001f4b5 Balance: ${balance:.2f}\n"
            f"{profit_emoji} Profit: {profit_sign}${profit:.2f}\n"
            f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
            f"\U0001f4ca Ops: {total_trades} | \u2705 W: {total_wins} | \u274c L: {total_losses}\n"
            f"\U0001f3af Win rate: {win_rate:.1f}%"
        )
        self.send(msg)

    def test_connection(self):
        if not self.token or not self.chat_id:
            return False, "Token o Chat ID vacios"
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        now = datetime.now().strftime("%H:%M:%S")
        payload = {"chat_id": self.chat_id, "text": f"\u2705 Sistema Ouhries V5 - Notificaciones activadas [{now}]", "parse_mode": "HTML"}
        try:
            response = requests.post(url, json=payload, timeout=10)
            if response.status_code == 200:
                result = response.json()
                if result.get("ok"):
                    return True, "Mensaje de prueba enviado"
                else:
                    return False, result.get("description", "Error API")
            else:
                return False, f"Error HTTP {response.status_code}"
        except Exception as e:
            return False, str(e)
