"""
Sistema Ouhries V5 - Motor de Estrategia V3 (ALTO WINRATE)
Filosofia: EXTREMA SELECTIVIDAD - Menos operaciones, mayor probabilidad.

Mejoras clave sobre V2:
1. ADX >= 25 (tendencia mas fuerte requerida)
2. CERO operaciones contra-tendencia - solo a favor de la tendencia
3. Calidad >= 88% (confianza superior)
4. Minimo 7 votos (mas confirmacion)
5. RSI zonas extremas 20/80 (mas fiables que 25/75)
6. Confluencia multi-indicador obligatoria
7. Filtro de momentum direccional obligatorio
8. Filtro de volatilidad minima (evitar mercado muerto)
9. Bollinger squeeze como confirmacion de breakout
10. Ratio cuerpo/mecha para filtrar velas debiles

Regla de oro: Si hay duda, NO operar.
"""

import numpy as np

# Reusar patrones de strategies.py e indicadores avanzados de strategies_v2.py
from strategies.strategies import (
    PATTERN_FUNCTIONS, calc_rsi, calc_bollinger, calc_ma_cross,
    calc_macd, calc_stochastic, _ema, _avg_body
)
from strategies.strategies_v2 import (
    calc_adx, calc_ema_trend, calc_support_resistance,
    calc_candle_momentum, calc_volume_profile
)


def calc_atr(candles, period=14):
    """Average True Range - mide volatilidad."""
    if len(candles) < period + 1:
        return 0
    tr_list = []
    for i in range(1, len(candles)):
        h, l, c_prev = candles[i][1], candles[i][2], candles[i-1][3]
        tr = max(h - l, abs(h - c_prev), abs(l - c_prev))
        tr_list.append(tr)
    if not tr_list:
        return 0
    return np.mean(tr_list[-period:])


def calc_bollinger_width(closes, period=20):
    """Ancho de Bollinger Bands - detecta squeeze."""
    if len(closes) < period:
        return 0, False
    slice_c = closes[-period:]
    middle = np.mean(slice_c)
    std = np.std(slice_c)
    width = (2 * std) / middle if middle > 0 else 0
    # Verificar squeeze (width en percentil bajo de los ultimos 50 periodos)
    is_squeeze = False
    if len(closes) >= 50:
        widths = []
        for i in range(50, len(closes) + 1):
            s = closes[i-50:i]
            m = np.mean(s)
            sd = np.std(s)
            if m > 0:
                widths.append((2 * sd) / m)
        if widths and len(widths) >= 10:
            percentile_20 = np.percentile(widths, 20)
            is_squeeze = width <= percentile_20
    return width, is_squeeze


def calc_body_ratio(candles, n=5):
    """Ratio cuerpo/total de las ultimas N velas. >0.6 = velas con cuerpo definido."""
    if len(candles) < n:
        return 0
    ratios = []
    for c in candles[-n:]:
        total_range = c[1] - c[2]  # high - low
        body = abs(c[3] - c[0])
        if total_range > 0:
            ratios.append(body / total_range)
    return np.mean(ratios) if ratios else 0


def calc_di_direction(candles, period=14):
    """Direccion del DI+ vs DI- - confirma direccion de tendencia."""
    if len(candles) < period * 2:
        return 0, 0
    highs = [c[1] for c in candles]
    lows = [c[2] for c in candles]
    closes = [c[3] for c in candles]

    plus_dm = []
    minus_dm = []
    tr_list = []

    for i in range(1, len(candles)):
        high_diff = highs[i] - highs[i-1]
        low_diff = lows[i-1] - lows[i]

        plus_dm.append(high_diff if high_diff > low_diff and high_diff > 0 else 0)
        minus_dm.append(low_diff if low_diff > high_diff and low_diff > 0 else 0)

        tr = max(highs[i] - lows[i], abs(highs[i] - closes[i-1]), abs(lows[i] - closes[i-1]))
        tr_list.append(tr)

    if len(tr_list) < period:
        return 0, 0

    atr = np.mean(tr_list[-period:])
    if atr == 0:
        return 0, 0

    plus_di = (np.mean(plus_dm[-period:]) / atr) * 100
    minus_di = (np.mean(minus_dm[-period:]) / atr) * 100

    return plus_di, minus_di


def calc_trend_consistency(candles, n=10):
    """Que tan consistente es la tendencia en las ultimas N velas (0-1)."""
    if len(candles) < n:
        return 0
    recent = candles[-n:]
    # Contar velas en la misma direccion
    greens = sum(1 for c in recent if c[3] > c[0])
    reds = sum(1 for c in recent if c[3] < c[0])
    consistency = max(greens, reds) / n
    return consistency


def analyze_candles_v3(candles, min_votes=7):
    """
    Analisis V3 - ALTO WINRATE por extrema selectividad.

    Filtros obligatorios (cualquier fallo = NO operar):
    1. ADX >= 25 (tendencia fuerte)
    2. Tendencia EMA clara (alcista o bajista, no lateral)
    3. Momentum direccional confirmado
    4. Volatilidad suficiente (ATR > promedio)
    5. Velas con cuerpo definido (body ratio > 0.4)
    6. Calidad >= 85%
    7. Minimo 6 votos a favor
    8. NUNCA contra tendencia
    9. DI+/DI- debe confirmar direccion

    Retorna: dict con 'direction', 'quality', 'votes_detail' o None
    """
    if len(candles) < 30:
        return None

    detail = {
        "patterns_call": 0, "patterns_put": 0,
        "indicators_call": 0, "indicators_put": 0,
        "trend": "none", "adx": 0, "quality": 0,
        "filters_passed": [], "filters_failed": [],
    }

    closes = np.array([c[3] for c in candles])
    votes_call = 0
    votes_put = 0

    # ============================================================
    # FILTRO 1: ADX >= 25 (Mas estricto que V2)
    # ============================================================
    adx = calc_adx(candles)
    detail["adx"] = round(adx, 2)

    if adx < 25:
        detail["filters_failed"].append(f"ADX={adx:.1f}<25")
        return None
    detail["filters_passed"].append(f"ADX={adx:.1f}>=25")

    # ============================================================
    # FILTRO 2: Tendencia EMA clara - OBLIGATORIA
    # Si no hay tendencia, NO hay operacion
    # ============================================================
    ema_trend = calc_ema_trend(closes, 21)
    if ema_trend == 0:
        detail["filters_failed"].append("Sin tendencia EMA")
        return None

    if ema_trend == 1:
        detail["trend"] = "bullish"
        votes_call += 4  # Peso mayor que V2 (era 3)
        detail["filters_passed"].append("Tendencia EMA alcista")
    elif ema_trend == -1:
        detail["trend"] = "bearish"
        votes_put += 4
        detail["filters_passed"].append("Tendencia EMA bajista")

    # ============================================================
    # FILTRO 3: DI+/DI- debe confirmar direccion de tendencia
    # ============================================================
    plus_di, minus_di = calc_di_direction(candles)
    if detail["trend"] == "bullish" and plus_di < minus_di:
        detail["filters_failed"].append("DI+<DI- en tendencia alcista")
        return None
    elif detail["trend"] == "bearish" and minus_di < plus_di:
        detail["filters_failed"].append("DI->DI+ en tendencia bajista")
        return None
    detail["filters_passed"].append(f"DI confirma: DI+={plus_di:.1f}, DI-={minus_di:.1f}")

    # Bonificacion si DI es muy dominante
    if detail["trend"] == "bullish" and plus_di > minus_di * 1.5:
        votes_call += 1
    elif detail["trend"] == "bearish" and minus_di > plus_di * 1.5:
        votes_put += 1

    # ============================================================
    # FILTRO 4: Volatilidad suficiente (ATR > 70% del promedio)
    # Mercado muerto = senales falsas
    # ============================================================
    atr = calc_atr(candles, 14)
    if len(candles) >= 50:
        avg_atr = calc_atr(candles[:30], 14)
        if avg_atr > 0 and atr < avg_atr * 0.7:
            detail["filters_failed"].append(f"ATR bajo={atr:.6f}<70%avg")
            return None
    detail["filters_passed"].append(f"ATR={atr:.6f} OK")

    # ============================================================
    # FILTRO 5: Velas con cuerpo definido
    # Si las velas son mayormente dojis, las senales no son fiables
    # ============================================================
    body_ratio = calc_body_ratio(candles, 5)
    if body_ratio < 0.35:
        detail["filters_failed"].append(f"Body ratio={body_ratio:.2f}<0.35")
        return None
    detail["filters_passed"].append(f"Body ratio={body_ratio:.2f} OK")

    # ============================================================
    # PATRONES DE VELAS (peso 1) - Solo a favor de tendencia
    # ============================================================
    for pattern_fn in PATTERN_FUNCTIONS:
        try:
            result = pattern_fn(candles)
            if result == 1:
                # REGLA: Solo contar patrones alcistas en tendencia alcista
                if detail["trend"] == "bullish":
                    votes_call += 1
                    detail["patterns_call"] += 1
                # Patrones alcistas contra tendencia = ignorar
            elif result == -1:
                # REGLA: Solo contar patrones bajistas en tendencia bajista
                if detail["trend"] == "bearish":
                    votes_put += 1
                    detail["patterns_put"] += 1
                # Patrones bajistas contra tendencia = ignorar
        except Exception:
            continue

    # ============================================================
    # INDICADORES TECNICOS (peso 2) - Con filtro de tendencia
    # ============================================================

    # RSI con zonas EXTREMAS (20/80)
    try:
        rsi = calc_rsi(closes)
        if rsi < 20:
            # Solo CALL en tendencia alcista (oversold + uptrend = rebote)
            if detail["trend"] == "bullish":
                votes_call += 3  # Peso extra por RSI extremo + tendencia
                detail["indicators_call"] += 1
            # RSI oversold en tendencia bajista = ignorar (puede seguir bajando)
        elif rsi > 80:
            if detail["trend"] == "bearish":
                votes_put += 3
                detail["indicators_put"] += 1
        elif rsi < 30 and detail["trend"] == "bullish":
            votes_call += 1  # Senal debil pero a favor de tendencia
        elif rsi > 70 and detail["trend"] == "bearish":
            votes_put += 1
    except Exception:
        pass

    # Bollinger Bands - Solo a favor de tendencia
    try:
        lower, middle, upper = calc_bollinger(closes)
        if lower is not None:
            if closes[-1] <= lower and detail["trend"] == "bullish":
                # Precio en banda inferior + tendencia alcista = rebote alcista
                votes_call += 2
                detail["indicators_call"] += 1
            elif closes[-1] >= upper and detail["trend"] == "bearish":
                votes_put += 2
                detail["indicators_put"] += 1
            # Banda contraria a tendencia = NO contar
    except Exception:
        pass

    # Bollinger Squeeze como bonus
    try:
        width, is_squeeze = calc_bollinger_width(closes)
        if is_squeeze:
            # Squeeze + tendencia = breakout inminente a favor de tendencia
            if detail["trend"] == "bullish":
                votes_call += 1
                detail["filters_passed"].append("Bollinger squeeze + tendencia alcista")
            elif detail["trend"] == "bearish":
                votes_put += 1
                detail["filters_passed"].append("Bollinger squeeze + tendencia bajista")
    except Exception:
        pass

    # MA Cross - Solo a favor de tendencia
    try:
        ma_signal = calc_ma_cross(closes)
        if ma_signal == 1 and detail["trend"] == "bullish":
            votes_call += 2
            detail["indicators_call"] += 1
        elif ma_signal == -1 and detail["trend"] == "bearish":
            votes_put += 2
            detail["indicators_put"] += 1
    except Exception:
        pass

    # MACD - Solo a favor de tendencia
    try:
        macd_line, signal_line = calc_macd(closes)
        if macd_line > signal_line and detail["trend"] == "bullish":
            votes_call += 2
            detail["indicators_call"] += 1
        elif macd_line < signal_line and detail["trend"] == "bearish":
            votes_put += 2
            detail["indicators_put"] += 1
    except Exception:
        pass

    # Stochastic - Solo a favor de tendencia
    try:
        stoch = calc_stochastic(candles)
        if stoch < 20 and detail["trend"] == "bullish":
            votes_call += 2
            detail["indicators_call"] += 1
        elif stoch > 80 and detail["trend"] == "bearish":
            votes_put += 2
            detail["indicators_put"] += 1
    except Exception:
        pass

    # Soporte/Resistencia - Solo a favor de tendencia
    try:
        near_support, near_resistance = calc_support_resistance(candles)
        if near_support < 0.2 and detail["trend"] == "bullish":
            votes_call += 2
            detail["indicators_call"] += 1
        elif near_resistance < 0.2 and detail["trend"] == "bearish":
            votes_put += 2
            detail["indicators_put"] += 1
    except Exception:
        pass

    # Momentum - OBLIGATORIO que confirme tendencia
    try:
        momentum = calc_candle_momentum(candles, 3)
        if detail["trend"] == "bullish":
            if momentum > 0.3:
                votes_call += 2
                detail["indicators_call"] += 1
            elif momentum < -0.3:
                # Momentum bajista en tendencia alcista = peligro
                detail["filters_failed"].append("Momentum contra tendencia alcista")
                return None
        elif detail["trend"] == "bearish":
            if momentum < -0.3:
                votes_put += 2
                detail["indicators_put"] += 1
            elif momentum > 0.3:
                detail["filters_failed"].append("Momentum contra tendencia bajista")
                return None
    except Exception:
        pass

    # Consistencia de tendencia (bonus)
    try:
        consistency = calc_trend_consistency(candles, 10)
        if consistency >= 0.7:
            # Tendencia muy consistente
            if detail["trend"] == "bullish":
                votes_call += 1
            elif detail["trend"] == "bearish":
                votes_put += 1
            detail["filters_passed"].append(f"Tendencia consistente={consistency:.0%}")
    except Exception:
        pass

    # Perfil de volatilidad
    try:
        vol_profile = calc_volume_profile(candles)
        if vol_profile < 0.6:
            # Volatilidad decreciendo = mercado muriendo
            detail["filters_failed"].append(f"Vol profile={vol_profile:.2f}<0.6")
            return None
        detail["filters_passed"].append(f"Vol profile={vol_profile:.2f} OK")
    except Exception:
        pass

    # ============================================================
    # DETERMINAR DIRECCION FINAL
    # Solo operar A FAVOR de la tendencia (regla absoluta)
    # ============================================================

    if detail["trend"] == "bullish":
        direction = "call"
        signal_votes = votes_call
        against_votes = votes_put
    elif detail["trend"] == "bearish":
        direction = "put"
        signal_votes = votes_put
        against_votes = votes_call
    else:
        return None  # Ya filtrado arriba, pero por seguridad

    total_votes = signal_votes + against_votes

    if total_votes == 0:
        return None

    # ============================================================
    # FILTRO 6: Minimo de votos (7 = alta confirmacion)
    # ============================================================
    if signal_votes < min_votes:
        detail["filters_failed"].append(f"Votos={signal_votes}<{min_votes}")
        return None

    # ============================================================
    # FILTRO 7: Mayoridad calificada (65%+ - mas estricto que V2)
    # ============================================================
    signal_strength = signal_votes / total_votes
    if signal_strength < 0.65:
        detail["filters_failed"].append(f"Fuerza={signal_strength:.0%}<65%")
        return None

    # ============================================================
    # FILTRO 8: Contra-votos limitados (no mas del 35%)
    # ============================================================
    if against_votes > signal_votes * 0.5:
        detail["filters_failed"].append(f"Contra-votos={against_votes}>50% signal")
        return None

    # ============================================================
    # CALCULAR CALIDAD FINAL
    # ============================================================
    quality = min(100, int(
        signal_strength * 40 +           # 40% peso a fuerza de senal
        (signal_votes - against_votes) * 4 +  # 4pts por voto neto
        min(adx, 50) / 50 * 15 +         # 15% peso a ADX (cap 50)
        consistency * 100 * 0.1 +         # 10% peso a consistencia
        (body_ratio * 20)                 # Body ratio contribuye
    ))

    # Bonus por confluencia extrema
    if signal_votes >= 10:
        quality = min(100, quality + 5)
    if signal_votes >= 12:
        quality = min(100, quality + 5)
    if adx >= 35:
        quality = min(100, quality + 5)

    detail["quality"] = quality
    detail["votes_call"] = votes_call
    detail["votes_put"] = votes_put
    detail["signal_strength"] = signal_strength
    detail["total_votes"] = total_votes

    # ============================================================
    # FILTRO 9: Calidad minima 88%
    # ============================================================
    if quality < 88:
        detail["filters_failed"].append(f"Calidad={quality}%<88%")
        return None

    detail["filters_passed"].append(f"Calidad={quality}%>=88%")

    return {
        "direction": direction,
        "quality": quality,
        "votes_detail": detail,
        "total_votes": total_votes,
        "signal_votes": signal_votes,
        "against_votes": against_votes,
    }
