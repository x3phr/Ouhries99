"""
Sistema Ouhries V5 - Estrategias de Trading
31 Patrones de velas japonesas + 5 Indicadores tecnicos
Votacion ponderada con minimo de votos requeridos.
"""

import numpy as np

# ============================================================
# HELPERS
# ============================================================

def _body(o, c):
    return abs(c - o)

def _upper_shadow(o, c, h):
    return h - max(o, c)

def _lower_shadow(o, c, l):
    return min(o, c) - l

def _is_green(o, c):
    return c > o

def _is_red(o, c):
    return c < o

def _avg_body(candles, n=5):
    bodies = [abs(c[3] - c[0]) for c in candles[-n:]]
    return np.mean(bodies) if bodies else 0.0001

# ============================================================
# PATRONES ALCISTAS (11)
# ============================================================

def hammer(candles):
    if len(candles) < 2: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    lshadow = _lower_shadow(o, c, l)
    ushadow = _upper_shadow(o, c, h)
    if lshadow >= body * 2 and ushadow <= body * 0.3 and body > 0: return 1
    return 0

def inverted_hammer(candles):
    if len(candles) < 2: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    lshadow = _lower_shadow(o, c, l)
    ushadow = _upper_shadow(o, c, h)
    if ushadow >= body * 2 and lshadow <= body * 0.3 and body > 0: return 1
    return 0

def bullish_engulfing(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if _is_red(prev[0], prev[3]) and _is_green(curr[0], curr[3]):
        if curr[0] <= prev[3] and curr[3] >= prev[0]: return 1
    return 0

def morning_star(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_red(c1[0], c1[3]) and _body(c2[0], c2[3]) < _body(c1[0], c1[3]) * 0.3:
        if _is_green(c3[0], c3[3]) and c3[3] > (c1[0] + c1[3]) / 2: return 1
    return 0

def three_white_soldiers(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if all(_is_green(c[0], c[3]) for c in [c1, c2, c3]):
        if c1[3] < c2[3] < c3[3] and c2[0] > c1[0] and c3[0] > c2[0]: return 1
    return 0

def piercing_line(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if _is_red(prev[0], prev[3]) and _is_green(curr[0], curr[3]):
        mid = (prev[0] + prev[3]) / 2
        if curr[0] < prev[3] and curr[3] > mid: return 1
    return 0

def tweezers_bottom(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if abs(prev[2] - curr[2]) < _avg_body(candles) * 0.1:
        if _is_red(prev[0], prev[3]) and _is_green(curr[0], curr[3]): return 1
    return 0

def three_inside_up(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_red(c1[0], c1[3]) and _is_green(c2[0], c2[3]):
        if c2[0] > c1[3] and c2[3] < c1[0]:
            if _is_green(c3[0], c3[3]) and c3[3] > c1[0]: return 1
    return 0

def three_outside_up(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if bullish_engulfing(candles[-2:]) == 1:
        if _is_green(c3[0], c3[3]) and c3[3] > c2[3]: return 1
    return 0

def abandoned_baby_bottom(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_red(c1[0], c1[3]) and _body(c2[0], c2[3]) < _body(c1[0], c1[3]) * 0.1:
        if _is_green(c3[0], c3[3]):
            if c2[1] < c1[2] and c2[1] < c3[2]: return 1
    return 0

def dragonfly_doji(candles):
    if len(candles) < 1: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    if body < _avg_body(candles) * 0.1:
        if _lower_shadow(o, c, l) > body * 3 and _upper_shadow(o, c, h) < body * 0.5: return 1
    return 0

# ============================================================
# PATRONES BAJISTAS (11)
# ============================================================

def hanging_man(candles):
    if len(candles) < 2: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    lshadow = _lower_shadow(o, c, l)
    ushadow = _upper_shadow(o, c, h)
    if lshadow >= body * 2 and ushadow <= body * 0.3:
        prev = candles[-2]
        if _is_green(prev[0], prev[3]): return -1
    return 0

def shooting_star(candles):
    if len(candles) < 2: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    ushadow = _upper_shadow(o, c, h)
    lshadow = _lower_shadow(o, c, l)
    if ushadow >= body * 2 and lshadow <= body * 0.3: return -1
    return 0

def bearish_engulfing(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if _is_green(prev[0], prev[3]) and _is_red(curr[0], curr[3]):
        if curr[0] >= prev[3] and curr[3] <= prev[0]: return -1
    return 0

def evening_star(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_green(c1[0], c1[3]) and _body(c2[0], c2[3]) < _body(c1[0], c1[3]) * 0.3:
        if _is_red(c3[0], c3[3]) and c3[3] < (c1[0] + c1[3]) / 2: return -1
    return 0

def three_black_crows(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if all(_is_red(c[0], c[3]) for c in [c1, c2, c3]):
        if c1[3] > c2[3] > c3[3] and c2[0] < c1[0] and c3[0] < c2[0]: return -1
    return 0

def dark_cloud_cover(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if _is_green(prev[0], prev[3]) and _is_red(curr[0], curr[3]):
        mid = (prev[0] + prev[3]) / 2
        if curr[0] > prev[3] and curr[3] < mid: return -1
    return 0

def tweezers_top(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    if abs(prev[1] - curr[1]) < _avg_body(candles) * 0.1:
        if _is_green(prev[0], prev[3]) and _is_red(curr[0], curr[3]): return -1
    return 0

def three_inside_down(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_green(c1[0], c1[3]) and _is_red(c2[0], c2[3]):
        if c2[0] < c1[3] and c2[3] > c1[0]:
            if _is_red(c3[0], c3[3]) and c3[3] < c1[0]: return -1
    return 0

def three_outside_down(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if bearish_engulfing(candles[-2:]) == -1:
        if _is_red(c3[0], c3[3]) and c3[3] < c2[3]: return -1
    return 0

def abandoned_baby_top(candles):
    if len(candles) < 3: return 0
    c1, c2, c3 = candles[-3], candles[-2], candles[-1]
    if _is_green(c1[0], c1[3]) and _body(c2[0], c2[3]) < _body(c1[0], c1[3]) * 0.1:
        if _is_red(c3[0], c3[3]):
            if c2[2] > c1[1] and c2[2] > c3[1]: return -1
    return 0

def gravestone_doji(candles):
    if len(candles) < 1: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    if body < _avg_body(candles) * 0.1:
        if _upper_shadow(o, c, h) > body * 3 and _lower_shadow(o, c, l) < body * 0.5: return -1
    return 0

# ============================================================
# PATRONES NEUTRALES / MIXTOS (9)
# ============================================================

def doji(candles):
    if len(candles) < 3: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    if body < _avg_body(candles) * 0.1:
        prev_trend = sum(1 if candles[i][3] > candles[i][0] else -1 for i in range(-3, 0))
        if prev_trend > 0: return -1
        elif prev_trend < 0: return 1
    return 0

def spinning_top(candles):
    if len(candles) < 3: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    body = _body(o, c)
    avg = _avg_body(candles)
    if body < avg * 0.3:
        ushadow = _upper_shadow(o, c, h)
        lshadow = _lower_shadow(o, c, l)
        if ushadow > body and lshadow > body:
            prev_trend = sum(1 if candles[i][3] > candles[i][0] else -1 for i in range(-3, 0))
            return -1 if prev_trend > 0 else 1
    return 0

def harami_cross(candles):
    if len(candles) < 2: return 0
    prev, curr = candles[-2], candles[-1]
    prev_body = _body(prev[0], prev[3])
    curr_body = _body(curr[0], curr[3])
    if curr_body < prev_body * 0.1:
        if curr[0] < max(prev[0], prev[3]) and curr[3] > min(prev[0], prev[3]):
            if _is_green(prev[0], prev[3]): return -1
            elif _is_red(prev[0], prev[3]): return 1
    return 0

def belt_hold_bullish(candles):
    if len(candles) < 1: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    if _is_green(o, c) and o == l: return 1
    return 0

def belt_hold_bearish(candles):
    if len(candles) < 1: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    if _is_red(o, c) and o == h: return -1
    return 0

def marubozu_green(candles):
    if len(candles) < 1: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    if _is_green(o, c) and o == l and c == h: return 1
    return 0

def marubozu_red(candles):
    if len(candles) < 1: return 0
    o, h, l, c = candles[-1][0], candles[-1][1], candles[-1][2], candles[-1][3]
    if _is_red(o, c) and o == h and c == l: return -1
    return 0


# Lista de todos los patrones
PATTERN_FUNCTIONS = [
    hammer, inverted_hammer, bullish_engulfing, morning_star,
    three_white_soldiers, piercing_line, tweezers_bottom,
    three_inside_up, three_outside_up, abandoned_baby_bottom,
    dragonfly_doji,
    hanging_man, shooting_star, bearish_engulfing, evening_star,
    three_black_crows, dark_cloud_cover, tweezers_top,
    three_inside_down, three_outside_down, abandoned_baby_top,
    gravestone_doji,
    doji, spinning_top, harami_cross,
    belt_hold_bullish, belt_hold_bearish,
    marubozu_green, marubozu_red,
]

# ============================================================
# INDICADORES TECNICOS (5)
# ============================================================

def calc_rsi(closes, period=14):
    if len(closes) < period + 1: return 50
    deltas = np.diff(closes[-(period + 1):])
    gains = np.where(deltas > 0, deltas, 0)
    losses = np.where(deltas < 0, -deltas, 0)
    avg_gain = np.mean(gains)
    avg_loss = np.mean(losses)
    if avg_loss == 0: return 100
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def calc_bollinger(closes, period=20, std_mult=2):
    if len(closes) < period: return None, None, None
    slice_c = closes[-period:]
    middle = np.mean(slice_c)
    std = np.std(slice_c)
    return middle - std_mult * std, middle, middle + std_mult * std

def calc_ma_cross(closes, fast=5, slow=20):
    if len(closes) < slow: return 0
    ma_fast = np.mean(closes[-fast:])
    ma_slow = np.mean(closes[-slow:])
    if ma_fast > ma_slow: return 1
    elif ma_fast < ma_slow: return -1
    return 0

def calc_macd(closes, fast=12, slow=26, signal=9):
    if len(closes) < slow + signal: return 0, 0
    ema_fast = _ema(closes, fast)
    ema_slow = _ema(closes, slow)
    macd_line = ema_fast - ema_slow
    macd_values = []
    for i in range(slow, len(closes)):
        ef = _ema(closes[:i+1], fast)
        es = _ema(closes[:i+1], slow)
        macd_values.append(ef - es)
    if len(macd_values) >= signal:
        signal_line = np.mean(macd_values[-signal:])
    else:
        signal_line = macd_line
    return macd_line, signal_line

def calc_stochastic(candles, period=14):
    if len(candles) < period: return 50
    recent = candles[-period:]
    highs = [c[1] for c in recent]
    lows = [c[2] for c in recent]
    closes = [c[3] for c in recent]
    highest = max(highs)
    lowest = min(lows)
    if highest == lowest: return 50
    return ((closes[-1] - lowest) / (highest - lowest)) * 100

def _ema(data, period):
    if len(data) < period: return np.mean(data)
    multiplier = 2 / (period + 1)
    ema = np.mean(data[:period])
    for price in data[period:]:
        ema = (price - ema) * multiplier + ema
    return ema

# ============================================================
# ANALISIS COMBINADO
# ============================================================

def analyze_candles(candles, min_votes=2):
    """
    Analiza velas con todos los patrones e indicadores.
    Retorna: 'call', 'put', o None
    """
    if len(candles) < 5: return None

    votes_call = 0
    votes_put = 0

    # Patrones (peso 1)
    for pattern_fn in PATTERN_FUNCTIONS:
        try:
            result = pattern_fn(candles)
            if result == 1: votes_call += 1
            elif result == -1: votes_put += 1
        except Exception:
            continue

    # Indicadores (peso 2)
    closes = np.array([c[3] for c in candles])

    try:
        rsi = calc_rsi(closes)
        if rsi < 30: votes_call += 2
        elif rsi > 70: votes_put += 2
    except Exception: pass

    try:
        lower, middle, upper = calc_bollinger(closes)
        if lower is not None:
            if closes[-1] <= lower: votes_call += 2
            elif closes[-1] >= upper: votes_put += 2
    except Exception: pass

    try:
        ma_signal = calc_ma_cross(closes)
        if ma_signal == 1: votes_call += 2
        elif ma_signal == -1: votes_put += 2
    except Exception: pass

    try:
        macd_line, signal_line = calc_macd(closes)
        if macd_line > signal_line: votes_call += 2
        elif macd_line < signal_line: votes_put += 2
    except Exception: pass

    try:
        stoch = calc_stochastic(candles)
        if stoch < 20: votes_call += 2
        elif stoch > 80: votes_put += 2
    except Exception: pass

    if votes_call >= min_votes and votes_call > votes_put: return "call"
    elif votes_put >= min_votes and votes_put > votes_call: return "put"
    return None
