#!/home/z/my-project/sysOuhries/deploy/venv/bin/python3
"""Operacion individual - conectar, analizar, operar, verificar, guardar resultado"""
import sys, os, time, json
sys.path.insert(0, '/home/z/my-project/sysOuhries/deploy')
os.chdir('/home/z/my-project/sysOuhries/deploy')

from iqoptionapi.stable_api import IQ_Option
import iqoptionapi.global_value as global_value
import numpy as np
from strategies.strategies_v2 import analyze_candles_v2, analyze_candles, calc_ema_trend

RESULTS_FILE = "/home/z/my-project/sysOuhries/deploy/real_test_results.json"

# Load existing results
results = {"total": 0, "wins": 0, "losses": 0, "profit": 0, "trades": [], "initial_balance": 0, "balance": 0}
if os.path.exists(RESULTS_FILE):
    with open(RESULTS_FILE) as f:
        results = json.load(f)

if results["total"] >= 15:
    print(f"MAX OPS REACHED: {results['total']}")
    sys.exit(0)

print(f"Connecting... (trade #{results['total']+1})")
api = IQ_Option('deadly.x@hotmail.com', 'Shinigami1')
c, _ = api.connect()
if not c:
    print("Connection failed")
    sys.exit(1)

api.change_balance('PRACTICE')
time.sleep(2)
balance = api.get_balance()

if results["total"] == 0:
    results["initial_balance"] = balance
    results["balance"] = balance

print(f"Balance: ${balance:.2f}")

# Check stops
profit = balance - results["initial_balance"]
if profit >= 50:
    print(f"STOP WIN: ${profit:+.2f}")
    sys.exit(0)
if profit <= -25:
    print(f"STOP LOSS: ${profit:+.2f}")
    sys.exit(0)

# Find signal
acts = api.get_all_ACTIVES_OPCODE()
otcs = [k for k in acts if 'otc' in k.lower()]
print(f"Scanning {len(otcs)} OTC instruments...")

best = None
bestq = -1

for inst in otcs:
    try:
        raw = api.get_candles(inst, 60, 50, int(time.time()))
        if not raw or len(raw) < 15: continue
        cs = [[c['open'], c['max'], c['min'], c['close']] for c in raw]
        cl = np.array([c[3] for c in cs])

        v2 = analyze_candles_v2(cs, min_votes=2)
        if v2 and v2["quality"] > bestq:
            bestq = v2["quality"]
            best = {"i": inst, "d": v2["direction"], "q": v2["quality"],
                    "t": v2["votes_detail"].get("trend","?"),
                    "adx": float(v2["votes_detail"].get("adx",0)),
                    "vc": v2["votes_detail"].get("votes_call",0),
                    "vp": v2["votes_detail"].get("votes_put",0)}

        if best is None:
            v1 = analyze_candles(cs, min_votes=2)
            if v1:
                tr = calc_ema_trend(cl, 21)
                if (v1=="call" and tr>=0) or (v1=="put" and tr<=0):
                    best = {"i": inst, "d": v1, "q": 20,
                            "t": "bullish" if tr==1 else "bearish" if tr==-1 else "none",
                            "adx": 0, "vc": 0, "vp": 0}
                    bestq = 20
    except: pass
    time.sleep(0.3)

if not best:
    print("NO SIGNAL FOUND")
    sys.exit(2)  # Exit code 2 = no signal, try again

print(f"SIGNAL: {best['d'].upper()} {best['i']} Q={best['q']}% T={best['t']} ADX={best['adx']:.0f}")
print(f"Votes: CALL={best['vc']} PUT={best['vp']}")

# Trade
ok, oid = api.buy(2.50, best['i'], best['d'], 1)
if not ok:
    print(f"ORDER REJECTED: {oid}")
    sys.exit(3)

print(f"ORDER OPEN: id={oid}")
print("Waiting 67s for result...")
time.sleep(67)

# Verify
won = None
pf = 0
try:
    r = api.check_win_v3(oid)
    if r is not None:
        won = r > 0
        pf = r
except: pass

if won is None:
    try:
        nb = api.get_balance()
        d = nb - balance
        if abs(d) > 0.01:
            won = d > 0
            pf = d
    except: pass

if won is None:
    won = False
    pf = -2.50

try: balance = api.get_balance()
except: balance += pf

result_str = "WIN" if won else "LOSS"
print(f"RESULT: {result_str} ${pf:+.2f} | Balance: ${balance:.2f}")

# Save results
results["total"] += 1
results["wins"] += 1 if won else 0
results["losses"] += 1 if not won else 0
results["profit"] += pf
results["balance"] = balance
results["trades"].append({
    "num": results["total"],
    "instrument": best["i"],
    "direction": best["d"].upper(),
    "amount": 2.50,
    "won": won,
    "profit": pf,
    "quality": best["q"],
    "trend": best["t"],
    "adx": best["adx"],
    "balance": balance,
    "time": time.strftime("%H:%M:%S"),
})

with open(RESULTS_FILE, "w") as f:
    json.dump(results, f, indent=2)

wr = (results["wins"] / results["total"] * 100) if results["total"] > 0 else 0
print(f"SESSION: {results['total']} ops | {results['wins']}W {results['losses']}L | WR={wr:.1f}% | Profit=${results['profit']:+.2f}")
