"""Generate SistemaOuhriesV5 Preview Dashboard"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import numpy as np

fm.fontManager.addfont('/usr/share/fonts/truetype/chinese/SarasaMonoSC-Regular.ttf')
fm.fontManager.addfont('/usr/share/fonts/truetype/chinese/SarasaMonoSC-Bold.ttf')
fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
plt.rcParams['font.sans-serif'] = ['Sarasa Mono SC', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# Colors
BG = '#F8FAFC'
CARD_BG = '#FFFFFF'
TP = '#243447'
TS = '#64748B'
AC = '#4C6EF5'
SC = '#10B981'
DC = '#EF4444'
WC = '#F59E0B'
BD = '#E2E8F0'

fig = plt.figure(figsize=(16, 12), facecolor=BG)

fig.text(0.5, 0.97, 'SISTEMA OUHRIES V5 - PREVIEW', fontsize=22, fontweight='bold', ha='center', va='top', color=TP)
fig.text(0.5, 0.945, 'Estrategia V2.1 (ADX>=20, Calidad>=70%, Min 5 votos) | Prueba 5 Operaciones OTC', fontsize=11, ha='center', va='top', color=TS)

# ===== CARD 1: V2.1 Params =====
ax1 = fig.add_axes([0.04, 0.62, 0.30, 0.30], facecolor=CARD_BG)
ax1.set_xlim(0, 10); ax1.set_ylim(0, 10); ax1.axis('off')
ax1.add_patch(plt.Rectangle((0.2, 8.8), 9.6, 1, facecolor='#EFF6FF', edgecolor='none'))
ax1.text(5, 9.3, 'PARAMETROS V2.1', fontsize=12, fontweight='bold', ha='center', color=AC)
params = [
    ('ADX Minimo', '20', 'V3: 25'),
    ('Min Votos', '5', 'V3: 7'),
    ('Calidad Min', '70%', 'V3: 88%'),
    ('Payout Min', '87%', 'Ambas'),
    ('RSI Zonas', '25/75', 'V3: 20/80'),
    ('Contra-tendencia', '58%+ fuerza', 'V3: Nunca'),
    ('EMA Peso', '4', 'V3: 4'),
    ('Penalizacion CT', '-15', 'V3: N/A'),
]
y = 8.2
for l, v, c in params:
    ax1.text(0.5, y, l, fontsize=9, color=TS)
    ax1.text(7.5, y, v, fontsize=9, fontweight='bold', color=TP, ha='right')
    ax1.text(9.5, y, c, fontsize=7, color=TS, ha='right', style='italic')
    y -= 0.9

# ===== CARD 2: Radar =====
categories = ['Selectividad', 'Winrate\nEsperado', 'Ops/\nSesion', 'Filtros', 'Contra-\nTendencia']
v2v = [2, 3, 8, 3, 8]; v21v = [5, 6, 5, 6, 4]; v3v = [9, 8, 2, 9, 0]
angles = np.linspace(0, 2 * np.pi, len(categories), endpoint=False).tolist()
angles += angles[:1]; v2v += v2v[:1]; v21v += v21v[:1]; v3v += v3v[:1]

ax_r = fig.add_axes([0.36, 0.63, 0.30, 0.28], polar=True, facecolor=CARD_BG)
ax_r.fill(angles, v2v, alpha=0.1, color='#94A3B8')
ax_r.plot(angles, v2v, 'o-', linewidth=1.5, color='#94A3B8', markersize=3, label='V2 Original')
ax_r.fill(angles, v21v, alpha=0.2, color=AC)
ax_r.plot(angles, v21v, 'o-', linewidth=2, color=AC, markersize=4, label='V2.1')
ax_r.fill(angles, v3v, alpha=0.15, color=SC)
ax_r.plot(angles, v3v, 'o-', linewidth=1.5, color=SC, markersize=3, label='V3')
ax_r.set_xticks(angles[:-1])
ax_r.set_xticklabels(categories, fontsize=7, color=TS)
ax_r.set_yticks([2, 4, 6, 8, 10])
ax_r.set_yticklabels(['2', '4', '6', '8', '10'], fontsize=6, color=TS)
ax_r.set_ylim(0, 10)
ax_r.spines['polar'].set_color(BD)
ax_r.grid(color=BD, alpha=0.3)
ax_r.legend(loc='lower right', fontsize=7, bbox_to_anchor=(1.15, -0.1), framealpha=0.9)

# ===== CARD 3: Test Results =====
ax3 = fig.add_axes([0.68, 0.62, 0.30, 0.30], facecolor=CARD_BG)
ax3.set_xlim(0, 10); ax3.set_ylim(0, 10); ax3.axis('off')
ax3.add_patch(plt.Rectangle((0.2, 8.8), 9.6, 1, facecolor='#EFF6FF', edgecolor='none'))
ax3.text(5, 9.3, 'RESULTADOS PRUEBAS', fontsize=12, fontweight='bold', ha='center', color=AC)
sessions = [
    ('V3 (3 ops)', 33.3, 1, 2, -3.60, DC),
    ('V2.1 Op1 PUT', 100, 1, 0, 2.25, SC),
    ('V2.1 Op2 CALL', 0, 0, 1, -2.50, DC),
]
y = 8.0
for n, wr, w, l, p, c in sessions:
    ax3.text(0.5, y, n, fontsize=9, color=TP, fontweight='bold')
    ax3.text(0.5, y - 0.45, f'W:{w} L:{l} | WR: {wr:.0f}%', fontsize=8, color=TS)
    ps = f'+${p:.2f}' if p >= 0 else f'-${abs(p):.2f}'
    ax3.text(9.5, y - 0.2, ps, fontsize=10, fontweight='bold', color=c, ha='right')
    y -= 1.4

# ===== CARD 4: Trade History =====
ax4 = fig.add_axes([0.04, 0.32, 0.60, 0.28], facecolor=CARD_BG)
ax4.axis('off')
ax4.add_patch(plt.Rectangle((0.01, 0.87), 0.98, 0.12, facecolor='#EFF6FF', edgecolor='none', transform=ax4.transAxes))
ax4.text(0.5, 0.93, 'HISTORIAL DE OPERACIONES', fontsize=12, fontweight='bold', ha='center', color=AC, transform=ax4.transAxes)
headers = ['#', 'Activo', 'Direccion', 'Estrategia', 'Calidad', 'ADX', 'Payout', 'Resultado', 'Profit']
cx = [0.02, 0.07, 0.22, 0.33, 0.44, 0.52, 0.59, 0.68, 0.84]
for i, h in enumerate(headers):
    ax4.text(cx[i], 0.80, h, fontsize=8, fontweight='bold', color=TS, transform=ax4.transAxes)

trades = [
    (1, 'SP500-OTC', 'PUT', 'V2.1', '87%', '23.7', '90%', 'WIN', '+$2.25', SC),
    (2, 'SP500-OTC', 'CALL', 'V2.1', '100%', '40.8', '90%', 'LOSS', '-$2.50', DC),
    (3, 'EU50-OTC', 'CALL', 'V3', '-', '-', '87%', 'LOSS', '-$2.50', DC),
    (4, 'UKOUSD-OTC', 'CALL', 'V3', '-', '-', '87%', 'WIN', '+$2.15', SC),
    (5, 'US30-OTC', 'PUT', 'V3', '-', '-', '85%', 'LOSS', '-$3.25', DC),
]
yp = 0.72
for n, a, d, s, q, ax_v, p, r, pr, cl in trades:
    ax4.text(cx[0], yp, str(n), fontsize=8, color=TP, transform=ax4.transAxes)
    ax4.text(cx[1], yp, a, fontsize=8, color=TP, transform=ax4.transAxes)
    dc = SC if d == 'CALL' else DC
    ax4.text(cx[2], yp, d, fontsize=8, fontweight='bold', color=dc, transform=ax4.transAxes)
    ax4.text(cx[3], yp, s, fontsize=8, color=AC if s == 'V2.1' else TS, transform=ax4.transAxes)
    ax4.text(cx[4], yp, q, fontsize=8, color=TP, transform=ax4.transAxes)
    ax4.text(cx[5], yp, ax_v, fontsize=8, color=TP, transform=ax4.transAxes)
    ax4.text(cx[6], yp, p, fontsize=8, color=TP, transform=ax4.transAxes)
    ax4.text(cx[7], yp, r, fontsize=8, fontweight='bold', color=cl, transform=ax4.transAxes)
    ax4.text(cx[8], yp, pr, fontsize=8, fontweight='bold', color=cl, transform=ax4.transAxes)
    yp -= 0.10
ax4.plot([0.02, 0.98], [0.78, 0.78], color=BD, linewidth=0.5, transform=ax4.transAxes, clip_on=False)

# ===== CARD 5: Config =====
ax5 = fig.add_axes([0.66, 0.32, 0.32, 0.28], facecolor=CARD_BG)
ax5.set_xlim(0, 10); ax5.set_ylim(0, 10); ax5.axis('off')
ax5.add_patch(plt.Rectangle((0.2, 8.8), 9.6, 1, facecolor='#EFF6FF', edgecolor='none'))
ax5.text(5, 9.3, 'CONFIG SISTEMA V5', fontsize=12, fontweight='bold', ha='center', color=AC)
cfgs = [
    ('Capital Op', '$2.50'),
    ('Niveles', '3 (35% profit)'),
    ('Stop Win', '$7.00'),
    ('Stop Loss', '$5.00/15% bal'),
    ('Payout Min', '87%'),
    ('Scanner', '35 OTC'),
    ('Delay Ops', '20-60s'),
    ('Telegram', 'Emojis activo'),
    ('GUI Msgbox', 'Fin sesion'),
    ('Estrategia', 'V3/V2.1'),
]
y = 8.0
for l, v in cfgs:
    ax5.text(0.5, y, l, fontsize=8, color=TS)
    ax5.text(9.5, y, v, fontsize=8, fontweight='bold', color=TP, ha='right')
    y -= 0.72

# ===== CARD 6: Insights =====
ax6 = fig.add_axes([0.04, 0.04, 0.45, 0.25], facecolor=CARD_BG)
ax6.set_xlim(0, 10); ax6.set_ylim(0, 10); ax6.axis('off')
ax6.add_patch(plt.Rectangle((0.2, 8.5), 9.6, 1.3, facecolor='#F0FDF4', edgecolor='none'))
ax6.text(5, 9.2, 'ANALISIS V2.1 vs V3', fontsize=12, fontweight='bold', ha='center', color=SC)
ins = [
    ('V2.1 encuentra mas senales que V3', 'ADX>=20 vs ADX>=25'),
    ('Calidad 70% permite mas entradas', 'V3 requiere 88% - muy selectiva'),
    ('V2.1 permite contra-tendencia (58%+)', 'V3 nunca opera contra tendencia'),
    ('V2.1 ideal para sesiones con mas ops', 'V3 ideal para alta precision'),
]
y = 7.5
for t, d in ins:
    ax6.text(0.5, y, '  ' + t, fontsize=8, fontweight='bold', color=TP)
    ax6.text(0.5, y - 0.55, '    ' + d, fontsize=7, color=TS)
    y -= 1.5

# ===== CARD 7: Files =====
ax7 = fig.add_axes([0.52, 0.04, 0.46, 0.25], facecolor=CARD_BG)
ax7.set_xlim(0, 10); ax7.set_ylim(0, 10); ax7.axis('off')
ax7.add_patch(plt.Rectangle((0.2, 8.5), 9.6, 1.3, facecolor='#FFF7ED', edgecolor='none'))
ax7.text(5, 9.2, 'ARCHIVOS DEL SISTEMA', fontsize=12, fontweight='bold', ha='center', color=WC)
files = [
    ('main.py', 'GUI tkinter + messagebox'),
    ('engine.py', 'Motor trading + niveles'),
    ('scanner.py', 'Scanner OTC V1/V2.1/V3'),
    ('config.py', 'Config global'),
    ('strategies_v2.py', 'V2.1 (ADX>=20, 5 votos)'),
    ('strategies_v3.py', 'V3 (ADX>=25, 7 votos)'),
    ('telegram_notifier.py', 'Notif. Telegram emojis'),
    ('iqoption_patched.py', 'API IQ Option parchada'),
]
y = 7.8
for f, d in files:
    ax7.text(0.5, y, f, fontsize=7.5, fontweight='bold', color=AC, family='monospace')
    ax7.text(5.2, y, d, fontsize=7, color=TS)
    y -= 0.85

# Save
output = '/home/z/my-project/download/SistemaOuhriesV5_Preview.png'
plt.savefig(output, dpi=200, bbox_inches='tight', facecolor=BG, pad_inches=0.3)
plt.close()
print(f'Preview saved: {output}')
