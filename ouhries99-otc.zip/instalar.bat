@echo off
title Instalar Ouhries V5
color 0B

echo ================================================
echo   SISTEMA OUHRIES V5 - INSTALADOR
echo ================================================
echo.

:: Change to script directory
cd /d "%~dp0"

:: Check Python
echo [1/3] Verificando Python...
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python no esta instalado.
    echo Descargalo de: https://www.python.org/downloads/
    echo Asegurate de marcar "Add Python to PATH".
    echo.
    pause
    exit /b 1
)
echo [OK] Python encontrado.

:: Check Node.js
echo [2/3] Verificando Node.js...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js no esta instalado.
    echo Descargalo de: https://nodejs.org/
    echo.
    pause
    exit /b 1
)
echo [OK] Node.js encontrado.

:: Install Python dependencies
echo [3/3] Instalando dependencias...
pip install -r requirements.txt --quiet
if %errorlevel% neq 0 (
    echo [ERROR] Fallo la instalacion de dependencias Python.
    pause
    exit /b 1
)

cd electron
call npm install
if %errorlevel% neq 0 (
    echo [ERROR] Fallo la instalacion de Electron.
    cd ..
    pause
    exit /b 1
)
cd ..

echo.
echo ================================================
echo   INSTALACION COMPLETADA
echo   Ejecuta "OuhriesV5.bat" para iniciar la app
echo ================================================
echo.
pause
