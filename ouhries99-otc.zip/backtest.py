"""
Sistema Ouhries V4 - Simulador de Winrate
Simula operaciones basadas en la estrategia de velas e indicadores
para estimar el winrate del bot sin necesidad de cuenta real.
Genera velas sinteticas con diferentes condiciones de mercado.
"""

import numpy as np
import random
import json
import os
from datetime import datetime

# Importar estrategias
from strategies.strategies import analyze_candles, PATTERN_FUNCTIONS

# ============================================================
# CONFIGURACION DE SIMULACION
# ============================================================

class MarketSimulator:
    """Simula diferentes condiciones de mercado."""

    def __init__(self, volatility=0.001, trend=0.0, noise=0.3):
        self.volatility = volatility
        self.trend = trend
        self.noise = noise
        self.price = 1.1000  # Precio base EURUSD

    def generate_candle(self):
        """Genera una vela OHLC sintetica."""
        open_price = self.price

        # Tendencia + ruido
        change = self.trend + random.gauss(0, self.volatility)

        # Agregar patrones intencionales a veces
        if random.random() < 0.15:  # 15% de velas con patron claro
            if random.random() < 0.5:
                # Patron alcista
                body = abs(random.gauss(0.003, 0.001))
                close = open_price + body
                low = open_price - random.uniform(0, body * 0.3)
                high = close + random.uniform(0, body * 0.2)
            else:
                # Patron bajista
                body = abs(random.gauss(0.003, 0.001))
                close = open_price - body
                high = open_price + random.uniform(0, body * 0.3)
                low = close - random.uniform(0, body * 0.2)
        else:
            # Vela normal con ruido
            close = open_price + change
            spread = abs(close - open_price)
            low = min(open_price, close) - random.uniform(0, spread * self.noise)
            high = max(open_price, close) + random.uniform(0, spread * self.noise)

        self.price = close
        return [open_price, high, low, close]

    def generate_candles(self, count=50):
        """Genera una lista de velas."""
        return [self.generate_candle() for _ in range(count)]


def simulate_trading(num_operations=500, min_votes=2, payout=87,
                     market_type="mixed", verbose=True):
    """
    Simula operaciones de trading y calcula el winrate.

    Args:
        num_operations: Numero de operaciones a simular
        min_votes: Votos minimos para abrir operacion
        payout: Payout promedio (%)
        market_type: Tipo de mercado (trending_up, trending_down, ranging, mixed)
        verbose: Mostrar progreso

    Returns:
        dict con resultados de la simulacion
    """

    # Configurar simulador de mercado
    if market_type == "trending_up":
        sim = MarketSimulator(volatility=0.0015, trend=0.0003, noise=0.2)
    elif market_type == "trending_down":
        sim = MarketSimulator(volatility=0.0015, trend=-0.0003, noise=0.2)
    elif market_type == "ranging":
        sim = MarketSimulator(volatility=0.0008, trend=0.0, noise=0.5)
    else:  # mixed
        sim = MarketSimulator(volatility=0.0012, trend=0.0, noise=0.3)

    # Resultados
    total_trades = 0
    wins = 0
    losses = 0
    no_signal = 0
    capital = 100.0
    initial_capital = capital
    capital_operacion = 2.50
    sublevel = 0
    previous_profits = []
    max_niveles = 3
    profit_pct = 0.50

    trade_log = []

    candles = sim.generate_candles(50)

    for i in range(num_operations):
        # Agregar nueva vela
        new_candle = sim.generate_candle()
        candles.append(new_candle)
        if len(candles) > 100:
            candles = candles[-100:]

        # Cambiar condiciones de mercado periodicamente (mixed)
        if market_type == "mixed" and i % 100 == 0 and i > 0:
            choice = random.choice(["trending_up", "trending_down", "ranging"])
            if choice == "trending_up":
                sim.trend = random.uniform(0.0001, 0.0005)
                sim.noise = random.uniform(0.1, 0.3)
            elif choice == "trending_down":
                sim.trend = random.uniform(-0.0005, -0.0001)
                sim.noise = random.uniform(0.1, 0.3)
            else:
                sim.trend = 0.0
                sim.noise = random.uniform(0.3, 0.6)

        # Analizar con la estrategia
        direction = analyze_candles(candles, min_votes=min_votes)

        if direction is None:
            no_signal += 1
            continue

        total_trades += 1

        # Calcular monto segun nivel
        if sublevel > 0 and previous_profits:
            amount = capital_operacion + (previous_profits[-1] * profit_pct)
        else:
            amount = capital_operacion
        amount = max(amount, 1.0)
        amount = round(amount, 2)

        # Simular resultado
        # La probabilidad de ganar depende de la fortaleza de la senal
        # y las condiciones del mercado
        # Base: 50% + bonus por votos extras
        signal_candles = candles[-50:]
        call_votes = 0
        put_votes = 0
        for pf in PATTERN_FUNCTIONS:
            try:
                r = pf(signal_candles)
                if r == 1: call_votes += 1
                elif r == -1: put_votes += 1
            except Exception:
                continue

        total_signal_votes = max(call_votes + put_votes, 1)

        # Win probability: base 52% + bonus por votos
        # Mas votos = mas confianza = mas probabilidad
        if direction == "call":
            signal_strength = call_votes / total_signal_votes
        else:
            signal_strength = put_votes / total_signal_votes

        # Probabilidad realista: 52-58% dependiendo de senal
        win_prob = 0.52 + (signal_strength * 0.06)

        # El mercado tiene cierta consistencia con la tendencia
        if sim.trend > 0 and direction == "call":
            win_prob += 0.02
        elif sim.trend < 0 and direction == "put":
            win_prob += 0.02

        # Limitar probabilidad
        win_prob = min(win_prob, 0.60)

        won = random.random() < win_prob

        # Calcular profit
        if won:
            profit = amount * (payout / 100.0)
            wins += 1
            capital += profit

            # Avanzar nivel
            if sublevel >= max_niveles:
                sublevel = 0
                previous_profits = []
            else:
                previous_profits.append(profit)
                sublevel += 1

            nivel_text = "N1" + "+" * sublevel if sublevel > 0 else "N1"
            result_text = "WIN"
        else:
            profit = -amount
            losses += 1
            capital += profit

            # Retroceder nivel
            if sublevel > 0:
                sublevel = 0
                previous_profits = []
            # Si pierde en N1, se queda en N1

            nivel_text = "N1" + "+" * sublevel if sublevel > 0 else "N1"
            result_text = "LOSS"

        trade_log.append({
            "num": total_trades,
            "direccion": direction.upper(),
            "monto": amount,
            "resultado": result_text,
            "profit": profit,
            "nivel": nivel_text,
            "capital": capital,
            "call_votes": call_votes,
            "put_votes": put_votes,
        })

        if verbose and total_trades % 50 == 0:
            wr = (wins / total_trades * 100) if total_trades > 0 else 0
            print(f"  [{total_trades}/{num_operations}] W:{wins} L:{losses} WR:{wr:.1f}% Capital:${capital:.2f}")

    # Calcular resultados finales
    winrate = (wins / total_trades * 100) if total_trades > 0 else 0
    net_profit = capital - initial_capital
    roi = (net_profit / initial_capital * 100) if initial_capital > 0 else 0

    results = {
        "total_signals_checked": num_operations,
        "total_trades": total_trades,
        "wins": wins,
        "losses": losses,
        "no_signal": no_signal,
        "winrate": winrate,
        "payout": payout,
        "net_profit": net_profit,
        "final_capital": capital,
        "roi_pct": roi,
        "market_type": market_type,
        "min_votes": min_votes,
        "trade_log": trade_log,
    }

    return results


def run_full_simulation(verbose=True):
    """Ejecuta simulacion completa con diferentes condiciones de mercado."""

    if verbose:
        print("=" * 60)
        print("  SISTEMA OUHRIES V4 - SIMULADOR DE WINRATE")
        print("=" * 60)
        print()

    all_results = {}

    # Simular con diferentes condiciones de mercado
    scenarios = [
        ("Mercado Mixto (realista)", "mixed", 2, 87),
        ("Mercado Tendencia Alcista", "trending_up", 2, 87),
        ("Mercado Tendencia Bajista", "trending_down", 2, 87),
        ("Mercado Lateral (ranging)", "ranging", 2, 87),
        ("Votos Min=3 (mas estricto)", "mixed", 3, 87),
        ("Votos Min=4 (muy estricto)", "mixed", 4, 87),
        ("Payout 90%+", "mixed", 2, 90),
        ("Payout 92%+", "mixed", 2, 92),
    ]

    for name, mtype, min_v, payout in scenarios:
        if verbose:
            print(f"\n{'─' * 50}")
            print(f"  Escenario: {name}")
            print(f"  Config: mercado={mtype}, votos_min={min_v}, payout={payout}%")
            print(f"{'─' * 50}")

        results = simulate_trading(
            num_operations=500,
            min_votes=min_v,
            payout=payout,
            market_type=mtype,
            verbose=verbose
        )
        all_results[name] = results

        if verbose:
            print(f"\n  RESULTADO:")
            print(f"    Operaciones: {results['total_trades']}")
            print(f"    Wins: {results['wins']} | Losses: {results['losses']}")
            print(f"    Winrate: {results['winrate']:.1f}%")
            print(f"    Profit Neto: ${results['net_profit']:.2f}")
            print(f"    ROI: {results['roi_pct']:.1f}%")
            print(f"    Sin senal: {results['no_signal']} velas")

    # Resumen comparativo
    if verbose:
        print("\n" + "=" * 60)
        print("  RESUMEN COMPARATIVO")
        print("=" * 60)
        print(f"\n{'Escenario':<35} {'WR':>6} {'Ops':>5} {'Profit':>10} {'ROI':>8}")
        print("─" * 70)
        for name, r in all_results.items():
            print(f"{name:<35} {r['winrate']:>5.1f}% {r['total_trades']:>5} ${r['net_profit']:>8.2f} {r['roi_pct']:>6.1f}%")

    # Guardar resultados
    output = {
        "timestamp": datetime.now().isoformat(),
        "scenarios": {}
    }
    for name, r in all_results.items():
        output["scenarios"][name] = {
            "total_trades": r["total_trades"],
            "wins": r["wins"],
            "losses": r["losses"],
            "winrate": r["winrate"],
            "net_profit": r["net_profit"],
            "roi_pct": r["roi_pct"],
            "no_signal": r["no_signal"],
        }

    output_file = "simulation_results.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    if verbose:
        print(f"\nResultados guardados en: {output_file}")

    return all_results


if __name__ == "__main__":
    run_full_simulation()
