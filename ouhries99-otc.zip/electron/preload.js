/**
 * Sistema Ouhries V5 - Preload Script
 * Exposes safe IPC methods to the renderer process.
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  getServerUrl: () => ipcRenderer.invoke('get-server-url'),
  getAppVersion: () => ipcRenderer.invoke('get-app-version'),
  restartServer: () => ipcRenderer.invoke('restart-server'),

  onStartupError: (callback) => {
    ipcRenderer.on('startup-error', (event, data) => callback(data));
  },

  onPythonCrash: (callback) => {
    ipcRenderer.on('python-crash', (event, data) => callback(data));
  }
});
