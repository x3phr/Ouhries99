@echo off
title Sistema Ouhries V5
color 0A

echo ================================================
echo   SISTEMA OUHRIES V5 - APLICACION DE ESCRITORIO
echo ================================================
echo.

:: Check Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js no esta instalado.
    echo Descargalo de: https://nodejs.org/
    echo.
    pause
    exit /b 1
)

:: Check Python
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python no esta instalado.
    echo Descargalo de: https://www.python.org/downloads/
    echo Asegurate de marcar "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

:: Change to the directory where this script is located
cd /d "%~dp0"

:: Check if node_modules exists (Electron installed)
if not exist "electron\node_modules\electron\dist\electron.exe" (
    echo [INFO] Instalando dependencias de Electron...
    echo Esto solo se hace la primera vez.
    echo.
    cd electron
    call npm install
    cd ..
    echo.
    echo [OK] Dependencias instaladas.
    echo.
)

:: Check Python dependencies
echo [INFO] Verificando dependencias de Python...
pip show fastapi >nul 2>nul
if %errorlevel% neq 0 (
    echo [INFO] Instalando dependencias de Python...
    pip install -r requirements.txt
    echo.
)

:: Start the Electron app
echo [OK] Iniciando Sistema Ouhries V5...
echo.
cd electron
call npx electron .
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] La aplicacion se cerro con errores.
    pause
)
