@echo off
title Instalar Ouhries V6.3 Playwright
color 0B

echo ================================================
echo   SISTEMA OUHRIES V6.3 PLAYWRIGHT - INSTALADOR
echo   Anti-Detection V5 (Navegador Real)
echo ================================================
echo.

:: Change to script directory
cd /d "%~dp0"

:: Check Python
echo [1/4] Verificando Python...
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python no esta instalado.
    echo Descargalo de: https://www.python.org/downloads/
    echo Asegurate de marcar "Add Python to PATH".
    echo.
    pause
    exit /b 1
)
echo [OK] Python encontrado.

:: Check Node.js
echo [2/4] Verificando Node.js...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js no esta instalado.
    echo Descargalo de: https://nodejs.org/
    echo.
    pause
    exit /b 1
)
echo [OK] Node.js encontrado.

:: Install Python dependencies
echo [3/4] Instalando dependencias Python...
pip install -r requirements.txt --quiet
if %errorlevel% neq 0 (
    echo [ERROR] Fallo la instalacion de dependencias Python.
    pause
    exit /b 1
)

:: Install Playwright browsers (REQUERIDO para Anti-Detection V5)
echo [3b/4] Instalando Playwright Chromium (navegador real)...
playwright install chromium
if %errorlevel% neq 0 (
    echo [WARNING] Playwright Chromium no se pudo instalar automaticamente.
    echo Ejecuta manualmente: playwright install chromium
    echo El bot funcionara con iqoptionapi (Legacy) como fallback.
    echo.
)

cd electron
call npm install
if %errorlevel% neq 0 (
    echo [ERROR] Fallo la instalacion de Electron.
    cd ..
    pause
    exit /b 1
)
cd ..

echo [4/4] Verificando instalacion...
python -c "from iqoption_playwright import IQ_Option_Patched; print('[OK] Playwright backend disponible')" 2>nul
if %errorlevel% neq 0 (
    echo [WARNING] Playwright backend no disponible. Se usara iqoptionapi (Legacy).
    echo Para habilitar Playwright: pip install playwright && playwright install chromium
)

echo.
echo ================================================
echo   INSTALACION COMPLETADA
echo   Ejecuta "OuhriesV5.bat" para iniciar la app
echo   
echo   MODO PLAYWRIGHT: Indetectable por IQ Option
echo   MODO LEGACY:     Usa iqoptionapi (detectable)
echo ================================================
echo.
pause
