"""
Sistema Ouhries V7.2.0 - Instrumentos OTC
Obtiene instrumentos OTC operables.
Combina ACTIVES_OPCODE con OTC_FALLBACK para maxima cobertura.
Filtra por payout minimo usando get_all_profit().
"""

OTC_FALLBACK = {
    # Major Forex Pairs
    "EURUSD-OTC": "EURUSD-OTC",
    "GBPUSD-OTC": "GBPUSD-OTC",
    "USDJPY-OTC": "USDJPY-OTC",
    "AUDUSD-OTC": "AUDUSD-OTC",
    "USDCAD-OTC": "USDCAD-OTC",
    "USDCHF-OTC": "USDCHF-OTC",
    "NZDUSD-OTC": "NZDUSD-OTC",
    
    # Cross Pairs EUR
    "EURGBP-OTC": "EURGBP-OTC",
    "EURJPY-OTC": "EURJPY-OTC",
    "EURAUD-OTC": "EURAUD-OTC",
    "EURCHF-OTC": "EURCHF-OTC",
    "EURNZD-OTC": "EURNZD-OTC",
    "EURCAD-OTC": "EURCAD-OTC",
    "EURSEK-OTC": "EURSEK-OTC",
    "EURNOK-OTC": "EURNOK-OTC",
    "EURDKK-OTC": "EURDKK-OTC",
    "EURPLN-OTC": "EURPLN-OTC",
    "EURHUF-OTC": "EURHUF-OTC",
    "EURCZK-OTC": "EURCZK-OTC",
    "EURAED-OTC": "EURAED-OTC",
    "EURTRY-OTC": "EURTRY-OTC",
    "EURZAR-OTC": "EURZAR-OTC",
    "EURSGD-OTC": "EURSGD-OTC",
    "EURHKD-OTC": "EURHKD-OTC",
    "EURMXN-OTC": "EURMXN-OTC",
    
    # Cross Pairs GBP
    "GBPAUD-OTC": "GBPAUD-OTC",
    "GBPCAD-OTC": "GBPCAD-OTC",
    "GBPCHF-OTC": "GBPCHF-OTC",
    "GBPJPY-OTC": "GBPJPY-OTC",
    "GBPNZD-OTC": "GBPNZD-OTC",
    "GBPSGD-OTC": "GBPSGD-OTC",
    "GBPPLN-OTC": "GBPPLN-OTC",
    "GBPHKD-OTC": "GBPHKD-OTC",
    "GBPZAR-OTC": "GBPZAR-OTC",
    "GBPTRY-OTC": "GBPTRY-OTC",
    "GBPMXN-OTC": "GBPMXN-OTC",
    
    # Cross Pairs AUD
    "AUDCAD-OTC": "AUDCAD-OTC",
    "AUDCHF-OTC": "AUDCHF-OTC",
    "AUDJPY-OTC": "AUDJPY-OTC",
    "AUDNZD-OTC": "AUDNZD-OTC",
    "AUDSGD-OTC": "AUDSGD-OTC",
    
    # Cross Pairs NZD
    "NZDJPY-OTC": "NZDJPY-OTC",
    "NZDCAD-OTC": "NZDCAD-OTC",
    "NZDCHF-OTC": "NZDCHF-OTC",
    "NZDSGD-OTC": "NZDSGD-OTC",
    
    # Cross Pairs CAD
    "CADCHF-OTC": "CADCHF-OTC",
    "CADJPY-OTC": "CADJPY-OTC",
    "CADSGD-OTC": "CADSGD-OTC",
    
    # Cross Pairs CHF
    "CHFJPY-OTC": "CHFJPY-OTC",
    "CHFSGD-OTC": "CHFSGD-OTC",
    
    # USD Exotic
    "USDSGD-OTC": "USDSGD-OTC",
    "USDHKD-OTC": "USDHKD-OTC",
    "USDZAR-OTC": "USDZAR-OTC",
    "USDMXN-OTC": "USDMXN-OTC",
    "USDNOK-OTC": "USDNOK-OTC",
    "USDSEK-OTC": "USDSEK-OTC",
    "USDDKK-OTC": "USDDKK-OTC",
    "USDPLN-OTC": "USDPLN-OTC",
    "USDCNH-OTC": "USDCNH-OTC",
    "USDCZK-OTC": "USDCZK-OTC",
    "USDHUF-OTC": "USDHUF-OTC",
    "USDTRY-OTC": "USDTRY-OTC",
    "USDINR-OTC": "USDINR-OTC",
    "USDRUB-OTC": "USDRUB-OTC",
    "USDBRL-OTC": "USDBRL-OTC",
    "USDCLP-OTC": "USDCLP-OTC",
    "USDCOP-OTC": "USDCOP-OTC",
    "USDPEN-OTC": "USDPEN-OTC",
    "USDPHP-OTC": "USDPHP-OTC",
    "USDKRW-OTC": "USDKRW-OTC",
    "USDTWD-OTC": "USDTWD-OTC",
    "USDTHB-OTC": "USDTHB-OTC",
    "USDAED-OTC": "USDAED-OTC",
    "USDSAR-OTC": "USDSAR-OTC",
    
    # Commodities
    "XAUUSD-OTC": "XAUUSD-OTC",
    "XAGUSD-OTC": "XAGUSD-OTC",
    "XAUJPY-OTC": "XAUJPY-OTC",
    "XAGJPY-OTC": "XAGJPY-OTC",
    "XAGEUR-OTC": "XAGEUR-OTC",
    "XAUEUR-OTC": "XAUEUR-OTC",
    "XPDUSD-OTC": "XPDUSD-OTC",
    "XPTUSD-OTC": "XPTUSD-OTC",
    
    # Crypto (OTC)
    "BTCUSD-OTC": "BTCUSD-OTC",
    "ETHUSD-OTC": "ETHUSD-OTC",
    "LTCUSD-OTC": "LTCUSD-OTC",
    "XRPARS-OTC": "XRPARS-OTC",
    "BNBUSD-OTC": "BNBUSD-OTC",
    
    # Stocks (OTC)
    "AAPL-OTC": "AAPL-OTC",
    "AMZN-OTC": "AMZN-OTC",
    "GOOGL-OTC": "GOOGL-OTC",
    "MSFT-OTC": "MSFT-OTC",
    "TSLA-OTC": "TSLA-OTC",
    "META-OTC": "META-OTC",
    "NFLX-OTC": "NFLX-OTC",
    "NVDA-OTC": "NVDA-OTC",
    "AMD-OTC": "AMD-OTC",
    "INTC-OTC": "INTC-OTC",
    "DIS-OTC": "DIS-OTC",
    "BA-OTC": "BA-OTC",
    "V-OTC": "V-OTC",
    "MA-OTC": "MA-OTC",
    "JPM-OTC": "JPM-OTC",
    "BAC-OTC": "BAC-OTC",
    "WFC-OTC": "WFC-OTC",
    "C-OTC": "C-OTC",
    "GS-OTC": "GS-OTC",
    "MS-OTC": "MS-OTC",
    "PFE-OTC": "PFE-OTC",
    "JNJ-OTC": "JNJ-OTC",
    "UNH-OTC": "UNH-OTC",
    "MRK-OTC": "MRK-OTC",
    "ABT-OTC": "ABT-OTC",
    "KO-OTC": "KO-OTC",
    "PEP-OTC": "PEP-OTC",
    "MCD-OTC": "MCD-OTC",
    "SBUX-OTC": "SBUX-OTC",
    "NKE-OTC": "NKE-OTC",
    "ADIDAS-OTC": "ADIDAS-OTC",
    "XOM-OTC": "XOM-OTC",
    "CVX-OTC": "CVX-OTC",
    "COP-OTC": "COP-OTC",
    "SHEL-OTC": "SHEL-OTC",
    "TMO-OTC": "TMO-OTC",
    "LLY-OTC": "LLY-OTC",
    "ABBV-OTC": "ABBV-OTC",
    "AVGO-OTC": "AVGO-OTC",
    "ORCL-OTC": "ORCL-OTC",
    "CRM-OTC": "CRM-OTC",
    "ADOBE-OTC": "ADOBE-OTC",
    "IBM-OTC": "IBM-OTC",
    "QCOM-OTC": "QCOM-OTC",
    "TXN-OTC": "TXN-OTC",
    
    # Indices (OTC)
    "US100-OTC": "US100-OTC",
    "US500-OTC": "US500-OTC",
    "US30-OTC": "US30-OTC",
    "UK100-OTC": "UK100-OTC",
    "DE40-OTC": "DE40-OTC",
    "FR40-OTC": "FR40-OTC",
    "JP225-OTC": "JP225-OTC",
    "AU200-OTC": "AU200-OTC",
    "ES35-OTC": "ES35-OTC",
    "IT40-OTC": "IT40-OTC",
    "HK50-OTC": "HK50-OTC",
    "CN50-OTC": "CN50-OTC",
    "SG30-OTC": "SG30-OTC",
    "TW50-OTC": "TW50-OTC",
    "KR200-OTC": "KR200-OTC",
    "IN50-OTC": "IN50-OTC",
    "BR50-OTC": "BR50-OTC",
    "ZA40-OTC": "ZA40-OTC",
    "MX20-OTC": "MX20-OTC",
    
    # ETFs
    "SPY-OTC": "SPY-OTC",
    "QQQ-OTC": "QQQ-OTC",
    "IWM-OTC": "IWM-OTC",
    "DIA-OTC": "DIA-OTC",
    "GLD-OTC": "GLD-OTC",
    "SLV-OTC": "SLV-OTC",
    "USO-OTC": "USO-OTC",
    "TLT-OTC": "TLT-OTC",
    "HYG-OTC": "HYG-OTC",
    "VIX-OTC": "VIX-OTC",
}


def _get_payout_for_instrument(all_profit, name_str):
    """Obtiene el payout turbo de un instrumento desde all_profit."""
    for name in [name_str, name_str.upper(),
                 name_str.replace("-OTC", "_otc"),
                 name_str.replace("-OTC", "-otc")]:
        if name in all_profit:
            info = all_profit[name]
            if isinstance(info, dict):
                turbo = info.get("turbo", 0)
                if turbo:
                    return int(float(turbo) * 100)
                binary = info.get("binary", 0)
                if binary:
                    return int(float(binary) * 100)
            elif isinstance(info, (int, float)):
                return int(float(info) * 100)
    return 0


def get_otc_instruments(api, payout_min=0):
    """
    V7.2: Obtiene instrumentos OTC operables.
    Combina ACTIVES_OPCODE con OTC_FALLBACK para maxima cobertura.
    Ya no requiere que un instrumento este en ACTIVES_OPCODE para ser incluido.
    """
    instruments = {}
    all_profit = {}
    try:
        all_profit = api.get_all_profit() or {}
    except Exception:
        pass

    # Instrumentos excluidos
    EXCLUDED = {"NZDUSD-OTC"}

    # V7.2: Always start with OTC_FALLBACK as the base
    for name in OTC_FALLBACK.keys():
        if name in EXCLUDED:
            continue
        if payout_min > 0 and all_profit:
            payout = _get_payout_for_instrument(all_profit, name)
            if payout < payout_min and payout > 0:
                continue
        instruments[name] = OTC_FALLBACK[name]

    # V7.2: Also add any OTC instruments from ACTIVES_OPCODE not in fallback
    try:
        all_actives = api.get_all_ACTIVES_OPCODE()
        if all_actives:
            for name in all_actives.keys():
                name_str = str(name)
                if "otc" not in name_str.lower():
                    continue
                if name_str in EXCLUDED:
                    continue
                if name_str in instruments:
                    # Already in from fallback, prefer active_id from API
                    active_id = all_actives[name_str]
                    if active_id:
                        instruments[name_str] = active_id
                    continue
                if payout_min > 0:
                    payout = _get_payout_for_instrument(all_profit, name_str)
                    if payout < payout_min and payout > 0:
                        continue
                instruments[name_str] = name_str
    except Exception:
        pass

    return instruments


def get_active_id(api, instrument_name):
    """Obtiene el ID de un instrumento especifico."""
    try:
        all_actives = api.get_all_ACTIVES_OPCODE()
        if all_actives and instrument_name in all_actives:
            return all_actives[instrument_name]
    except Exception:
        pass
    return OTC_FALLBACK.get(instrument_name, None)
