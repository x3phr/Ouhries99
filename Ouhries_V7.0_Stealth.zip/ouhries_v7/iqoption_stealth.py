"""
Ouhries V7 Stealth - IQ Option API (Pure Python, Zero iqoptionapi dependency)
================================================================================
Complete, standalone implementation of IQ Option's HTTP + WebSocket protocol.
Undetectable by IQ Option's anti-bot system thanks to:
  - TLS fingerprint masking via curl_cffi (Chrome impersonation)
  - Realistic Chrome User-Agent rotation (2025/2026)
  - Browser-like HTTP headers on ALL requests (Sec-Fetch-*, sec-ch-ua, etc.)
  - WebSocket headers: Origin + UA + Sec-WebSocket-Version: 13
  - Session rotation every 30-60 minutes
  - Buy jitter: random 0.05-0.6s delay before order
  - Noise browsing: periodic balance checks without trading
  - NO permessage-deflate extension (avoids RSV1 detection vectors)

Architecture:
  - requests.Session (or curl_cffi.requests.Session) for HTTP
  - websocket-client's WebSocketApp for real-time data
  - Thread-safe with threading.Lock
  - Connection generation counter to prevent stale callbacks
  - Auto-reconnect with exponential backoff + jitter
  - Watchdog thread for silent disconnection detection
  - Timeouts on ALL blocking operations
  - No cooldowns (session_cooldown_min=0 default, handled in engine.py)

Protocol (reverse-engineered from iqoptionapi):
  1. POST https://iqoption.com/api/login -> ssid cookie
  2. GET  https://iqoption.com/api/getprofile -> profile + balance data
  3. WebSocket wss://iqoption.com/echo/websocket
  4. Send SSID message: {"name":"ssid","msg":"<ssid>"}
  5. Server sends: timeSync, profile, balances, actives, profit, etc.
  6. Subscribe to channels, buy via buyv2, get candles via getCandles
"""

import time
import json
import logging
import threading
import random
import ssl
import traceback
from datetime import datetime
from collections import defaultdict

import websocket  # system websocket-client package
import requests   # system requests package

# ============================================================
# Optional: curl_cffi for TLS fingerprint masking
# ============================================================
CURL_CFFI_AVAILABLE = False
try:
    from curl_cffi import requests as curl_requests
    CURL_CFFI_AVAILABLE = True
except ImportError:
    curl_requests = None

# Optional: numpy for candle analysis (not required for API itself)
try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    np = None
    NUMPY_AVAILABLE = False

logger = logging.getLogger("iq_stealth")

# ============================================================
# Constants & Timeouts
# ============================================================
DEFAULT_TIMEOUT_CANDLE = 30
DEFAULT_TIMEOUT_BUY = 15
DEFAULT_TIMEOUT_CHECK_WIN = 120
DEFAULT_TIMEOUT_BALANCE = 15
DEFAULT_TIMEOUT_PROFIT = 60
DEFAULT_TIMEOUT_ACTIVES = 30
DEFAULT_TIMEOUT_CONNECT = 60
MAX_RECONNECT_ATTEMPTS = 10
RECONNECT_BACKOFF_BASE = 2

IQOPTION_BASE_URL = "https://iqoption.com"
IQOPTION_API_URL = "https://iqoption.com/api"
IQOPTION_WS_URL = "wss://iqoption.com/echo/websocket"

# ============================================================
# Connection Generation Counter
# Prevents stale WebSocket callbacks from corrupting state
# ============================================================
_connection_generation = 0
_connection_lock = threading.Lock()


def _next_generation():
    global _connection_generation
    with _connection_lock:
        _connection_generation += 1
        return _connection_generation


def _current_generation():
    with _connection_lock:
        return _connection_generation


# ============================================================
# Anti-Detection: Chrome User-Agent rotation (2025/2026)
# ============================================================
CHROME_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 Edg/135.0.0.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
]

BROWSER_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Accept-Language": "en-US,en;q=0.9,es;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Cache-Control": "max-age=0",
    "sec-ch-ua": '"Not A(Brand";v="99", "Google Chrome";v="135", "Chromium";v="135"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
}

SESSION_ROTATION_MIN = 1800
SESSION_ROTATION_MAX = 3600

# Active name lookup cache
_active_name_cache = {}


def _get_random_ua():
    """Return a random Chrome User-Agent string."""
    return random.choice(CHROME_USER_AGENTS)


def _make_browser_headers():
    """Build a full dict of browser-like headers with a fresh UA."""
    ua = _get_random_ua()
    chrome_version = ua.split("Chrome/")[1].split(" ")[0] if "Chrome/" in ua else "135"
    headers = dict(BROWSER_HEADERS)
    headers["User-Agent"] = ua
    headers["sec-ch-ua"] = f'"Not A(Brand";v="99", "Google Chrome";v="{chrome_version}", "Chromium";v="{chrome_version}"'
    return headers


def _make_ws_headers():
    """Build browser-like headers for the WebSocket upgrade request."""
    ua = _get_random_ua()
    return {
        "User-Agent": ua,
        "Origin": "https://iqoption.com",
        "Sec-WebSocket-Version": "13",
        # NOTE: No permessage-deflate extension header — avoids RSV1 issues
        # and prevents the server from enabling compression, which is a
        # detection vector for automated clients.
    }


# ============================================================
# HTTP Session Factory (with TLS fingerprint masking)
# ============================================================
def _create_http_session():
    """Create an HTTP session with browser-like headers and optional TLS masking.

    If curl_cffi is available, we use it to impersonate a real Chrome browser
    at the TLS level, making the JA3/JA4 fingerprint indistinguishable from
    a legitimate browser. Otherwise, we fall back to plain requests with
    browser headers (less stealthy but functional).
    """
    if CURL_CFFI_AVAILABLE:
        try:
            profiles = ["chrome131", "chrome130", "chrome124", "chrome120"]
            chosen = random.choice(profiles)
            session = curl_requests.Session(impersonate=chosen)
            headers = _make_browser_headers()
            for k, v in headers.items():
                session.headers[k] = v
            logger.info(f"[Stealth] TLS FINGERPRINT MASKING active - curl_cffi ({chosen})")
            return session
        except Exception as e:
            logger.warning(f"[Stealth] curl_cffi session failed, falling back: {e}")

    # Fallback: plain requests with browser headers
    session = requests.Session()
    headers = _make_browser_headers()
    session.headers.update(headers)
    if not CURL_CFFI_AVAILABLE:
        logger.warning("[Stealth] curl_cffi NOT available - TLS fingerprint NOT masked")
    return session


# ============================================================
# IQ Option Protocol: Pure Python Implementation
# ============================================================
class _IQOptionProtocol:
    """Low-level IQ Option protocol handler.

    Manages HTTP authentication and WebSocket communication.
    All state is stored here; IQ_Option_Patched wraps it with
    anti-detection, caching, and retry logic.
    """

    def __init__(self, email, password):
        self._email = email
        self._password = password

        # HTTP session
        self._http = _create_http_session()

        # Auth state
        self._ssid = None
        self._profile = None
        self._user_id = None
        self._balance_id = None
        self._balances = {}  # {"PRACTICE": {id, amount}, "REAL": {id, amount}}
        self._current_balance_type = "PRACTICE"

        # WebSocket state
        self._ws = None
        self._ws_thread = None
        self._ws_connected = False
        self._ws_generation = 0

        # Server timestamp (from timeSync)
        self._server_timestamp = None
        self._last_timesync = 0

        # Instrument mappings
        self._actives_opcode = {}   # name -> active_id
        self._profit_data = {}      # name -> {"turbo": x, "binary": y}
        self._active_by_id = {}     # active_id -> name

        # Request/response correlation
        self._request_id = 0
        self._pending = {}          # request_id -> {"event": Event, "result": any}

        # Order tracking
        self._open_orders = {}      # order_id -> {"price": x, "active_id": y, ...}
        self._closed_orders = {}    # order_id -> {"profit_amount": x, "amount": y, ...}

        # Thread-safety
        self._lock = threading.Lock()

        # Candles subscription tracking
        self._candles_data = {}     # request_id -> candles list

        # Balance change events
        self._balance_amount = 0.0
        self._balance_event = threading.Event()

    # ----------------------------------------------------------
    # HTTP Authentication
    # ----------------------------------------------------------
    def _http_login(self):
        """POST /api/login with email/password. Extract ssid cookie."""
        url = f"{IQOPTION_API_URL}/login"
        payload = {"email": self._email, "password": self._password}
        try:
            resp = self._http.post(url, json=payload, timeout=30, allow_redirects=False)
            # Check for ssid cookie
            ssid = None
            for cookie in self._http.cookies:
                if cookie.name == "ssid":
                    ssid = cookie.value
                    break
            if not ssid and resp.status_code in (200, 301, 302):
                # Try extracting from Set-Cookie header
                set_cookie = resp.headers.get("Set-Cookie", "")
                if "ssid=" in set_cookie:
                    for part in set_cookie.split(";"):
                        part = part.strip()
                        if part.startswith("ssid="):
                            ssid = part.split("=", 1)[1]
                            break
            if not ssid:
                # Some responses return JSON with data
                try:
                    data = resp.json()
                    if data.get("code") == "success" or data.get("data", {}).get("ssid"):
                        ssid = data.get("data", {}).get("ssid")
                except Exception:
                    pass

            if not ssid:
                reason = f"Login failed (HTTP {resp.status_code})"
                try:
                    body = resp.json()
                    reason = body.get("message", body.get("errors", reason))
                except Exception:
                    pass
                return False, reason

            self._ssid = ssid
            logger.info("[Stealth] Login successful - ssid obtained")
            return True, None

        except requests.exceptions.ConnectionError as e:
            return False, f"Connection error: {e}"
        except requests.exceptions.Timeout:
            return False, "Login request timed out"
        except Exception as e:
            return False, f"Login error: {e}"

    def _http_get_profile(self):
        """GET /api/getprofile to obtain user profile and balance info."""
        url = f"{IQOPTION_API_URL}/getprofile"
        try:
            resp = self._http.get(url, timeout=30)
            if resp.status_code != 200:
                logger.warning(f"[Stealth] getprofile returned HTTP {resp.status_code}")
                return False
            data = resp.json()
            if data.get("code") != "success" and "msg" not in data:
                logger.warning("[Stealth] getprofile: unexpected response format")
                return False

            msg = data.get("msg", data.get("data", {}))
            if isinstance(msg, dict):
                self._profile = msg
                self._user_id = msg.get("id")
                # Extract balance information
                balances_list = msg.get("balances", [])
                for bal in balances_list:
                    bal_type = "PRACTICE" if bal.get("type") == 1 else "REAL"
                    self._balances[bal_type] = {
                        "id": bal.get("id"),
                        "amount": bal.get("amount", 0.0),
                    }
                # Set default balance_id to practice
                if "PRACTICE" in self._balances:
                    self._balance_id = self._balances["PRACTICE"]["id"]
                    self._balance_amount = self._balances["PRACTICE"]["amount"]
                elif "REAL" in self._balances:
                    self._balance_id = self._balances["REAL"]["id"]
                    self._balance_amount = self._balances["REAL"]["amount"]

                logger.info(f"[Stealth] Profile loaded: user_id={self._user_id}, "
                            f"balances={list(self._balances.keys())}")
            return True
        except Exception as e:
            logger.warning(f"[Stealth] getprofile error: {e}")
            return False

    # ----------------------------------------------------------
    # WebSocket Connection
    # ----------------------------------------------------------
    def _ws_connect(self):
        """Connect to the IQ Option WebSocket and authenticate with SSID."""
        generation = _next_generation()
        self._ws_generation = generation

        ws_headers = _make_ws_headers()
        # Add cookies for authentication
        cookie_str = ""
        if self._ssid:
            cookie_str = f"ssid={self._ssid}"
        if cookie_str:
            ws_headers["Cookie"] = cookie_str

        connected_event = threading.Event()
        error_info = [None]

        def on_open(ws_app):
            gen = getattr(ws_app, "_stealth_generation", 0)
            if gen != _current_generation():
                logger.debug(f"[Stealth] on_open STALE ignored (gen={gen})")
                return
            self._ws_connected = True
            logger.info("[Stealth] WebSocket connected")
            # Send SSID message to authenticate the WebSocket session
            ssid_msg = json.dumps({"name": "ssid", "msg": self._ssid})
            try:
                ws_app.send(ssid_msg)
            except Exception as e:
                logger.warning(f"[Stealth] Error sending SSID: {e}")
            connected_event.set()

        def on_message(ws_app, message):
            gen = getattr(ws_app, "_stealth_generation", 0)
            if gen != _current_generation():
                return
            self._handle_ws_message(message)

        def on_error(ws_app, error):
            gen = getattr(ws_app, "_stealth_generation", 0)
            if gen != _current_generation():
                return
            logger.warning(f"[Stealth] WebSocket error: {error}")
            error_info[0] = str(error)

        def on_close(ws_app, close_status, close_msg):
            gen = getattr(ws_app, "_stealth_generation", 0)
            if gen != _current_generation():
                logger.debug(f"[Stealth] on_close STALE ignored (gen={gen})")
                return
            self._ws_connected = False
            logger.info(f"[Stealth] WebSocket closed (status={close_status}, msg={close_msg})")

        ws_app = websocket.WebSocketApp(
            IQOPTION_WS_URL,
            header=ws_headers,
            on_open=on_open,
            on_message=on_message,
            on_error=on_error,
            on_close=on_close,
        )
        ws_app._stealth_generation = generation

        ssl_opts = {
            "cert_reqs": ssl.CERT_NONE,
            "check_hostname": False,
        }

        def _run_ws():
            try:
                ws_app.run_forever(sslopt=ssl_opts, ping_interval=20, ping_timeout=10)
            except Exception as e:
                logger.debug(f"[Stealth] WebSocket run_forever error: {e}")

        self._ws = ws_app
        self._ws_thread = threading.Thread(target=_run_ws, daemon=True)
        self._ws_thread.start()

        # Wait for connection with timeout
        if connected_event.wait(timeout=45):
            return True, None
        if error_info[0]:
            return False, error_info[0]
        return False, "WebSocket connection timeout"

    def _ws_send(self, name, msg=None):
        """Send a WebSocket message with the given name and msg payload.

        Returns the request_id used for correlation (or None if send fails).
        """
        with self._lock:
            self._request_id += 1
            rid = self._request_id

        payload = {"name": name, "msg": msg if msg is not None else {}, "request_id": rid}
        raw = json.dumps(payload)
        try:
            if self._ws and self._ws_connected:
                self._ws.send(raw)
                return rid
            else:
                logger.warning(f"[Stealth] Cannot send '{name}': WebSocket not connected")
                return None
        except Exception as e:
            logger.warning(f"[Stealth] Error sending '{name}': {e}")
            self._ws_connected = False
            return None

    # ----------------------------------------------------------
    # WebSocket Message Handler
    # ----------------------------------------------------------
    def _handle_ws_message(self, message):
        """Route incoming WebSocket messages to the appropriate handler."""
        try:
            data = json.loads(message)
        except (json.JSONDecodeError, TypeError):
            return

        name = data.get("name", "")
        msg = data.get("msg")
        request_id = data.get("request_id")

        # Resolve any pending request
        if request_id and request_id in self._pending:
            with self._lock:
                entry = self._pending.pop(request_id, None)
            if entry:
                entry["result"] = msg
                entry["event"].set()

        # Route by message name
        handler = {
            "timeSync": self._on_timesync,
            "profile": self._on_profile,
            "balance": self._on_balance,
            "actives": self._on_actives,
            "profit": self._on_profit,
            "candles": self._on_candles,
            "buyv2": self._on_buyv2,
            "option-closed": self._on_option_closed,
            "heartbeat": lambda m: None,
            "positions": lambda m: None,
            "underlying-list": lambda m: None,
        }.get(name)

        if handler:
            try:
                handler(msg)
            except Exception as e:
                logger.debug(f"[Stealth] Error handling '{name}': {e}")
        elif name:
            logger.debug(f"[Stealth] Unhandled WS message: {name}")

    # --- Individual message handlers ---

    def _on_timesync(self, msg):
        """Handle timeSync message: update server timestamp."""
        if isinstance(msg, dict):
            ts = msg.get("ms", msg.get("timestamp", 0))
            if ts:
                self._server_timestamp = ts / 1000.0 if ts > 1e12 else ts
                self._last_timesync = time.time()

    def _on_profile(self, msg):
        """Handle profile message from WebSocket (richer than HTTP profile)."""
        if not isinstance(msg, dict):
            return
        self._profile = msg
        self._user_id = msg.get("id")
        # Update balances from profile
        balances_list = msg.get("balances", [])
        for bal in balances_list:
            bal_type = "PRACTICE" if bal.get("type") == 1 else "REAL"
            self._balances[bal_type] = {
                "id": bal.get("id"),
                "amount": bal.get("amount", 0.0),
            }
        # Update balance_id if not set
        if not self._balance_id:
            current = self._balances.get(self._current_balance_type)
            if current:
                self._balance_id = current["id"]
                self._balance_amount = current["amount"]

    def _on_balance(self, msg):
        """Handle balance update message."""
        if not isinstance(msg, dict):
            return
        bal_id = msg.get("id")
        amount = msg.get("amount", 0.0)
        bal_type = msg.get("type")
        # Update internal balance tracking
        type_str = "PRACTICE" if bal_type == 1 else "REAL"
        self._balances[type_str] = {"id": bal_id, "amount": amount}
        # Update current balance if this is the active one
        if bal_id == self._balance_id:
            self._balance_amount = amount
            self._balance_event.set()

    def _on_actives(self, msg):
        """Handle actives message: populate instrument name -> active_id mapping."""
        if not isinstance(msg, dict):
            return
        # msg is typically {"binary": {"actives": {...}}, "turbo": {"actives": {...}}}
        for mode in ("binary", "turbo", "otc"):
            mode_data = msg.get(mode, {})
            actives_list = mode_data.get("actives", {})
            if isinstance(actives_list, dict):
                for active_id_str, active_info in actives_list.items():
                    if isinstance(active_info, dict):
                        name = active_info.get("name", "")
                        if name:
                            aid = int(active_id_str) if active_id_str.isdigit() else active_id_str
                            self._actives_opcode[name] = aid
                            self._active_by_id[aid] = name
            elif isinstance(actives_list, list):
                for active_info in actives_list:
                    if isinstance(active_info, dict):
                        name = active_info.get("name", "")
                        aid = active_info.get("id")
                        if name and aid:
                            self._actives_opcode[name] = aid
                            self._active_by_id[aid] = name

    def _on_profit(self, msg):
        """Handle profit message: payout percentages per instrument."""
        if not isinstance(msg, dict):
            return
        for name, profit_info in msg.items():
            if isinstance(profit_info, dict):
                self._profit_data[name] = profit_info
                # Also update actives if we have an active_id
                active_id = profit_info.get("active_id")
                if active_id and name not in self._actives_opcode:
                    self._actives_opcode[name] = active_id
                    self._active_by_id[active_id] = name

    def _on_candles(self, msg):
        """Handle candles response."""
        if isinstance(msg, dict):
            # Store in candles_data keyed by request_id (already handled by pending)
            pass
        elif isinstance(msg, list):
            # Direct list of candles
            pass

    def _on_buyv2(self, msg):
        """Handle buyv2 response: order placed successfully."""
        if not isinstance(msg, dict):
            return
        order_id = msg.get("id")
        if order_id:
            self._open_orders[order_id] = msg
            logger.info(f"[Stealth] Order placed: id={order_id}")

    def _on_option_closed(self, msg):
        """Handle option-closed message: trade result."""
        if not isinstance(msg, dict):
            return
        order_id = msg.get("id")
        if order_id:
            self._closed_orders[order_id] = msg
            logger.info(f"[Stealth] Option closed: id={order_id}, "
                        f"profit={msg.get('profit_amount', 0)}")

    # ----------------------------------------------------------
    # WebSocket Request Methods
    # ----------------------------------------------------------
    def subscribe_balance(self, balance_id):
        """Subscribe to balance updates for the given balance_id."""
        self._balance_id = balance_id
        self._ws_send("subscribe", {"name": "balance", "params": {"balance_id": balance_id}})

    def subscribe_candles(self, active_id, size=60):
        """Subscribe to live candle updates."""
        self._ws_send("subscribe", {
            "name": "candle-generated",
            "params": {"active_id": active_id, "size": size}
        })

    def set_actives(self, active_ids):
        """Tell the server which actives we're interested in."""
        self._ws_send("setActives", {"actives": active_ids})

    def get_candles_request(self, active_id, size, from_ts, to_ts, count=100, offset=0):
        """Request candle data via WebSocket. Returns request_id for correlation."""
        rid = self._ws_send("getCandles", {
            "active_id": active_id,
            "size": size,
            "from": from_ts,
            "to": to_ts,
            "count": count,
            "offset": offset,
        })
        return rid

    def buyv2(self, price, active_id, direction, expiration_timestamp,
              option_type=1, expiration_type=1, refund_value=0):
        """Place a binary option trade via WebSocket buyv2.

        Args:
            price: Trade amount
            active_id: Numeric instrument ID
            direction: "call" or "put"
            expiration_timestamp: Unix timestamp when option expires
            option_type: 1 = binary
            expiration_type: 1 = turbo (1-5 min)
            refund_value: 0 (no refund)

        Returns:
            request_id for correlation, or None on failure
        """
        rid = self._ws_send("buyv2", {
            "price": price,
            "active_id": active_id,
            "option_type": option_type,
            "expiration_type": expiration_type,
            "direction": direction,
            "expired": expiration_timestamp,
            "refund_value": refund_value,
        })
        return rid

    # ----------------------------------------------------------
    # Cleanup
    # ----------------------------------------------------------
    def close(self):
        """Close the WebSocket connection and mark as disconnected."""
        self._ws_connected = False
        try:
            if self._ws:
                self._ws._stealth_generation = -1  # Invalidate stale callbacks
                self._ws.close()
        except Exception:
            pass
        try:
            if self._ws_thread and self._ws_thread.is_alive():
                self._ws_thread.join(timeout=10.0)
        except Exception:
            pass
        self._ws = None
        self._ws_thread = None


# ============================================================
# High-Level API: IQ_Option_Patched
# ============================================================
class IQ_Option_Patched:
    """IQ Option API wrapper with anti-detection features.

    This is the SAME class and interface used by engine.py, but implemented
    entirely in pure Python without depending on the iqoptionapi pip package.

    The engine creates an instance with IQ_Option_Patched(email, password),
    then calls connect(), check_connect(), get_balance(), buy(), etc.

    All public methods match the signature of the old wrapper so that
    engine.py and scanner.py work without modifications.
    """

    def __init__(self, email, password):
        self._email = email
        self._password = password

        # Protocol handler
        self._proto = _IQOptionProtocol(email, password)

        # State
        self._connected = False
        self._lock = threading.Lock()

        # Caches
        self._actives_cache = {}
        self._actives_cache_time = 0
        self._profit_cache = None
        self._profit_cache_time = 0
        self._profit_cache_ttl = 300

        # Reconnect tracking
        self._reconnect_count = 0
        self._last_connect_time = 0
        self._last_session_refresh = 0
        self._next_rotation = random.uniform(SESSION_ROTATION_MIN, SESSION_ROTATION_MAX)

        # Balance mode tracking (for reconnect restoration)
        self._last_balance_mode = "PRACTICE"

        # Watchdog
        self._watchdog_stop = threading.Event()
        self._watchdog_thread = None

        # Noise browsing state
        self._last_noise_time = 0

    # ----------------------------------------------------------
    # Connection Management
    # ----------------------------------------------------------
    def connect(self):
        """Authenticate and connect to IQ Option.

        Returns:
            (bool, str|None): (success, error_reason)
        """
        for attempt in range(MAX_RECONNECT_ATTEMPTS):
            try:
                logger.info(f"[Stealth] Connect attempt {attempt + 1}/{MAX_RECONNECT_ATTEMPTS}")

                # Close any existing connection
                self._proto.close()

                # Step 1: HTTP login to get ssid
                success, reason = self._proto._http_login()
                if not success:
                    logger.warning(f"[Stealth] Login failed: {reason}")
                    if attempt < MAX_RECONNECT_ATTEMPTS - 1:
                        backoff = min(RECONNECT_BACKOFF_BASE ** attempt, 10)
                        backoff += random.uniform(1.0, 3.0)
                        logger.info(f"[Stealth] Retrying in {backoff:.1f}s...")
                        time.sleep(backoff)
                    continue

                # Step 2: Get profile via HTTP
                self._proto._http_get_profile()

                # Step 3: Connect WebSocket and send SSID
                ws_ok, ws_reason = self._proto._ws_connect()
                if not ws_ok:
                    logger.warning(f"[Stealth] WebSocket connect failed: {ws_reason}")
                    if attempt < MAX_RECONNECT_ATTEMPTS - 1:
                        backoff = min(RECONNECT_BACKOFF_BASE ** attempt, 10)
                        backoff += random.uniform(1.0, 3.0)
                        time.sleep(backoff)
                    continue

                # Step 4: Wait for timeSync (confirms SSID auth worked)
                time_sync_ok = False
                deadline = time.time() + 30
                while time.time() < deadline:
                    if self._proto._server_timestamp and self._proto._server_timestamp > 0:
                        time_sync_ok = True
                        break
                    time.sleep(0.1)

                if not time_sync_ok:
                    logger.warning("[Stealth] timeSync not received after 30s")
                    # Still proceed — some connections work without immediate timeSync

                # Step 5: Subscribe to current balance
                if self._proto._balance_id:
                    self._proto.subscribe_balance(self._proto._balance_id)

                # Step 6: Request actives list
                self._request_actives()

                # Mark connected
                self._connected = True
                self._reconnect_count = 0
                self._last_connect_time = time.time()
                self._last_session_refresh = time.time()

                # Restore balance mode
                try:
                    self.change_balance(self._last_balance_mode)
                except Exception:
                    pass

                # Start watchdog
                self._start_watchdog()

                logger.info("[Stealth] Connection successful (Anti-Detection active)")
                return True, None

            except Exception as e:
                logger.error(f"[Stealth] Connect attempt {attempt + 1} error: {e}")
                traceback.print_exc()
                if attempt < MAX_RECONNECT_ATTEMPTS - 1:
                    backoff = min(RECONNECT_BACKOFF_BASE ** attempt, 10)
                    backoff += random.uniform(2.0, 5.0)
                    time.sleep(backoff)

        return False, "Connect failed after all attempts"

    def check_connect(self):
        """Check if the connection is alive.

        Uses multiple verification methods:
        1. Try getting a server timestamp (most reliable)
        2. Check WebSocket connected flag
        """
        # Method 1: Check if we've received a recent timeSync
        if self._proto._server_timestamp and self._proto._last_timesync:
            elapsed = time.time() - self._proto._last_timesync
            if elapsed < 120 and self._proto._ws_connected:
                return True

        # Method 2: Just check WebSocket flag
        if self._proto._ws_connected:
            # Verify with a quick test — try sending a ping-like message
            # Actually, just trust the flag if it's recent
            if self._proto._last_timesync and (time.time() - self._proto._last_timesync) < 300:
                return True

        return False

    def _ensure_connected(self, max_attempts=3):
        """Ensure we have a working connection. Reconnect if needed.

        Returns:
            bool: True if connected (either already or after reconnect)
        """
        if self.check_connect():
            self._connected = True
            self._maybe_rotate_session()
            return True

        logger.warning("[Stealth] Connection lost, reconnecting...")
        for attempt in range(max_attempts):
            try:
                ok, reason = self.connect()
                if ok:
                    try:
                        self.change_balance(self._last_balance_mode)
                    except Exception:
                        pass
                    return True
            except Exception as e:
                logger.error(f"[Stealth] Reconnect attempt {attempt + 1}: {e}")
            backoff = RECONNECT_BACKOFF_BASE ** attempt + random.uniform(0.5, 1.5)
            time.sleep(backoff)

        logger.error("[Stealth] Could not reconnect")
        return False

    # ----------------------------------------------------------
    # Balance Management
    # ----------------------------------------------------------
    def get_balance(self):
        """Get current balance amount.

        Returns:
            float: Current balance
        """
        try:
            return self.get_balance_safe()
        except Exception:
            try:
                return self._proto._balance_amount
            except Exception:
                return 0.0

    def get_balance_safe(self):
        """Get current balance with retries and timeout.

        Returns:
            float: Current balance

        Raises:
            Exception: If balance cannot be obtained after retries
        """
        for attempt in range(3):
            try:
                if not self._ensure_connected():
                    continue

                # Method 1: Return cached balance from WebSocket updates
                if self._proto._balance_amount > 0:
                    # Force a balance refresh by re-subscribing
                    if self._proto._balance_id:
                        self._proto.subscribe_balance(self._proto._balance_id)

                    # Wait briefly for an update
                    self._proto._balance_event.clear()
                    if self._proto._balance_event.wait(timeout=5):
                        return self._proto._balance_amount

                    # If no event, return what we have
                    return self._proto._balance_amount

                # Method 2: Try HTTP getprofile for balance
                try:
                    self._proto._http_get_profile()
                    type_info = self._balances.get(self._proto._current_balance_type, {})
                    if type_info.get("amount") is not None:
                        return type_info["amount"]
                except Exception:
                    pass

            except Exception as e:
                logger.warning(f"[Stealth] get_balance attempt {attempt + 1}: {e}")
                self._ensure_connected()
                time.sleep(2)

        # Final fallback
        if self._proto._balance_amount > 0:
            return self._proto._balance_amount
        raise Exception("get_balance failed after 3 attempts")

    def get_balances(self):
        """Get all balance information.

        Returns:
            dict: Balance data with msg list
        """
        result = {"msg": []}
        for btype, info in self._proto._balances.items():
            result["msg"].append({
                "id": info.get("id"),
                "type": 1 if btype == "PRACTICE" else 2,
                "amount": info.get("amount", 0.0),
            })
        return result

    def change_balance(self, mode):
        """Switch between PRACTICE and REAL balance.

        Args:
            mode: "PRACTICE" or "REAL"
        """
        self._last_balance_mode = mode
        if mode in self._proto._balances:
            bal_info = self._proto._balances[mode]
            self._proto._current_balance_type = mode
            self._proto._balance_id = bal_info.get("id")
            self._proto._balance_amount = bal_info.get("amount", 0.0)
            # Subscribe to the new balance
            if self._proto._balance_id:
                self._proto.subscribe_balance(self._proto._balance_id)
            logger.info(f"[Stealth] Balance switched to {mode} (id={self._proto._balance_id})")
        else:
            logger.warning(f"[Stealth] Balance mode '{mode}' not available, "
                           f"available: {list(self._proto._balances.keys())}")

    # ----------------------------------------------------------
    # Instrument & Active Management
    # ----------------------------------------------------------
    def _request_actives(self):
        """Request the list of available actives from the server."""
        # Subscribe to actives data
        self._proto._ws_send("subscribe", {"name": "actives", "params": {}})
        # Also request profit data
        self._proto._ws_send("subscribe", {"name": "profit", "params": {}})

    def update_ACTIVES_OPCODE(self):
        """Refresh the actives mapping from the server."""
        self._request_actives()
        # Give the server time to respond
        time.sleep(2)
        # Merge proto's actives into cache
        if self._proto._actives_opcode:
            self._actives_cache = dict(self._proto._actives_opcode)
            self._actives_cache_time = time.time()
            logger.info(f"[Stealth] ACTIVES updated: {len(self._actives_cache)} instruments")

    def get_all_ACTIVES_OPCODE(self):
        """Get the mapping of instrument names to active IDs.

        Returns:
            dict: {instrument_name: active_id}
        """
        # Return cached if fresh (< 10 min)
        if self._actives_cache and (time.time() - self._actives_cache_time) < 600:
            return self._actives_cache

        # Try to use proto's live data
        if self._proto._actives_opcode:
            self._actives_cache = dict(self._proto._actives_opcode)
            self._actives_cache_time = time.time()
            return self._actives_cache

        # Try refreshing
        try:
            self.update_ACTIVES_OPCODE()
            if self._actives_cache:
                return self._actives_cache
        except Exception:
            pass

        # Fallback: build from profit data
        try:
            all_profit = self.get_all_profit()
            if all_profit:
                result = {}
                for name in all_profit.keys():
                    result[name] = name
                if result:
                    self._actives_cache = result
                    self._actives_cache_time = time.time()
                    return result
        except Exception:
            pass

        return self._actives_cache if self._actives_cache else {}

    def get_all_profit(self, force_refresh=False):
        """Get profit/payout data for all instruments.

        Returns:
            dict: {instrument_name: {"turbo": x, "binary": y}}
        """
        now = time.time()
        if not force_refresh and self._profit_cache and (now - self._profit_cache_time) < self._profit_cache_ttl:
            return self._profit_cache

        # Use proto's live profit data
        if self._proto._profit_data:
            self._profit_cache = dict(self._proto._profit_data)
            self._profit_cache_time = time.time()
            return self._profit_cache

        # Request fresh data
        try:
            if self._ensure_connected():
                self._proto._ws_send("subscribe", {"name": "profit", "params": {}})
                time.sleep(3)
                if self._proto._profit_data:
                    self._profit_cache = dict(self._proto._profit_data)
                    self._profit_cache_time = time.time()
                    return self._profit_cache
        except Exception as e:
            logger.warning(f"[Stealth] get_all_profit error: {e}")

        # Fallback to cached
        if self._profit_cache:
            return self._profit_cache
        return None

    # ----------------------------------------------------------
    # Candle Data
    # ----------------------------------------------------------
    def _resolve_active_id(self, instrument_name):
        """Resolve an instrument name to its numeric active_id.

        Tries multiple name variations for OTC instruments.

        Returns:
            int|str|None: The active_id, or None if not found
        """
        # Direct lookup in actives_opcode
        if instrument_name in self._proto._actives_opcode:
            return self._proto._actives_opcode[instrument_name]

        # Try cached actives
        if instrument_name in self._actives_cache:
            aid = self._actives_cache[instrument_name]
            if isinstance(aid, int):
                return aid

        # Try name variations
        norm = instrument_name.upper().replace("-", "").replace("_", "")
        # Check cache first
        if norm in _active_name_cache:
            cached_name = _active_name_cache[norm]
            if cached_name in self._proto._actives_opcode:
                return self._proto._actives_opcode[cached_name]

        variations = [
            instrument_name,
            instrument_name.upper(),
            instrument_name.lower(),
            instrument_name.replace("-OTC", "_otc"),
            instrument_name.replace("-otc", "_otc"),
            instrument_name.replace("_otc", "-OTC"),
            instrument_name.replace("_OTC", "-OTC"),
            instrument_name.replace("-OTC", "otc"),
            # Also try without separator
            instrument_name.replace("-OTC", "OTC"),
            instrument_name.replace("-otc", "OTC"),
        ]
        # Remove duplicates while preserving order
        seen = set()
        unique = []
        for v in variations:
            if v not in seen:
                seen.add(v)
                unique.append(v)

        for name in unique:
            if name in self._proto._actives_opcode:
                _active_name_cache[norm] = name
                return self._proto._actives_opcode[name]

        # Try HTTP fallback: use the instrument name directly with getprofile-like endpoint
        return None

    def get_candles(self, ACTIVES, interval, count, endtime):
        """Get candle data for an instrument.

        Args:
            ACTIVES: Instrument name (e.g., "EURUSD-OTC")
            interval: Candle size in seconds (e.g., 60)
            count: Number of candles to retrieve
            endtime: End timestamp (int)

        Returns:
            list[dict]|None: List of candle dicts with keys:
                open, max (high), min (low), close, from, to, volume, etc.
        """
        self._maybe_rotate_session()

        # Resolve instrument name to active_id
        active_id = self._resolve_active_id(ACTIVES)

        # Build name variations for fallback
        norm = ACTIVES.upper().replace("-", "").replace("_", "")
        name_variations = [ACTIVES]
        if norm in _active_name_cache:
            name_variations.insert(0, _active_name_cache[norm])
        name_variations.extend([
            ACTIVES.upper(), ACTIVES.lower(),
            ACTIVES.replace("-OTC", "_otc"), ACTIVES.replace("-otc", "_otc"),
            ACTIVES.replace("_otc", "-OTC"), ACTIVES.replace("-OTC", "otc"),
        ])
        seen = set()
        unique_variations = []
        for n in name_variations:
            if n not in seen:
                seen.add(n)
                unique_variations.append(n)

        # Try WebSocket getCandles first
        if active_id and self._ensure_connected():
            result = self._get_candles_ws(active_id, interval, count, endtime)
            if result:
                return result

        # Fallback: Try HTTP candles endpoint
        for name in unique_variations:
            result = self._get_candles_http(name, interval, count, endtime)
            if result:
                if name != ACTIVES:
                    _active_name_cache[norm] = name
                return result

            # Also try resolving active_id for this name variation
            aid = self._resolve_active_id(name)
            if aid and aid != active_id:
                result = self._get_candles_ws(aid, interval, count, endtime)
                if result:
                    _active_name_cache[norm] = name
                    return result

        logger.error(f"[Stealth] get_candles FAILED for {ACTIVES} after all attempts")
        return None

    def _get_candles_ws(self, active_id, interval, count, endtime):
        """Get candles via WebSocket getCandles message."""
        try:
            if not self._ensure_connected():
                return None

            from_ts = endtime - (count * interval)
            rid = self._proto.get_candles_request(active_id, interval, from_ts, endtime, count)

            if not rid:
                return None

            # Wait for response
            with self._lock:
                event = threading.Event()
                entry = {"event": event, "result": None}
                self._proto._pending[rid] = entry

            if event.wait(timeout=DEFAULT_TIMEOUT_CANDLE):
                data = entry.get("result")
                if isinstance(data, list):
                    return self._normalize_candles(data)
                elif isinstance(data, dict):
                    candles = data.get("candles", data.get("msg", []))
                    if candles:
                        return self._normalize_candles(candles)

            return None
        except Exception as e:
            logger.warning(f"[Stealth] getCandles WS error: {e}")
            return None

    def _get_candles_http(self, instrument_name, interval, count, endtime):
        """Get candles via HTTP API as fallback."""
        try:
            # Resolve active_id for HTTP endpoint
            active_id = self._resolve_active_id(instrument_name)
            if not active_id:
                # Try using the name as-is (some endpoints accept names)
                active_id = instrument_name

            url = f"{IQOPTION_API_URL}/candles"
            params = {
                "active_id": active_id if isinstance(active_id, int) else 1,
                "size": interval,
                "count": count,
                "end": endtime,
            }

            resp = self._proto._http.get(url, params=params, timeout=DEFAULT_TIMEOUT_CANDLE)
            if resp.status_code == 200:
                data = resp.json()
                candles = data if isinstance(data, list) else data.get("msg", data.get("data", []))
                if candles:
                    return self._normalize_candles(candles)
        except Exception as e:
            logger.debug(f"[Stealth] getCandles HTTP error for {instrument_name}: {e}")
        return None

    @staticmethod
    def _normalize_candles(candles_raw):
        """Normalize candle data to a consistent format.

        The engine/scanner expects dicts with keys: open, max, min, close
        (matching the iqoptionapi format).
        """
        result = []
        for c in candles_raw:
            if isinstance(c, dict):
                result.append({
                    "open": c.get("open", 0),
                    "max": c.get("max", c.get("high", 0)),
                    "min": c.get("min", c.get("low", 0)),
                    "close": c.get("close", 0),
                    "from": c.get("from", c.get("time", 0)),
                    "to": c.get("to", 0),
                    "volume": c.get("volume", 0),
                    "id": c.get("id", 0),
                })
            elif isinstance(c, (list, tuple)) and len(c) >= 4:
                result.append({
                    "open": c[0], "max": c[1], "min": c[2], "close": c[3]
                })
        return result if result else None

    # ----------------------------------------------------------
    # Trading
    # ----------------------------------------------------------
    def buy(self, price, ACTIVES, ACTION, expirations):
        """Place a binary option trade.

        Args:
            price: Trade amount (e.g., 2.50)
            ACTIVES: Instrument name (e.g., "EURUSD-OTC")
            ACTION: "call" or "put"
            expirations: Expiration in minutes (typically 1)

        Returns:
            (bool, int|str): (success, order_id) on success,
                             (False, error_message) on failure
        """
        self._maybe_rotate_session()

        # Anti-detection: human-like jitter before order
        jitter = random.uniform(0.05, 0.6)
        time.sleep(jitter)

        # Resolve active_id
        active_id = self._resolve_active_id(ACTIVES)
        if not active_id:
            # Try updating actives
            self.update_ACTIVES_OPCODE()
            active_id = self._resolve_active_id(ACTIVES)
            if not active_id:
                logger.error(f"[Stealth] Cannot resolve active_id for {ACTIVES}")
                return False, f"Unknown instrument: {ACTIVES}"

        for attempt in range(3):
            try:
                if not self._ensure_connected():
                    logger.warning(f"[Stealth] No connection for buy (attempt {attempt + 1})")
                    time.sleep(2)
                    continue

                # Calculate expiration timestamp: next minute boundary + expirations minutes
                now_ts = self.get_server_timestamp()
                if not now_ts or now_ts <= 0:
                    now_ts = time.time()

                # Align to next minute boundary + expiration
                current_minute = int(now_ts) // 60
                expiration_timestamp = (current_minute + 1 + expirations) * 60

                # Place the order
                direction = ACTION.lower()
                if direction not in ("call", "put"):
                    return False, f"Invalid direction: {ACTION}"

                rid = self._proto.buyv2(
                    price=price,
                    active_id=active_id,
                    direction=direction,
                    expiration_timestamp=expiration_timestamp,
                )

                if not rid:
                    if attempt < 2:
                        self._ensure_connected()
                        time.sleep(2)
                    continue

                # Wait for buyv2 response
                with self._lock:
                    event = threading.Event()
                    entry = {"event": event, "result": None}
                    self._proto._pending[rid] = entry

                if event.wait(timeout=DEFAULT_TIMEOUT_BUY):
                    data = entry.get("result")
                    if isinstance(data, dict):
                        order_id = data.get("id")
                        if order_id:
                            self._proto._open_orders[order_id] = {
                                "price": price,
                                "active_id": active_id,
                                "direction": direction,
                                "expiration": expiration_timestamp,
                            }
                            logger.info(f"[Stealth] Buy OK: {ACTIVES} {direction} ${price:.2f} "
                                        f"-> order_id={order_id}")
                            return True, order_id
                        else:
                            error_msg = data.get("message", data.get("error", "Unknown error"))
                            logger.warning(f"[Stealth] Buy rejected: {error_msg}")
                            return False, str(error_msg)

                logger.warning(f"[Stealth] Buy timeout (attempt {attempt + 1})")

            except Exception as e:
                logger.warning(f"[Stealth] Buy error (attempt {attempt + 1}): {e}")
                self._ensure_connected()
                time.sleep(2)

        return False, "Buy failed after 3 attempts"

    # ----------------------------------------------------------
    # Trade Result
    # ----------------------------------------------------------
    def check_win_v3(self, id_number, timeout=None):
        """Check if a trade won or lost.

        Waits for the option-closed message via WebSocket.

        Args:
            id_number: The order_id returned by buy()
            timeout: Maximum wait time in seconds (default: 120)

        Returns:
            float|None: Profit amount (positive = win, negative = loss),
                        None if timeout/unable to determine
        """
        if timeout is None:
            timeout = DEFAULT_TIMEOUT_CHECK_WIN

        start_time = time.time()
        balance_before = None
        try:
            balance_before = self.get_balance_safe()
        except Exception:
            pass

        while time.time() - start_time < timeout:
            try:
                if not self.check_connect():
                    self._ensure_connected()
                    time.sleep(2)
                    continue

                # Check if option-closed message arrived
                if id_number in self._proto._closed_orders:
                    closed = self._proto._closed_orders[id_number]
                    profit_amount = closed.get("profit_amount", 0)
                    amount = closed.get("amount", 0)
                    # Net profit = profit_amount - amount (matches iqoptionapi convention)
                    net_profit = profit_amount - amount
                    # Clean up
                    del self._proto._closed_orders[id_number]
                    self._proto._open_orders.pop(id_number, None)
                    return net_profit

                # Also check open orders for status updates
                if id_number not in self._proto._open_orders:
                    # Order might have been closed but we missed the message
                    # Check via async order
                    order_data = self.get_async_order(id_number)
                    if order_data and isinstance(order_data, dict):
                        option_closed = order_data.get("option-closed", {})
                        if option_closed:
                            msg = option_closed.get("msg", option_closed)
                            if isinstance(msg, dict):
                                profit_amount = msg.get("profit_amount", 0)
                                amount = msg.get("amount", 0)
                                return profit_amount - amount

                time.sleep(random.uniform(0.8, 1.5))

            except Exception as e:
                logger.warning(f"[Stealth] check_win_v3 error: {e}")
                time.sleep(random.uniform(1.5, 3.0))

        # Timeout — try balance comparison fallback
        logger.warning(f"[Stealth] check_win_v3 TIMEOUT ({timeout}s), using balance fallback")
        if balance_before is not None:
            try:
                time.sleep(3)
                balance_after = self.get_balance_safe()
                diff = balance_after - balance_before
                if abs(diff) > 0.01:
                    return diff
            except Exception:
                pass

        logger.error(f"[Stealth] check_win_v3 could not determine result for order {id_number}")
        return None

    def get_async_order(self, id_number):
        """Get order data from the async order tracking.

        Returns:
            dict: Order data if available
        """
        # Check closed orders
        if id_number in self._proto._closed_orders:
            return {"option-closed": {"msg": self._proto._closed_orders[id_number]}}

        # Check open orders
        if id_number in self._proto._open_orders:
            return {"order": self._proto._open_orders[id_number]}

        # Try requesting via WebSocket
        try:
            if self._ensure_connected():
                rid = self._proto._ws_send("getOptions", {"option_ids": [id_number]})
                if rid:
                    with self._lock:
                        event = threading.Event()
                        entry = {"event": event, "result": None}
                        self._proto._pending[rid] = entry
                    if event.wait(timeout=10):
                        return entry.get("result") or {}
        except Exception:
            pass

        return {}

    # ----------------------------------------------------------
    # Server Time
    # ----------------------------------------------------------
    def get_server_timestamp(self):
        """Get the server timestamp from the last timeSync message.

        Returns:
            float: Server timestamp (unix epoch seconds)
        """
        if self._proto._server_timestamp and self._proto._server_timestamp > 0:
            return self._proto._server_timestamp
        # Fallback to local time if no server timestamp available
        return time.time()

    # ----------------------------------------------------------
    # Anti-Detection: Session Rotation
    # ----------------------------------------------------------
    def _maybe_rotate_session(self):
        """Rotate UA/TLS profile if the rotation interval has elapsed.

        This prevents IQ Option from flagging a session that uses the same
        TLS fingerprint and UA for too long (a telltale sign of bots).
        """
        now = time.time()
        if (now - self._last_session_refresh) > self._next_rotation:
            try:
                # Rotate HTTP session
                new_ua = _get_random_ua()
                chrome_version = new_ua.split("Chrome/")[1].split(" ")[0] if "Chrome/" in new_ua else "135"

                session = self._proto._http
                session.headers["User-Agent"] = new_ua
                session.headers["sec-ch-ua"] = (
                    f'"Not A(Brand";v="99", "Google Chrome";v="{chrome_version}", '
                    f'"Chromium";v="{chrome_version}"'
                )
                languages = [
                    "en-US,en;q=0.9,es;q=0.8",
                    "en-US,en;q=0.9",
                    "en-US,en;q=0.9,es;q=0.8,pt;q=0.7",
                    "en,en-US;q=0.9,es;q=0.8",
                ]
                session.headers["Accept-Language"] = random.choice(languages)

                # Rotate TLS fingerprint if curl_cffi is available
                if CURL_CFFI_AVAILABLE:
                    try:
                        profiles = ["chrome131", "chrome130", "chrome124", "chrome120"]
                        new_profile = random.choice(profiles)
                        old_session = session
                        new_session = curl_requests.Session(impersonate=new_profile)
                        for key, value in old_session.headers.items():
                            new_session.headers[key] = value
                        for cookie in old_session.cookies.jar:
                            new_session.cookies.set(cookie.name, cookie.value)
                        self._proto._http = new_session
                        logger.info(f"[Stealth] TLS fingerprint rotated -> {new_profile}")
                    except Exception as e:
                        logger.warning(f"[Stealth] Error rotating TLS fingerprint: {e}")

                logger.info(f"[Stealth] Session rotated - Chrome/{chrome_version}")
                self._last_session_refresh = now
                self._next_rotation = random.uniform(SESSION_ROTATION_MIN, SESSION_ROTATION_MAX)
            except Exception as e:
                logger.warning(f"[Stealth] Error rotating session: {e}")

    # ----------------------------------------------------------
    # Noise Browsing (Anti-Detection)
    # ----------------------------------------------------------
    def _noise_browsing(self):
        """Perform a random non-trading action to appear more human-like.

        Called periodically by the engine's main loop. Actions include:
        - Checking balance (without trading)
        - Browsing instruments
        - Checking payout data
        """
        now = time.time()
        # Only do noise every 60-180 seconds
        if now - self._last_noise_time < random.uniform(60, 180):
            return

        self._last_noise_time = now
        try:
            action = random.choice(["balance", "instruments", "profit"])
            if action == "balance":
                try:
                    bal = self.get_balance()
                    logger.debug(f"[Noise] Balance check: ${bal:.2f}")
                except Exception:
                    pass
            elif action == "instruments":
                try:
                    actives = self.get_all_ACTIVES_OPCODE()
                    if actives:
                        sample = random.choice(list(actives.keys()))
                        logger.debug(f"[Noise] Browsing instrument: {sample}")
                except Exception:
                    pass
            elif action == "profit":
                try:
                    profit = self.get_all_profit()
                    if profit:
                        sample = random.choice(list(profit.keys()))
                        logger.debug(f"[Noise] Checking payout: {sample}")
                except Exception:
                    pass
        except Exception:
            pass

    # ----------------------------------------------------------
    # Watchdog Thread
    # ----------------------------------------------------------
    def _start_watchdog(self):
        """Start a watchdog thread to detect silent WebSocket disconnections."""
        if self._watchdog_thread is not None and self._watchdog_thread.is_alive():
            return

        self._watchdog_stop.clear()

        def _watchdog_loop():
            logger.info("[Watchdog] Started - monitoring connection")
            last_good_ts = time.time()

            while not self._watchdog_stop.is_set():
                try:
                    self._watchdog_stop.wait(timeout=30.0)
                    if self._watchdog_stop.is_set():
                        break

                    if not self._connected:
                        continue

                    # Check if we've received timeSync recently
                    if self._proto._last_timesync > 0:
                        elapsed = time.time() - self._proto._last_timesync
                        if elapsed < 120:
                            last_good_ts = time.time()
                        elif elapsed > 180:
                            logger.warning(f"[Watchdog] No timeSync for {elapsed:.0f}s - "
                                           "marking disconnected")
                            self._connected = False
                            self._proto._ws_connected = False
                    else:
                        # No timeSync at all, check with a direct test
                        no_ts_elapsed = time.time() - last_good_ts
                        if no_ts_elapsed > 120:
                            logger.warning(f"[Watchdog] No server activity for "
                                           f"{no_ts_elapsed:.0f}s - marking disconnected")
                            self._connected = False

                except Exception as e:
                    logger.warning(f"[Watchdog] Error: {e}")

            logger.info("[Watchdog] Stopped")

        self._watchdog_thread = threading.Thread(target=_watchdog_loop, daemon=True)
        self._watchdog_thread.start()

    def _stop_watchdog(self):
        """Stop the watchdog thread."""
        self._watchdog_stop.set()
        if self._watchdog_thread is not None:
            try:
                self._watchdog_thread.join(timeout=5.0)
            except Exception:
                pass
            self._watchdog_thread = None

    # ----------------------------------------------------------
    # Cleanup
    # ----------------------------------------------------------
    def close(self):
        """Close the connection and clean up resources."""
        self._stop_watchdog()
        self._proto.close()
        self._connected = False

    # ----------------------------------------------------------
    # Compatibility: __getattr__ delegation
    # ----------------------------------------------------------
    def __getattr__(self, name):
        """Delegate unknown attributes to the protocol handler.

        This provides compatibility with code that might access internal
        iqoptionapi attributes that we don't explicitly implement.
        """
        if name.startswith("_"):
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")
        if hasattr(self._proto, name):
            return getattr(self._proto, name)
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")
