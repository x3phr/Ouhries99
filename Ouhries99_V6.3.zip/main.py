"""
Sistema Ouhries V6.2 - Aplicacion de Escritorio
GUI profesional con Canvas-based rendering, bordes redondeados reales,
gradientes, sombras de texto, profundidad visual.
Auto-guardado, log a archivo, payout 87+, expiracion 1m.
Niveles de interes compuesto (N1, N1+, N1++, ...).
Telegram con emojis.
"""

import sys
import os

# ============================================================
# ERROR HANDLER GLOBAL
# ============================================================
def _show_fatal_error(title, message):
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(title, message)
        root.destroy()
    except Exception:
        print(f"FATAL: {title}\n{message}", file=sys.stderr)

try:
    import tkinter as tk
    from tkinter import ttk, messagebox
except ImportError:
    _show_fatal_error("Error Critico",
        "tkinter no esta instalado.\n\n"
        "Instala Python con soporte Tk/Tcl:\n"
        "https://www.python.org/downloads/\n\n"
        "Asegurate de marcar 'Add Python to PATH'.")
    sys.exit(1)

import threading
import time
from datetime import datetime

try:
    from config import load_config, save_config, DEFAULT_CONFIG
except ImportError as e:
    _show_fatal_error("Error de Importacion",
        f"No se pudo importar config.py:\n{e}\n\n"
        "Asegurate de que todos los archivos del bot esten en la misma carpeta.")
    sys.exit(1)

_engine_class = None
_engine_import_error = None

def _get_engine_class():
    global _engine_class, _engine_import_error
    if _engine_class is not None:
        return _engine_class
    if _engine_import_error is not None:
        raise _engine_import_error
    try:
        from engine import TradingEngine
        _engine_class = TradingEngine
        return TradingEngine
    except ImportError as e:
        _engine_import_error = e
        raise

# ============================================================
# TEMA - PROFESIONAL DARK CON COLORES VIBRANTES
# text3 changed from #484f58 to #6e7681 for better visibility
# ============================================================
C = {
    "bg":        "#0d1117",
    "bg2":       "#161b22",
    "bg3":       "#1c2333",
    "card":      "#1a2233",
    "card2":     "#222d42",
    "input":     "#0d1117",
    "accent":    "#e94560",
    "accent2":   "#ff6b81",
    "success":   "#00e676",
    "success2":  "#69f0ae",
    "danger":    "#ff1744",
    "danger2":   "#ff5252",
    "warning":   "#ffab00",
    "warning2":  "#ffd740",
    "info":      "#448aff",
    "info2":     "#82b1ff",
    "orange":    "#ff9100",
    "orange2":   "#ffab40",
    "text":      "#e6edf3",
    "text2":     "#8b949e",
    "text3":     "#6e7681",
    "border":    "#30363d",
    "border2":   "#444c56",
}

FONT = "Segoe UI"
FONT_B = "Segoe UI Bold"
FONT_S = "Segoe UI Semibold"
FONT_M = "Consolas"

STRING_FIELDS = {"email", "password", "telegram_token", "telegram_chat_id"}


# ============================================================
# CANVAS HELPERS
# ============================================================
def rounded_rect(canvas, x1, y1, x2, y2, r=10, **kw):
    """Dibuja rectangulo redondeado en canvas y devuelve el item id."""
    pts = [
        x1+r, y1,   x1+r, y1,   x2-r, y1,   x2-r, y1,
        x2, y1,     x2, y1+r,   x2, y1+r,   x2, y2-r,
        x2, y2-r,   x2, y2,     x2-r, y2,   x2-r, y2,
        x1+r, y2,   x1+r, y2,   x1, y2,     x1, y2-r,
        x1, y2-r,   x1, y1+r,   x1, y1+r,   x1, y1,
    ]
    return canvas.create_polygon(pts, smooth=True, **kw)


def shadow_text(canvas, x, y, text, font, fill, shadow_color="#000000",
                shadow_offset=1, anchor=tk.NW, **kw):
    """Dibuja texto con sombra y devuelve (shadow_id, text_id).
    Shadow color should be dark (#000000 or #1a1a2e) for visibility on dark bg."""
    s = canvas.create_text(x + shadow_offset, y + shadow_offset, text=text,
                           font=font, fill=shadow_color, anchor=anchor, **kw)
    t = canvas.create_text(x, y, text=text, font=font, fill=fill,
                           anchor=anchor, **kw)
    return s, t


def gradient_rect(canvas, x1, y1, x2, y2, color1, color2, steps=12, r=10):
    """Dibuja rectangulo redondeado con gradiente vertical simulado."""
    items = []
    h = (y2 - y1) / steps
    for i in range(steps):
        ratio = i / max(steps - 1, 1)
        r_ = int(int(color1[1:3], 16) + (int(color2[1:3], 16) - int(color1[1:3], 16)) * ratio)
        g_ = int(int(color1[3:5], 16) + (int(color2[3:5], 16) - int(color1[3:5], 16)) * ratio)
        b_ = int(int(color1[5:7], 16) + (int(color2[5:7], 16) - int(color1[5:7], 16)) * ratio)
        c = f"#{r_:02x}{g_:02x}{b_:02x}"
        sy = y1 + i * h
        ey = y1 + (i + 1) * h + 1
        if i == 0:
            item = rounded_rect(canvas, x1, sy, x2, ey, r,
                                fill=c, outline="")
        elif i == steps - 1:
            item = rounded_rect(canvas, x1, sy, x2, ey, r,
                                fill=c, outline="")
        else:
            item = canvas.create_rectangle(x1, sy, x2, ey, fill=c, outline="")
        items.append(item)
    return items


# ============================================================
# STAT CARD WIDGET (Canvas-based, rounded, gradient)
# ============================================================
class StatCard(tk.Canvas):
    """Tarjeta de estadistica con bordes redondeados, gradiente y sombra de texto."""

    def __init__(self, parent, title="", value="", value_color=C["success"],
                 glow_color=None, width=180, height=70, **kw):
        super().__init__(parent, width=width, height=height,
                         bg=C["bg"], highlightthickness=0, **kw)
        self._title = title
        self._value = value
        self._value_color = value_color
        self._glow_color = glow_color or value_color
        self._width = width
        self._height = height
        self._draw()

    def _draw(self):
        self.delete("all")
        w, h = self._width, self._height

        # Glow exterior (borde brillante redondeado)
        rounded_rect(self, 1, 1, w-1, h-1, r=10,
                     fill="", outline=self._glow_color, width=2)

        # Card con gradiente
        gradient_rect(self, 3, 3, w-3, h-3, C["card"], C["card2"], steps=8, r=8)

        # Borde interior sutil
        rounded_rect(self, 3, 3, w-3, h-3, r=8,
                     fill="", outline=C["border"], width=1)

        # Dot indicador
        dot_color = self._value_color
        self.create_oval(12, 10, 18, 16, fill=dot_color, outline=dot_color)

        # Titulo (visible: text2=#8b949e on card=#1a2233)
        self.create_text(24, 8, text=self._title, font=(FONT, 8),
                         fill=C["text2"], anchor=tk.NW)

        # Valor con sombra oscura (no glow como sombra - usamos #000000)
        shadow_text(self, 12, 26, self._value, (FONT_M, 13, "bold"),
                    self._value_color, shadow_color="#000000",
                    shadow_offset=1, anchor=tk.NW)

    def configure_card(self, **kw):
        if "value" in kw:
            self._value = kw["value"]
        if "value_color" in kw:
            self._value_color = kw["value_color"]
        if "glow_color" in kw:
            self._glow_color = kw["glow_color"]
        self._draw()


# ============================================================
# GLOW BUTTON WIDGET (Canvas-based, rounded, gradient)
# ============================================================
class GlowButton(tk.Canvas):
    """Boton con bordes redondeados, gradiente y glow."""

    def __init__(self, parent, text="", command=None, color=C["success"],
                 text_color="#000000", width=160, height=44, **kw):
        super().__init__(parent, width=width, height=height,
                         bg=C["bg"], highlightthickness=0, **kw)
        self._text = text
        self._command = command
        self._color = color
        self._text_color = text_color
        self._width = width
        self._height = height
        self._enabled = True
        self._draw()

        self.bind("<Button-1>", self._on_click)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)

    def _draw(self):
        self.delete("all")
        w, h = self._width, self._height

        if not self._enabled:
            rounded_rect(self, 2, 2, w-2, h-2, r=8,
                         fill=C["bg3"], outline=C["border"], width=1)
            # Disabled text uses text2 for visibility (was text3 too dark)
            self.create_text(w//2, h//2, text=self._text,
                           font=(FONT_S, 11), fill=C["text2"], anchor=tk.CENTER)
            return

        # Glow exterior
        rounded_rect(self, 1, 1, w-1, h-1, r=9,
                     fill="", outline=self._color, width=2)

        # Gradiente del boton
        dark = self._blend(self._color, "#000000", 0.4)
        gradient_rect(self, 3, 3, w-3, h-3, self._color, dark, steps=6, r=7)

        # Texto con sombra oscura
        shadow_text(self, w//2, h//2, self._text, (FONT_S, 11, "bold"),
                    self._text_color, shadow_color="#000000",
                    shadow_offset=1, anchor=tk.CENTER)

    @staticmethod
    def _blend(c1, c2, ratio):
        r = int(int(c1[1:3],16) + (int(c2[1:3],16)-int(c1[1:3],16))*ratio)
        g = int(int(c1[3:5],16) + (int(c2[3:5],16)-int(c1[3:5],16))*ratio)
        b = int(int(c1[5:7],16) + (int(c2[5:7],16)-int(c1[5:7],16))*ratio)
        return f"#{max(0,min(255,r)):02x}{max(0,min(255,g)):02x}{max(0,min(255,b)):02x}"

    def _on_click(self, e):
        if self._enabled and self._command:
            self._command()

    def _on_enter(self, e):
        if self._enabled:
            self.configure(cursor="hand2")

    def _on_leave(self, e):
        self.configure(cursor="")

    def set_enabled(self, enabled):
        self._enabled = enabled
        self._draw()

    def set_text(self, text):
        self._text = text
        self._draw()

    def set_color(self, color, text_color=None):
        self._color = color
        if text_color:
            self._text_color = text_color
        self._draw()


# ============================================================
# HELPER: Bind scroll events for both Windows and Linux
# ============================================================
def _bind_scroll(canvas, target_canvas=None):
    """Bind mouse scroll for both Windows (MouseWheel) and Linux (Button-4/5)."""
    tc = target_canvas or canvas

    def _on_enter(event):
        canvas.bind_all("<MouseWheel>",
            lambda ev: tc.yview_scroll(int(-1*(ev.delta/120)), "units"))
        canvas.bind_all("<Button-4>",
            lambda ev: tc.yview_scroll(-1, "units"))
        canvas.bind_all("<Button-5>",
            lambda ev: tc.yview_scroll(1, "units"))

    def _on_leave(event):
        canvas.unbind_all("<MouseWheel>")
        canvas.unbind_all("<Button-4>")
        canvas.unbind_all("<Button-5>")

    canvas.bind("<Enter>", _on_enter)
    canvas.bind("<Leave>", _on_leave)


# ============================================================
# APLICACION PRINCIPAL
# ============================================================
class OuhriesApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema Ouhries V6.2")
        self.root.geometry("1150x720")
        self.root.minsize(950, 600)
        self.root.configure(bg=C["bg"])

        self.config = load_config()
        self.engine = None
        self.trade_thread = None
        self.connected = False
        self.trading_active = False
        self.paused = False
        self.recent_trades = []
        self.max_recent_trades = 999  # Sin limite de operaciones recientes
        self._seen_trade_ids = set()  # Deduplicacion por ID
        self.current_panel = "trading"
        self._prev_balance = 0.0
        self._balance_flash_id = None

        self._build_ui()
        self._update_stats_loop()

    # ============================================================
    # UI CONSTRUCTION
    # ============================================================
    def _build_ui(self):
        self.main_frame = tk.Frame(self.root, bg=C["bg"])
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        self._build_sidebar()

        # Content area
        self.content = tk.Frame(self.main_frame, bg=C["bg"])
        self.content.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self._build_top_bar()

        self.panels = {}
        self._build_trading_panel()
        self._build_gestion_panel()
        self._build_cuenta_panel()
        self._build_config_panel()
        self._show_panel("trading")

    # ============================================================
    # TOP BAR
    # ============================================================
    def _build_top_bar(self):
        top = tk.Frame(self.content, bg=C["bg2"], height=50)
        top.pack(fill=tk.X)
        top.pack_propagate(False)

        # Left - System name
        left = tk.Frame(top, bg=C["bg2"])
        left.pack(side=tk.LEFT, padx=15)
        tk.Label(left, text="SISTEMA OUHRIES V6.2", bg=C["bg2"],
                fg=C["accent"], font=(FONT_B, 14)).pack(side=tk.LEFT, pady=10)

        # Right - Balance
        right = tk.Frame(top, bg=C["bg2"])
        right.pack(side=tk.RIGHT, padx=15)

        tk.Label(right, text="BALANCE", bg=C["bg2"],
                fg=C["text3"], font=(FONT, 7, "bold")).pack(anchor=tk.E)

        is_demo = self.config.get("account_mode", "PRACTICE") == "PRACTICE"
        bal_color = C["orange"] if is_demo else C["success"]

        # Balance canvas con glow
        self.bal_canvas = tk.Canvas(right, width=140, height=30,
                                    bg=C["bg2"], highlightthickness=0)
        self.bal_canvas.pack(anchor=tk.E)
        self._draw_balance("$0.00", bal_color)

        mode_text = "DEMO" if is_demo else "REAL"
        self.lbl_mode_top = tk.Label(right, text=mode_text, bg=C["bg2"],
                                     fg=bal_color, font=(FONT, 8, "bold"))
        self.lbl_mode_top.pack(anchor=tk.E)

    def _draw_balance(self, text, color):
        c = self.bal_canvas
        c.delete("all")
        w, h = 140, 30
        # Glow border redondeado
        rounded_rect(c, 2, 2, w-2, h-2, r=8, fill="", outline=color, width=2)
        # Inner bg
        rounded_rect(c, 4, 4, w-4, h-4, r=6, fill=C["bg"], outline="")
        # Text con sombra oscura
        shadow_text(c, w//2, h//2, text, (FONT_M, 13, "bold"), color,
                    shadow_color="#000000", shadow_offset=1, anchor=tk.CENTER)
        # FIX: Always store last_text so _flash_balance can retrieve it
        self.bal_canvas._last_text = text

    def _flash_balance(self, won):
        if self._balance_flash_id:
            try:
                self.root.after_cancel(self._balance_flash_id)
            except Exception:
                pass

        is_demo = self.config.get("account_mode", "PRACTICE") == "PRACTICE"
        flash_color = C["success"] if won else C["danger"]
        normal_color = C["orange"] if is_demo else C["success"]

        def pulse(step=0):
            if step >= 6:
                self._draw_balance(
                    self.bal_canvas._last_text,
                    normal_color)
                return
            color = flash_color if step % 2 == 0 else normal_color
            self._draw_balance(
                self.bal_canvas._last_text,
                color)
            self._balance_flash_id = self.root.after(250, pulse, step + 1)
        pulse()

    # ============================================================
    # SIDEBAR
    # ============================================================
    def _build_sidebar(self):
        sidebar = tk.Frame(self.main_frame, bg=C["bg2"], width=180)
        sidebar.pack(side=tk.LEFT, fill=tk.Y)
        sidebar.pack_propagate(False)

        # Logo canvas
        logo_c = tk.Canvas(sidebar, width=170, height=55, bg=C["bg2"],
                          highlightthickness=0)
        logo_c.pack(pady=(15, 0), padx=5)
        # Glow rect detras del logo
        rounded_rect(logo_c, 5, 5, 165, 50, r=10,
                     fill=C["bg3"], outline=C["accent"], width=1)
        # Shadow with dark color for visibility
        shadow_text(logo_c, 85, 15, "OUHRIES", (FONT_B, 16), C["accent"],
                    shadow_color="#000000", shadow_offset=1, anchor=tk.CENTER)
        logo_c.create_text(85, 36, text="V6.2", font=(FONT, 10),
                          fill=C["text2"], anchor=tk.CENTER)

        tk.Frame(sidebar, bg=C["border"], height=1).pack(fill=tk.X, padx=15, pady=12)

        # Nav buttons - Cuenta primero
        self.nav_buttons = {}
        nav_items = [
            ("cuenta", "Cuenta", C["orange"]),
            ("trading", "Trading", C["info"]),
            ("gestion", "Gestion", C["success"]),
            ("config", "Configuracion", C["warning"]),
        ]
        for key, label, color in nav_items:
            btn_c = tk.Canvas(sidebar, width=170, height=40, bg=C["bg2"],
                             highlightthickness=0)
            btn_c.pack(padx=5, pady=2)

            # Barra lateral indicadora (solo visible si activo)
            btn_c.create_rectangle(0, 8, 4, 32, fill=C["bg2"], outline="",
                                   tags="indicator")

            rounded_rect(btn_c, 8, 4, 166, 36, r=8,
                         fill=C["bg2"], outline=C["bg2"], width=1, tags="bg")

            btn_c.create_text(20, 20, text=label, font=(FONT, 11),
                             fill=C["text"], anchor=tk.W, tags="label")

            btn_c.bind("<Button-1>", lambda e, k=key: self._show_panel(k))
            btn_c.bind("<Enter>", lambda e, c=btn_c, cl=color: self._nav_hover(c, cl, True))
            btn_c.bind("<Leave>", lambda e, c=btn_c: self._nav_hover(c, None, False))

            self.nav_buttons[key] = (btn_c, color)

        tk.Frame(sidebar, bg=C["border"], height=1).pack(fill=tk.X, padx=15, pady=12)

        # Connection status
        conn_f = tk.Frame(sidebar, bg=C["bg2"])
        conn_f.pack(pady=(5, 2))
        self.conn_canvas = tk.Canvas(conn_f, width=10, height=10, bg=C["bg2"],
                                     highlightthickness=0)
        self.conn_canvas.pack(side=tk.LEFT, padx=(0, 6))
        self.conn_canvas.create_oval(2, 2, 8, 8, fill=C["danger"], outline=C["danger"])
        self.lbl_connection = tk.Label(conn_f, text="Desconectado",
                                       bg=C["bg2"], fg=C["danger"], font=(FONT, 9))
        self.lbl_connection.pack(side=tk.LEFT)

        mode_f = tk.Frame(sidebar, bg=C["bg2"])
        mode_f.pack(pady=(0, 5))
        self.mode_canvas = tk.Canvas(mode_f, width=10, height=10, bg=C["bg2"],
                                     highlightthickness=0)
        self.mode_canvas.pack(side=tk.LEFT, padx=(0, 6))
        self.mode_canvas.create_oval(2, 2, 8, 8, fill=C["success"], outline=C["success"])
        self.lbl_mode = tk.Label(mode_f, text="DEMO", bg=C["bg2"],
                                 fg=C["success"], font=(FONT, 9, "bold"))
        self.lbl_mode.pack(side=tk.LEFT)

        # Footer - text3 now #6e7681 (visible on bg2)
        tk.Label(sidebar, text="Payout 86+ | Q>=88% | OTC V1 & V2.1",
                bg=C["bg2"], fg=C["text3"], font=(FONT, 7)).pack(side=tk.BOTTOM, pady=10)

    def _nav_hover(self, canvas, color, enter):
        try:
            if enter and color:
                canvas.delete("bg")
                rounded_rect(canvas, 8, 4, 166, 36, r=8,
                             fill=C["bg3"], outline=color, width=1, tags="bg")
                canvas.itemconfig("label", fill=C["text"])
            else:
                key = None
                for k, (c, _) in self.nav_buttons.items():
                    if c == canvas:
                        key = k
                        break
                if key != self.current_panel:
                    canvas.delete("bg")
                    rounded_rect(canvas, 8, 4, 166, 36, r=8,
                                 fill=C["bg2"], outline=C["bg2"], width=1, tags="bg")
                    canvas.itemconfig("label", fill=C["text"])
        except Exception:
            pass

    def _show_panel(self, panel_name):
        self.current_panel = panel_name
        for key, panel in self.panels.items():
            panel.pack_forget()
        if panel_name in self.panels:
            self.panels[panel_name].pack(fill=tk.BOTH, expand=True, in_=self.content)

        for key, (canvas, color) in self.nav_buttons.items():
            if key == panel_name:
                canvas.delete("bg")
                rounded_rect(canvas, 8, 4, 166, 36, r=8,
                             fill=C["bg3"], outline=color, width=2, tags="bg")
                canvas.itemconfig("label", font=(FONT_S, 11, "bold"))
                # Barra indicadora
                canvas.delete("indicator")
                canvas.create_rectangle(0, 8, 4, 32, fill=color, outline="",
                                       tags="indicator")
            else:
                canvas.delete("bg")
                rounded_rect(canvas, 8, 4, 166, 36, r=8,
                             fill=C["bg2"], outline=C["bg2"], width=1, tags="bg")
                canvas.itemconfig("label", font=(FONT, 11))
                canvas.delete("indicator")
                canvas.create_rectangle(0, 8, 4, 32, fill=C["bg2"], outline="",
                                       tags="indicator")

    # ============================================================
    # PANEL: TRADING
    # ============================================================
    def _build_trading_panel(self):
        panel = tk.Frame(self.content, bg=C["bg"])
        self.panels["trading"] = panel

        # Stats cards row 1
        row1 = tk.Frame(panel, bg=C["bg"])
        row1.pack(fill=tk.X, padx=15, pady=(10, 4))

        self.stat_profit = StatCard(row1, "PROFIT", "$0.00",
            C["success"], C["success2"], width=190, height=70)
        self.stat_profit.pack(side=tk.LEFT, padx=4)

        self.stat_winrate = StatCard(row1, "WIN RATE", "0%",
            C["warning"], C["warning2"], width=170, height=70)
        self.stat_winrate.pack(side=tk.LEFT, padx=4)

        self.stat_trades = StatCard(row1, "OPERACIONES", "0",
            C["info"], C["info2"], width=170, height=70)
        self.stat_trades.pack(side=tk.LEFT, padx=4)

        self.stat_activo = StatCard(row1, "ACTIVO", "---",
            C["text2"], C["border2"], width=170, height=70)
        self.stat_activo.pack(side=tk.LEFT, padx=4)

        # Stats cards row 2
        row2 = tk.Frame(panel, bg=C["bg"])
        row2.pack(fill=tk.X, padx=15, pady=4)

        self.stat_wins = StatCard(row2, "WINS", "0",
            C["success"], C["success2"], width=170, height=70)
        self.stat_wins.pack(side=tk.LEFT, padx=4)

        self.stat_losses = StatCard(row2, "LOSSES", "0",
            C["danger"], C["danger2"], width=170, height=70)
        self.stat_losses.pack(side=tk.LEFT, padx=4)

        self.stat_nivel = StatCard(row2, "NIVEL", "N1",
            C["accent"], C["accent2"], width=170, height=70)
        self.stat_nivel.pack(side=tk.LEFT, padx=4)

        self.stat_strategy = StatCard(row2, "ESTRATEGIA", "OTC V1",
            C["accent"], C["accent2"], width=170, height=70)
        self.stat_strategy.pack(side=tk.LEFT, padx=4)

        # Botones
        btn_row = tk.Frame(panel, bg=C["bg"])
        btn_row.pack(fill=tk.X, padx=15, pady=8)
        btn_center = tk.Frame(btn_row, bg=C["bg"])
        btn_center.pack(anchor=tk.CENTER)

        self.btn_start = GlowButton(btn_center, "  Iniciar Trading  ",
            self._start_trading, C["success"], "#000000", 170, 44)
        self.btn_start.pack(side=tk.LEFT, padx=4)

        self.btn_pause = GlowButton(btn_center, "  Pausar  ",
            self._pause_trading, C["warning"], "#000000", 130, 44)
        self.btn_pause.pack(side=tk.LEFT, padx=4)
        self.btn_pause.set_enabled(False)

        self.btn_stop = GlowButton(btn_center, "  Detener  ",
            self._stop_trading, C["danger"], "white", 130, 44)
        self.btn_stop.pack(side=tk.LEFT, padx=4)
        self.btn_stop.set_enabled(False)

        # Radar status
        self.radar_canvas = tk.Canvas(panel, width=900, height=32,
                                      bg=C["bg"], highlightthickness=0)
        self.radar_canvas.pack(fill=tk.X, padx=15, pady=4)
        self._draw_radar("Radar: Inactivo", C["text2"])

        # Tabla de operaciones
        ops_header = tk.Frame(panel, bg=C["bg"])
        ops_header.pack(fill=tk.X, padx=15, pady=(8, 0))
        tk.Label(ops_header, text="Operaciones Recientes", bg=C["bg"],
                fg=C["text"], font=(FONT_S, 10, "bold")).pack(anchor=tk.W)

        # Header row
        header_c = tk.Canvas(panel, height=28, bg=C["bg"], highlightthickness=0)
        header_c.pack(fill=tk.X, padx=15)
        self._draw_table_header(header_c)

        # Tabla scrollable
        table_container = tk.Frame(panel, bg=C["bg"])
        table_container.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 10))

        self.trades_canvas = tk.Canvas(table_container, bg=C["bg"],
                                       highlightthickness=0)
        scrollbar = ttk.Scrollbar(table_container, orient=tk.VERTICAL,
                                  command=self.trades_canvas.yview)
        self.trades_scrollable = tk.Frame(self.trades_canvas, bg=C["bg"])

        self.trades_scrollable.bind("<Configure>",
            lambda e: self.trades_canvas.configure(
                scrollregion=self.trades_canvas.bbox("all")))
        self.trades_canvas.create_window((0, 0), window=self.trades_scrollable,
                                         anchor=tk.NW)
        self.trades_canvas.configure(yscrollcommand=scrollbar.set)
        self.trades_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        def _on_tc_configure(event):
            items = self.trades_canvas.find_all()
            if items:
                self.trades_canvas.itemconfig(items[0], width=event.width)
        self.trades_canvas.bind("<Configure>", _on_tc_configure)

        # Scroll support: Windows + Linux
        _bind_scroll(self.trades_canvas, self.trades_canvas)

    def _draw_radar(self, text, color):
        c = self.radar_canvas
        c.delete("all")
        # Obtener ancho real
        c.update_idletasks()
        w = max(c.winfo_width(), 600)
        h = 30
        # Card redondeada
        rounded_rect(c, 2, 2, w-2, h-2, r=8, fill=C["card"], outline=C["border"], width=1)
        # Dot
        c.create_oval(10, 10, 18, 18, fill=color, outline=color)
        # Texto
        c.create_text(26, h//2, text=text, font=(FONT_M, 9),
                     fill=color, anchor=tk.W)

    def _draw_table_header(self, canvas):
        canvas.update_idletasks()
        w = max(canvas.winfo_width(), 600)
        canvas.configure(width=w)
        canvas.delete("all")
        rounded_rect(canvas, 0, 0, w, 26, r=6, fill=C["card"], outline=C["border"])

        headers = [("#", 6), ("Activo", 16), ("Direccion", 12), ("Monto", 10),
                   ("Resultado", 12), ("Profit", 10), ("Nivel", 8), ("Hora", 12)]
        x = 10
        for h_text, h_width in headers:
            canvas.create_text(x, 13, text=h_text, font=(FONT_M, 9, "bold"),
                             fill=C["text3"], anchor=tk.W)
            x += h_width * 8 + 10

    def _add_trade_row(self, trade_info):
        result = trade_info.get("resultado", "")
        if result == "WIN":
            bg = "#0d2818"; fg_r = C["success"]; glow = "#1a6b3e"
        elif result == "LOSS":
            bg = "#2d1114"; fg_r = C["danger"]; glow = "#6b1a2e"
        elif result == "DRAW" or result == "...":
            bg = "#1c1c0e"; fg_r = C["warning"]; glow = "#6b5500"
        else:
            bg = C["bg"]; fg_r = C["text2"]; glow = C["border"]

        row_c = tk.Canvas(self.trades_scrollable, height=26, bg=C["bg"],
                         highlightthickness=0)
        row_c.pack(fill=tk.X, pady=1)

        num = str(trade_info.get("num", ""))
        activo = trade_info.get("activo", "")
        direccion = trade_info.get("direccion", "")
        monto = f"${trade_info.get('monto', 0):.2f}"
        resultado = trade_info.get("resultado", "")
        profit_val = trade_info.get("profit", 0)
        nivel = trade_info.get("nivel", "")
        hora = trade_info.get("hora", "")

        if result == "WIN":
            profit_str = f"+${profit_val:.2f}"
        elif result == "LOSS":
            profit_str = f"-${abs(profit_val):.2f}"
        else:
            profit_str = "..."

        dir_fg = C["success"] if direccion == "CALL" else C["danger"]

        def on_configure(event):
            w = max(event.width, 600)
            row_c.configure(width=w)
            row_c.delete("all")
            # Background
            rounded_rect(row_c, 0, 0, w, 24, r=4, fill=bg,
                         outline=glow if result in ("WIN","LOSS","DRAW") else C["bg"],
                         width=1)

            values = [
                (num, C["text3"], False), (activo, C["text"], False),
                (direccion, dir_fg, True), (monto, C["text"], False),
                (resultado, fg_r, True), (profit_str, fg_r, True),
                (nivel, C["warning"], False), (hora, C["text2"], False),
            ]
            widths = [6, 16, 12, 10, 12, 10, 8, 12]
            x = 10
            for (val, fg, bold), wd in zip(values, widths):
                f = (FONT_M, 9, "bold") if bold else (FONT_M, 9)
                row_c.create_text(x, 12, text=val, font=f, fill=fg, anchor=tk.W)
                x += wd * 8 + 10

        row_c.bind("<Configure>", on_configure)

    def _rebuild_trades_table(self):
        for widget in self.trades_scrollable.winfo_children():
            widget.destroy()
        for trade in self.recent_trades[-self.max_recent_trades:]:
            self._add_trade_row(trade)
        self.trades_canvas.update_idletasks()
        self.trades_canvas.yview_moveto(1.0)

    # ============================================================
    # PANEL: GESTION
    # ============================================================
    def _build_gestion_panel(self):
        panel = tk.Frame(self.content, bg=C["bg"])
        self.panels["gestion"] = panel

        # Scrollable
        canvas = tk.Canvas(panel, bg=C["bg"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(panel, orient=tk.VERTICAL, command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg=C["bg"])

        scroll_frame.bind("<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scroll_frame, anchor=tk.NW)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        def _on_configure(event):
            items = canvas.find_all()
            if items:
                canvas.itemconfig(items[0], width=event.width)
        canvas.bind("<Configure>", _on_configure)

        # Scroll support: Windows + Linux
        _bind_scroll(canvas, canvas)

        # Header
        header_c = tk.Canvas(scroll_frame, width=800, height=45, bg=C["bg"],
                            highlightthickness=0)
        header_c.pack(fill=tk.X, padx=20, pady=(15, 5))
        shadow_text(header_c, 10, 10, "Gestion", (FONT_B, 18), C["accent"],
                    shadow_color="#000000", shadow_offset=2, anchor=tk.NW)
        header_c.create_text(10, 34, text="Configura los parametros de gestion del bot",
                           font=(FONT, 9), fill=C["text2"], anchor=tk.NW)

        # Card: Estrategia
        self._build_glow_card(scroll_frame, "Estrategia", C["accent"])
        strat_frame = tk.Frame(scroll_frame, bg=C["card"])
        strat_frame.pack(fill=tk.X, padx=30, pady=(0, 5))

        # Strategy buttons
        btn_row = tk.Frame(strat_frame, bg=C["card"])
        btn_row.pack(fill=tk.X, padx=15, pady=(8, 4))
        tk.Label(btn_row, text="Seleccionar Estrategia:", bg=C["card"],
                fg=C["text2"], font=(FONT, 9, "bold")).pack(fill=tk.X, pady=(0, 6))

        btns = tk.Frame(btn_row, bg=C["card"])
        btns.pack(fill=tk.X)

        use_otc = self.config.get("use_strategy_otc", True)
        use_v2 = self.config.get("use_strategy_v2", False)

        self.btn_strat_otc = tk.Button(btns, text="OTC V1 (7 Fuentes)",
            bg=C["accent"] if use_otc else C["input"],
            fg="white" if use_otc else C["text2"],
            font=(FONT_S, 10, "bold") if use_otc else (FONT, 10),
            relief=tk.FLAT, padx=15, pady=8, cursor="hand2",
            command=lambda: self._set_strategy("otc"))
        self.btn_strat_otc.pack(side=tk.LEFT, padx=(0, 6))

        self.btn_strat_v2 = tk.Button(btns, text="V2.1 Mejorada",
            bg=C["warning"] if use_v2 else C["input"],
            fg="#000000" if use_v2 else C["text2"],
            font=(FONT_S, 10, "bold") if use_v2 else (FONT, 10),
            relief=tk.FLAT, padx=15, pady=8, cursor="hand2",
            command=lambda: self._set_strategy("v2"))
        self.btn_strat_v2.pack(side=tk.LEFT, padx=(0, 6))

        self.lbl_strat_desc = tk.Label(strat_frame, text=self._get_strategy_desc(),
            bg=C["card"], fg=C["text3"], font=(FONT, 8),
            anchor=tk.W, wraplength=500, justify=tk.LEFT)
        self.lbl_strat_desc.pack(fill=tk.X, padx=15, pady=(0, 8))

        self._field(strat_frame, "Votos Minimos", "min_strategy_votes",
                    self.config.get("min_strategy_votes", 7))
        self._field(strat_frame, "Calidad Minima (%)", "min_signal_quality",
                    self.config.get("min_signal_quality", 88))
        self._field(strat_frame, "Payout Minimo (%)", "payout_min",
                    self.config.get("payout_min", 87))
        self._field(strat_frame, "Max Operaciones (0=sin limite)", "max_trades",
                    self.config.get("max_trades", 0))
        self._field(strat_frame, "Max Instrumentos Scanner", "scanner_max_instruments",
                    self.config.get("scanner_max_instruments", 35))

        # Card: Capital y Niveles
        self._build_glow_card(scroll_frame, "Capital y Niveles", C["info"])
        cap_frame = tk.Frame(scroll_frame, bg=C["card"])
        cap_frame.pack(fill=tk.X, padx=30, pady=(0, 5))

        self._field(cap_frame, "Capital de Operacion ($)", "capital_operacion",
                    self.config.get("capital_operacion", 2.50))
        self._field(cap_frame, "Niveles", "niveles",
                    self.config.get("niveles", 3))
        self._field(cap_frame, "Profit Reinvertido (%)", "sublevel_profit_pct",
                    self.config.get("sublevel_profit_pct", 35),
                    hint="0 = sin reinvertir, solo capital base")
        self._field(cap_frame, "Votos Minimos Subnivel", "sublevel_min_votes",
                    self.config.get("sublevel_min_votes", 3))

        # Card: Stops
        self._build_glow_card(scroll_frame, "Stops", C["danger"])
        stops_frame = tk.Frame(scroll_frame, bg=C["card"])
        stops_frame.pack(fill=tk.X, padx=30, pady=(0, 5))

        self._field(stops_frame, "Stop Win ($)", "stop_win",
                    self.config.get("stop_win", 7.0))
        self._field(stops_frame, "Stop Loss ($)", "stop_loss",
                    self.config.get("stop_loss", 5.0))
        # Nota: Stop loss sin cap - valor manual definido por el usuario

    def _build_glow_card(self, parent, title, accent_color):
        """Dibuja un header de card con glow y lo empaqueta."""
        container = tk.Frame(parent, bg=C["bg"])
        container.pack(fill=tk.X, padx=25, pady=(8, 0))

        card_c = tk.Canvas(container, height=35, bg=C["bg"], highlightthickness=0)
        card_c.pack(fill=tk.X)

        def draw(event=None):
            w = max(card_c.winfo_width(), 600)
            card_c.configure(width=w)
            card_c.delete("all")
            # Glow border
            rounded_rect(card_c, 2, 2, w-2, 33, r=10,
                         fill=C["card"], outline=accent_color, width=2)
            # Gradient fill
            gradient_rect(card_c, 3, 3, w-3, 32, C["card"], C["card2"],
                          steps=6, r=8)
            # Dot
            card_c.create_oval(14, 12, 22, 20, fill=accent_color, outline=accent_color)
            # Title con sombra oscura
            shadow_text(card_c, 30, 8, title, (FONT_S, 11, "bold"), C["text"],
                        shadow_color="#000000", shadow_offset=1, anchor=tk.NW)

        card_c.bind("<Configure>", draw)

    def _get_strategy_desc(self):
        use_otc = self.config.get("use_strategy_otc", True)
        use_v2 = self.config.get("use_strategy_v2", False)
        if use_otc:
            return "OTC V1: 7 fuentes de senal + meta-learning adaptativo. Confluencia minima 4/7 (57%). Optimizada para OTC."
        elif use_v2:
            return "V2.1 Mejorada: ADX>=20, calidad>=55%, contra-tendencia solo si strength>=58%. 31 patrones + 5 indicadores."
        else:
            return "OTC V1: 7 fuentes de senal + meta-learning adaptativo. Optimizada para OTC."

    def _set_strategy(self, version):
        if version == "otc":
            self.config["use_strategy_otc"] = True
            self.config["use_strategy_v2"] = False
        elif version == "v2":
            self.config["use_strategy_otc"] = False
            self.config["use_strategy_v2"] = True
        else:
            self.config["use_strategy_otc"] = True
            self.config["use_strategy_v2"] = False
        save_config(self.config)

        colors = {"otc": C["accent"], "v2": C["warning"]}
        fgs = {"otc": "white", "v2": "#000000"}
        for v, btn in [("otc", self.btn_strat_otc), ("v2", self.btn_strat_v2)]:
            btn.configure(
                bg=colors[v] if v == version else C["input"],
                fg=fgs[v] if v == version else C["text2"],
                font=(FONT_S, 10, "bold") if v == version else (FONT, 10)
            )

        self.lbl_strat_desc.configure(text=self._get_strategy_desc())
        labels = {"otc": "OTC V1", "v2": "V2.1"}
        self.stat_strategy.configure_card(value=labels.get(version, "OTC V1"),
                                          value_color=colors.get(version, C["accent"]))

    def _field(self, parent, label_text, config_key, default, hint=""):
        frame = tk.Frame(parent, bg=C["card"])
        frame.pack(fill=tk.X, padx=15, pady=4)
        tk.Label(frame, text=label_text, bg=C["card"], fg=C["text2"],
                font=(FONT, 9), anchor=tk.W).pack(fill=tk.X)

        is_string = config_key in STRING_FIELDS
        is_password = config_key == "password"

        entry = tk.Entry(frame, bg=C["input"], fg=C["success"],
                        font=(FONT_M, 10), insertbackground=C["success"],
                        relief=tk.FLAT, highlightbackground=C["border"],
                        highlightthickness=1, highlightcolor=C["info"],
                        width=20)
        if is_password:
            entry.configure(show="*")
        entry.insert(0, str(default))
        entry.pack(fill=tk.X, pady=(2, 0))
        if hint:
            tk.Label(frame, text=hint, bg=C["card"], fg=C["text3"],
                    font=(FONT, 8), anchor=tk.W).pack(fill=tk.X)

        def on_change(event=None):
            try:
                val = entry.get().strip()
                if not val:
                    return
                if is_string:
                    self.config[config_key] = val
                elif "." in val:
                    self.config[config_key] = float(val)
                else:
                    self.config[config_key] = int(val)
                save_config(self.config)
            except ValueError:
                pass

        entry.bind("<FocusOut>", on_change)
        entry.bind("<Return>", on_change)
        return entry

    # ============================================================
    # PANEL: CUENTA (sidebar - Demo/Real)
    # ============================================================
    def _build_cuenta_panel(self):
        panel = tk.Frame(self.content, bg=C["bg"])
        self.panels["cuenta"] = panel

        # Scrollable
        canvas = tk.Canvas(panel, bg=C["bg"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(panel, orient=tk.VERTICAL, command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg=C["bg"])

        scroll_frame.bind("<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scroll_frame, anchor=tk.NW)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        def _on_configure(event):
            items = canvas.find_all()
            if items:
                canvas.itemconfig(items[0], width=event.width)
        canvas.bind("<Configure>", _on_configure)
        _bind_scroll(canvas, canvas)

        # Header
        header_c = tk.Canvas(scroll_frame, width=800, height=45, bg=C["bg"],
                            highlightthickness=0)
        header_c.pack(fill=tk.X, padx=20, pady=(15, 5))
        shadow_text(header_c, 10, 10, "Cuenta", (FONT_B, 18), C["orange"],
                    shadow_color="#000000", shadow_offset=2, anchor=tk.NW)
        header_c.create_text(10, 34, text="Configura tu cuenta IQ Option y tipo de balance",
                           font=(FONT, 9), fill=C["text2"], anchor=tk.NW)

        # Card: Cuenta IQ Option
        self._build_glow_card(scroll_frame, "Cuenta IQ Option", C["info"])
        card_f = tk.Frame(scroll_frame, bg=C["card"])
        card_f.pack(fill=tk.X, padx=30, pady=(0, 5))
        self._field(card_f, "Email", "email", self.config.get("email", ""))
        self._field(card_f, "Contrasena", "password", self.config.get("password", ""))

        # Account mode - Demo/Real cards
        self._build_glow_card(scroll_frame, "Tipo de Cuenta", C["orange"])
        mode_frame = tk.Frame(scroll_frame, bg=C["card"])
        mode_frame.pack(fill=tk.X, padx=30, pady=(0, 5))

        acc_f = tk.Frame(mode_frame, bg=C["card"])
        acc_f.pack(fill=tk.X, padx=15, pady=(12, 4))
        tk.Label(acc_f, text="Selecciona el tipo de cuenta:", bg=C["card"],
                fg=C["text2"], font=(FONT, 9, "bold")).pack(fill=tk.X, pady=(0, 6))

        btn_f = tk.Frame(acc_f, bg=C["card"])
        btn_f.pack(fill=tk.X, pady=(0, 8))
        current_mode = self.config.get("account_mode", "PRACTICE")

        # Demo card
        demo_card = tk.Frame(btn_f, bg=C["card"])
        demo_card.pack(side=tk.LEFT, padx=(0, 12), expand=True, fill=tk.X)

        self.btn_demo = tk.Button(demo_card, text="DEMO",
            bg=C["info"] if current_mode == "PRACTICE" else C["input"],
            fg="white" if current_mode == "PRACTICE" else C["text2"],
            font=(FONT_S, 12, "bold"), relief=tk.FLAT, padx=30, pady=10,
            cursor="hand2", command=lambda: self._set_account_mode("PRACTICE"))
        self.btn_demo.pack(fill=tk.X)
        tk.Label(demo_card, text="Dinero virtual para practicar",
                bg=C["card"], fg=C["text3"], font=(FONT, 8)).pack(pady=(2, 0))

        # Real card
        real_card = tk.Frame(btn_f, bg=C["card"])
        real_card.pack(side=tk.LEFT, padx=(0, 0), expand=True, fill=tk.X)

        self.btn_real = tk.Button(real_card, text="REAL",
            bg=C["danger"] if current_mode == "REAL" else C["input"],
            fg="white" if current_mode == "REAL" else C["text2"],
            font=(FONT_S, 12, "bold"), relief=tk.FLAT, padx=30, pady=10,
            cursor="hand2", command=lambda: self._set_account_mode("REAL"))
        self.btn_real.pack(fill=tk.X)
        tk.Label(real_card, text="Dinero real - operar con cuidado",
                bg=C["card"], fg=C["text3"], font=(FONT, 8)).pack(pady=(2, 0))

        # Info note
        info_f = tk.Frame(mode_frame, bg=C["input"])
        info_f.pack(fill=tk.X, padx=15, pady=(0, 10))
        tk.Label(info_f, text=(
            "Puedes cambiar entre Demo y Real en cualquier momento,\n"
            "incluso con el bot en ejecucion."
        ), bg=C["input"], fg=C["info"], font=(FONT_M, 8),
        justify=tk.LEFT, padx=10, pady=8).pack(fill=tk.X)

    # ============================================================
    # PANEL: CONFIGURACION
    # ============================================================
    def _build_config_panel(self):
        panel = tk.Frame(self.content, bg=C["bg"])
        self.panels["config"] = panel

        # Header
        header_c = tk.Canvas(panel, width=800, height=45, bg=C["bg"],
                            highlightthickness=0)
        header_c.pack(fill=tk.X, padx=25, pady=(15, 5))
        shadow_text(header_c, 10, 10, "Configuracion", (FONT_B, 18), C["accent"],
                    shadow_color="#000000", shadow_offset=2, anchor=tk.NW)
        header_c.create_text(10, 34, text="Ajusta la configuracion del bot",
                           font=(FONT, 9), fill=C["text2"], anchor=tk.NW)

        # Tab buttons (sin Cuenta - ahora esta en el sidebar)
        tab_frame = tk.Frame(panel, bg=C["bg"])
        tab_frame.pack(fill=tk.X, padx=25, pady=(0, 8))

        self.config_tabs = {}
        tab_configs = [
            ("delays", "Delays", C["warning"]),
            ("telegram", "Telegram", C["success"]),
        ]
        for key, label, color in tab_configs:
            btn = tk.Button(tab_frame, text=label,
                bg=C["card"],
                fg=C["text"],
                font=(FONT, 10),
                relief=tk.FLAT, padx=15, pady=5, cursor="hand2",
                command=lambda k=key: self._show_config_tab(k))
            btn.pack(side=tk.LEFT, padx=(0, 5))
            self.config_tabs[key] = (btn, color)

        # Tab container
        self.config_tab_container = tk.Frame(panel, bg=C["bg"])
        self.config_tab_container.pack(fill=tk.BOTH, expand=True, padx=25)

        self.config_tab_panels = {}

        # Tab: Delays
        delays_panel = tk.Frame(self.config_tab_container, bg=C["bg"])
        self.config_tab_panels["delays"] = delays_panel

        delays_canvas = tk.Canvas(delays_panel, bg=C["bg"], highlightthickness=0)
        delays_scroll = ttk.Scrollbar(delays_panel, orient=tk.VERTICAL,
                                      command=delays_canvas.yview)
        delays_inner = tk.Frame(delays_canvas, bg=C["bg"])
        delays_inner.bind("<Configure>",
            lambda e: delays_canvas.configure(scrollregion=delays_canvas.bbox("all")))
        delays_canvas.create_window((0, 0), window=delays_inner, anchor=tk.NW)
        delays_canvas.configure(yscrollcommand=delays_scroll.set)
        delays_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        delays_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        def _delays_configure(event):
            items = delays_canvas.find_all()
            if items:
                delays_canvas.itemconfig(items[0], width=event.width)
        delays_canvas.bind("<Configure>", _delays_configure)
        _bind_scroll(delays_canvas, delays_canvas)

        self._build_glow_card(delays_inner, "Delays y Anti-Deteccion", C["warning"])
        card2_f = tk.Frame(delays_inner, bg=C["card"])
        card2_f.pack(fill=tk.X, padx=30, pady=(0, 5))
        self._field(card2_f, "Delay entre ops - Min (s)", "delay_between_ops_min",
                    self.config.get("delay_between_ops_min", 20))
        self._field(card2_f, "Delay entre ops - Max (s)", "delay_between_ops_max",
                    self.config.get("delay_between_ops_max", 60))
        self._field(card2_f, "Delay thinking - Min (s)", "delay_thinking_min",
                    self.config.get("delay_thinking_min", 2))
        self._field(card2_f, "Delay thinking - Max (s)", "delay_thinking_max",
                    self.config.get("delay_thinking_max", 5))
        self._field(card2_f, "Delay scanner - Min (s)", "delay_scanner_min",
                    self.config.get("delay_scanner_min", 0.5))
        self._field(card2_f, "Delay scanner - Max (s)", "delay_scanner_max",
                    self.config.get("delay_scanner_max", 1.0))
        self._field(card2_f, "Accion humana (%)", "human_action_pct",
                    self.config.get("human_action_pct", 15))

        # Tab: Telegram
        telegram_panel = tk.Frame(self.config_tab_container, bg=C["bg"])
        self.config_tab_panels["telegram"] = telegram_panel

        telegram_canvas = tk.Canvas(telegram_panel, bg=C["bg"], highlightthickness=0)
        telegram_scroll = ttk.Scrollbar(telegram_panel, orient=tk.VERTICAL,
                                        command=telegram_canvas.yview)
        telegram_inner = tk.Frame(telegram_canvas, bg=C["bg"])
        telegram_inner.bind("<Configure>",
            lambda e: telegram_canvas.configure(scrollregion=telegram_canvas.bbox("all")))
        telegram_canvas.create_window((0, 0), window=telegram_inner, anchor=tk.NW)
        telegram_canvas.configure(yscrollcommand=telegram_scroll.set)
        telegram_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        telegram_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        def _telegram_configure(event):
            items = telegram_canvas.find_all()
            if items:
                telegram_canvas.itemconfig(items[0], width=event.width)
        telegram_canvas.bind("<Configure>", _telegram_configure)
        _bind_scroll(telegram_canvas, telegram_canvas)

        self._build_glow_card(telegram_inner, "Telegram Notificaciones", C["success"])
        card3_f = tk.Frame(telegram_inner, bg=C["card"])
        card3_f.pack(fill=tk.X, padx=30, pady=(0, 5))

        toggle_f = tk.Frame(card3_f, bg=C["card"])
        toggle_f.pack(fill=tk.X, padx=15, pady=10)
        self.telegram_enabled_var = tk.BooleanVar(
            value=self.config.get("telegram_enabled", False))
        tk.Checkbutton(toggle_f, text="Activar notificaciones Telegram",
            variable=self.telegram_enabled_var,
            bg=C["card"], fg=C["text"], selectcolor=C["input"],
            activebackground=C["card"], activeforeground=C["text"],
            font=(FONT, 10, "bold"),
            command=self._toggle_telegram).pack(side=tk.LEFT)

        self._field(card3_f, "Bot Token", "telegram_token",
                    self.config.get("telegram_token", ""))
        self._field(card3_f, "Chat ID", "telegram_chat_id",
                    self.config.get("telegram_chat_id", ""))

        test_f = tk.Frame(card3_f, bg=C["card"])
        test_f.pack(fill=tk.X, padx=15, pady=10)
        tk.Button(test_f, text="Probar Conexion",
            bg=C["info"], fg="white", font=(FONT_S, 10, "bold"),
            relief=tk.FLAT, padx=15, pady=5, cursor="hand2",
            command=self._test_telegram).pack(side=tk.LEFT)

        info_f = tk.Frame(card3_f, bg=C["input"])
        info_f.pack(fill=tk.X, padx=15, pady=(0, 10))
        tk.Label(info_f, text=(
            "Como configurar Telegram:\n"
            "1. Habla con @BotFather en Telegram\n"
            "2. Envia /newbot y sigue las instrucciones\n"
            "3. Copia el Token y pegalo arriba\n"
            "4. Enviale un mensaje a tu bot\n"
            "5. Obten tu Chat ID desde:\n"
            "   api.telegram.org/bot<TOKEN>/getUpdates"
        ), bg=C["input"], fg=C["info"], font=(FONT_M, 8),
        justify=tk.LEFT, padx=10, pady=8).pack(fill=tk.X)

        self._show_config_tab("delays")

    def _show_config_tab(self, tab_name):
        for key, p in self.config_tab_panels.items():
            p.pack_forget()
        if tab_name in self.config_tab_panels:
            self.config_tab_panels[tab_name].pack(fill=tk.BOTH, expand=True,
                                                   in_=self.config_tab_container)
        for key, (btn, color) in self.config_tabs.items():
            if key == tab_name:
                btn.configure(bg=color, fg="white", font=(FONT_S, 10, "bold"))
            else:
                btn.configure(bg=C["card"], fg=C["text"], font=(FONT, 10))

    # ============================================================
    # ACCOUNT MODE / TELEGRAM
    # ============================================================
    def _set_account_mode(self, mode):
        if mode == "REAL":
            if not messagebox.askyesno("Confirmacion",
                    "Cambiar a cuenta REAL?\n\nSe operara con dinero real."):
                return
        self.config["account_mode"] = mode
        save_config(self.config)

        is_demo = mode == "PRACTICE"
        balance_color = C["orange"] if is_demo else C["success"]

        if mode == "PRACTICE":
            self.btn_demo.configure(bg=C["info"], fg="white")
            self.btn_real.configure(bg=C["input"], fg=C["text2"])
            self.lbl_mode.config(text="DEMO", fg=C["success"])
        else:
            self.btn_demo.configure(bg=C["input"], fg=C["text2"])
            self.btn_real.configure(bg=C["danger"], fg="white")
            self.lbl_mode.config(text="REAL", fg=C["danger"])

        self._draw_balance(
            self.bal_canvas._last_text,
            balance_color)
        self.lbl_mode_top.configure(text="DEMO" if is_demo else "REAL",
                                    fg=balance_color)

        if self.engine and self.connected:
            self.engine.switch_account(mode)

    def _toggle_telegram(self):
        self.config["telegram_enabled"] = self.telegram_enabled_var.get()
        save_config(self.config)
        if self.engine and hasattr(self.engine, 'telegram'):
            self.engine.telegram.configure(enabled=self.config["telegram_enabled"])

    def _test_telegram(self):
        try:
            from telegram_notifier import TelegramNotifier
            token = self.config.get("telegram_token", "")
            chat_id = self.config.get("telegram_chat_id", "")
            if not token or not chat_id:
                messagebox.showwarning("Atencion",
                    "Configura el Token y Chat ID de Telegram primero.")
                return
            notifier = TelegramNotifier(token, chat_id, enabled=True)
            notifier.send("Prueba de conexion - Sistema Ouhries V6.2")
            messagebox.showinfo("Exito", "Mensaje de prueba enviado correctamente.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo enviar el mensaje:\n{e}")

    # ============================================================
    # TRADING CONTROL
    # ============================================================
    def _start_trading(self):
        if self.trading_active and not self.paused:
            return

        # Limpiar historial si no hay sesion previa para recuperar
        if not self.connected and not os.path.exists("session_state.json"):
            self.recent_trades = []
            self._seen_trade_ids.clear()
            for widget in self.trades_scrollable.winfo_children():
                widget.destroy()

        if not self.connected:
            try:
                TradingEngine = _get_engine_class()
            except ImportError as e:
                messagebox.showerror("Error de Importacion",
                    f"No se pudo cargar el motor de trading:\n{e}\n\n"
                    "Verifica que iqoptionapi este instalado:\n"
                    "pip install iqoptionapi==6.8.9.1")
                self.btn_start.set_text("  Iniciar Trading  ")
                self.btn_start.set_enabled(True)
                return

            self.btn_start.set_text("Conectando...")
            self.btn_start.set_enabled(False)
            self.lbl_connection.config(text="Conectando...", fg=C["warning"])
            self.conn_canvas.delete("all")
            self.conn_canvas.create_oval(2, 2, 8, 8, fill=C["warning"],
                                         outline=C["warning"])

            def do_connect():
                try:
                    self.engine = TradingEngine(
                        self.config,
                        log_callback=lambda msg: self.root.after(0, self._on_status_update, msg),
                        status_callback=lambda msg: self.root.after(0, self._on_status_update, msg),
                        radar_callback=lambda asset, idx, total: self.root.after(0, self._on_radar_update, asset, idx, total),
                        trade_callback=lambda info: self.root.after(0, self._on_trade_update, info),
                    )
                    self.engine._session_end_callback = lambda summary: self.root.after(0, self._session_end_callback, summary)
                    result = self.engine.connect()
                    if result:
                        self.connected = True
                        self.root.after(0, self._on_connected_then_trade)
                    else:
                        self.root.after(0, self._on_connection_failed)
                except Exception as e:
                    self.root.after(0, lambda: self._on_status_update(f"Error: {e}"))
                    self.root.after(0, self._on_connection_failed)

            threading.Thread(target=do_connect, daemon=True).start()
            return

        # Resume from pause
        if self.paused:
            self.paused = False
            if self.engine:
                self.engine.paused = False

        self.trading_active = True
        self.btn_start.set_enabled(False)
        self.btn_pause.set_enabled(True)
        self.btn_stop.set_enabled(True)

        # Start trading thread if engine exists and not already running
        if self.engine and not self.engine.running:
            def run_engine():
                try:
                    self.engine.run()
                except Exception as e:
                    self.root.after(0, lambda: self._on_status_update(f"Engine error: {e}"))
            self.trade_thread = threading.Thread(target=run_engine, daemon=True)
            self.trade_thread.start()

        self._on_status_update("Trading iniciado")

    def _on_connected_then_trade(self):
        self.lbl_connection.config(text="Conectado", fg=C["success"])
        self.conn_canvas.delete("all")
        self.conn_canvas.create_oval(2, 2, 8, 8, fill=C["success"],
                                     outline=C["success"])

        mode = self.config.get("account_mode", "PRACTICE")
        mode_text = "DEMO" if mode == "PRACTICE" else "REAL"
        is_demo = mode == "PRACTICE"
        bal_color = C["orange"] if is_demo else C["success"]

        self.lbl_mode.config(text=mode_text, fg=C["success"] if is_demo else C["danger"])
        self.mode_canvas.delete("all")
        self.mode_canvas.create_oval(2, 2, 8, 8,
                                     fill=C["success"] if is_demo else C["danger"],
                                     outline=C["success"] if is_demo else C["danger"])
        self.lbl_mode_top.configure(text=mode_text, fg=bal_color)
        self.btn_start.set_text("  Iniciar Trading  ")
        self.btn_start.set_enabled(True)

        # Get initial balance
        if self.engine:
            try:
                bal = self.engine.balance
                self._draw_balance(f"${bal:.2f}", bal_color)
            except Exception:
                pass

        self._start_trading()

    def _on_connection_failed(self):
        self.lbl_connection.config(text="Error de conexion", fg=C["danger"])
        self.conn_canvas.delete("all")
        self.conn_canvas.create_oval(2, 2, 8, 8, fill=C["danger"],
                                     outline=C["danger"])
        self.btn_start.set_text("  Iniciar Trading  ")
        self.btn_start.set_enabled(True)

    def _pause_trading(self):
        if self.engine and self.engine.running:
            self.paused = True
            self.engine.paused = True
            self.btn_start.set_enabled(True)
            self.btn_pause.set_enabled(False)
            self._on_status_update("Trading pausado")

    def _stop_trading(self):
        if self.engine:
            self.engine.stop()
        self.trading_active = False
        self.paused = False
        self.btn_start.set_enabled(True)
        self.btn_pause.set_enabled(False)
        self.btn_stop.set_enabled(False)
        self._draw_radar("Radar: Inactivo", C["text2"])
        self._on_status_update("Trading detenido")

    def _on_trade_update(self, trade_info):
        trade_id = trade_info.get("id", "")
        if trade_info.get("status") == "open":
            # Deduplicacion por ID
            if trade_id and trade_id in self._seen_trade_ids:
                return
            if trade_id:
                self._seen_trade_ids.add(trade_id)
            self.recent_trades.append(trade_info)
            self._add_trade_row(trade_info)
            self.trades_canvas.update_idletasks()
            self.trades_canvas.yview_moveto(1.0)

        elif trade_info.get("status") == "closed":
            # Update trade by ID (deduplication)
            for i in range(len(self.recent_trades) - 1, -1, -1):
                if trade_id and self.recent_trades[i].get("id") == trade_id:
                    self.recent_trades[i].update(trade_info)
                    break
                elif (not trade_id and
                    self.recent_trades[i].get("activo") == trade_info.get("activo") and
                    self.recent_trades[i].get("status") == "open"):
                    self.recent_trades[i].update(trade_info)
                    break
            self._rebuild_trades_table()
            self._flash_balance(trade_info.get("resultado") == "WIN")

    def _update_stats_loop(self):
        try:
            if self.engine and self.connected:
                stats = self.engine.get_stats()
                if stats:
                    balance = stats.get("balance", 0)
                    profit = stats.get("profit", 0)
                    wr = stats.get("win_rate", 0)
                    total = stats.get("total_trades", 0)
                    wins = stats.get("total_wins", 0)
                    losses = stats.get("total_losses", 0)
                    nivel = stats.get("sublevel_text", "N1")
                    activo = stats.get("current_instrument", "---")

                    # Update balance
                    is_demo = self.config.get("account_mode", "PRACTICE") == "PRACTICE"
                    bal_color = C["orange"] if is_demo else C["success"]
                    self._draw_balance(f"${balance:.2f}", bal_color)

                    # Update stat cards
                    self.stat_profit.configure_card(
                        value=f"${profit:.2f}",
                        value_color=C["success"] if profit >= 0 else C["danger"],
                        glow_color=C["success2"] if profit >= 0 else C["danger2"])
                    self.stat_winrate.configure_card(value=f"{wr:.0f}%")
                    self.stat_trades.configure_card(value=str(total))
                    self.stat_activo.configure_card(value=activo or "---")
                    self.stat_wins.configure_card(value=str(wins))
                    self.stat_losses.configure_card(value=str(losses))
                    self.stat_nivel.configure_card(value=nivel)

                    # Strategy label - solo OTC V1 y V2.1
                    use_otc = self.config.get("use_strategy_otc", True)
                    use_v2 = self.config.get("use_strategy_v2", False)
                    if use_otc:
                        strat_label = "OTC V1"
                        strat_color = C["accent"]
                    elif use_v2:
                        strat_label = "V2.1"
                        strat_color = C["warning"]
                    else:
                        strat_label = "OTC V1"
                        strat_color = C["accent"]
                    self.stat_strategy.configure_card(value=strat_label, value_color=strat_color)

                    # Update connection status if engine stopped
                    if not stats.get("running", False) and self.trading_active:
                        self.trading_active = False
                        self.btn_start.set_enabled(True)
                        self.btn_pause.set_enabled(False)
                        self.btn_stop.set_enabled(False)
        except Exception:
            pass

        self.root.after(2000, self._update_stats_loop)

    def _on_radar_update(self, asset, idx, total):
        if idx > 0 and total > 0:
            self._draw_radar(f"Radar Analizando {asset} ({idx}/{total})", C["info"])
        else:
            self._draw_radar("Radar: Buscando senal...", C["warning"])

    def _on_status_update(self, msg):
        pass

    def _session_end_callback(self, summary):
        reason = summary.get("reason_label", summary.get("reason", "Completado"))
        total_ops = summary.get("total_trades", 0)
        wins = summary.get("total_wins", 0)
        losses = summary.get("total_losses", 0)
        profit = summary.get("profit", 0.0)
        wr = summary.get("win_rate", 0.0)

        msg = (f"Sesion finalizada: {reason}\n\n"
               f"Operaciones: {total_ops}\n"
               f"Wins: {wins} | Losses: {losses}\n"
               f"Win Rate: {wr:.1f}%\n"
               f"Profit: ${profit:.2f}")

        self.trading_active = False
        self.connected = False
        self.btn_start.set_enabled(True)
        self.btn_pause.set_enabled(False)
        self.btn_stop.set_enabled(False)

        # Update connection status
        self.lbl_connection.config(text="Desconectado", fg=C["danger"])
        self.conn_canvas.delete("all")
        self.conn_canvas.create_oval(2, 2, 8, 8, fill=C["danger"], outline=C["danger"])

        messagebox.showinfo("Sesion Finalizada", msg)


# ============================================================
# MAIN
# ============================================================
if __name__ == "__main__":
    root = tk.Tk()
    try:
        root.iconbitmap(default="")
    except Exception:
        pass
    app = OuhriesApp(root)
    root.mainloop()
