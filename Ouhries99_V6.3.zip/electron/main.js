/**
 * Sistema Ouhries V6 - Electron Main Process
 * Aplicacion de escritorio que lanza el backend Python (FastAPI)
 * y muestra la interfaz profesional en una BrowserWindow.
 */

const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');

// ============================================================
// CONFIG
// ============================================================
const SERVER_PORT = 8585;
const SERVER_HOST = '127.0.0.1';
const SERVER_URL = `http://${SERVER_HOST}:${SERVER_PORT}`;
const MAX_WAIT_MS = 60000; // 60s max wait for Python server (V6: increased for slower connections)
const CHECK_INTERVAL_MS = 500;

let mainWindow = null;
let splashWindow = null;
let pythonProcess = null;
let isQuitting = false;

// ============================================================
// PATHS
// ============================================================
const isDev = !app.isPackaged;
const appDir = path.dirname(app.getPath('exe'));
const resourceDir = isDev ? path.join(__dirname, '..') : process.resourcesPath;
const pythonDir = path.join(resourceDir, 'python');
const backendDir = isDev ? path.join(__dirname, '..') : resourceDir;

// Find Python executable
function findPython() {
  // 1. Bundled Python (portable)
  const bundledPython = path.join(pythonDir, 'python.exe');
  if (fs.existsSync(bundledPython)) {
    return bundledPython;
  }

  // 2. System Python
  return 'python';
}

// ============================================================
// SPLASH SCREEN
// ============================================================
function createSplash() {
  splashWindow = new BrowserWindow({
    width: 480,
    height: 320,
    frame: false,
    transparent: true,
    resizable: false,
    center: true,
    alwaysOnTop: true,
    skipTaskbar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  splashWindow.loadFile(path.join(__dirname, 'splash.html'));
  splashWindow.on('closed', () => { splashWindow = null; });
}

// ============================================================
// MAIN WINDOW
// ============================================================
function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 950,
    minHeight: 600,
    title: 'Sistema Ouhries V6',
    icon: path.join(__dirname, 'icon.ico'),
    show: false,
    frame: true,
    backgroundColor: '#0a0e17',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      webSecurity: false // Allow loading from localhost
    }
  });

  // Remove menu bar
  mainWindow.setMenuBarVisibility(false);

  // Clear cache before loading to ensure fresh content
  mainWindow.webContents.session.clearCache().catch(() => {});
  mainWindow.webContents.session.clearStorageData({
    storages: ['cache', 'serviceworkers']
  }).catch(() => {});

  mainWindow.loadURL(SERVER_URL + '?t=' + Date.now());

  mainWindow.once('ready-to-show', () => {
    if (splashWindow) {
      splashWindow.close();
      splashWindow = null;
    }
    mainWindow.show();
    mainWindow.focus();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Prevent title from changing
  mainWindow.on('page-title-updated', (event) => {
    event.preventDefault();
    mainWindow.setTitle('Sistema Ouhries V6');
  });
}

// ============================================================
// PYTHON SERVER
// ============================================================
function startPythonServer() {
  return new Promise((resolve, reject) => {
    const pythonExe = findPython();
    const serverScript = path.join(backendDir, 'server.py');

    console.log(`[Ouhries] Starting Python server: ${pythonExe} ${serverScript}`);
    console.log(`[Ouhries] Backend dir: ${backendDir}`);

    // Set environment for Python
    const env = Object.assign({}, process.env, {
      PYTHONUNBUFFERED: '1',
      PYTHONIOENCODING: 'utf-8',
      OUHRIES_PORT: String(SERVER_PORT),
    });

    pythonProcess = spawn(pythonExe, [serverScript], {
      cwd: backendDir,
      env: env,
      stdio: ['pipe', 'pipe', 'pipe']
    });

    pythonProcess.stdout.on('data', (data) => {
      const msg = data.toString().trim();
      console.log(`[Python] ${msg}`);
    });

    pythonProcess.stderr.on('data', (data) => {
      const msg = data.toString().trim();
      console.error(`[Python ERR] ${msg}`);
    });

    pythonProcess.on('error', (err) => {
      console.error(`[Ouhries] Failed to start Python: ${err.message}`);
      reject(err);
    });

    pythonProcess.on('close', (code) => {
      console.log(`[Python] Process exited with code ${code}`);
      pythonProcess = null;
      if (!isQuitting) {
        // Unexpected exit
        if (mainWindow) {
          mainWindow.webContents.send('python-crash', { code });
        }
      }
    });

    // Wait for server to be ready
    waitForServer().then(resolve).catch(reject);
  });
}

function waitForServer() {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();

    const check = () => {
      if (Date.now() - startTime > MAX_WAIT_MS) {
        reject(new Error('Timeout esperando al servidor Python'));
        return;
      }

      const req = http.get(`${SERVER_URL}/api/stats`, (res) => {
        if (res.statusCode === 200) {
          resolve();
        } else {
          setTimeout(check, CHECK_INTERVAL_MS);
        }
      });

      req.on('error', () => {
        setTimeout(check, CHECK_INTERVAL_MS);
      });

      req.setTimeout(2000, () => {
        req.destroy();
        setTimeout(check, CHECK_INTERVAL_MS);
      });
    };

    // Start checking after a short delay to let Python initialize
    setTimeout(check, 1500);
  });
}

function stopPythonServer() {
  if (pythonProcess) {
    console.log('[Ouhries] Stopping Python server...');
    isQuitting = true;

    // Try graceful shutdown first
    try {
      http.post(`${SERVER_URL}/api/disconnect`);
    } catch (e) { }

    // Kill the process
    setTimeout(() => {
      if (pythonProcess) {
        pythonProcess.kill('SIGTERM');
        setTimeout(() => {
          if (pythonProcess) {
            pythonProcess.kill('SIGKILL');
          }
        }, 3000);
      }
    }, 1000);
  }
}

// ============================================================
// IPC HANDLERS
// ============================================================
ipcMain.handle('get-server-url', () => SERVER_URL);
ipcMain.handle('get-app-version', () => app.getVersion());
ipcMain.handle('restart-server', async () => {
  stopPythonServer();
  await new Promise(r => setTimeout(r, 2000));
  await startPythonServer();
  return { ok: true };
});

// ============================================================
// APP LIFECYCLE
// ============================================================
app.whenReady().then(async () => {
  createSplash();

  try {
    await startPythonServer();
    createMainWindow();
  } catch (err) {
    console.error('[Ouhries] Failed to start:', err);

    // Show error in splash or dialog
    if (splashWindow) {
      splashWindow.webContents.send('startup-error', {
        message: `Error iniciando el servidor Python:\n${err.message}\n\nAsegurate de tener Python instalado y las dependencias (pip install -r requirements.txt)`
      });
    }

    // Also create main window with error page
    setTimeout(() => {
      if (!mainWindow) {
        createMainWindow();
        mainWindow.once('ready-to-show', () => {
          if (splashWindow) {
            splashWindow.close();
            splashWindow = null;
          }
          mainWindow.show();
        });
      }
    }, 5000);
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on('window-all-closed', () => {
  stopPythonServer();
  app.quit();
});

app.on('before-quit', () => {
  stopPythonServer();
});

// Prevent multiple instances
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}
