@echo off
title Sistema Ouhries V6 - Inicio Limpio
color 0B

:: ============================================================
:: LIMPIEZA RAPIDA + INICIO DEL BOT EN ENTORNO LIMPIO
:: ============================================================

echo [1/4] Deteniendo procesos residuales...
taskkill /F /IM python.exe 2>NUL
timeout /t 1 /nobreak >NUL

echo [2/4] Limpiando cache Python...
for /d /r "%~dp0" %%d in (__pycache__) do (
    rd /s /q "%%d" 2>NUL
)
del /s /q "%~dp0*.pyc" 2>NUL
del /s /q "%~dp0*.pyo" 2>NUL

echo [3/4] Eliminando estado de sesion anterior...
del /f /q "%~dp0session_state.json" 2>NUL

:: Limpiar cache Electron
for %%N in ("Sistema Ouhries" "ouhries" "Ouhries" "OuhriesV5" "OuhriesV6" "Sistema Ouhries V5" "Sistema Ouhries V6") do (
    rd /s /q "%APPDATA%\%%~N\Cache" 2>NUL
    rd /s /q "%APPDATA%\%%~N\Code Cache" 2>NUL
    rd /s /q "%APPDATA%\%%~N\GPUCache" 2>NUL
    rd /s /q "%APPDATA%\%%~N\Service Worker" 2>NUL
    rd /s /q "%APPDATA%\%%~N\Local Storage" 2>NUL
    rd /s /q "%APPDATA%\%%~N\Session Storage" 2>NUL
    rd /s /q "%LOCALAPPDATA%\%%~N\Cache" 2>NUL
    rd /s /q "%LOCALAPPDATA%\%%~N\Code Cache" 2>NUL
    rd /s /q "%LOCALAPPDATA%\%%~N\GPUCache" 2>NUL
)

echo [4/4] Iniciando bot en entorno limpio...
echo.
echo ============================================================
echo   Sistema Ouhries V6 - Entorno Limpio
echo   Estrategias: OTC V1 + V2.1 Mejorada
echo   http://localhost:8585
echo ============================================================
echo.

:: Verificar Python
where python >NUL 2>NUL
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Python no encontrado. Instala Python 3.8+
    pause
    exit /b 1
)

:: Instalar dependencias si hace falta
if not exist "%~dp0venv\Scripts\python.exe" (
    echo Instalando dependencias...
    pip install -r "%~dp0requirements.txt" -q 2>NUL
)

:: Iniciar servidor
cd /d "%~dp0"
python server.py

pause
