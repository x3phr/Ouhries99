@echo off
title Sistema Ouhries V6
color 0A

echo ================================================
echo   SISTEMA OUHRIES V6.0 - APLICACION DE ESCRITORIO
echo   Anti-Detection PRO v3 + Session Control
echo ================================================
echo.

:: Check Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js no esta instalado.
    echo Descargalo de: https://nodejs.org/
    echo.
    pause
    exit /b 1
)

:: Check Python
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python no esta instalado.
    echo Descargalo de: https://www.python.org/downloads/
    echo Asegurate de marcar "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

:: Change to the directory where this script is located
cd /d "%~dp0"

:: Check if node_modules exists (Electron installed)
if not exist "electron\node_modules\electron\dist\electron.exe" (
    echo [INFO] Instalando dependencias de Electron...
    echo Esto solo se hace la primera vez.
    echo.
    cd electron
    call npm install
    cd ..
    echo.
    echo [OK] Dependencias instaladas.
    echo.
)

:: Check Python dependencies
echo [INFO] Verificando dependencias de Python...
pip show fastapi >nul 2>nul
if %errorlevel% neq 0 (
    echo [INFO] Instalando dependencias de Python...
    pip install -r requirements.txt
    echo.
)

:: Limpiar cache de Electron para cargar version nueva
echo [INFO] Limpiando cache de Electron...
set ELECTRON_DISABLE_CACHE=1
if exist "%APPDATA%\ouhries-v6" (
    rd /s /q "%APPDATA%\ouhries-v6\Cache" 2>nul
    rd /s /q "%APPDATA%\ouhries-v6\Code Cache" 2>nul
    rd /s /q "%APPDATA%\ouhries-v6\GPUCache" 2>nul
)
if exist "%LOCALAPPDATA%\Temp\ouhries-v6" (
    rd /s /q "%LOCALAPPDATA%\Temp\ouhries-v6" 2>nul
)
echo [OK] Cache limpiado.
echo.

:: Start the Electron app
echo [OK] Iniciando Sistema Ouhries V6.0...
echo.
cd electron
call npx electron .
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] La aplicacion se cerro con errores.
    pause
)
