"""
Sistema Ouhries V5 - IQ Option API Patched Wrapper
Parchea la libreria iqoptionapi v6.8.9.1 para funcionar al 100%:
- Timeouts en TODAS las operaciones bloqueantes
- Auto-reconexion con backoff exponencial
- ACTIVES cache auto-actualizado
- check_win_v3 con timeout y fallback a balance
- get_candles con timeout y reintentos
- buy con reintento automatico
- get_balance con retry
- get_all_profit cacheado con TTL
"""

import time
import logging
import threading
import traceback
from datetime import datetime

from iqoptionapi.stable_api import IQ_Option
import iqoptionapi.global_value as global_value
import iqoptionapi.constants as OP_code

logger = logging.getLogger("iq_patched")

DEFAULT_TIMEOUT_CANDLE = 30
DEFAULT_TIMEOUT_BUY = 10
DEFAULT_TIMEOUT_CHECK_WIN = 120
DEFAULT_TIMEOUT_BALANCE = 15
DEFAULT_TIMEOUT_PROFIT = 60
DEFAULT_TIMEOUT_ACTIVES = 30
DEFAULT_TIMEOUT_CONNECT = 30
MAX_RECONNECT_ATTEMPTS = 5
RECONNECT_BACKOFF_BASE = 2
# FIX: cache de resolucion de nombres OTC
_active_name_cache = {}  # normalized_name -> raw_api_name


class IQ_Option_Patched:
    def __init__(self, email, password):
        self._email = email
        self._password = password
        self._api = IQ_Option(email, password)
        self._lock = threading.Lock()
        self._connected = False
        self._actives_cache = {}
        self._actives_cache_time = 0
        self._profit_cache = None
        self._profit_cache_time = 0
        self._profit_cache_ttl = 300
        self._reconnect_count = 0
        self._last_connect_time = 0

    def __getattr__(self, name):
        return getattr(self._api, name)

    def connect(self):
        """Connect con TIMEOUT - FIX para el bug de login timeout."""
        for attempt in range(MAX_RECONNECT_ATTEMPTS):
            try:
                logger.info(f"[Patched] Connect intento {attempt + 1}/{MAX_RECONNECT_ATTEMPTS}")
                try:
                    self._api.close()
                except Exception:
                    pass

                # FIX: Crear API y conectar CON TIMEOUT
                # El bug original: IQ_Option.connect() puede colgarse indefinidamente
                # Solucion: ejecutar en thread separado con timeout
                api_instance = IQ_Option(self._email, self._password)
                connect_result = [False, "Timeout"]
                connect_error = [None]

                def _do_connect(api_inst, result, error):
                    try:
                        check, reason = api_inst.connect()
                        result[0] = check
                        result[1] = reason
                    except Exception as e:
                        error[0] = e
                        result[0] = False
                        result[1] = str(e)

                t = threading.Thread(target=_do_connect, args=(api_instance, connect_result, connect_error), daemon=True)
                t.start()
                t.join(timeout=DEFAULT_TIMEOUT_CONNECT)

                if t.is_alive():
                    # Thread sigue vivo = TIMEOUT
                    logger.warning(f"[Patched] Connect TIMEOUT ({DEFAULT_TIMEOUT_CONNECT}s) en intento {attempt + 1}")
                    # No usar esta instancia, descartar
                    try:
                        api_instance.close()
                    except Exception:
                        pass
                    if attempt < MAX_RECONNECT_ATTEMPTS - 1:
                        backoff = min(RECONNECT_BACKOFF_BASE ** attempt, 8)
                        logger.info(f"[Patched] Reintentando en {backoff}s...")
                        time.sleep(backoff)
                    continue

                if connect_error[0]:
                    raise connect_error[0]

                if connect_result[0]:
                    self._api = api_instance
                    self._connected = True
                    self._reconnect_count = 0
                    self._last_connect_time = time.time()
                    try:
                        self._update_actives_safe()
                    except Exception as e:
                        logger.warning(f"[Patched] Error actualizando ACTIVES: {e}")
                    logger.info("[Patched] Conexion exitosa")
                    return True, None
                else:
                    self._api = api_instance  # Guardar para reintentos internos
                    logger.warning(f"[Patched] Connect fallo: {connect_result[1]}")
                    if attempt < MAX_RECONNECT_ATTEMPTS - 1:
                        backoff = min(RECONNECT_BACKOFF_BASE ** attempt, 8)
                        logger.info(f"[Patched] Reintentando en {backoff}s...")
                        time.sleep(backoff)
            except Exception as e:
                logger.error(f"[Patched] Connect excepcion: {e}")
                if attempt < MAX_RECONNECT_ATTEMPTS - 1:
                    backoff = min(RECONNECT_BACKOFF_BASE ** attempt, 8)
                    time.sleep(backoff)
        self._connected = False
        return False, "Max reintentos alcanzado"

    def check_connect(self):
        try:
            if global_value.check_websocket_if_connect in (0, None):
                return False
            try:
                ts = self._api.get_server_timestamp()
                if ts and ts > 0:
                    return True
            except Exception:
                pass
            return bool(global_value.check_websocket_if_connect)
        except Exception:
            return False

    def _ensure_connected(self, max_attempts=3):
        if self.check_connect():
            self._connected = True
            return True
        logger.warning("[Patched] Conexion perdida, reconectando...")
        for attempt in range(max_attempts):
            try:
                check, reason = self.connect()
                if check:
                    try:
                        if hasattr(self, '_last_balance_mode'):
                            self._api.change_balance(self._last_balance_mode)
                    except Exception:
                        pass
                    return True
            except Exception as e:
                logger.error(f"[Patched] Reconexion intento {attempt + 1}: {e}")
            backoff = RECONNECT_BACKOFF_BASE ** attempt
            time.sleep(backoff)
        logger.error("[Patched] No se pudo reconectar")
        return False

    def _update_actives_safe(self):
        try:
            old_actives = dict(OP_code.ACTIVES)
            def _do_update():
                try:
                    self._api.update_ACTIVES_OPCODE()
                except Exception as e:
                    logger.warning(f"[Patched] update_ACTIVES_OPCODE fallo: {e}")
            t = threading.Thread(target=_do_update, daemon=True)
            t.start()
            t.join(timeout=DEFAULT_TIMEOUT_ACTIVES)
            if len(OP_code.ACTIVES) > len(old_actives):
                self._actives_cache = dict(OP_code.ACTIVES)
                self._actives_cache_time = time.time()
                logger.info(f"[Patched] ACTIVES actualizado: {len(OP_code.ACTIVES)} instrumentos")
            elif len(OP_code.ACTIVES) > 0:
                self._actives_cache = dict(OP_code.ACTIVES)
                self._actives_cache_time = time.time()
        except Exception as e:
            logger.warning(f"[Patched] Error actualizando ACTIVES: {e}")

    def get_all_ACTIVES_OPCODE(self):
        if self._actives_cache and (time.time() - self._actives_cache_time) < 600:
            return self._actives_cache
        try:
            actives = self._api.get_all_ACTIVES_OPCODE()
            if actives and len(actives) > 0:
                self._actives_cache = actives
                self._actives_cache_time = time.time()
                return actives
        except Exception as e:
            logger.warning(f"[Patched] get_all_ACTIVES_OPCODE fallo: {e}")
        # Fallback: construir desde get_all_profit()
        try:
            all_profit = self.get_all_profit()
            if all_profit:
                actives_from_profit = {}
                for name in all_profit.keys():
                    actives_from_profit[name] = name
                if actives_from_profit:
                    self._actives_cache = actives_from_profit
                    self._actives_cache_time = time.time()
                    logger.info(f"[Patched] ACTIVES desde profit: {len(actives_from_profit)} instrumentos")
                    return actives_from_profit
        except Exception as e:
            logger.warning(f"[Patched] get_all_profit fallback fallo: {e}")
        if self._actives_cache:
            return self._actives_cache
        return OP_code.ACTIVES

    def get_candles(self, ACTIVES, interval, count, endtime):
        """Get candles con resolucion de nombre OTC y reintentos."""
        # Probar multiples variaciones del nombre del activo
        norm = ACTIVES.upper().replace("-", "").replace("_", "")
        name_variations = [ACTIVES]
        if norm in _active_name_cache:
            name_variations.insert(0, _active_name_cache[norm])
        name_variations.extend([
            ACTIVES.upper(), ACTIVES.lower(),
            ACTIVES.replace("-OTC", "_otc"), ACTIVES.replace("-otc", "_otc"),
            ACTIVES.replace("_otc", "-OTC"), ACTIVES.replace("-OTC", "otc"),
        ])
        # Deduplicar manteniendo orden
        seen = set(); unique_variations = []
        for n in name_variations:
            if n not in seen: seen.add(n); unique_variations.append(n)

        for name in unique_variations:
            for attempt in range(3):  # 3 intentos por variacion
                try:
                    if not self._ensure_connected():
                        time.sleep(1)
                        continue
                    result = [None]
                    error = [None]
                    def _worker(n=name):
                        try:
                            result[0] = self._api.get_candles(n, interval, count, endtime)
                        except Exception as e:
                            error[0] = e
                    t = threading.Thread(target=_worker, daemon=True)
                    t.start()
                    t.join(timeout=DEFAULT_TIMEOUT_CANDLE)
                    if t.is_alive():
                        logger.warning(f"[Patched] get_candles TIMEOUT para {name}")
                        self._ensure_connected()
                        continue
                    if error[0]:
                        raise error[0]
                    if result[0] is not None and len(result[0]) > 0:
                        # Cache la resolucion exitosa
                        if name != ACTIVES:
                            _active_name_cache[norm] = name
                        return result[0]
                except KeyError:
                    self._update_actives_safe()
                    break  # Pasar a siguiente variacion
                except Exception as e:
                    logger.warning(f"[Patched] get_candles error para {name}: {e}")
                    break  # Pasar a siguiente variacion
        logger.error(f"[Patched] get_candles FALLO para {ACTIVES} despues de todos los intentos")
        return None

    def buy(self, price, ACTIVES, ACTION, expirations):
        # FIX: No bloquear por ACTIVES check - muchos OTC no estan en OP_code
        # Intentar actualizar solo como best-effort
        try:
            if ACTIVES not in OP_code.ACTIVES:
                self._update_actives_safe()
        except Exception:
            pass
        for attempt in range(3):
            try:
                if not self._ensure_connected():
                    logger.warning(f"[Patched] Sin conexion para buy (intento {attempt + 1})")
                    time.sleep(2)
                    continue
                result = [None, None]
                error = [None]
                def _worker():
                    try:
                        result[0], result[1] = self._api.buy(price, ACTIVES, ACTION, expirations)
                    except Exception as e:
                        error[0] = e
                t = threading.Thread(target=_worker, daemon=True)
                t.start()
                t.join(timeout=DEFAULT_TIMEOUT_BUY)
                if t.is_alive():
                    logger.warning(f"[Patched] buy TIMEOUT ({DEFAULT_TIMEOUT_BUY}s)")
                    self._ensure_connected()
                    continue
                if error[0]:
                    raise error[0]
                if result[0] is not None:
                    return result[0], result[1]
            except KeyError as e:
                logger.warning(f"[Patched] buy KeyError para {ACTIVES}: {e}")
                self._update_actives_safe()
                time.sleep(2)
            except Exception as e:
                logger.warning(f"[Patched] buy error (intento {attempt + 1}): {e}")
                self._ensure_connected()
                time.sleep(2)
        return False, "Buy fallo despues de 3 intentos"

    def check_win_v3(self, id_number, timeout=None):
        if timeout is None:
            timeout = DEFAULT_TIMEOUT_CHECK_WIN
        start_time = time.time()
        balance_before = None
        try:
            balance_before = self.get_balance_safe()
        except Exception:
            pass
        while time.time() - start_time < timeout:
            try:
                if not self.check_connect():
                    self._ensure_connected()
                    time.sleep(2)
                    continue
                try:
                    async_order = self._api.get_async_order(id_number)
                    if async_order and async_order.get("option-closed", {}) != {}:
                        option_closed = async_order["option-closed"]["msg"]
                        profit = option_closed.get("profit_amount", 0) - option_closed.get("amount", 0)
                        return profit
                except (KeyError, TypeError, AttributeError):
                    pass
                except Exception:
                    pass
                try:
                    result = self._api.check_win_v3(id_number)
                    if result is not None:
                        return result
                except Exception:
                    pass
                time.sleep(1)
            except Exception as e:
                logger.warning(f"[Patched] check_win_v3 error: {e}")
                time.sleep(2)
        logger.warning(f"[Patched] check_win_v3 TIMEOUT ({timeout}s), usando fallback balance")
        if balance_before is not None:
            try:
                time.sleep(3)
                balance_after = self.get_balance_safe()
                diff = balance_after - balance_before
                if abs(diff) > 0.01:
                    return diff
            except Exception:
                pass
        logger.error(f"[Patched] check_win_v3 no pudo determinar resultado para orden {id_number}")
        return None

    def get_balance_safe(self):
        for attempt in range(3):
            try:
                if not self._ensure_connected():
                    continue
                result = [None]
                error = [None]
                def _worker():
                    try:
                        result[0] = self._api.get_balance()
                    except Exception as e:
                        error[0] = e
                t = threading.Thread(target=_worker, daemon=True)
                t.start()
                t.join(timeout=DEFAULT_TIMEOUT_BALANCE)
                if t.is_alive():
                    logger.warning("[Patched] get_balance TIMEOUT")
                    self._ensure_connected()
                    continue
                if error[0]:
                    raise error[0]
                if result[0] is not None:
                    return result[0]
            except Exception as e:
                logger.warning(f"[Patched] get_balance error (intento {attempt + 1}): {e}")
                self._ensure_connected()
                time.sleep(2)
        try:
            balances = self._api.get_balances()
            if balances and "msg" in balances:
                for balance in balances["msg"]:
                    if balance["id"] == global_value.balance_id:
                        return balance["amount"]
        except Exception:
            pass
        raise Exception("get_balance fallo despues de 3 intentos")

    def get_all_profit(self, force_refresh=False):
        now = time.time()
        if not force_refresh and self._profit_cache and (now - self._profit_cache_time) < self._profit_cache_ttl:
            return self._profit_cache
        for attempt in range(2):
            try:
                if not self._ensure_connected():
                    continue
                result = [None]
                error = [None]
                def _worker():
                    try:
                        result[0] = self._api.get_all_profit()
                    except Exception as e:
                        error[0] = e
                t = threading.Thread(target=_worker, daemon=True)
                t.start()
                t.join(timeout=DEFAULT_TIMEOUT_PROFIT)
                if t.is_alive():
                    logger.warning("[Patched] get_all_profit TIMEOUT")
                    continue
                if error[0]:
                    raise error[0]
                if result[0] is not None:
                    self._profit_cache = result[0]
                    self._profit_cache_time = time.time()
                    return result[0]
            except Exception as e:
                logger.warning(f"[Patched] get_all_profit error (intento {attempt + 1}): {e}")
                time.sleep(3)
        if self._profit_cache:
            logger.warning("[Patched] get_all_profit usando cache expirado como fallback")
            return self._profit_cache
        return None

    def change_balance(self, Balance_MODE):
        try:
            self._api.change_balance(Balance_MODE)
            self._last_balance_mode = Balance_MODE
        except Exception as e:
            logger.warning(f"[Patched] change_balance error: {e}")
            if self._ensure_connected():
                self._api.change_balance(Balance_MODE)
                self._last_balance_mode = Balance_MODE

    def get_server_timestamp(self):
        try:
            return self._api.get_server_timestamp()
        except Exception:
            return time.time()

    def close(self):
        try:
            self._api.close()
        except Exception:
            pass
        self._connected = False

    def get_async_order(self, id_number):
        try:
            result = [None]
            error = [None]
            def _worker():
                try:
                    result[0] = self._api.get_async_order(id_number)
                except Exception as e:
                    error[0] = e
            t = threading.Thread(target=_worker, daemon=True)
            t.start()
            t.join(timeout=10)
            if error[0]:
                raise error[0]
            return result[0]
        except Exception:
            return {}

    def get_balance(self):
        try:
            return self.get_balance_safe()
        except Exception:
            try:
                return self._api.get_balance()
            except Exception:
                return 0.0
