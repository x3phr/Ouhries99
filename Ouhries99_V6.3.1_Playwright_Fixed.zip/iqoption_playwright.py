"""
Sistema Ouhries V6.3 Playwright Edition - IQ Option API Wrapper (Anti-Detection V5)
REEMPLAZO DROP-IN para iqoption_patched.py

V6.3.1 FIX: Playwright Python compatibility fixes
- FIX: _on_frame_received() signature mismatch (recibe 1 arg, no 2)
- FIX: networkidle timeout -> domcontentloaded (IQ Option WS persistente)
- FIX: Mouse activity thread lambda async logic
- FIX: WS interceptor is_connected() mas tolerante
- FIX: Soporte formato array y binario en WS messages

ARQUITECTURA HIBRIDA - Indetectable por IQ Option:
- Login: Playwright (navegador real, TLS real, cookies reales)
- Datos: Intercepcion WebSocket del navegador real (mismo formato que SDK JavaScript)
- Trading: Clicks reales en CALL/PUT (eventos DOM reales con movimiento de mouse)
- Balance: Lectura del DOM (como un usuario real lo ve)
- Anti-deteccion: Stealth patches, mouse real, scroll real, actividad fuera de trading

VENTAJAS sobre iqoptionapi:
- TLS fingerprint de Chrome REAL (no simulado con curl_cffi)
- Formato de mensajes WS identico al SDK JavaScript (iqoptionapi usa formato diferente)
- Eventos de mouse/scroll reales generados por el navegador
- Heartbeat/telemetria automatica (el navegador los envia naturalmente)
- Canvas/WebGL fingerprints reales
- Ninguna anomalia detectable en el protocolo

MISMA INTERFAZ que IQ_Option_Patched:
- engine.py NO necesita cambios (excepto el import)
- scanner.py NO necesita cambios
- config.py NO necesita cambios
"""

import asyncio
import json
import logging
import os
import random
import re
import threading
import time
import traceback
from datetime import datetime
from typing import Optional, Tuple, Dict, List, Any

logger = logging.getLogger("iq_playwright")

# ============================================================
# SELECTOR MAP - IQ Option DOM Selectors
# Actualizable via selector_map.json sin cambiar codigo
# ============================================================
DEFAULT_SELECTORS = {
    "login": {
        "page_url": "https://login.iqoption.com/en/login",
        "email_input": 'input[name="identifier"]',
        "password_input": 'input[name="password"]',
        "submit_button": 'button.Button_green.Button_big, button[type="submit"]:has-text("Log In"), #login-submit-button',
        "form": '#login-form',
    },
    "dashboard": {
        "traderoom_url_pattern": "**/traderoom**",
        "balance_container": '[class*="balance"], [class*="Balance"], [data-test*="balance"]',
        "practice_button": 'button:has-text("Practice"), [class*="practice"], [class*="Practice"]',
        "real_button": 'button:has-text("Real"), [class*="real-"], [class*="Real"]',
        "account_switch": '[class*="account-switch"], [class*="AccountSwitch"], [class*="toggle"]',
    },
    "trading": {
        "asset_selector_button": '[class*="asset-selector"], [class*="instrument"], [class*="AssetSelector"], [class*="current-asset"]',
        "asset_search_input": 'input[class*="search"], input[placeholder*="Search"], input[placeholder*="search"]',
        "otc_tab": 'button:has-text("OTC"), [class*="otc"], [class*="OTC"], [data-test*="otc"]',
        "asset_item": '[class*="asset-item"], [class*="instrument-item"], [class*="AssetItem"]',
        "amount_input": 'input[class*="amount"], input[name*="amount"], [class*="amount-input"], [class*="AmountInput"]',
        "call_button": 'button:has-text("CALL"), [class*="call-btn"], [class*="btn-call"], [class*="CallButton"], [class*="up-btn"]',
        "put_button": 'button:has-text("PUT"), [class*="put-btn"], [class*="btn-put"], [class*="PutButton"], [class*="down-btn"]',
        "expiration_selector": '[class*="expiration"], [class*="expiry"], [class*="Expiration"]',
        "expiration_1min": 'button:has-text("1 min"), [class*="1m"], [data-test*="1min"]',
        "trade_confirmation": '[class*="confirmation"], [class*="result"], [class*="trade-result"]',
        "close_confirmation": 'button:has-text("OK"), button:has-text("Close"), [class*="close"]',
    },
    "navigation": {
        "deposit_link": 'a:has-text("Deposit"), button:has-text("Deposit"), [class*="deposit"]',
        "settings_link": 'a:has-text("Settings"), [class*="settings"], [class*="Settings"]',
        "history_link": 'a:has-text("History"), [class*="history"], [class*="History"]',
    }
}

# ============================================================
# STEALTH JAVASCRIPT - Anti-Detection Patches
# Se inyectan en el navegador antes de cargar cualquier pagina
# ============================================================
STEALTH_JS = """
// 1. Ocultar navigator.webdriver
Object.defineProperty(navigator, 'webdriver', {
    get: () => undefined,
    configurable: true
});

// 2. Agregar chrome.runtime (ausente en Playwright)
if (!window.chrome) window.chrome = {};
if (!window.chrome.runtime) {
    window.chrome.runtime = {
        connect: function() {},
        sendMessage: function() {},
        onMessage: { addListener: function() {} },
        id: undefined
    };
}

// 3. Corregir Permissions API
const originalQuery = window.navigator.permissions.query;
window.navigator.permissions.query = (parameters) => (
    parameters.name === 'notifications' ?
        Promise.resolve({ state: Notification.permission }) :
        originalQuery(parameters)
);

// 4. Agregar plugins realistas
Object.defineProperty(navigator, 'plugins', {
    get: () => [
        { name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer' },
        { name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai' },
        { name: 'Native Client', filename: 'internal-nacl-plugin' }
    ],
    configurable: true
});

// 5. Corregir languages
Object.defineProperty(navigator, 'languages', {
    get: () => ['en-US', 'en', 'es'],
    configurable: true
});

// 6. Prevenir deteccion de automation via CDP
window.cdc_adoQpoasnfa76pfcZLmcfl_Array = undefined;
window.cdc_adoQpoasnfa76pfcZLmcfl_Promise = undefined;
window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol = undefined;

// 7. Corregir iframe contentWindow
const origAttachShadow = Element.prototype.attachShadow;
Element.prototype.attachShadow = function() {
    const shadowRoot = origAttachShadow.apply(this, arguments);
    shadowRoot.querySelector = new Proxy(shadowRoot.querySelector, {
        apply: function(target, thisArg, args) {
            return target.apply(thisArg, args);
        }
    });
    return shadowRoot;
};

// 8. WebGL vendor/renderer realistas
const getParameter = WebGLRenderingContext.prototype.getParameter;
WebGLRenderingContext.prototype.getParameter = function(param) {
    if (param === 37445) return 'Google Inc. (NVIDIA)';
    if (param === 37446) return 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1060, OpenGL 4.5)';
    return getParameter.call(this, param);
};

// 9. Mouse movement tracking (para simular actividad humana)
window.__ouhries_mouse_positions = [];
document.addEventListener('mousemove', (e) => {
    if (window.__ouhries_mouse_positions.length > 100) {
        window.__ouhries_mouse_positions.shift();
    }
    window.__ouhries_mouse_positions.push({
        x: e.clientX, y: e.clientY,
        t: Date.now()
    });
});

// 10. Prevenir deteccion de headless
Object.defineProperty(navigator, 'maxTouchPoints', {
    get: () => 0,
    configurable: true
});

// 11. Corregir hairline detection
if (window.devicePixelRatio !== undefined) {
    Object.defineProperty(window, 'devicePixelRatio', {
        get: () => 1,
        configurable: true
    });
}
"""

# ============================================================
# CHROME USER AGENTS (2025/2026)
# ============================================================
CHROME_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
]


# ============================================================
# ASYNC BRIDGE - Conecta el engine sincronico con Playwright async
# ============================================================
class _AsyncBridge:
    """Puente entre el engine.py sincronico y Playwright async.
    Ejecuta un event loop en un thread daemon separado."""

    def __init__(self):
        self._loop = None
        self._thread = None
        self._started = threading.Event()
        self._lock = threading.Lock()

    def start(self):
        with self._lock:
            if self._loop is not None and self._loop.is_running():
                return
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()
            self._started.wait(timeout=10)

    def _run(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._started.set()
        self._loop.run_forever()

    def run(self, coro, timeout=120):
        """Ejecuta una corutina async desde codigo sincronico."""
        self.start()
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        try:
            return future.result(timeout=timeout)
        except Exception as e:
            logger.error(f"[AsyncBridge] Error ejecutando corutina: {e}")
            raise

    def stop(self):
        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)


# ============================================================
# WEBSOCKET INTERCEPTOR - Captura datos del WS real del navegador
# ============================================================
class _WSInterceptor:
    """Intercepta mensajes WebSocket del navegador real.
    IQ Option envia todos los datos (candles, profit, actives, timesync)
    a traves del WebSocket. Interceptamos estos mensajes para obtener
    los mismos datos que la interfaz web muestra al usuario."""

    def __init__(self):
        self._ws = None
        self._messages = {}
        self._actives = {}
        self._profit = {}
        self._candles_cache = {}
        self._balance = 0.0
        self._server_timestamp = time.time()
        self._trade_results = {}
        self._lock = threading.Lock()
        self._last_timesync = time.time()
        self._connected = False

    def on_ws_created(self, ws):
        """Llamado cuando el navegador crea una conexion WebSocket."""
        logger.info(f"[WS] Conexion WebSocket detectada: {ws.url}")
        self._ws = ws
        self._connected = True
        # FIX: Playwright Python "framereceived" event passes a single WebSocketFrame argument
        # NOT (ws, frame). Using lambda to adapt the signature.
        ws.on("framereceived", lambda frame: self._on_frame_received(frame))
        ws.on("close", lambda: self._on_ws_close())

    def _on_ws_close(self):
        """Llamado cuando el WebSocket se cierra."""
        logger.info("[WS] Conexion WebSocket cerrada")
        self._connected = False
        self._ws = None

    def _on_frame_received(self, frame):
        """Procesa cada frame recibido del WebSocket.
        FIX: Recibe un unico argumento 'frame' (WebSocketFrame object)
        en lugar de (ws, frame) que causaba TypeError con Playwright.
        FIX: Soporta ambos formatos de mensaje IQ Option:
        - Formato dict: {"name": "timeSync", "msg": {...}}
        - Formato array: ["timeSync", {...}]"""
        try:
            # Playwright WebSocketFrame tiene atributo .payload (str|bytes)
            payload = frame.payload if hasattr(frame, 'payload') else str(frame)
            if not payload:
                return
            # FIX: IQ Option puede enviar frames binarios (opcode=2) o texto (opcode=1)
            if isinstance(payload, bytes):
                try:
                    payload = payload.decode('utf-8')
                except (UnicodeDecodeError, AttributeError):
                    return  # Ignorar frames binarios que no son JSON
            if not isinstance(payload, str):
                return

            # Los mensajes de IQ Option son JSON
            try:
                data = json.loads(payload)
            except (json.JSONDecodeError, ValueError):
                return

            # FIX: IQ Option usa dos formatos de mensaje:
            # 1. Formato dict: {"name": "timeSync", "msg": {...}}
            # 2. Formato array: ["timeSync", {...}]
            if isinstance(data, list) and len(data) >= 2:
                msg_name = data[0] if isinstance(data[0], str) else ""
                msg = data[1]
                data = {"name": msg_name, "msg": msg}
            elif not isinstance(data, dict):
                return

            # FIX: Actualizar last_timesync con CUALQUIER mensaje recibido
            # para mantener la conexion marcada como activa
            self._last_timesync = time.time()

            msg_name = data.get("name", "")

            # TimeSync - actualizar timestamp del servidor
            if msg_name == "timeSync":
                msg = data.get("msg", 0)
                if isinstance(msg, (int, float)) and msg > 0:
                    self._server_timestamp = msg / 1000.0
                    self._last_timesync = time.time()

            # Balance update
            elif msg_name == "balance":
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    amount = msg.get("amount", 0)
                    if amount:
                        with self._lock:
                            self._balance = float(amount)

            # Profit/Payout data
            elif msg_name in ("profit", "turbo-profit", "profit-all"):
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    with self._lock:
                        self._profit.update(msg)
                elif isinstance(msg, list):
                    with self._lock:
                        for item in msg:
                            if isinstance(item, dict):
                                name = item.get("name", item.get("instrument", ""))
                                if name:
                                    self._profit[name] = item

            # Actives/Instruments
            elif msg_name in ("actives", "instruments", "instrument-list",
                              "getAllInstruments", "get_all_ACTIVES_OPCODE"):
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    with self._lock:
                        self._actives.update(msg)
                elif isinstance(msg, list):
                    with self._lock:
                        for item in msg:
                            if isinstance(item, dict):
                                name = item.get("name", item.get("instrument", ""))
                                aid = item.get("id", item.get("active_id", ""))
                                if name:
                                    self._actives[name] = aid

            # Candle data
            elif msg_name in ("candles", "candle", "get-candles"):
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    instrument = msg.get("instrument", msg.get("active", ""))
                    candles = msg.get("candles", msg.get("data", []))
                    if instrument and candles:
                        with self._lock:
                            self._candles_cache[instrument] = candles

            # Trade result
            elif msg_name in ("option-closed", "order-result", "trade-result"):
                msg = data.get("msg", {})
                if isinstance(msg, dict):
                    order_id = msg.get("id", msg.get("order_id", ""))
                    profit = msg.get("profit", msg.get("win", 0))
                    if order_id:
                        with self._lock:
                            self._trade_results[str(order_id)] = float(profit)

        except Exception as e:
            logger.debug(f"[WS] Error procesando frame: {e}")

    def get_balance(self):
        with self._lock:
            return self._balance

    def get_server_timestamp(self):
        return self._server_timestamp

    def is_connected(self):
        # FIX: Mas tolerante - si el WS esta conectado, considerarlo activo
        # incluso si no hemos recibido timeSync recientemente (puede variar el formato)
        if not self._connected:
            return False
        # Si nunca recibimos ningun mensaje en 5 minutos, desconectar
        if time.time() - self._last_timesync > 300:
            return False
        return True

    def get_actives(self):
        with self._lock:
            return self._actives.copy()

    def get_profit(self):
        with self._lock:
            return self._profit.copy()

    def get_candles(self, instrument):
        with self._lock:
            return self._candles_cache.get(instrument, [])

    def get_trade_result(self, order_id):
        with self._lock:
            return self._trade_results.pop(str(order_id), None)


# ============================================================
# IQ_OPTION_PLAYWRIGHT - Reemplazo Drop-In para IQ_Option_Patched
# ============================================================
class IQ_Option_Patched:
    """
    Wrapper de IQ Option usando Playwright para automatizacion de navegador real.
    INDTECTABLE: Usa navegador Chrome real, TLS real, WS real, mouse real.

    MISMA INTERFAZ que iqoption_patched.py:
    - connect() -> (bool, str|None)
    - check_connect() -> bool
    - _ensure_connected() -> bool
    - get_all_ACTIVES_OPCODE() -> dict
    - get_candles(ACTIVES, interval, count, endtime) -> list
    - buy(price, ACTIVES, ACTION, expirations) -> (bool, id)
    - check_win_v3(id_number) -> float
    - get_balance() -> float
    - get_balance_safe() -> float
    - get_all_profit() -> dict
    - change_balance(Balance_MODE) -> None
    - get_server_timestamp() -> float
    - get_async_order(id_number) -> dict
    - close() -> None
    """

    def __init__(self, email, password):
        self._email = email
        self._password = password
        self._bridge = _AsyncBridge()
        self._browser = None
        self._context = None
        self._page = None
        self._ws_interceptor = _WSInterceptor()
        self._connected = False
        self._connect_time = 0
        self._actives_cache = {}
        self._actives_cache_time = 0
        self._profit_cache = {}
        self._profit_cache_time = 0
        self._profit_cache_ttl = 300  # 5 minutos
        self._balance_id = None
        self._ssid = None
        self._last_balance_read = 0.0
        self._pending_trades = {}  # order_id -> {pre_balance, timestamp, ...}
        self._trade_counter = 0
        self._lock = threading.Lock()
        self._reconnect_count = 0
        self._max_reconnect = 5
        self._selectors = self._load_selectors()
        self._mouse_activity_thread = None
        self._mouse_activity_stop = threading.Event()

    # ============================================================
    # SELECTOR MANAGEMENT
    # ============================================================
    def _load_selectors(self):
        """Carga selectores desde archivo JSON o usa los defaults."""
        selector_file = os.path.join(os.path.dirname(__file__), "selector_map.json")
        if os.path.exists(selector_file):
            try:
                with open(selector_file, "r") as f:
                    custom = json.load(f)
                # Merge con defaults (custom sobreescribe)
                merged = {}
                for key in DEFAULT_SELECTORS:
                    merged[key] = {**DEFAULT_SELECTORS[key], **custom.get(key, {})}
                return merged
            except Exception as e:
                logger.warning(f"[Selector] Error cargando selector_map.json: {e}")
        return DEFAULT_SELECTORS.copy()

    # ============================================================
    # BROWSER LIFECYCLE
    # ============================================================
    async def _launch_browser(self):
        """Lanza el navegador Chrome con stealth patches."""
        try:
            from playwright.async_api import async_playwright

            self._playwright = await async_playwright().start()

            # Usar Chrome real si esta disponible, sino Chromium
            launch_args = [
                '--disable-blink-features=AutomationControlled',
                '--disable-features=IsolateOrigins,site-per-process',
                '--disable-site-isolation-trials',
                '--no-first-run',
                '--no-default-browser-check',
                '--disable-background-timer-throttling',
                '--disable-backgrounding-occluded-windows',
                '--disable-renderer-backgrounding',
                '--disable-component-update',
                '--disable-default-apps',
                '--disable-hang-monitor',
                '--disable-prompt-on-repost',
                '--disable-sync',
                '--metrics-recording-only',
                '--password-store=basic',
                '--use-mock-keychain',
            ]

            try:
                self._browser = await self._playwright.chromium.launch(
                    channel="chrome",
                    headless=False,
                    args=launch_args,
                    timeout=30000,
                )
                logger.info("[Playwright] Chrome REAL lanzado")
            except Exception:
                self._browser = await self._playwright.chromium.launch(
                    headless=False,
                    args=launch_args,
                    timeout=30000,
                )
                logger.info("[Playwright] Chromium lanzado (Chrome no disponible)")

            # Crear contexto con fingerprint realista
            ua = random.choice(CHROME_USER_AGENTS)
            self._context = await self._browser.new_context(
                viewport={'width': 1920, 'height': 1080},
                user_agent=ua,
                locale='en-US',
                timezone_id='America/Argentina/Buenos_Aires',
                color_scheme='dark',
                device_scale_factor=1.0,
                has_touch=False,
                java_script_enabled=True,
                no_viewport=False,
            )

            # Inyectar stealth patches ANTES de cualquier pagina
            await self._context.add_init_script(STEALTH_JS)

            # Crear pagina principal
            self._page = await self._context.new_page()

            # Configurar timeout por defecto
            self._page.set_default_timeout(30000)
            self._page.set_default_navigation_timeout(60000)

            # Interceptar WebSocket
            self._page.on("websocket", self._ws_interceptor.on_ws_created)

            # Interceptar requests para debug
            self._page.on("request", self._on_request)
            self._page.on("response", self._on_response)

            logger.info(f"[Playwright] Navegador listo (UA: Chrome/{ua.split('Chrome/')[1].split(' ')[0]})")
            return True

        except Exception as e:
            logger.error(f"[Playwright] Error lanzando navegador: {e}")
            return False

    def _on_request(self, request):
        """Intercepta requests HTTP para descubrir API endpoints."""
        url = request.url
        # Solo loggear endpoints de API relevantes
        if any(kw in url for kw in ['/api/', '/echo/', 'websocket', 'candles', 'instruments']):
            logger.debug(f"[HTTP] {request.method} {url[:120]}")

    def _on_response(self, response):
        """Intercepta responses HTTP para extraer datos utiles."""
        url = response.url
        status = response.status
        # Loggear redirects y errores
        if status >= 300:
            logger.debug(f"[HTTP] {status} {url[:120]}")

    # ============================================================
    # LOGIN
    # ============================================================
    async def _login(self):
        """Realiza login en IQ Option usando el navegador real."""
        try:
            sel = self._selectors["login"]
            login_url = sel["page_url"]

            logger.info(f"[Login] Navegando a {login_url}...")
            # FIX: Usar 'domcontentloaded' en lugar de 'networkidle' porque IQ Option
            # mantiene conexiones WebSocket/polling persistentes que nunca se asientan
            await self._page.goto(login_url, wait_until='domcontentloaded', timeout=60000)
            await asyncio.sleep(random.uniform(2.0, 4.0))

            # Esperar a que el formulario de login cargue
            email_input = None
            for selector in [sel["email_input"], 'input[name="identifier"]', '#login-email-input',
                             'input[type="email"]', 'input[placeholder*="Email"]']:
                try:
                    email_input = await self._page.wait_for_selector(selector, timeout=5000)
                    if email_input:
                        logger.info(f"[Login] Email input encontrado: {selector}")
                        break
                except Exception:
                    continue

            if not email_input:
                # Intentar landing page login
                logger.info("[Login] Formulario de login no encontrado, intentando pagina principal...")
                await self._page.goto("https://iqoption.com/en", wait_until='domcontentloaded', timeout=60000)
                await asyncio.sleep(random.uniform(2.0, 4.0))

                # Buscar boton de login
                for btn_sel in ['button:has-text("Log in")', 'a:has-text("Log in")',
                                '[class*="login"]', 'button.link-ghost']:
                    try:
                        btn = await self._page.wait_for_selector(btn_sel, timeout=5000)
                        if btn:
                            await btn.click()
                            await asyncio.sleep(random.uniform(2.0, 4.0))
                            break
                    except Exception:
                        continue

                # Re-buscar formulario
                for selector in [sel["email_input"], 'input[name="identifier"]', '#login-email-input']:
                    try:
                        email_input = await self._page.wait_for_selector(selector, timeout=5000)
                        if email_input:
                            break
                    except Exception:
                        continue

            if not email_input:
                logger.error("[Login] No se encontro el campo de email")
                return False, "Login form not found"

            # Simular actividad humana antes de escribir
            await self._human_mouse_move()
            await asyncio.sleep(random.uniform(0.5, 1.5))

            # Llenar email con simulacion de tipeo humano
            logger.info("[Login] Ingresando email...")
            await email_input.click()
            await asyncio.sleep(random.uniform(0.3, 0.8))
            await self._human_type(email_input, self._email)
            await asyncio.sleep(random.uniform(0.5, 1.5))

            # Llenar password
            logger.info("[Login] Ingresando password...")
            pw_input = None
            for selector in [sel["password_input"], 'input[name="password"]', '#login-password-input',
                             'input[type="password"]']:
                try:
                    pw_input = await self._page.wait_for_selector(selector, timeout=5000)
                    if pw_input:
                        break
                except Exception:
                    continue

            if not pw_input:
                logger.error("[Login] No se encontro el campo de password")
                return False, "Password field not found"

            await pw_input.click()
            await asyncio.sleep(random.uniform(0.3, 0.8))
            await self._human_type(pw_input, self._password)
            await asyncio.sleep(random.uniform(0.5, 2.0))

            # Click en submit
            logger.info("[Login] Enviando formulario...")
            submit_btn = None
            for selector in [sel["submit_button"], '#login-submit-button',
                             'button.Button_green', 'button[type="submit"]',
                             'button:has-text("Log In")', 'button:has-text("Log in")']:
                try:
                    submit_btn = await self._page.wait_for_selector(selector, timeout=5000)
                    if submit_btn:
                        break
                except Exception:
                    continue

            if not submit_btn:
                logger.error("[Login] No se encontro el boton de submit")
                return False, "Submit button not found"

            # Mover el mouse al boton y hacer click
            await self._human_move_to_element(submit_btn)
            await asyncio.sleep(random.uniform(0.2, 0.5))
            await submit_btn.click()

            # Esperar redireccion al traderoom
            logger.info("[Login] Esperando redireccion al traderoom...")
            try:
                await self._page.wait_for_url(
                    "**/traderoom**",
                    timeout=30000
                )
                logger.info("[Login] Redireccion al traderoom exitosa!")
            except Exception:
                # Verificar si estamos en la pagina correcta de todas formas
                current_url = self._page.url
                if "traderoom" in current_url or "trade" in current_url:
                    logger.info(f"[Login] En traderoom: {current_url}")
                else:
                    logger.warning(f"[Login] URL inesperada: {current_url}")
                    # Verificar si hay errores en la pagina
                    error_el = await self._page.query_selector('[class*="error"], [class*="Error"]')
                    if error_el:
                        error_text = await error_el.text_content()
                        logger.error(f"[Login] Error en pagina: {error_text}")
                        return False, f"Login error: {error_text}"

            # Esperar a que la pagina cargue completamente
            await asyncio.sleep(random.uniform(5.0, 8.0))
            # FIX: Usar 'load' en lugar de 'networkidle' - IQ Option tiene WS persistente
            try:
                await self._page.wait_for_load_state('load', timeout=30000)
            except Exception:
                logger.debug("[Login] wait_for_load_state timeout (ignorable, WS persistente)")

            # Esperar a que aparezca el WebSocket (indicador de que el dashboard cargo)
            for _ in range(30):
                if self._ws_interceptor.is_connected():
                    break
                await asyncio.sleep(1.0)

            if not self._ws_interceptor.is_connected():
                logger.warning("[Login] WebSocket no detectado, pero procediendo...")

            # Leer balance inicial del DOM
            await asyncio.sleep(2.0)
            balance = await self._read_balance_from_dom()
            if balance > 0:
                self._ws_interceptor._balance = balance
                logger.info(f"[Login] Balance inicial (DOM): ${balance:.2f}")
            else:
                # Intentar desde WS interceptor
                balance = self._ws_interceptor.get_balance()
                logger.info(f"[Login] Balance inicial (WS): ${balance:.2f}")

            # Descubrir selectores del dashboard
            await self._discover_dashboard_selectors()

            # Iniciar simulacion de actividad de mouse
            self._start_mouse_activity()

            logger.info("[Login] LOGIN EXITOSO - Dashboard cargado")
            return True, None

        except Exception as e:
            logger.error(f"[Login] Error: {e}")
            logger.debug(traceback.format_exc())
            return False, str(e)

    async def _discover_dashboard_selectors(self):
        """Descubre y mapea selectores del dashboard automaticamente.
        Guarda los selectores encontrados en selector_map_discovered.json."""
        try:
            logger.info("[Discovery] Mapeando elementos del dashboard...")

            discovered = {}

            # Buscar elementos clave por texto
            text_searches = {
                "call_button": ["CALL", "Call", "call", "Higher"],
                "put_button": ["PUT", "Put", "put", "Lower"],
                "amount_input": None,  # Buscar por tipo
                "balance_container": None,
            }

            for key, texts in text_searches.items():
                if texts:
                    for text in texts:
                        try:
                            el = await self._page.query_selector(f'button:has-text("{text}")')
                            if el:
                                tag = await el.evaluate("el => el.tagName")
                                classes = await el.evaluate("el => el.className")
                                discovered[key] = {
                                    "text": text,
                                    "tag": tag,
                                    "classes": classes,
                                }
                                logger.info(f"[Discovery] {key}: text='{text}', class='{classes[:80]}'")
                                break
                        except Exception:
                            continue

            # Buscar inputs
            inputs = await self._page.query_selector_all('input')
            for inp in inputs:
                try:
                    input_type = await inp.evaluate("el => el.type")
                    input_name = await inp.evaluate("el => el.name")
                    input_class = await inp.evaluate("el => el.className")
                    input_placeholder = await inp.evaluate("el => el.placeholder")
                    input_value = await inp.evaluate("el => el.value")

                    logger.debug(f"[Discovery] Input: type={input_type}, name={input_name}, "
                                 f"class={input_class[:50]}, placeholder={input_placeholder}, "
                                 f"value={input_value[:30]}")

                    # Detectar input de amount
                    if any(kw in (input_class + input_name + input_placeholder).lower()
                           for kw in ['amount', 'investment', 'price', 'stake']):
                        discovered["amount_input"] = {
                            "name": input_name,
                            "class": input_class,
                            "placeholder": input_placeholder,
                        }
                        logger.info(f"[Discovery] amount_input: class='{input_class[:80]}'")

                except Exception:
                    continue

            # Guardar selectores descubiertos
            if discovered:
                discover_file = os.path.join(os.path.dirname(__file__), "selector_map_discovered.json")
                with open(discover_file, "w") as f:
                    json.dump(discovered, f, indent=2)
                logger.info(f"[Discovery] Selectores guardados en {discover_file}")

        except Exception as e:
            logger.warning(f"[Discovery] Error: {e}")

    # ============================================================
    # HUMAN SIMULATION - Movimientos de mouse, tipeo, scroll
    # ============================================================
    async def _human_mouse_move(self):
        """Simula movimiento aleatorio de mouse por la pagina."""
        try:
            for _ in range(random.randint(2, 5)):
                x = random.randint(200, 1700)
                y = random.randint(200, 800)
                await self._page.mouse.move(x, y, steps=random.randint(5, 15))
                await asyncio.sleep(random.uniform(0.05, 0.2))
        except Exception:
            pass

    async def _human_move_to_element(self, element):
        """Mueve el mouse a un elemento con trayectoria humana."""
        try:
            box = await element.bounding_box()
            if not box:
                await element.click()
                return

            # Centro del elemento con pequena variacion
            target_x = box['x'] + box['width'] / 2 + random.uniform(-5, 5)
            target_y = box['y'] + box['height'] / 2 + random.uniform(-5, 5)

            # Movimiento en pasos (como un humano)
            steps = random.randint(10, 25)
            await self._page.mouse.move(target_x, target_y, steps=steps)
            await asyncio.sleep(random.uniform(0.1, 0.3))
        except Exception:
            try:
                await element.click()
            except Exception:
                pass

    async def _human_type(self, element, text):
        """Escribe texto simulando tipeo humano con delays variables."""
        try:
            await element.click()
            await asyncio.sleep(random.uniform(0.1, 0.3))
            # Limpiar campo existente
            await element.fill("")
            await asyncio.sleep(random.uniform(0.1, 0.3))

            for char in text:
                await element.type(char, delay=random.randint(30, 150))
                # Pausa mas larga en algunos caracteres (como pensamiento)
                if random.random() < 0.1:
                    await asyncio.sleep(random.uniform(0.2, 0.5))
        except Exception as e:
            # Fallback: fill directo
            try:
                await element.fill(text)
            except Exception:
                pass

    async def _human_scroll(self, direction="down", amount=3):
        """Simula scroll humano en la pagina."""
        try:
            delta_y = 300 if direction == "down" else -300
            for _ in range(amount):
                await self._page.mouse.wheel(0, delta_y + random.randint(-50, 50))
                await asyncio.sleep(random.uniform(0.3, 0.8))
        except Exception:
            pass

    def _start_mouse_activity(self):
        """Inicia thread que simula actividad periodica de mouse.
        Hace que la sesion parezca activa incluso cuando el bot no esta operando."""
        if self._mouse_activity_thread and self._mouse_activity_thread.is_alive():
            return

        self._mouse_activity_stop.clear()

        def _activity_loop():
            logger.info("[MouseActivity] Iniciado - simulando actividad humana")
            while not self._mouse_activity_stop.is_set():
                try:
                    self._mouse_activity_stop.wait(timeout=random.uniform(30, 120))
                    if self._mouse_activity_stop.is_set():
                        break

                    if not self._page or not self._connected:
                        continue

                    # Ejecutar actividad aleatoria
                    async def _do_activity():
                        # FIX: Logica de seleccion de accion corregida
                        actions = [
                            self._human_mouse_move,
                            self._noise_browse_instruments,
                        ]
                        action = random.choice(actions)
                        try:
                            if asyncio.iscoroutinefunction(action):
                                await action()
                        except Exception:
                            pass
                        # Scroll con funcion lambda separada
                        try:
                            if random.random() < 0.5:
                                await self._human_scroll("down", random.randint(1, 3))
                            elif random.random() < 0.3:
                                await self._human_scroll("up", random.randint(1, 2))
                        except Exception:
                            pass

                    try:
                        self._bridge.run(_do_activity(), timeout=15)
                    except Exception:
                        pass

                except Exception:
                    pass

            logger.info("[MouseActivity] Detenido")

        self._mouse_activity_thread = threading.Thread(target=_activity_loop, daemon=True)
        self._mouse_activity_thread.start()

    def _stop_mouse_activity(self):
        """Detiene la simulacion de actividad de mouse."""
        self._mouse_activity_stop.set()

    # ============================================================
    # NOISE BROWSING - Actividad fuera de trading
    # ============================================================
    async def _noise_browse_instruments(self):
        """Simula navegacion por instrumentos (como un usuario explorando)."""
        try:
            # Intentar abrir el selector de assets
            sel = self._selectors["trading"]
            for selector in [sel["asset_selector_button"],
                             '[class*="asset"]', '[class*="instrument"]']:
                try:
                    el = await self._page.wait_for_selector(selector, timeout=3000)
                    if el:
                        await self._human_move_to_element(el)
                        await el.click()
                        await asyncio.sleep(random.uniform(1.0, 2.5))

                        # Scroll por la lista
                        await self._human_scroll("down", random.randint(2, 5))
                        await asyncio.sleep(random.uniform(1.0, 3.0))

                        # Cerrar selector (presionar Escape)
                        await self._page.keyboard.press("Escape")
                        await asyncio.sleep(random.uniform(0.5, 1.0))
                        break
                except Exception:
                    continue
        except Exception as e:
            logger.debug(f"[Noise] browse_instruments: {e}")

    # ============================================================
    # BALANCE READING
    # ============================================================
    async def _read_balance_from_dom(self):
        """Lee el balance del DOM de la pagina."""
        try:
            sel = self._selectors["dashboard"]

            # Estrategia 1: Selector conocido
            for selector in [sel["balance_container"],
                             '[class*="balance-amount"]', '[class*="Balance"]',
                             '[class*="user-balance"]', '[data-test*="balance"]']:
                try:
                    el = await self._page.wait_for_selector(selector, timeout=3000)
                    if el:
                        text = await el.text_content()
                        if text:
                            # Parsear numero del texto
                            cleaned = re.sub(r'[^\d.,\-]', '', text)
                            cleaned = cleaned.replace(',', '.')
                            if cleaned:
                                return float(cleaned)
                except Exception:
                    continue

            # Estrategia 2: Buscar por texto con patron de moneda
            try:
                elements = await self._page.query_selector_all('span, div, p')
                for el in elements:
                    try:
                        text = await el.text_content()
                        if text and re.match(r'^\$?\d{1,3}[.,]?\d{0,2}$', text.strip()):
                            cleaned = re.sub(r'[^\d.,]', '', text.strip())
                            cleaned = cleaned.replace(',', '.')
                            if cleaned and float(cleaned) > 0:
                                return float(cleaned)
                    except Exception:
                        continue
            except Exception:
                pass

            # Estrategia 3: Usar page.evaluate para buscar en el DOM
            try:
                balance = await self._page.evaluate("""
                    () => {
                        const allElements = document.querySelectorAll('*');
                        for (const el of allElements) {
                            if (el.textContent && el.children.length === 0) {
                                const match = el.textContent.match(/\\$?([\\d,]+\\.?\\d{2})/);
                                if (match && parseFloat(match[1].replace(',', '')) > 0) {
                                    return parseFloat(match[1].replace(',', ''));
                                }
                            }
                        }
                        return 0;
                    }
                """)
                if balance and balance > 0:
                    return float(balance)
            except Exception:
                pass

            return 0.0

        except Exception as e:
            logger.debug(f"[Balance] Error leyendo del DOM: {e}")
            return 0.0

    # ============================================================
    # TRADE EXECUTION
    # ============================================================
    async def _navigate_to_asset(self, instrument_name):
        """Navega a un activo especifico en la interfaz de trading."""
        try:
            sel = self._selectors["trading"]

            # Si ya estamos en el activo correcto, no hacer nada
            current_asset = await self._get_current_asset()
            if current_asset and instrument_name.upper() in current_asset.upper():
                logger.debug(f"[Trade] Ya en {instrument_name}")
                return True

            # Abrir selector de assets
            for selector in [sel["asset_selector_button"],
                             '[class*="asset-selector"]', '[class*="current-asset"]',
                             '[class*="instrument"]']:
                try:
                    el = await self._page.wait_for_selector(selector, timeout=3000)
                    if el:
                        await self._human_move_to_element(el)
                        await el.click()
                        await asyncio.sleep(random.uniform(1.0, 2.0))
                        break
                except Exception:
                    continue

            # Si es OTC, intentar filtrar
            if "-OTC" in instrument_name.upper():
                for selector in [sel["otc_tab"], 'button:has-text("OTC")',
                                 '[class*="otc"]', '[class*="OTC"]']:
                    try:
                        el = await self._page.wait_for_selector(selector, timeout=3000)
                        if el:
                            await self._human_move_to_element(el)
                            await el.click()
                            await asyncio.sleep(random.uniform(0.5, 1.5))
                            break
                    except Exception:
                        continue

            # Buscar el activo
            for selector in [sel["asset_search_input"],
                             'input[class*="search"]', 'input[placeholder*="Search"]']:
                try:
                    search_input = await self._page.wait_for_selector(selector, timeout=3000)
                    if search_input:
                        # Limpiar y escribir nombre del activo
                        await search_input.click()
                        await asyncio.sleep(0.3)
                        await search_input.fill("")
                        # Escribir sin el sufijo -OTC para mejor busqueda
                        search_name = instrument_name.replace("-OTC", "").replace("_otc", "")
                        await self._human_type(search_input, search_name)
                        await asyncio.sleep(random.uniform(1.0, 2.0))
                        break
                except Exception:
                    continue

            # Click en el activo de la lista de resultados
            asset_found = False
            # Buscar por texto del nombre del activo
            for text_variant in [instrument_name, instrument_name.replace("-OTC", ""),
                                 instrument_name.replace("-", " "),
                                 instrument_name.upper()]:
                try:
                    el = await self._page.wait_for_selector(
                        f'text="{text_variant}"', timeout=3000
                    )
                    if el:
                        await self._human_move_to_element(el)
                        await el.click()
                        asset_found = True
                        await asyncio.sleep(random.uniform(1.0, 2.5))
                        break
                except Exception:
                    continue

            if not asset_found:
                # Intentar buscar en la lista de assets visibles
                try:
                    items = await self._page.query_selector_all('[class*="asset-item"], [class*="instrument-item"]')
                    for item in items:
                        text = await item.text_content()
                        if text and instrument_name.replace("-OTC", "") in text.upper():
                            await self._human_move_to_element(item)
                            await item.click()
                            asset_found = True
                            await asyncio.sleep(random.uniform(1.0, 2.5))
                            break
                except Exception:
                    pass

            if not asset_found:
                logger.warning(f"[Trade] No se pudo navegar a {instrument_name}")
                return False

            logger.info(f"[Trade] Navegado a {instrument_name}")
            return True

        except Exception as e:
            logger.error(f"[Trade] Error navegando a {instrument_name}: {e}")
            return False

    async def _get_current_asset(self):
        """Obtiene el nombre del activo actualmente seleccionado."""
        try:
            sel = self._selectors["trading"]
            for selector in [sel["asset_selector_button"],
                             '[class*="current-asset"]', '[class*="asset-name"]']:
                try:
                    el = await self._page.wait_for_selector(selector, timeout=2000)
                    if el:
                        text = await el.text_content()
                        if text:
                            return text.strip()
                except Exception:
                    continue
            return None
        except Exception:
            return None

    async def _set_amount(self, amount):
        """Establece el monto de la operacion."""
        try:
            sel = self._selectors["trading"]

            # Buscar input de amount
            amount_input = None
            for selector in [sel["amount_input"],
                             'input[class*="amount"]', 'input[name*="amount"]',
                             'input[class*="investment"]', 'input[class*="stake"]']:
                try:
                    amount_input = await self._page.wait_for_selector(selector, timeout=3000)
                    if amount_input:
                        break
                except Exception:
                    continue

            if not amount_input:
                logger.warning("[Trade] No se encontro input de amount")
                return False

            # Click, limpiar y escribir el monto
            await self._human_move_to_element(amount_input)
            await amount_input.click()
            await asyncio.sleep(random.uniform(0.2, 0.5))

            # Seleccionar todo y borrar
            await self._page.keyboard.press("Control+a")
            await asyncio.sleep(0.1)

            # Escribir monto
            await self._human_type(amount_input, f"{amount:.2f}")
            await asyncio.sleep(random.uniform(0.3, 0.8))

            # Tab para salir del campo
            await self._page.keyboard.press("Tab")
            await asyncio.sleep(0.3)

            return True

        except Exception as e:
            logger.error(f"[Trade] Error estableciendo monto: {e}")
            return False

    async def _set_expiration(self, expiration_minutes):
        """Establece el tiempo de expiracion."""
        if expiration_minutes == 1:
            # 1 minuto es generalmente el default para opciones binarias turbo
            # No necesitamos cambiar nada en la mayoria de los casos
            return True

        try:
            sel = self._selectors["trading"]
            for selector in [sel["expiration_selector"],
                             '[class*="expiration"]', '[class*="expiry"]']:
                try:
                    el = await self._page.wait_for_selector(selector, timeout=3000)
                    if el:
                        await el.click()
                        await asyncio.sleep(0.5)

                        # Buscar la opcion de 1 minuto
                        for min_selector in [sel["expiration_1min"],
                                             'button:has-text("1 min")',
                                             'text="1m"', 'text="1 min"']:
                            try:
                                opt = await self._page.wait_for_selector(min_selector, timeout=2000)
                                if opt:
                                    await opt.click()
                                    await asyncio.sleep(0.5)
                                    return True
                            except Exception:
                                continue
                except Exception:
                    continue
        except Exception:
            pass

        return True  # Default es 1 min generalmente

    async def _click_call_or_put(self, direction):
        """Hace click en CALL o PUT con movimiento de mouse realista."""
        try:
            sel = self._selectors["trading"]

            if direction.lower() == "call":
                selectors = [sel["call_button"],
                             'button:has-text("CALL")', '[class*="call-btn"]',
                             '[class*="btn-call"]', '[class*="CallButton"]',
                             '[class*="up-btn"]', 'button[class*="green"]']
            else:
                selectors = [sel["put_button"],
                             'button:has-text("PUT")', '[class*="put-btn"]',
                             '[class*="btn-put"]', '[class*="PutButton"]',
                             '[class*="down-btn"]', 'button[class*="red"]']

            for selector in selectors:
                try:
                    el = await self._page.wait_for_selector(selector, timeout=3000)
                    if el:
                        # Verificar que es visible y clickeable
                        is_visible = await el.is_visible()
                        if not is_visible:
                            continue

                        # Movimiento de mouse hacia el boton (HUMANO)
                        await self._human_move_to_element(el)

                        # Pequena hesitacion antes del click
                        await asyncio.sleep(random.uniform(0.05, 0.2))

                        # CLICK REAL
                        await el.click()

                        logger.info(f"[Trade] Click en {direction.upper()} ejecutado")
                        return True
                except Exception:
                    continue

            logger.error(f"[Trade] No se encontro boton {direction.upper()}")
            return False

        except Exception as e:
            logger.error(f"[Trade] Error en click {direction}: {e}")
            return False

    async def _wait_for_trade_confirmation(self, timeout=10):
        """Espera la confirmacion de la operacion."""
        try:
            sel = self._selectors["trading"]

            # Buscar popup de confirmacion
            for selector in [sel["trade_confirmation"],
                             '[class*="confirmation"]', '[class*="result"]',
                             '[class*="trade-result"]', '[class*="order-open"]']:
                try:
                    el = await self._page.wait_for_selector(selector, timeout=timeout * 1000)
                    if el:
                        await asyncio.sleep(1.0)
                        # Cerrar la confirmacion si es necesario
                        for close_sel in [sel["close_confirmation"],
                                          'button:has-text("OK")',
                                          'button:has-text("Close")']:
                            try:
                                close_btn = await self._page.wait_for_selector(close_sel, timeout=2000)
                                if close_btn:
                                    await close_btn.click()
                                    await asyncio.sleep(0.5)
                                    break
                            except Exception:
                                continue
                        return True
                except Exception:
                    continue

            # Si no hay confirmacion visible, asumir que la orden fue colocada
            return True

        except Exception:
            return True

    # ============================================================
    # CANDLE DATA VIA INTERNAL API
    # ============================================================
    async def _fetch_candles_via_browser(self, instrument_name, interval, count, endtime):
        """Obtiene datos de velas usando el navegador como proxy.
        Usa page.evaluate() para hacer fetch desde el navegador real,
        lo que significa que la request tiene TLS, cookies y headers reales."""

        try:
            # Intentar via API interna del navegador
            candles = await self._page.evaluate("""
                async (params) => {
                    try {
                        const url = `/api/candles?active_id=${params.active_id}&size=${params.interval}&count=${params.count}&endtime=${params.endtime}`;
                        const response = await fetch(url, {
                            credentials: 'include',
                            headers: {
                                'Accept': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        });
                        if (response.ok) {
                            const data = await response.json();
                            return data;
                        }
                    } catch (e) {}

                    // Fallback: buscar datos en el WebSocket cache del navegador
                    try {
                        const url2 = `/api/candles/${params.active_id}/${params.interval}?count=${params.count}`;
                        const response2 = await fetch(url2, { credentials: 'include' });
                        if (response2.ok) {
                            return await response2.json();
                        }
                    } catch (e) {}

                    return null;
                }
            """, {
                "active_id": instrument_name,
                "interval": interval,
                "count": count,
                "endtime": endtime
            })

            if candles and isinstance(candles, list):
                return candles
            elif candles and isinstance(candles, dict):
                # Buscar el array de candles en la respuesta
                for key in ['candles', 'data', 'result', 'msg']:
                    if key in candles and isinstance(candles[key], list):
                        return candles[key]

            return None

        except Exception as e:
            logger.debug(f"[Candles] Error via browser fetch: {e}")
            return None

    # ============================================================
    # PUBLIC API - Drop-in replacement methods
    # ============================================================
    def connect(self):
        """Conecta a IQ Option usando navegador real.
        Returns: (bool, str|None) - Mismo formato que IQ_Option_Patched"""
        try:
            logger.info("[Connect] Iniciando conexion Playwright...")

            async def _do_connect():
                # Lanzar navegador
                if not await self._launch_browser():
                    return False, "Failed to launch browser"

                # Login
                check, reason = await self._login()
                if not check:
                    return False, reason

                return True, None

            result = self._bridge.run(_do_connect(), timeout=120)

            if result[0]:
                self._connected = True
                self._connect_time = time.time()
                self._reconnect_count = 0
                logger.info("[Connect] Conexion exitosa (Playwright Anti-Detection V5)")
            else:
                self._connected = False
                logger.error(f"[Connect] Fallo: {result[1]}")

            return result

        except Exception as e:
            logger.error(f"[Connect] Excepcion: {e}")
            self._connected = False
            return False, str(e)

    def check_connect(self):
        """Verifica si la conexion esta activa.
        Returns: bool"""
        if not self._connected:
            return False

        try:
            # Verificar que el navegador y la pagina siguen activos
            async def _check():
                try:
                    if not self._page or self._page.is_closed():
                        return False
                    # Verificar que no fuimos redirigidos al login
                    url = self._page.url
                    if "login" in url and "traderoom" not in url:
                        return False
                    # Verificar timesync via WS interceptor
                    if self._ws_interceptor.is_connected():
                        return True
                    # Si no hay WS, verificar que la pagina responde
                    title = await self._page.title()
                    return bool(title)
                except Exception:
                    return False

            return self._bridge.run(_check(), timeout=10)
        except Exception:
            return False

    def _ensure_connected(self, max_attempts=3):
        """Asegura que la conexion esta activa, reconecta si es necesario.
        Returns: bool"""
        if self.check_connect():
            return True

        for attempt in range(max_attempts):
            logger.warning(f"[Reconnect] Intento {attempt + 1}/{max_attempts}")
            try:
                # Intentar reconectar
                result = self.connect()
                if result[0]:
                    return True
            except Exception as e:
                logger.error(f"[Reconnect] Error: {e}")

            # Backoff con jitter
            backoff = min(2 ** attempt, 10) + random.uniform(1.0, 3.0)
            time.sleep(backoff)

        self._connected = False
        return False

    def get_all_ACTIVES_OPCODE(self):
        """Obtiene lista de instrumentos disponibles.
        Returns: dict - {instrument_name: active_id}"""
        try:
            # Intentar desde cache
            now = time.time()
            if self._actives_cache and (now - self._actives_cache_time) < 600:
                return self._actives_cache

            # Desde WS interceptor
            actives = self._ws_interceptor.get_actives()
            if actives:
                self._actives_cache = actives
                self._actives_cache_time = now
                return actives

            # Fallback: obtener via browser
            async def _get_actives():
                try:
                    result = await self._page.evaluate("""
                        async () => {
                            try {
                                const response = await fetch('/api/instruments', {
                                    credentials: 'include',
                                    headers: {'Accept': 'application/json'}
                                });
                                if (response.ok) {
                                    return await response.json();
                                }
                            } catch(e) {}
                            return null;
                        }
                    """)
                    return result
                except Exception:
                    return None

            result = self._bridge.run(_get_actives(), timeout=15)
            if result and isinstance(result, dict):
                self._actives_cache = result
                self._actives_cache_time = now
                return result
            elif result and isinstance(result, list):
                actives_dict = {}
                for item in result:
                    if isinstance(item, dict):
                        name = item.get("name", item.get("instrument", ""))
                        aid = item.get("id", item.get("active_id", ""))
                        if name:
                            actives_dict[name] = aid
                if actives_dict:
                    self._actives_cache = actives_dict
                    self._actives_cache_time = now
                    return actives_dict

            return self._actives_cache or {}

        except Exception as e:
            logger.error(f"[Actives] Error: {e}")
            return self._actives_cache or {}

    def get_candles(self, ACTIVES, interval, count, endtime):
        """Obtiene datos de velas OHLC.
        Args: ACTIVES (str), interval (int), count (int), endtime (int)
        Returns: list - Lista de candles"""
        try:
            # Intentar desde WS interceptor cache
            cached = self._ws_interceptor.get_candles(ACTIVES)
            if cached and len(cached) >= count:
                return cached[-count:]

            # Obtener via browser (TLS real, cookies reales)
            candles = self._bridge.run(
                self._fetch_candles_via_browser(ACTIVES, interval, count, endtime),
                timeout=30
            )

            if candles and isinstance(candles, list):
                return candles

            # Fallback: intentar via API directa con cookies del navegador
            async def _fetch_with_cookies():
                try:
                    cookies = await self._context.cookies()
                    cookie_dict = {c['name']: c['value'] for c in cookies}

                    # Construir URL de API
                    import urllib.request
                    url = f"https://iqoption.com/api/candles?active={ACTIVES}&size={interval}&count={count}&endtime={endtime}"
                    req = urllib.request.Request(url)
                    req.add_header('Cookie', '; '.join(f'{k}={v}' for k, v in cookie_dict.items()))
                    req.add_header('Accept', 'application/json')

                    with urllib.request.urlopen(req, timeout=10) as resp:
                        data = json.loads(resp.read())
                        if isinstance(data, dict):
                            for key in ['candles', 'data', 'result', 'msg']:
                                if key in data and isinstance(data[key], list):
                                    return data[key]
                        return None
                except Exception:
                    return None

            result = self._bridge.run(_fetch_with_cookies(), timeout=15)
            if result:
                return result

            return []

        except Exception as e:
            logger.error(f"[Candles] Error obteniendo velas para {ACTIVES}: {e}")
            return []

    def buy(self, price, ACTIVES, ACTION, expirations):
        """Ejecuta una operacion de trading via click real en el navegador.
        Args: price (float), ACTIVES (str), ACTION (str), expirations (int)
        Returns: (bool, str) - (exito, order_id o error_msg)"""
        try:
            self._trade_counter += 1
            order_id = f"pw_{int(time.time())}_{self._trade_counter}"

            # Registrar balance antes del trade
            pre_balance = self.get_balance()

            async def _do_buy():
                # 1. Navegar al activo
                if not await self._navigate_to_asset(ACTIVES):
                    return False, f"Asset {ACTIVES} not found"

                # 2. Establecer monto
                if not await self._set_amount(price):
                    # Si no se puede setear el monto via DOM, intentar alternativa
                    logger.warning("[Buy] No se pudo setear monto via DOM, continuando...")

                # 3. Establecer expiracion
                await self._set_expiration(expirations)

                # 4. Jitter humano antes del click (como IQ_Option_Patched)
                jitter = random.uniform(0.05, 0.6)
                await asyncio.sleep(jitter)

                # 5. Click en CALL o PUT
                if not await self._click_call_or_put(ACTION):
                    return False, f"{ACTION.upper()} button not found"

                # 6. Esperar confirmacion
                await self._wait_for_trade_confirmation(timeout=10)

                return True, order_id

            result = self._bridge.run(_do_buy(), timeout=60)

            if result[0]:
                # Registrar trade pendiente para check_win_v3
                with self._lock:
                    self._pending_trades[order_id] = {
                        "pre_balance": pre_balance,
                        "timestamp": time.time(),
                        "instrument": ACTIVES,
                        "direction": ACTION,
                        "amount": price,
                        "expiration": expirations,
                    }
                logger.info(f"[Buy] {ACTION.upper()} {ACTIVES} ${price:.2f} - Order: {order_id}")
            else:
                logger.error(f"[Buy] Fallo: {result[1]}")

            return result

        except Exception as e:
            logger.error(f"[Buy] Excepcion: {e}")
            return False, str(e)

    def check_win_v3(self, id_number, timeout=120):
        """Verifica el resultado de una operacion.
        Usa balance diff como metodo principal.
        Returns: float - Profit (positivo=win, negativo=loss)"""
        try:
            order_id = str(id_number)

            # Buscar en pending trades
            trade_info = None
            with self._lock:
                trade_info = self._pending_trades.pop(order_id, None)

            if not trade_info:
                logger.warning(f"[CheckWin] Trade {order_id} no encontrado en pendientes")
                return 0.0

            # Esperar que pase el tiempo de expiracion
            expiration_sec = trade_info.get("expiration", 1) * 60 + 5
            jitter = random.uniform(-3.0, 3.0)
            wait_time = expiration_sec + jitter

            logger.info(f"[CheckWin] Esperando {wait_time:.0f}s para resultado de {order_id}...")
            time.sleep(wait_time)

            # Metodo 1: Verificar via WS interceptor
            ws_result = self._ws_interceptor.get_trade_result(order_id)
            if ws_result is not None:
                logger.info(f"[CheckWin] Resultado WS: {ws_result}")
                return float(ws_result)

            # Metodo 2: Balance diff
            pre_balance = trade_info.get("pre_balance", 0)
            amount = trade_info.get("amount", 0)

            # Leer balance actual
            post_balance = self.get_balance()

            if pre_balance > 0 and post_balance > 0:
                diff = post_balance - pre_balance

                # Si la diferencia es significativa, es el resultado
                if abs(diff) > 0.01:
                    logger.info(f"[CheckWin] Balance diff: ${diff:.2f} (pre: ${pre_balance:.2f}, post: ${post_balance:.2f})")
                    return diff

            # Metodo 3: Si no se puede determinar, asumir perdida
            logger.warning(f"[CheckWin] No se pudo verificar resultado, asumiendo perdida")
            return -amount

        except Exception as e:
            logger.error(f"[CheckWin] Error: {e}")
            return -trade_info.get("amount", 0) if trade_info else 0.0

    def get_balance(self):
        """Obtiene el balance de la cuenta.
        Returns: float"""
        try:
            # Intentar desde WS interceptor (mas rapido)
            ws_balance = self._ws_interceptor.get_balance()
            if ws_balance > 0:
                self._last_balance_read = ws_balance
                return ws_balance

            # Leer del DOM
            async def _read():
                return await self._read_balance_from_dom()

            balance = self._bridge.run(_read(), timeout=10)
            if balance and balance > 0:
                self._last_balance_read = balance
                self._ws_interceptor._balance = balance
                return balance

            # Retornar ultimo balance conocido
            return self._last_balance_read

        except Exception as e:
            logger.debug(f"[Balance] Error: {e}")
            return self._last_balance_read

    def get_balance_safe(self):
        """Obtiene el balance con reintentos.
        Returns: float"""
        for attempt in range(3):
            try:
                balance = self.get_balance()
                if balance > 0:
                    return balance
            except Exception:
                pass
            time.sleep(random.uniform(1.0, 3.0))
        return self._last_balance_read

    def get_all_profit(self, force_refresh=False):
        """Obtiene datos de payout/profit de todos los instrumentos.
        Returns: dict"""
        try:
            now = time.time()

            # Usar cache si es reciente
            if not force_refresh and self._profit_cache and (now - self._profit_cache_time) < self._profit_cache_ttl:
                return self._profit_cache

            # Desde WS interceptor
            profit = self._ws_interceptor.get_profit()
            if profit:
                self._profit_cache = profit
                self._profit_cache_time = now
                return profit

            # Fallback: via browser
            async def _get_profit():
                try:
                    result = await self._page.evaluate("""
                        async () => {
                            try {
                                const response = await fetch('/api/profit', {
                                    credentials: 'include',
                                    headers: {'Accept': 'application/json'}
                                });
                                if (response.ok) return await response.json();
                            } catch(e) {}
                            return null;
                        }
                    """)
                    return result
                except Exception:
                    return None

            result = self._bridge.run(_get_profit(), timeout=15)
            if result:
                if isinstance(result, dict):
                    self._profit_cache = result
                elif isinstance(result, list):
                    profit_dict = {}
                    for item in result:
                        if isinstance(item, dict):
                            name = item.get("name", item.get("instrument", ""))
                            if name:
                                profit_dict[name] = item
                    if profit_dict:
                        self._profit_cache = profit_dict

                self._profit_cache_time = now
                return self._profit_cache

            return self._profit_cache or {}

        except Exception as e:
            logger.error(f"[Profit] Error: {e}")
            return self._profit_cache or {}

    def change_balance(self, Balance_MODE):
        """Cambia entre cuenta Practice y Real.
        Args: Balance_MODE (str) - "PRACTICE" o "REAL" """
        try:
            async def _switch():
                sel = self._selectors["dashboard"]

                if Balance_MODE.upper() == "PRACTICE":
                    # Buscar boton/toggle de Practice
                    for selector in [sel["practice_button"],
                                     'button:has-text("Practice")',
                                     '[class*="practice"]', '[class*="demo"]']:
                        try:
                            el = await self._page.wait_for_selector(selector, timeout=5000)
                            if el:
                                await self._human_move_to_element(el)
                                await el.click()
                                logger.info("[Account] Cambiado a PRACTICE")
                                await asyncio.sleep(2.0)
                                return True
                        except Exception:
                            continue
                else:
                    # Buscar boton/toggle de Real
                    for selector in [sel["real_button"],
                                     'button:has-text("Real")',
                                     '[class*="real-"]']:
                        try:
                            el = await self._page.wait_for_selector(selector, timeout=5000)
                            if el:
                                await self._human_move_to_element(el)
                                await el.click()
                                logger.info("[Account] Cambiado a REAL")
                                await asyncio.sleep(2.0)
                                return True
                        except Exception:
                            continue

                # Fallback: intentar toggle generico
                for selector in [sel["account_switch"],
                                 '[class*="account-switch"]',
                                 '[class*="toggle"]']:
                    try:
                        el = await self._page.wait_for_selector(selector, timeout=3000)
                        if el:
                            await self._human_move_to_element(el)
                            await el.click()
                            await asyncio.sleep(2.0)
                            return True
                    except Exception:
                        continue

                logger.warning(f"[Account] No se pudo cambiar a {Balance_MODE}")
                return False

            self._bridge.run(_switch(), timeout=30)

        except Exception as e:
            logger.error(f"[Account] Error: {e}")

    def get_server_timestamp(self):
        """Obtiene timestamp del servidor.
        Returns: float"""
        ts = self._ws_interceptor.get_server_timestamp()
        if ts > 0:
            return ts
        # Fallback: usar hora del navegador
        try:
            async def _get_time():
                return await self._page.evaluate("Date.now() / 1000")
            ts = self._bridge.run(_get_time(), timeout=5)
            if ts:
                return ts
        except Exception:
            pass
        return time.time()

    def get_async_order(self, id_number):
        """Obtiene informacion de una orden.
        Returns: dict"""
        # Buscar en WS interceptor
        result = self._ws_interceptor.get_trade_result(str(id_number))
        if result is not None:
            return {"id": id_number, "profit": result}

        # Buscar en pendientes
        with self._lock:
            trade = self._pending_trades.get(str(id_number))
            if trade:
                return {"id": id_number, "status": "pending", **trade}

        return {"id": id_number, "status": "unknown"}

    def close(self):
        """Cierra la conexion y el navegador."""
        try:
            self._connected = False
            self._stop_mouse_activity()

            async def _close():
                try:
                    if self._page and not self._page.is_closed():
                        await self._page.close()
                except Exception:
                    pass
                try:
                    if self._context:
                        await self._context.close()
                except Exception:
                    pass
                try:
                    if self._browser:
                        await self._browser.close()
                except Exception:
                    pass
                try:
                    if hasattr(self, '_playwright') and self._playwright:
                        await self._playwright.stop()
                except Exception:
                    pass

            try:
                self._bridge.run(_close(), timeout=15)
            except Exception:
                pass

            self._bridge.stop()

            logger.info("[Close] Navegador cerrado")

        except Exception as e:
            logger.debug(f"[Close] Error: {e}")

    # ============================================================
    # ACTIVITY SIMULATION - Actividad fuera de trading
    # ============================================================
    def simulate_deposit_visit(self):
        """Simula una visita a la pagina de deposito (actividad fuera de trading)."""
        try:
            async def _visit():
                sel = self._selectors["navigation"]
                for selector in [sel["deposit_link"],
                                 'a:has-text("Deposit")', 'button:has-text("Deposit")']:
                    try:
                        el = await self._page.wait_for_selector(selector, timeout=3000)
                        if el:
                            await self._human_move_to_element(el)
                            await el.click()
                            await asyncio.sleep(random.uniform(3.0, 8.0))
                            # Volver atras
                            await self._page.go_back()
                            await asyncio.sleep(random.uniform(1.0, 3.0))
                            return
                    except Exception:
                        continue
            self._bridge.run(_visit(), timeout=20)
        except Exception:
            pass

    def simulate_settings_visit(self):
        """Simula una visita a la pagina de ajustes."""
        try:
            async def _visit():
                sel = self._selectors["navigation"]
                for selector in [sel["settings_link"],
                                 'a:has-text("Settings")', '[class*="settings"]']:
                    try:
                        el = await self._page.wait_for_selector(selector, timeout=3000)
                        if el:
                            await self._human_move_to_element(el)
                            await el.click()
                            await asyncio.sleep(random.uniform(3.0, 8.0))
                            await self._page.go_back()
                            await asyncio.sleep(random.uniform(1.0, 3.0))
                            return
                    except Exception:
                        continue
            self._bridge.run(_visit(), timeout=20)
        except Exception:
            pass

    def simulate_scroll_chart(self):
        """Simula scroll en el grafico (como un usuario revisando el historial)."""
        try:
            async def _scroll():
                # Click en el area del grafico
                chart_area = await self._page.query_selector('[class*="chart"], [class*="Chart"], canvas')
                if chart_area:
                    box = await chart_area.bounding_box()
                    if box:
                        # Mover mouse al centro del grafico
                        center_x = box['x'] + box['width'] / 2
                        center_y = box['y'] + box['height'] / 2
                        await self._page.mouse.move(center_x, center_y, steps=10)

                        # Scroll horizontal (como viendo historial)
                        for _ in range(random.randint(2, 5)):
                            await self._page.mouse.wheel(random.randint(-200, -100), 0)
                            await asyncio.sleep(random.uniform(0.3, 1.0))

                        # Scroll de vuelta
                        for _ in range(random.randint(1, 3)):
                            await self._page.mouse.wheel(random.randint(100, 200), 0)
                            await asyncio.sleep(random.uniform(0.3, 0.8))
            self._bridge.run(_scroll(), timeout=15)
        except Exception:
            pass

    # ============================================================
    # SELECTOR DISCOVERY MODE
    # ============================================================
    def discover_selectors(self):
        """Modo de descubrimiento: mapea todos los elementos interactivos
        del dashboard y los guarda en selector_map_discovered.json.
        Ejecutar DESPUES de conectar exitosamente."""
        try:
            async def _discover():
                result = {}

                # Obtener todos los elementos interactivos
                elements = await self._page.evaluate("""
                    () => {
                        const elements = [];
                        const tags = ['button', 'input', 'select', 'a', '[role="button"]'];
                        for (const tag of tags) {
                            for (const el of document.querySelectorAll(tag)) {
                                const rect = el.getBoundingClientRect();
                                if (rect.width > 0 && rect.height > 0) {
                                    elements.push({
                                        tag: el.tagName,
                                        id: el.id,
                                        classes: el.className?.substring?.(0, 100),
                                        text: el.textContent?.substring?.(0, 80),
                                        type: el.type,
                                        name: el.name,
                                        placeholder: el.placeholder,
                                        href: el.href,
                                        role: el.role || el.getAttribute('role'),
                                        x: Math.round(rect.x),
                                        y: Math.round(rect.y),
                                        width: Math.round(rect.width),
                                        height: Math.round(rect.height),
                                    });
                                }
                            }
                        }
                        return elements;
                    }
                """)

                result["elements"] = elements
                result["url"] = self._page.url
                result["timestamp"] = datetime.now().isoformat()

                # Guardar
                discover_file = os.path.join(os.path.dirname(__file__), "selector_map_discovered.json")
                with open(discover_file, "w") as f:
                    json.dump(result, f, indent=2)

                logger.info(f"[Discovery] {len(elements)} elementos encontrados guardados en {discover_file}")
                return len(elements)

            return self._bridge.run(_discover(), timeout=30)

        except Exception as e:
            logger.error(f"[Discovery] Error: {e}")
            return 0

    # ============================================================
    # SCREENSHOT & DEBUG
    # ============================================================
    def take_screenshot(self, filename="screenshot.png"):
        """Toma una captura de pantalla del navegador."""
        try:
            filepath = os.path.join(os.path.dirname(__file__), filename)
            async def _screenshot():
                await self._page.screenshot(path=filepath, full_page=False)
                return filepath
            return self._bridge.run(_screenshot(), timeout=15)
        except Exception as e:
            logger.error(f"[Screenshot] Error: {e}")
            return None

    def get_page_html(self):
        """Obtiene el HTML de la pagina actual (para debug)."""
        try:
            async def _html():
                return await self._page.content()
            return self._bridge.run(_html(), timeout=15)
        except Exception as e:
            logger.error(f"[Debug] Error: {e}")
            return None
