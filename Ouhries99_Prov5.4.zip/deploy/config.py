"""
Sistema Ouhries V5.4 - Configuracion Global (Anti-Detection)
Capital de operacion, Niveles de interes compuesto, stops.
Payout 87+ automatico, expiracion siempre 1.
Estrategia V3 con ADX >= 25 y calidad >= 88%.
Notificaciones Telegram con emojis.
Anti-Detection: broker_delay random, delays humanos, human_action_pct.
"""
import json
import os

CONFIG_FILE = "config.json"

DEFAULT_CONFIG = {
    # Cuenta
    "email": "deadly.x@hotmail.com",
    "password": "Shinigami1",
    "account_mode": "PRACTICE",

    # Gestion - Capital y Niveles
    "capital_operacion": 2.50,
    "niveles": 0,
    "disable_niveles": False,
    "stop_win": 1.0,
    "stop_loss": 1.0,
    # stop_loss_pct_balance eliminado - stop_loss es manual sin cap

    # Sub-nivel (interes compuesto) - 0 = sin reinvertir
    "sublevel_profit_pct": 35,
    "sublevel_min_votes": 3,
    "sublevel_payout_min": 87,

    # Estrategia (OTC V1 es la default - optimizada para OTC)
    # Solo OTCEspecializada V1 (principal) y V2.1 Mejorada (backup)
    "min_strategy_votes": 4,
    "use_strategy_v2": False,
    "use_strategy_otc": True,
    "min_signal_quality": 88,
    "payout_min": 86,

    # Maximo de operaciones por sesion (0 = sin limite)
    "max_trades": 0,

    # Scanner
    "scanner_max_instruments": 35,

    # Delays anti-deteccion (segundos) - AUMENTADOS para comportamiento humano
    "delay_between_ops_min": 30,
    "delay_between_ops_max": 90,
    "delay_thinking_min": 3,
    "delay_thinking_max": 8,
    "delay_scanner_min": 0.8,
    "delay_scanner_max": 2.5,

    # Anti-deteccion - AHORA FUNCIONAL
    "human_action_pct": 15,

    # Telegram Notificaciones
    "telegram_enabled": True,
    "telegram_token": "8580761533:AAEunrfQWHKCNbN5wNENr0hba6qZ0TFL_5c",
    "telegram_chat_id": "7985764642",

    # Repetir Win
    "repeat_win": False,
    "broker_delay_enabled": True,
    "broker_delay": 4.0,
}


def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                saved = json.load(f)
            merged = {**DEFAULT_CONFIG, **saved}
            return merged
        except Exception:
            return DEFAULT_CONFIG.copy()
    return DEFAULT_CONFIG.copy()


def save_config(cfg):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)
