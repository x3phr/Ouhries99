"""
Sistema Ouhries V5.4 - IQ Option API Patched Wrapper (Anti-Detection)
Parchea la libreria iqoptionapi v6.8.9.1 para funcionar al 100%:
- TLS FINGERPRINT MASKING con curl_cffi (impersona Chrome real)
- User-Agent spoofing con rotacion de Chrome realista
- Headers de navegador real en TODAS las peticiones
- Session rotation periodica
- WebSocket anti-detection headers
- Timeouts en TODAS las operaciones bloqueantes
- Auto-reconexion con backoff exponencial
- ACTIVES cache auto-actualizado
- check_win_v3 con timeout y fallback a balance
- get_candles con timeout y reintentos
- buy con reintento automatico
- get_balance con retry
- get_all_profit cacheado con TTL
- Noise browsing: balance checks sin operar (comportamiento humano)
"""

import time
import logging
import threading
import random
import traceback
from datetime import datetime

from iqoptionapi.stable_api import IQ_Option
import iqoptionapi.global_value as global_value
import iqoptionapi.constants as OP_code

# ============================================================
# ANTI-DETECTION: curl_cffi for TLS fingerprint masking
# ============================================================
# This is the MOST CRITICAL anti-detection layer.
# Python's `requests` library has a distinctive TLS fingerprint (JA3 hash)
# that IQ Option can easily detect. curl_cffi impersonates Chrome's exact
# TLS handshake, cipher suites, and extensions - making the HTTP traffic
# indistinguishable from a real Chrome browser.
#
# If curl_cffi is not installed, falls back to standard requests with
# browser headers (less secure but still functional).
CURL_CFFI_AVAILABLE = False
try:
    from curl_cffi import requests as curl_requests
    CURL_CFFI_AVAILABLE = True
    logger_preflight = logging.getLogger("iq_patched")
    logger_preflight.info("[AntiDetect] curl_cffi DISPONIBLE - TLS fingerprint masking ACTIVO")
except ImportError:
    curl_requests = None

# ============================================================
# ANTI-DETECTION: WebSocket header patching
# ============================================================
# The iqoptionapi uses websocket-client to connect to IQ Option's WebSocket.
# By default, websocket-client sends a Python-specific User-Agent header
# that is an instant detection signal. We patch it to send Chrome-like headers.
try:
    import websocket
    _original_websocket_init = websocket.WebSocketApp.__init__
    
    def _patched_ws_init(self, url, **kwargs):
        """Patched WebSocketApp.__init__ that injects browser-like headers."""
        # Add browser-like headers to WebSocket connection
        browser_ws_headers = {
            "User-Agent": _get_random_ua(),
            "Origin": "https://iqoption.com",
            "Sec-WebSocket-Version": "13",
            "Sec-WebSocket-Extensions": "permessage-deflate; client_max_window_bits",
        }
        if "header" in kwargs and kwargs["header"]:
            if isinstance(kwargs["header"], dict):
                kwargs["header"].update(browser_ws_headers)
            elif isinstance(kwargs["header"], list):
                for key, value in browser_ws_headers.items():
                    kwargs["header"].append(f"{key}: {value}")
        else:
            kwargs["header"] = browser_ws_headers
        _original_websocket_init(self, url, **kwargs)
    
    websocket.WebSocketApp.__init__ = _patched_ws_init
    logger_ws = logging.getLogger("iq_patched")
    logger_ws.info("[AntiDetect] WebSocket headers patched con Origin de navegador real")
except Exception as e:
    logging.getLogger("iq_patched").warning(f"[AntiDetect] Error patcheando WebSocket: {e}")

logger = logging.getLogger("iq_patched")

DEFAULT_TIMEOUT_CANDLE = 30
DEFAULT_TIMEOUT_BUY = 10
DEFAULT_TIMEOUT_CHECK_WIN = 120
DEFAULT_TIMEOUT_BALANCE = 15
DEFAULT_TIMEOUT_PROFIT = 60
DEFAULT_TIMEOUT_ACTIVES = 30
DEFAULT_TIMEOUT_CONNECT = 30
MAX_RECONNECT_ATTEMPTS = 5
RECONNECT_BACKOFF_BASE = 2
# FIX: cache de resolucion de nombres OTC
_active_name_cache = {}  # normalized_name -> raw_api_name

# ============================================================
# ANTI-DETECTION: Realistic Chrome User-Agent rotation
# ============================================================
# These are real Chrome User-Agents from different versions/platforms
# Updated regularly to match current browser market share
CHROME_USER_AGENTS = [
    # Chrome 120+ on Windows 10/11
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    # Chrome on macOS
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    # Chrome on Windows 8.1
    "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    # Edge (Chromium-based) - also common
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0",
]

# Realistic browser headers that Chrome sends with every request
# These make the HTTP traffic look like a real browser session
BROWSER_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Accept-Language": "en-US,en;q=0.9,es;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Cache-Control": "max-age=0",
    "sec-ch-ua": '"Not A(Brand";v="99", "Google Chrome";v="122", "Chromium";v="122"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
}

# Session rotation interval (seconds) - refresh session every 30-60 minutes
SESSION_ROTATION_MIN = 1800  # 30 min
SESSION_ROTATION_MAX = 3600  # 60 min


def _get_random_ua():
    """Return a random Chrome User-Agent string."""
    return random.choice(CHROME_USER_AGENTS)


def _inject_browser_headers(session):
    """Inject realistic browser headers into a requests.Session.
    This replaces the default python-requests headers that are a dead giveaway."""
    if session is None:
        return
    # Set User-Agent (most critical for detection)
    session.headers["User-Agent"] = _get_random_ua()
    # Set all browser-like headers
    for key, value in BROWSER_HEADERS.items():
        session.headers[key] = value
    # Remove python-requests default headers that expose the library
    for remove_key in ["Accept-Encoding"]:
        if remove_key in session.headers:
            pass  # Already set above with browser version


def _patch_api_session(api):
    """Patch an IQ_Option API instance's session with browser headers AND
    TLS fingerprint masking via curl_cffi if available.
    
    TLS fingerprint masking is the most critical anti-detection measure:
    - Python's requests library has a known JA3 fingerprint that IQ Option can detect
    - curl_cffi replaces the HTTP transport to impersonate Chrome's exact TLS handshake
    - This makes the traffic indistinguishable from a real Chrome browser at the network level
    """
    try:
        if hasattr(api, 'session') and api.session is not None:
            # Layer 1: TLS fingerprint masking (MOST CRITICAL)
            if CURL_CFFI_AVAILABLE and api.session is not None:
                try:
                    # Replace the requests.Session with curl_cffi Session
                    # that impersonates Chrome's TLS fingerprint
                    old_session = api.session
                    ua = old_session.headers.get("User-Agent", _get_random_ua())
                    cookies = dict(old_session.cookies)
                    
                    # Create curl_cffi session impersonating Chrome
                    # This gives us the EXACT same TLS fingerprint as Chrome
                    new_session = curl_requests.Session(impersonate="chrome120")
                    
                    # Copy over browser headers
                    new_session.headers["User-Agent"] = ua
                    for key, value in BROWSER_HEADERS.items():
                        new_session.headers[key] = value
                    
                    # Copy cookies from old session
                    for name, value in cookies.items():
                        new_session.cookies.set(name, value)
                    
                    # Replace the session
                    api.session = new_session
                    logger.info("[AntiDetect] TLS FINGERPRINT MASKING ACTIVO - Session reemplazada con curl_cffi (Chrome 120)")
                except Exception as e:
                    logger.warning(f"[AntiDetect] curl_cffi session replacement fallo, usando headers normales: {e}")
                    _inject_browser_headers(api.session)
            else:
                # Fallback: just inject browser headers
                _inject_browser_headers(api.session)
                if not CURL_CFFI_AVAILABLE:
                    logger.warning("[AntiDetect] curl_cffi NO disponible - TLS fingerprint NO enmascarado (instalar: pip install curl_cffi)")
                else:
                    logger.info("[AntiDetect] Session headers patched con User-Agent de navegador real")
    except Exception as e:
        logger.warning(f"[AntiDetect] Error patcheando session: {e}")


class IQ_Option_Patched:
    def __init__(self, email, password):
        self._email = email
        self._password = password
        self._api = IQ_Option(email, password)
        self._lock = threading.Lock()
        self._connected = False
        self._actives_cache = {}
        self._actives_cache_time = 0
        self._profit_cache = None
        self._profit_cache_time = 0
        self._profit_cache_ttl = 300
        self._reconnect_count = 0
        self._last_connect_time = 0
        self._last_session_refresh = 0
        self._next_rotation = random.uniform(SESSION_ROTATION_MIN, SESSION_ROTATION_MAX)
        # Patch the initial session immediately
        _patch_api_session(self._api)

    def __getattr__(self, name):
        return getattr(self._api, name)

    def _maybe_rotate_session(self):
        """Periodically rotate User-Agent and refresh headers to avoid pattern detection.
        Also rotates curl_cffi impersonation if available.
        Called before each major operation (buy, scan, etc.)"""
        now = time.time()
        if (now - self._last_session_refresh) > self._next_rotation:
            try:
                # Rotate User-Agent and optionally curl_cffi impersonation
                if hasattr(self._api, 'session') and self._api.session is not None:
                    new_ua = _get_random_ua()
                    self._api.session.headers["User-Agent"] = new_ua
                    # Also rotate sec-ch-ua to match
                    chrome_version = new_ua.split("Chrome/")[1].split(" ")[0] if "Chrome/" in new_ua else "122"
                    self._api.session.headers["sec-ch-ua"] = f'"Not A(Brand";v="99", "Google Chrome";v="{chrome_version}", "Chromium";v="{chrome_version}"'
                    # Vary Accept-Language slightly
                    languages = [
                        "en-US,en;q=0.9,es;q=0.8",
                        "en-US,en;q=0.9",
                        "en-US,en;q=0.9,es;q=0.8,pt;q=0.7",
                        "en,en-US;q=0.9,es;q=0.8",
                    ]
                    self._api.session.headers["Accept-Language"] = random.choice(languages)
                    
                    # Anti-Detection: Rotate curl_cffi impersonation profile
                    # This changes the TLS fingerprint entirely, like switching browsers
                    if CURL_CFFI_AVAILABLE and isinstance(self._api.session, curl_requests.Session):
                        try:
                            # Rotate between Chrome versions for TLS fingerprint diversity
                            profiles = ["chrome120", "chrome121", "chrome122", "chrome116", "chrome119"]
                            new_profile = random.choice(profiles)
                            old_session = self._api.session
                            # Create new session with different impersonation
                            new_session = curl_requests.Session(impersonate=new_profile)
                            # Copy headers
                            for key, value in old_session.headers.items():
                                new_session.headers[key] = value
                            # Copy cookies
                            for cookie in old_session.cookies.jar:
                                new_session.cookies.set(cookie.name, cookie.value)
                            self._api.session = new_session
                            logger.info(f"[AntiDetect] TLS fingerprint rotado -> {new_profile}")
                        except Exception as e:
                            logger.warning(f"[AntiDetect] Error rotando TLS fingerprint: {e}")
                    
                    logger.info(f"[AntiDetect] Session rotada - nuevo UA: Chrome/{chrome_version}")
                self._last_session_refresh = now
                self._next_rotation = random.uniform(SESSION_ROTATION_MIN, SESSION_ROTATION_MAX)
            except Exception as e:
                logger.warning(f"[AntiDetect] Error rotando session: {e}")

    def connect(self):
        """Connect con TIMEOUT y ANTI-DETECTION headers."""
        for attempt in range(MAX_RECONNECT_ATTEMPTS):
            try:
                logger.info(f"[Patched] Connect intento {attempt + 1}/{MAX_RECONNECT_ATTEMPTS}")
                try:
                    self._api.close()
                except Exception:
                    pass

                # FIX: Crear API y conectar CON TIMEOUT + Anti-Detection
                api_instance = IQ_Option(self._email, self._password)
                # PATCH: Inject browser headers BEFORE connecting
                _patch_api_session(api_instance)

                connect_result = [False, "Timeout"]
                connect_error = [None]

                def _do_connect(api_inst, result, error):
                    try:
                        check, reason = api_inst.connect()
                        result[0] = check
                        result[1] = reason
                    except Exception as e:
                        error[0] = e
                        result[0] = False
                        result[1] = str(e)

                t = threading.Thread(target=_do_connect, args=(api_instance, connect_result, connect_error), daemon=True)
                t.start()
                t.join(timeout=DEFAULT_TIMEOUT_CONNECT)

                if t.is_alive():
                    # Thread sigue vivo = TIMEOUT
                    logger.warning(f"[Patched] Connect TIMEOUT ({DEFAULT_TIMEOUT_CONNECT}s) en intento {attempt + 1}")
                    try:
                        api_instance.close()
                    except Exception:
                        pass
                    if attempt < MAX_RECONNECT_ATTEMPTS - 1:
                        backoff = min(RECONNECT_BACKOFF_BASE ** attempt, 8)
                        # Add random jitter to backoff
                        backoff += random.uniform(0.5, 2.0)
                        logger.info(f"[Patched] Reintentando en {backoff:.1f}s...")
                        time.sleep(backoff)
                    continue

                if connect_error[0]:
                    raise connect_error[0]

                if connect_result[0]:
                    self._api = api_instance
                    self._connected = True
                    self._reconnect_count = 0
                    self._last_connect_time = time.time()
                    self._last_session_refresh = time.time()
                    # PATCH: Re-apply browser headers after successful connect
                    _patch_api_session(self._api)
                    try:
                        self._update_actives_safe()
                    except Exception as e:
                        logger.warning(f"[Patched] Error actualizando ACTIVES: {e}")
                    logger.info("[Patched] Conexion exitosa (Anti-Detection activo)")
                    return True, None
                else:
                    self._api = api_instance
                    logger.warning(f"[Patched] Connect fallo: {connect_result[1]}")
                    if attempt < MAX_RECONNECT_ATTEMPTS - 1:
                        backoff = min(RECONNECT_BACKOFF_BASE ** attempt, 8)
                        backoff += random.uniform(0.5, 2.0)
                        logger.info(f"[Patched] Reintentando en {backoff:.1f}s...")
                        time.sleep(backoff)
            except Exception as e:
                logger.error(f"[Patched] Connect excepcion: {e}")
                if attempt < MAX_RECONNECT_ATTEMPTS - 1:
                    backoff = min(RECONNECT_BACKOFF_BASE ** attempt, 8)
                    backoff += random.uniform(0.5, 2.0)
                    time.sleep(backoff)
        self._connected = False
        return False, "Max reintentos alcanzado"

    def check_connect(self):
        try:
            if global_value.check_websocket_if_connect in (0, None):
                return False
            try:
                ts = self._api.get_server_timestamp()
                if ts and ts > 0:
                    return True
            except Exception:
                pass
            return bool(global_value.check_websocket_if_connect)
        except Exception:
            return False

    def _ensure_connected(self, max_attempts=3):
        if self.check_connect():
            self._connected = True
            # Anti-detection: rotate session if needed
            self._maybe_rotate_session()
            return True
        logger.warning("[Patched] Conexion perdida, reconectando...")
        for attempt in range(max_attempts):
            try:
                check, reason = self.connect()
                if check:
                    try:
                        if hasattr(self, '_last_balance_mode'):
                            self._api.change_balance(self._last_balance_mode)
                    except Exception:
                        pass
                    return True
            except Exception as e:
                logger.error(f"[Patched] Reconexion intento {attempt + 1}: {e}")
            backoff = RECONNECT_BACKOFF_BASE ** attempt
            backoff += random.uniform(0.5, 1.5)
            time.sleep(backoff)
        logger.error("[Patched] No se pudo reconectar")
        return False

    def _update_actives_safe(self):
        try:
            old_actives = dict(OP_code.ACTIVES)
            def _do_update():
                try:
                    self._api.update_ACTIVES_OPCODE()
                except Exception as e:
                    logger.warning(f"[Patched] update_ACTIVES_OPCODE fallo: {e}")
            t = threading.Thread(target=_do_update, daemon=True)
            t.start()
            t.join(timeout=DEFAULT_TIMEOUT_ACTIVES)
            if len(OP_code.ACTIVES) > len(old_actives):
                self._actives_cache = dict(OP_code.ACTIVES)
                self._actives_cache_time = time.time()
                logger.info(f"[Patched] ACTIVES actualizado: {len(OP_code.ACTIVES)} instrumentos")
            elif len(OP_code.ACTIVES) > 0:
                self._actives_cache = dict(OP_code.ACTIVES)
                self._actives_cache_time = time.time()
        except Exception as e:
            logger.warning(f"[Patched] Error actualizando ACTIVES: {e}")

    def get_all_ACTIVES_OPCODE(self):
        if self._actives_cache and (time.time() - self._actives_cache_time) < 600:
            return self._actives_cache
        try:
            actives = self._api.get_all_ACTIVES_OPCODE()
            if actives and len(actives) > 0:
                self._actives_cache = actives
                self._actives_cache_time = time.time()
                return actives
        except Exception as e:
            logger.warning(f"[Patched] get_all_ACTIVES_OPCODE fallo: {e}")
        try:
            all_profit = self.get_all_profit()
            if all_profit:
                actives_from_profit = {}
                for name in all_profit.keys():
                    actives_from_profit[name] = name
                if actives_from_profit:
                    self._actives_cache = actives_from_profit
                    self._actives_cache_time = time.time()
                    logger.info(f"[Patched] ACTIVES desde profit: {len(actives_from_profit)} instrumentos")
                    return actives_from_profit
        except Exception as e:
            logger.warning(f"[Patched] get_all_profit fallback fallo: {e}")
        if self._actives_cache:
            return self._actives_cache
        return OP_code.ACTIVES

    def get_candles(self, ACTIVES, interval, count, endtime):
        """Get candles con resolucion de nombre OTC y reintentos."""
        # Anti-detection: rotate session if needed before heavy API calls
        self._maybe_rotate_session()
        
        # Probar multiples variaciones del nombre del activo
        norm = ACTIVES.upper().replace("-", "").replace("_", "")
        name_variations = [ACTIVES]
        if norm in _active_name_cache:
            name_variations.insert(0, _active_name_cache[norm])
        name_variations.extend([
            ACTIVES.upper(), ACTIVES.lower(),
            ACTIVES.replace("-OTC", "_otc"), ACTIVES.replace("-otc", "_otc"),
            ACTIVES.replace("_otc", "-OTC"), ACTIVES.replace("-OTC", "otc"),
        ])
        seen = set(); unique_variations = []
        for n in name_variations:
            if n not in seen: seen.add(n); unique_variations.append(n)

        for name in unique_variations:
            for attempt in range(3):
                try:
                    if not self._ensure_connected():
                        time.sleep(1)
                        continue
                    result = [None]
                    error = [None]
                    def _worker(n=name):
                        try:
                            result[0] = self._api.get_candles(n, interval, count, endtime)
                        except Exception as e:
                            error[0] = e
                    t = threading.Thread(target=_worker, daemon=True)
                    t.start()
                    t.join(timeout=DEFAULT_TIMEOUT_CANDLE)
                    if t.is_alive():
                        logger.warning(f"[Patched] get_candles TIMEOUT para {name}")
                        self._ensure_connected()
                        continue
                    if error[0]:
                        raise error[0]
                    if result[0] is not None and len(result[0]) > 0:
                        if name != ACTIVES:
                            _active_name_cache[norm] = name
                        return result[0]
                except KeyError:
                    self._update_actives_safe()
                    break
                except Exception as e:
                    logger.warning(f"[Patched] get_candles error para {name}: {e}")
                    break
        logger.error(f"[Patched] get_candles FALLO para {ACTIVES} despues de todos los intentos")
        return None

    def buy(self, price, ACTIVES, ACTION, expirations):
        """Buy con anti-detection jitter: add small random delay before sending order
        to avoid perfectly-timed trade patterns."""
        # Anti-detection: rotate session before buy
        self._maybe_rotate_session()
        
        # Anti-detection: Add small random jitter (0.1-0.8s) before buy
        # This makes each trade have slightly different timing, like a human clicking
        jitter = random.uniform(0.1, 0.8)
        time.sleep(jitter)
        
        # FIX: No bloquear por ACTIVES check
        try:
            if ACTIVES not in OP_code.ACTIVES:
                self._update_actives_safe()
        except Exception:
            pass
        for attempt in range(3):
            try:
                if not self._ensure_connected():
                    logger.warning(f"[Patched] Sin conexion para buy (intento {attempt + 1})")
                    time.sleep(2)
                    continue
                result = [None, None]
                error = [None]
                def _worker():
                    try:
                        result[0], result[1] = self._api.buy(price, ACTIVES, ACTION, expirations)
                    except Exception as e:
                        error[0] = e
                t = threading.Thread(target=_worker, daemon=True)
                t.start()
                t.join(timeout=DEFAULT_TIMEOUT_BUY)
                if t.is_alive():
                    logger.warning(f"[Patched] buy TIMEOUT ({DEFAULT_TIMEOUT_BUY}s)")
                    self._ensure_connected()
                    continue
                if error[0]:
                    raise error[0]
                if result[0] is not None:
                    return result[0], result[1]
            except KeyError as e:
                logger.warning(f"[Patched] buy KeyError para {ACTIVES}: {e}")
                self._update_actives_safe()
                time.sleep(2)
            except Exception as e:
                logger.warning(f"[Patched] buy error (intento {attempt + 1}): {e}")
                self._ensure_connected()
                time.sleep(2)
        return False, "Buy fallo despues de 3 intentos"

    def check_win_v3(self, id_number, timeout=None):
        if timeout is None:
            timeout = DEFAULT_TIMEOUT_CHECK_WIN
        start_time = time.time()
        balance_before = None
        try:
            balance_before = self.get_balance_safe()
        except Exception:
            pass
        while time.time() - start_time < timeout:
            try:
                if not self.check_connect():
                    self._ensure_connected()
                    time.sleep(2)
                    continue
                try:
                    async_order = self._api.get_async_order(id_number)
                    if async_order and async_order.get("option-closed", {}) != {}:
                        option_closed = async_order["option-closed"]["msg"]
                        profit = option_closed.get("profit_amount", 0) - option_closed.get("amount", 0)
                        return profit
                except (KeyError, TypeError, AttributeError):
                    pass
                except Exception:
                    pass
                try:
                    result = self._api.check_win_v3(id_number)
                    if result is not None:
                        return result
                except Exception:
                    pass
                # Anti-detection: randomize polling interval (0.8-1.5s instead of exact 1s)
                time.sleep(random.uniform(0.8, 1.5))
            except Exception as e:
                logger.warning(f"[Patched] check_win_v3 error: {e}")
                time.sleep(random.uniform(1.5, 3.0))
        logger.warning(f"[Patched] check_win_v3 TIMEOUT ({timeout}s), usando fallback balance")
        if balance_before is not None:
            try:
                time.sleep(3)
                balance_after = self.get_balance_safe()
                diff = balance_after - balance_before
                if abs(diff) > 0.01:
                    return diff
            except Exception:
                pass
        logger.error(f"[Patched] check_win_v3 no pudo determinar resultado para orden {id_number}")
        return None

    def get_balance_safe(self):
        for attempt in range(3):
            try:
                if not self._ensure_connected():
                    continue
                result = [None]
                error = [None]
                def _worker():
                    try:
                        result[0] = self._api.get_balance()
                    except Exception as e:
                        error[0] = e
                t = threading.Thread(target=_worker, daemon=True)
                t.start()
                t.join(timeout=DEFAULT_TIMEOUT_BALANCE)
                if t.is_alive():
                    logger.warning("[Patched] get_balance TIMEOUT")
                    self._ensure_connected()
                    continue
                if error[0]:
                    raise error[0]
                if result[0] is not None:
                    return result[0]
            except Exception as e:
                logger.warning(f"[Patched] get_balance error (intento {attempt + 1}): {e}")
                self._ensure_connected()
                time.sleep(2)
        try:
            balances = self._api.get_balances()
            if balances and "msg" in balances:
                for balance in balances["msg"]:
                    if balance["id"] == global_value.balance_id:
                        return balance["amount"]
        except Exception:
            pass
        raise Exception("get_balance fallo despues de 3 intentos")

    def get_all_profit(self, force_refresh=False):
        now = time.time()
        if not force_refresh and self._profit_cache and (now - self._profit_cache_time) < self._profit_cache_ttl:
            return self._profit_cache
        for attempt in range(2):
            try:
                if not self._ensure_connected():
                    continue
                result = [None]
                error = [None]
                def _worker():
                    try:
                        result[0] = self._api.get_all_profit()
                    except Exception as e:
                        error[0] = e
                t = threading.Thread(target=_worker, daemon=True)
                t.start()
                t.join(timeout=DEFAULT_TIMEOUT_PROFIT)
                if t.is_alive():
                    logger.warning("[Patched] get_all_profit TIMEOUT")
                    continue
                if error[0]:
                    raise error[0]
                if result[0] is not None:
                    self._profit_cache = result[0]
                    self._profit_cache_time = time.time()
                    return result[0]
            except Exception as e:
                logger.warning(f"[Patched] get_all_profit error (intento {attempt + 1}): {e}")
                time.sleep(3)
        if self._profit_cache:
            logger.warning("[Patched] get_all_profit usando cache expirado como fallback")
            return self._profit_cache
        return None

    def change_balance(self, Balance_MODE):
        try:
            self._api.change_balance(Balance_MODE)
            self._last_balance_mode = Balance_MODE
        except Exception as e:
            logger.warning(f"[Patched] change_balance error: {e}")
            if self._ensure_connected():
                self._api.change_balance(Balance_MODE)
                self._last_balance_mode = Balance_MODE

    def get_server_timestamp(self):
        try:
            return self._api.get_server_timestamp()
        except Exception:
            return time.time()

    def close(self):
        try:
            self._api.close()
        except Exception:
            pass
        self._connected = False

    def get_async_order(self, id_number):
        try:
            result = [None]
            error = [None]
            def _worker():
                try:
                    result[0] = self._api.get_async_order(id_number)
                except Exception as e:
                    error[0] = e
            t = threading.Thread(target=_worker, daemon=True)
            t.start()
            t.join(timeout=10)
            if error[0]:
                raise error[0]
            return result[0]
        except Exception:
            return {}

    def get_balance(self):
        try:
            return self.get_balance_safe()
        except Exception:
            try:
                return self._api.get_balance()
            except Exception:
                return 0.0
