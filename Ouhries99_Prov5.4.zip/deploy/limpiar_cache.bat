@echo off
title Sistema Ouhries - Limpiar Cache y Entorno
color 0A
echo ============================================================
echo   SISTEMA OUHRIES V5 - LIMPIEZA COMPLETA DE CACHE
echo ============================================================
echo.
echo Este script eliminara:
echo   [1] Cache de Python (__pycache__)
echo   [2] Archivos de estado de sesion (session_state.json)
echo   [3] Archivos temporales (.pyc, .pyo)
echo   [4] Cache del navegador Electron/Chromium
echo   [5] Logs de sesiones anteriores
echo   [6] Procesos Python/Electron residuales
echo.
pause

echo.
echo ============================================================
echo   PASO 1: Deteniendo procesos residuales...
echo ============================================================
echo.

:: Matar procesos de Python del bot
tasklist /FI "IMAGENAME eq python.exe" 2>NUL | find /I "python.exe" >NUL
if %ERRORLEVEL% equ 0 (
    echo   Matando procesos python.exe residuales...
    taskkill /F /IM python.exe 2>NUL
    timeout /t 2 /nobreak >NUL
) else (
    echo   No hay procesos python.exe corriendo.
)

:: Matar procesos de Electron del bot
tasklist /FI "IMAGENAME eq ouhries*.exe" 2>NUL | find /I "ouhries" >NUL
if %ERRORLEVEL% equ 0 (
    echo   Matando procesos Ouhries Electron residuales...
    taskkill /F /IM "ouhries*.exe" 2>NUL
    timeout /t 2 /nobreak >NUL
) else (
    echo   No hay procesos Ouhries Electron corriendo.
)

echo.
echo ============================================================
echo   PASO 2: Limpiando cache de Python...
echo ============================================================
echo.

:: Eliminar __pycache__ de forma recursiva
echo   Eliminando carpetas __pycache__...
for /d /r "%~dp0" %%d in (__pycache__) do (
    if exist "%%d" (
        echo     - %%d
        rd /s /q "%%d" 2>NUL
    )
)

:: Eliminar archivos .pyc y .pyo
echo   Eliminando archivos .pyc y .pyo...
del /s /q "%~dp0*.pyc" 2>NUL
del /s /q "%~dp0*.pyo" 2>NUL

echo   Cache de Python limpio.
echo.

echo ============================================================
echo   PASO 3: Eliminando estado de sesion anterior...
echo ============================================================
echo.

if exist "%~dp0session_state.json" (
    echo   Eliminando session_state.json...
    del /f /q "%~dp0session_state.json"
    echo   Estado de sesion eliminado.
) else (
    echo   No hay session_state.json (ya limpio).
)

echo.

echo ============================================================
echo   PASO 4: Eliminando logs de sesiones anteriores...
echo ============================================================
echo.

if exist "%~dp0logs" (
    echo   Eliminando carpeta logs...
    del /f /q "%~dp0logs\*.log" 2>NUL
    del /f /q "%~dp0logs\*.txt" 2>NUL
    echo   Logs eliminados.
) else (
    echo   No hay carpeta logs.
)

if exist "%~dp0ouhries.log" (
    del /f /q "%~dp0ouhries.log" 2>NUL
)
if exist "%~dp0batch_test_log.txt" (
    del /f /q "%~dp0batch_test_log.txt" 2>NUL
)

echo.

echo ============================================================
echo   PASO 5: Limpiando cache de Electron/Chromium...
echo ============================================================
echo.

:: Cache de Electron en AppData
set "ELECTRON_CACHE=%APPDATA%\Sistema Ouhries"
if exist "%ELECTRON_CACHE%" (
    echo   Eliminando cache Electron: %ELECTRON_CACHE%
    echo     - Cache...
    rd /s /q "%ELECTRON_CACHE%\Cache" 2>NUL
    rd /s /q "%ELECTRON_CACHE%\Code Cache" 2>NUL
    rd /s /q "%ELECTRON_CACHE%\GPUCache" 2>NUL
    rd /s /q "%ELECTRON_CACHE%\Service Worker" 2>NUL
    rd /s /q "%ELECTRON_CACHE%\DawnCache" 2>NUL
    echo     - Local Storage...
    rd /s /q "%ELECTRON_CACHE%\Local Storage" 2>NUL
    echo     - Session Storage...
    rd /s /q "%ELECTRON_CACHE%\Session Storage" 2>NUL
    echo     - IndexedDB...
    rd /s /q "%ELECTRON_CACHE%\IndexedDB" 2>NUL
    echo   Cache Electron limpio.
) else (
    echo   No se encontro cache de Electron en AppData.
)

:: Tambien buscar en LocalAppData
set "ELECTRON_LOCAL=%LOCALAPPDATA%\Sistema Ouhries"
if exist "%ELECTRON_LOCAL%" (
    echo   Eliminando cache Electron local: %ELECTRON_LOCAL%
    rd /s /q "%ELECTRON_LOCAL%\Cache" 2>NUL
    rd /s /q "%ELECTRON_LOCAL%\Code Cache" 2>NUL
    rd /s /q "%ELECTRON_LOCAL%\GPUCache" 2>NUL
    rd /s /q "%ELECTRON_LOCAL%\Service Worker" 2>NUL
    echo   Cache Electron local limpio.
)

:: Buscar cache con variantes de nombre
for %%N in ("ouhries" "Ouhries" "OuhriesV5" "Sistema Ouhries V5") do (
    set "CHECK_PATH=%APPDATA%\%%~N"
    if exist "!CHECK_PATH!" (
        echo   Encontrado cache: !CHECK_PATH!
        rd /s /q "!CHECK_PATH!\Cache" 2>NUL
        rd /s /q "!CHECK_PATH!\Code Cache" 2>NUL
        rd /s /q "!CHECK_PATH!\GPUCache" 2>NUL
        rd /s /q "!CHECK_PATH!\Service Worker" 2>NUL
        rd /s /q "!CHECK_PATH!\Local Storage" 2>NUL
        rd /s /q "!CHECK_PATH!\Session Storage" 2>NUL
        rd /s /q "!CHECK_PATH!\IndexedDB" 2>NUL
    )
)

echo.

echo ============================================================
echo   PASO 6: Limpiando cache de navegador (Chrome/Edge)...
echo ============================================================
echo.
echo   Si abres el bot en navegador (no Electron), la cache del
echo   navegador puede servir la version antigua. Solucion:
echo.
echo   OPCION A - Hard refresh en navegador:
echo     Chrome/Edge: Ctrl+Shift+Delete ^> Borrar cache
echo     O pulsa Ctrl+F5 en la pagina del bot
echo.
echo   OPCION B - Abrir en modo incognito:
echo     Chrome: Ctrl+Shift+N
echo     Edge:   Ctrl+Shift+N
echo     Navega a: http://localhost:8585
echo.

echo ============================================================
echo   VERIFICACION FINAL
echo ============================================================
echo.

:: Verificar que los archivos criticos existen
echo   Verificando archivos criticos...
set "ALL_OK=1"

if not exist "%~dp0engine.py" (
    echo   [ERROR] Falta engine.py!
    set "ALL_OK=0"
)
if not exist "%~dp0server.py" (
    echo   [ERROR] Falta server.py!
    set "ALL_OK=0"
)
if not exist "%~dp0config.py" (
    echo   [ERROR] Falta config.py!
    set "ALL_OK=0"
)
if not exist "%~dp0strategies\strategies_otc.py" (
    echo   [ERROR] Falta strategies\strategies_otc.py!
    set "ALL_OK=0"
)
if not exist "%~dp0strategies\strategies_v2.py" (
    echo   [ERROR] Falta strategies\strategies_v2.py!
    set "ALL_OK=0"
)
if not exist "%~dp0static\index.html" (
    echo   [ERROR] Falta static\index.html!
    set "ALL_OK=0"
)

:: Verificar que strategies.py (V1 basica) NO existe
if exist "%~dp0strategies\strategies.py" (
    echo   [AVISO] strategies\strategies.py existe - V1 basica deberia estar eliminada!
    set "ALL_OK=0"
)
:: Verificar que strategies_v3.py NO existe
if exist "%~dp0strategies\strategies_v3.py" (
    echo   [AVISO] strategies\strategies_v3.py existe - deberia estar eliminada!
    set "ALL_OK=0"
)

if "%ALL_OK%"=="1" (
    echo.
    echo   Todos los archivos criticos estan presentes.
    echo   Archivos no deseados eliminados.
)

echo.
echo ============================================================
echo   LIMPIEZA COMPLETADA
echo ============================================================
echo.
echo   Ahora puedes iniciar el bot con:
echo     - start.bat          (navegador)
echo     - OuhriesV5.bat      (Electron)
echo.
echo   TIP: Si usas navegador, abre en INCOGNITO para evitar
echo   cache: Ctrl+Shift+N ^> http://localhost:8585
echo.
pause
