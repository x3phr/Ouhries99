"""
Sistema Ouhries V5.4 - Motor de Trading (Anti-Detection PRO)
Sistema de Niveles de interes compuesto con subniveles (N1, N1+, N1++, ...).
N1 win -> subnivel (capital + 35% profit anterior).
N1+ loss -> reset N1. N1 loss -> queda en N1.
N1++ win -> N1+++ (segun niveles configurados).
Stop loss sin cap - solo valor manual.
Payout 87+ automatico, expiracion 1 minuto.
Estrategia OTCEspecializada V1 (7 fuentes + Meta-learning) y V2.1 Mejorada (ADX+Calidad+Tendencia).
Notificacion Telegram con emojis al finalizar sesion.
Timing: envio anticipado con broker_delay RANDOM (1.0-4.0s) para comportamiento humano.
Anti-Detection PRO: TLS masking, UA rotation, jitter, delays humanos, noise browsing,
session rotation, scan randomization, entry hesitation, human_action_pct.
"""

import time
import random
import json
import os
import threading
from datetime import datetime

from iqoption_patched import IQ_Option_Patched
from scanner import OTCScanner
from instruments import get_otc_instruments
from telegram_notifier import TelegramNotifier
from logger import Logger
from strategies.strategies_otc import meta_learner

STATE_FILE = "session_state.json"


class TradingEngine:
    def __init__(self, config, log_callback=None, status_callback=None,
                 radar_callback=None, trade_callback=None):
        self.config = config
        self.log_cb = log_callback or (lambda x: None)
        self.status = status_callback or (lambda x: None)
        self.radar_cb = radar_callback or (lambda asset, idx, total: None)
        self.trade_cb = trade_callback or (lambda trade_info: None)
        self.api = None
        self.scanner = None
        self.running = False
        self._stop_flag = False
        self._lock = threading.Lock()
        self._trade_in_progress = False
        self._end_reason = None
        self._session_end_callback = None

        self.logger = Logger()

        self.telegram = TelegramNotifier(
            token=config.get("telegram_token", ""),
            chat_id=config.get("telegram_chat_id", ""),
            enabled=config.get("telegram_enabled", False),
            log_callback=lambda x: None
        )

        self.balance = 0.0
        self.initial_balance = 0.0
        self.current_level = 1
        self.current_sublevel = 0
        self.total_trades = 0
        self.total_wins = 0
        self.total_losses = 0
        self.current_profit = 0.0
        self.current_instrument = None
        self.last_trade_amount = 0.0
        self.previous_profits = []
        self.operated_assets = set()
        self._seen_trade_ids = set()  # Deduplication

        self.repeat_win_enabled = config.get("repeat_win", False)
        self._repeat_count = 0
        self._repeat_instrument = None
        self._repeat_direction = None

    def log(self, msg):
        self.logger.log(msg)
        try:
            self.log_cb(msg)
        except Exception:
            pass

    # PERSISTENCIA
    def save_state(self):
        state = {
            "timestamp": datetime.now().isoformat(),
            "balance": self.balance,
            "initial_balance": self.initial_balance,
            "current_level": self.current_level,
            "current_sublevel": self.current_sublevel,
            "total_trades": self.total_trades,
            "total_wins": self.total_wins,
            "total_losses": self.total_losses,
            "current_profit": self.current_profit,
            "current_instrument": self.current_instrument,
            "last_trade_amount": self.last_trade_amount,
            "previous_profits": self.previous_profits,
            "operated_assets": list(self.operated_assets),
            "repeat_count": self._repeat_count,
            "repeat_instrument": self._repeat_instrument,
            "repeat_direction": self._repeat_direction,
        }
        try:
            with open(STATE_FILE, "w") as f:
                json.dump(state, f, indent=2)
            sl_text = self._sublevel_text()
            self.log(f"[Persistencia] Estado guardado ({sl_text} | Ops: {self.total_trades})")
        except Exception as e:
            self.log(f"[Persistencia] Error guardando estado: {e}")

    def load_state(self):
        if not os.path.exists(STATE_FILE):
            self.log("[Persistencia] No hay sesion previa, iniciando nueva")
            return False
        try:
            with open(STATE_FILE, "r") as f:
                state = json.load(f)
            self.balance = state.get("balance", 0.0)
            self.initial_balance = state.get("initial_balance", 0.0)
            self.current_level = state.get("current_level", 1)
            self.current_sublevel = state.get("current_sublevel", 0)
            self.total_trades = state.get("total_trades", 0)
            self.total_wins = state.get("total_wins", 0)
            self.total_losses = state.get("total_losses", 0)
            self.current_profit = state.get("current_profit", 0.0)
            self.current_instrument = state.get("current_instrument", None)
            self.last_trade_amount = state.get("last_trade_amount", 0.0)
            self.previous_profits = state.get("previous_profits", [])
            self.operated_assets = set(state.get("operated_assets", []))
            self._repeat_count = state.get("repeat_count", 0)
            self._repeat_instrument = state.get("repeat_instrument", None)
            self._repeat_direction = state.get("repeat_direction", None)
            saved_time = state.get("timestamp", "desconocido")
            sl_text = self._sublevel_text()
            self.log(f"[Persistencia] Sesion previa encontrada: {saved_time}")
            self.log(f"[Persistencia] {sl_text} | Ops: {self.total_trades} | W: {self.total_wins} | L: {self.total_losses}")
            if self.scanner:
                for asset in self.operated_assets:
                    self.scanner.add_operated(asset)
            return True
        except Exception as e:
            self.log(f"[Persistencia] Error cargando estado: {e}")
            return False

    def clear_state(self):
        try:
            if os.path.exists(STATE_FILE):
                os.remove(STATE_FILE)
                self.log("[Persistencia] Estado anterior eliminado")
        except Exception as e:
            self.log(f"[Persistencia] Error eliminando estado: {e}")

    # CONEXION
    def _ensure_connected(self):
        if self.api is None:
            return False
        try:
            return self.api._ensure_connected()
        except Exception as e:
            self.log(f"[Engine] Error verificando conexion: {e}")
            return False

    def connect(self):
        try:
            self.log("[Engine] Conectando a IQ Option (API Parchada V5)...")
            email = self.config.get("email", "")
            password = self.config.get("password", "")
            self.api = IQ_Option_Patched(email, password)
            check, reason = self.api.connect()
            if not check:
                self.log(f"[Engine] Error de conexion: {reason}")
                return False
            self.log("[Engine] Conexion exitosa!")
            mode = self.config.get("account_mode", "PRACTICE")
            self.api.change_balance(mode)
            self.log(f"[Engine] Modo de cuenta: {mode}")
            self.balance = self.api.get_balance()
            self.initial_balance = self.balance
            self.log(f"[Engine] Balance inicial: ${self.balance:.2f}")
            self.scanner = OTCScanner(self.api, self.config, self.log,
                                      radar_callback=self.radar_cb)
            self.telegram = TelegramNotifier(
                token=self.config.get("telegram_token", ""),
                chat_id=self.config.get("telegram_chat_id", ""),
                enabled=self.config.get("telegram_enabled", False),
                log_callback=lambda x: self.log(f"[TG] {x}") if False else None
            )
            self.telegram.start()
            if self.config.get("telegram_enabled", False):
                self.log("[Engine] Telegram habilitado - enviando notificacion de inicio...")
            return True
        except Exception as e:
            self.log(f"[Engine] Error conectando: {e}")
            return False

    def switch_account(self, mode):
        try:
            if self.api:
                self.api.change_balance(mode)
                self.config["account_mode"] = mode
                self.balance = self.api.get_balance()
                self.log(f"[Engine] Cambiado a cuenta {mode}. Balance: ${self.balance:.2f}")
                self.status(f"Cuenta: {mode} | Balance: ${self.balance:.2f}")
                self.save_state()
                return True
        except Exception as e:
            self.log(f"[Engine] Error cambiando cuenta: {e}")
        return False

    # PAYOUT
    def _get_instrument_payout(self, instrument_name):
        try:
            all_profit = self.api.get_all_profit()
            if all_profit:
                for name in [instrument_name, instrument_name.upper(),
                             instrument_name.replace("-OTC", "_otc"),
                             instrument_name.replace("-OTC", "-otc")]:
                    if name in all_profit:
                        payout_info = all_profit[name]
                        if isinstance(payout_info, dict):
                            turbo = payout_info.get("turbo", 0)
                            if turbo:
                                return int(float(turbo) * 100)
                            binary = payout_info.get("binary", 0)
                            if binary:
                                return int(float(binary) * 100)
                        elif isinstance(payout_info, (int, float)):
                            return int(float(payout_info) * 100)
        except Exception as e:
            self.log(f"[Payout] Error obteniendo payout de {instrument_name}: {e}")
        return 0

    def _check_payout_min(self, instrument_name):
        payout_min = self.config.get("payout_min", 87)
        payout = self._get_instrument_payout(instrument_name)
        if payout >= payout_min:
            return True
        else:
            self.log(f"[Payout] {instrument_name}: {payout}% < {payout_min}% RECHAZADO")
            return False

    # TIMING - Anti-Detection: Random broker_delay (1.0-4.0) + human jitter
    # Instead of always sending at the exact same second, we randomize the broker_delay
    # each time (1.0 to 4.0 seconds) and add a small human jitter (±1.5s).
    # This makes the entry timing vary naturally like a real trader pressing buttons.
    # Target: broker executes around second 56-59 of the candle (varies each time).
    def _wait_for_candle_timing(self):
        """Wait for entry timing with ANTI-DETECTION randomization.
        - broker_delay is randomized between 1.0 and 4.0 seconds each trade
        - A small human jitter (0-1.5s) is added to the send time
        - The entry window is wider (50-57) to allow natural variation
        - This makes timing patterns look human instead of robotic."""
        candle_seconds = 60
        # Anti-Detection: Randomize broker_delay for each trade (1.0 to 4.0)
        broker_delay_enabled = self.config.get("broker_delay_enabled", True)
        if broker_delay_enabled:
            base_delay = self.config.get("broker_delay", 4.0)
            # Randomize: pick a delay between 1.0 and base_delay each time
            # This means sometimes we anticipate more, sometimes less
            broker_delay = random.uniform(1.0, base_delay)
        else:
            broker_delay = 0.0

        # Anti-Detection: Add human jitter to send time (0 to 1.5s early/late)
        human_jitter = random.uniform(0.0, 1.5)

        # Target broker execution: second 57-59 (varies due to random delay)
        # We need to send at: target_execution - broker_delay
        target_execution = random.uniform(57.0, 59.0)  # Vary target slightly
        send_second = target_execution - broker_delay  # e.g., 58 - 2.5 = 55.5
        send_second = max(send_second - human_jitter, 50.0)  # Don't send before second 50
        send_window_end = 57.0  # Wider window for natural variation

        now = time.time()
        seconds_into_candle = now % candle_seconds

        # If we're in the send window, enter with a small random micro-delay
        if send_second <= seconds_into_candle <= send_window_end:
            # Anti-Detection: small micro-delay (0-0.3s) before actually sending
            # Simulates the time it takes a human to click the button
            micro_delay = random.uniform(0.0, 0.3)
            time.sleep(micro_delay)
            self.log(f"[Timing] En ventana (segundo {seconds_into_candle:.1f}, delay: {broker_delay:.1f}s, jitter: {human_jitter:.1f}s). Broker ejecutara en ~segundo {seconds_into_candle + broker_delay:.0f}")
            return

        # If we're between second 57 and 59, we're late but might still make it
        if 57 < seconds_into_candle < 59:
            self.log(f"[Timing] Ventana tarde (segundo {seconds_into_candle:.1f}). Enviando de inmediato (delay: {broker_delay:.1f}s)")
            return

        # If we're at second 0-0.3 of new candle, emergency entry
        if seconds_into_candle < 0.3:
            self.log(f"[Timing] Entrada de emergencia en segundo {seconds_into_candle:.1f} de nueva vela")
            return

        # Otherwise, wait until the send window
        if seconds_into_candle < send_second:
            wait_seconds = send_second - seconds_into_candle
        else:
            wait_seconds = (candle_seconds - seconds_into_candle) + send_second

        if wait_seconds > 0:
            self.log(f"[Timing] Esperando {wait_seconds:.0f}s (delay: {broker_delay:.1f}s, jitter: {human_jitter:.1f}s)...")
            # Anti-Detection: don't wait in exact 5-second chunks
            while wait_seconds > 0 and not self._stop_flag:
                chunk = min(wait_seconds, random.uniform(3.0, 7.0))  # Variable chunk
                time.sleep(chunk)
                wait_seconds -= chunk

        if self._stop_flag:
            return

        # Verify we're in the right send window
        now = time.time()
        seconds_into_candle = now % candle_seconds
        if send_second <= seconds_into_candle <= send_window_end:
            self.log(f"[Timing] Ventana confirmada (segundo {seconds_into_candle:.1f}, delay: {broker_delay:.1f}s)")
        elif 57 < seconds_into_candle < 59:
            self.log(f"[Timing] Entrada tardia (segundo {seconds_into_candle:.1f}, delay: {broker_delay:.1f}s)")
        else:
            # Missed the window, wait for next candle
            wait_for_zero = candle_seconds - seconds_into_candle
            self.log(f"[Timing] Ventana perdida, esperando {wait_for_zero:.1f}s para proxima vela...")
            if wait_for_zero > 0 and not self._stop_flag:
                time.sleep(wait_for_zero - 0.1)
                while not self._stop_flag:
                    now = time.time()
                    seconds_into_candle = now % candle_seconds
                    if seconds_into_candle < 0.3:
                        self.log(f"[Timing] Entrada de emergencia en segundo {seconds_into_candle:.2f} de nueva vela")
                        break
                    if seconds_into_candle >= send_second:
                        break
                    time.sleep(random.uniform(0.03, 0.08))

    # MONTO
    def _sublevel_text(self):
        if self.current_sublevel == 0:
            return "N1"
        return "N1" + "+" * self.current_sublevel

    def _get_trade_amount(self):
        base = self.config.get("capital_operacion", 2.50)
        if self.config.get("disable_niveles", False):
            amount = base
        elif self.current_sublevel > 0 and self.previous_profits:
            # sublevel_profit_pct is configurable, including 0 (no reinvestment)
            profit_pct = self.config.get("sublevel_profit_pct", 35) / 100.0
            last_profit = self.previous_profits[-1]
            amount = base + (last_profit * profit_pct)
        else:
            amount = base
        amount = round(amount, 2)
        amount = max(amount, 1.0)
        return amount

    # SISTEMA DE NIVELES
    def _advance_level(self, won):
        max_niveles = self.config.get("niveles", 0)
        repeat_win = self.config.get("repeat_win", False)
        
        if won:
            payout_pct = self._get_instrument_payout(self.current_instrument or "")
            if payout_pct <= 0:
                payout_pct = 86
            profit = self.last_trade_amount * (payout_pct / 100.0)
            self.previous_profits.append(profit)
            
            # Repetir Win logic: simplified - repeat once then re-scan
            if repeat_win and self._repeat_count == 0:
                # First win with repeat enabled: set repeat for one more time
                self._repeat_count = 1
                self._repeat_instrument = self.current_instrument
                old_text = self._sublevel_text()
                if self.current_sublevel >= max_niveles:
                    self.current_sublevel += 1
                else:
                    self.current_sublevel += 1
                new_text = self._sublevel_text()
                amount = self._get_trade_amount()
                self.log(f"[Niveles] WIN -> REPETIR en {self._repeat_instrument} (1 vez) -> {new_text} (monto: ${amount:.2f})")
            elif repeat_win and self._repeat_count > 0:
                # Won during repeat: reset and re-scan all instruments
                self._repeat_count = 0
                self._repeat_instrument = None
                self._repeat_direction = None
                if self.scanner:
                    self.scanner.reset_operated()
                    self.operated_assets.clear()
                self._switch_asset()
                old_text = self._sublevel_text()
                if self.current_sublevel >= max_niveles:
                    self.current_sublevel += 1
                else:
                    self.current_sublevel += 1
                new_text = self._sublevel_text()
                amount = self._get_trade_amount()
                self.log(f"[Niveles] WIN en REPETIR -> Re-escaneando todos los instrumentos -> {new_text} (monto: ${amount:.2f})")
            else:
                # Normal level progression (no repeat win)
                if self.current_sublevel >= max_niveles:
                    self.log(f"[Niveles] WIN en {self._sublevel_text()} -> Ciclo completado! Reset a N1")
                    self.current_sublevel = 0
                    self.previous_profits = []
                    self._switch_asset()
                else:
                    old_text = self._sublevel_text()
                    self.current_sublevel += 1
                    new_text = self._sublevel_text()
                    amount = self._get_trade_amount()
                    profit_pct = self.config.get("sublevel_profit_pct", 35)
                    self.log(f"[Niveles] WIN en {old_text} -> {new_text} (monto: ${amount:.2f}, {profit_pct}% profit)")
        else:
            # LOSS - if in repeat mode, reset and re-scan all
            if self._repeat_count > 0:
                self.log(f"[Niveles] LOSS en REPETIR -> Re-escaneando todos los instrumentos")
                self._repeat_count = 0
                self._repeat_instrument = None
                self._repeat_direction = None
                if self.scanner:
                    self.scanner.reset_operated()
                    self.operated_assets.clear()
                self._switch_asset()
                self.current_sublevel = 0
                self.previous_profits = []
            elif self.current_sublevel > 0:
                self.log(f"[Niveles] LOSS en {self._sublevel_text()} -> Reset a N1")
                self.current_sublevel = 0
                self.previous_profits = []
                self._switch_asset()
            else:
                self.log(f"[Niveles] LOSS en N1 -> Permanece en N1")
        self.status(f"Nivel: {self._sublevel_text()} | Profit: ${self.current_profit:.2f}")
        self.save_state()

    def _switch_asset(self):
        if self.current_instrument:
            if self.scanner:
                self.scanner.add_operated(self.current_instrument)
            self.operated_assets.add(self.current_instrument)
            self.log(f"[Engine] Cambiando de activo (era: {self.current_instrument})")
            self.current_instrument = None
            self.save_state()

    # VERIFICACION DE RESULTADO
    def _check_win(self, order_id, amount, expiration_min):
        # Anti-Detection: Add random variation to wait time (57-67s instead of exact 65s)
        # A human wouldn't check at the exact same time every single trade
        base_wait = expiration_min * 60 + 5
        wait_time = base_wait + random.uniform(-3.0, 3.0)
        self.log(f"[Engine] Esperando {wait_time:.0f}s para resultado...")
        time.sleep(wait_time)
        try:
            result = self.api.check_win_v3(order_id)
            if result is not None:
                return result > 0, result
        except Exception as e:
            self.log(f"[Engine] check_win_v3 fallo: {e}")
        try:
            if self._ensure_connected():
                new_balance = self.api.get_balance()
                diff = new_balance - self.balance
                if abs(diff) > 0.01:
                    return diff > 0, diff
        except Exception:
            pass
        self.log("[Engine] No se pudo verificar resultado, asumiendo perdida")
        return False, -amount

    # EJECUCION DE OPERACION
    def _execute_trade(self, instrument_name, direction, amount):
        with self._lock:
            if self._trade_in_progress:
                self.log("[Engine] Ya hay una operacion en curso")
                return None, None
            self._trade_in_progress = True

        trade_time = datetime.now().strftime("%H:%M:%S")
        trade_id = f"{instrument_name}_{trade_time}"

        # Deduplication
        if trade_id in self._seen_trade_ids:
            self.log(f"[Engine] Operacion duplicada ignorada: {trade_id}")
            with self._lock:
                self._trade_in_progress = False
            return None, None
        self._seen_trade_ids.add(trade_id)

        try:
            if not self._ensure_connected():
                self.log("[Engine] Sin conexion, no se puede operar")
                return False, 0

            try:
                all_actives = self.api.get_all_ACTIVES_OPCODE()
                if all_actives and instrument_name not in all_actives:
                    self.log(f"[Engine] {instrument_name} no disponible en ACTIVES")
                    return False, 0
            except Exception:
                pass

            if not self._check_payout_min(instrument_name):
                self.log(f"[Engine] {instrument_name} no cumple payout minimo")
                return False, 0

            level_info = self._sublevel_text()
            payout = self._get_instrument_payout(instrument_name)
            self.log(f"[Engine] Operando [{level_info}]: {direction.upper()} {instrument_name} | ${amount:.2f} | Payout: {payout}% | Exp: 1m")

            self.telegram.notify_trade_opened(
                instrument=instrument_name, direction=direction,
                amount=amount, level=self.current_level,
                sublevel=self.current_sublevel, payout=payout,
                trade_time=trade_time
            )

            check, order_id = self.api.buy(amount, instrument_name, direction, 1)

            if not check:
                self.log(f"[Engine] Orden rechazada: {order_id}")
                self.telegram.notify_error(f"Orden rechazada: {instrument_name} {direction.upper()} ${amount:.2f}")
                return False, 0

            self.last_trade_amount = amount
            self.total_trades += 1
            self.current_instrument = instrument_name

            self.trade_cb({
                "id": trade_id,
                "num": self.total_trades,
                "activo": instrument_name,
                "direccion": direction.upper(),
                "monto": amount,
                "resultado": "...",
                "profit": 0.0,
                "nivel": level_info,
                "hora": trade_time,
                "status": "open"
            })

            self.save_state()

            won, profit = self._check_win(order_id, amount, 1)

            if self._ensure_connected():
                try:
                    self.balance = self.api.get_balance()
                except Exception:
                    self.balance += profit
            self.current_profit = self.balance - self.initial_balance

            if won:
                self.total_wins += 1
                self.log(f"[Engine] WIN! Profit: +${profit:.2f} | Balance: ${self.balance:.2f}")
            else:
                self.total_losses += 1
                self.log(f"[Engine] LOSS. Perdida: -${abs(profit):.2f} | Balance: ${self.balance:.2f}")

            self.trade_cb({
                "id": trade_id,
                "num": self.total_trades,
                "activo": instrument_name,
                "direccion": direction.upper(),
                "monto": amount,
                "resultado": "WIN" if won else "LOSS",
                "profit": profit,
                "nivel": level_info,
                "hora": trade_time,
                "status": "closed"
            })

            self.telegram.notify_trade_result(
                instrument=instrument_name, direction=direction,
                won=won, profit=profit, amount=amount,
                balance=self.balance, level=self.current_level,
                sublevel=self.current_sublevel,
                total_trades=self.total_trades,
                total_wins=self.total_wins,
                total_losses=self.total_losses,
                current_profit=self.current_profit,
                trade_time=trade_time
            )

            self.save_state()
            return won, profit

        except Exception as e:
            self.log(f"[Engine] Error ejecutando operacion: {e}")
            self.telegram.notify_error(f"Error en operacion: {e}")
            self._ensure_connected()
            self.save_state()
            return False, 0
        finally:
            with self._lock:
                self._trade_in_progress = False

    # STOPS - MODIFIED: No stoploss cap - use configured stop_loss directly
    def _check_stops(self):
        profit = self.balance - self.initial_balance
        stop_win = self.config.get("stop_win", 1.0)
        stop_loss = self.config.get("stop_loss", 1.0)
        # No cap - stop_loss is the value configured by the user, period
        effective_stop_loss = stop_loss

        # Max trades
        max_trades = self.config.get("max_trades", 0)
        if max_trades > 0 and self.total_trades >= max_trades:
            self.log(f"[Engine] Maximo de operaciones alcanzado ({self.total_trades}/{max_trades})")
            self._end_reason = "max_trades"
            self._stop_flag = True
            return True

        if profit >= stop_win:
            self.log(f"[Engine] STOP WIN alcanzado! Profit: ${profit:.2f} >= ${stop_win:.2f}")
            self.telegram.notify_stop_hit("win", profit, self.balance,
                                           self.total_trades, self.total_wins, self.total_losses)
            self._end_reason = "stopwin"
            self._stop_flag = True
            return True

        if profit <= -effective_stop_loss:
            self.log(f"[Engine] STOP LOSS alcanzado! Perdida: ${profit:.2f} >= ${effective_stop_loss:.2f}")
            self.telegram.notify_stop_hit("loss", profit, self.balance,
                                           self.total_trades, self.total_wins, self.total_losses)
            self._end_reason = "stoploss"
            self._stop_flag = True
            return True

        return False

    # NOISE BROWSING - Anti-Detection: Mimics human browsing behavior
    # A real trader doesn't just open trades - they check balances, view charts,
    # browse instruments, check their trade history, etc.
    def _noise_browsing(self):
        """Perform random 'browsing' actions that a human trader would do.
        This makes the API call pattern look like a real person using the platform.
        Called randomly between trades based on human_action_pct probability."""
        try:
            actions = [
                self._noise_check_balance,
                self._noise_browse_instruments,
                self._noise_check_profit,
            ]
            action = random.choice(actions)
            action()
        except Exception as e:
            self.log(f"[AntiDetect] Noise browsing error (ignorable): {e}")

    def _noise_check_balance(self):
        """Human behavior: check balance without trading."""
        try:
            if self._ensure_connected():
                balance = self.api.get_balance()
                self.log(f"[AntiDetect] Noise: Consultando balance (${balance:.2f}) - comportamiento humano")
                # Small random delay like a human reading their balance
                time.sleep(random.uniform(1.5, 4.0))
        except Exception:
            pass

    def _noise_browse_instruments(self):
        """Human behavior: browse through instruments without trading."""
        try:
            if self._ensure_connected():
                # Get a random instrument and fetch its candles (like browsing charts)
                instruments = get_otc_instruments(self.api)
                if instruments:
                    # Pick 1-3 random instruments to "browse"
                    browse_count = random.randint(1, 3)
                    browse_list = random.sample(list(instruments.keys()), min(browse_count, len(instruments)))
                    for name in browse_list:
                        if self._stop_flag:
                            break
                        # Fetch candles like a human looking at charts
                        endtime = int(time.time())
                        candles = self.api.get_candles(name, 60, 10, endtime)
                        if candles:
                            self.log(f"[AntiDetect] Noise: Consultando grafico {name} - comportamiento humano")
                        time.sleep(random.uniform(0.8, 2.5))
        except Exception:
            pass

    def _noise_check_profit(self):
        """Human behavior: check payout/profit for instruments."""
        try:
            if self._ensure_connected():
                all_profit = self.api.get_all_profit()
                if all_profit:
                    # Pick a random instrument and check its payout
                    random_instrument = random.choice(list(all_profit.keys()))
                    self.log(f"[AntiDetect] Noise: Consultando payout de {random_instrument} - comportamiento humano")
                    time.sleep(random.uniform(1.0, 3.0))
        except Exception:
            pass

    # LOOP PRINCIPAL
    def run(self):
        self.running = True
        self._stop_flag = False
        self._end_reason = None
        self._trade_in_progress = False
        self._seen_trade_ids.clear()  # Clear dedup set for new session

        had_previous_state = self.load_state()

        if not had_previous_state:
            # New session - clear all history and trade state
            self.current_level = 1
            self.current_sublevel = 0
            self.total_trades = 0
            self.total_wins = 0
            self.total_losses = 0
            self.current_profit = 0.0
            self.previous_profits = []
            self.last_trade_amount = 0.0
            self.operated_assets = set()
            self._seen_trade_ids.clear()
            self._end_reason = None
            self._trade_in_progress = False
            if self.scanner:
                self.scanner.reset_operated()
            if self._ensure_connected():
                self.balance = self.api.get_balance()
                self.initial_balance = self.balance
        else:
            if self._ensure_connected():
                self.balance = self.api.get_balance()
                self.current_profit = self.balance - self.initial_balance
            if self.scanner:
                self.scanner.reset_operated()
                for asset in self.operated_assets:
                    self.scanner.add_operated(asset)

        niveles = self.config.get("niveles", 0)
        disable_niveles = self.config.get("disable_niveles", False)
        capital_op = self.config.get("capital_operacion", 2.50)
        stop_win = self.config.get("stop_win", 1.0)
        stop_loss = self.config.get("stop_loss", 1.0)
        payout_min = self.config.get("payout_min", 87)
        min_votes = self.config.get("min_strategy_votes", 4)
        min_quality = self.config.get("min_signal_quality", 88)
        max_trades = self.config.get("max_trades", 0)
        use_otc = self.config.get("use_strategy_otc", True)
        use_v2 = self.config.get("use_strategy_v2", False) if not use_otc else False

        # Strategy labels - only OTCEspecializada V1 and V2.1 Mejorada available
        if use_otc:
            strategy_label = "OTCEspecializada V1 (7 fuentes + Meta-learning)"
        elif use_v2:
            strategy_label = "V2.1 Mejorada (ADX+Calidad+Tendencia)"
        else:
            strategy_label = "OTCEspecializada V1 (7 fuentes + Meta-learning)"
            use_otc = True
            self.config["use_strategy_otc"] = True

        self.log("[Engine] ========================================")
        self.log("[Engine]   SISTEMA OUHRIES V5.4 - INICIADO")
        niveles_text = "OFF (Capital fijo)" if disable_niveles else f"{niveles}"
        self.log(f"[Engine]   Niveles: {niveles_text} | Capital Op: ${capital_op}")
        self.log(f"[Engine]   Stop Win: ${stop_win} | Stop Loss: ${stop_loss}")
        self.log(f"[Engine]   Payout: {payout_min}%+ | Expiracion: 1m")
        self.log(f"[Engine]   Estrategia: {strategy_label}")
        self.log(f"[Engine]   Calidad min: {min_quality}%")
        self.log(f"[Engine]   Votos min: {min_votes} | Max trades: {max_trades or 'Sin limite'}")
        if not disable_niveles:
            sublevel_pct = self.config.get('sublevel_profit_pct', 35)
            self.log(f"[Engine]   Sub-nivel: {sublevel_pct}% profit reinvertido")
        self.log(f"[Engine]   Telegram: {'ACTIVO' if self.config.get('telegram_enabled') else 'INACTIVO'}")
        if self.config.get('repeat_win', False):
            self.log(f"[Engine]   Repetir Win: SI (1 vez)")
        else:
            self.log(f"[Engine]   Repetir Win: NO")
        if had_previous_state:
            self.log(f"[Engine]   ** Sesion recuperada **")
        self.log("[Engine] ========================================")

        self.telegram.notify_session_start(
            config=self.config, balance=self.balance,
            mode=self.config.get("account_mode", "PRACTICE"),
            had_previous=had_previous_state
        )

        while not self._stop_flag:
            try:
                with self._lock:
                    if self._trade_in_progress:
                        time.sleep(5)
                        continue

                if not self._ensure_connected():
                    self.log("[Engine] Sin conexion, reintentando en 10s...")
                    time.sleep(10)
                    continue

                if self._check_stops():
                    break

                self.log(f"[Engine] Escaneando ({strategy_label}, votos >= {min_votes}, payout >= {payout_min}%, calidad >= {min_quality}%)")

                # Repetir Win: if repeat is active, use same instrument and re-analyze direction
                if self.repeat_win_enabled and self._repeat_instrument and self._repeat_count > 0:
                    instrument = self._repeat_instrument
                    # Re-analyze direction for the same instrument
                    direction = self.scanner.analyze_single_instrument(
                        instrument,
                        min_votes=min_votes,
                        payout_min_func=self._check_payout_min
                    )
                    if not direction:
                        self.log(f"[Engine] REPETIR: No se pudo analizar {instrument}, escaneando normalmente...")
                        self._repeat_count = 0
                        self._repeat_instrument = None
                        instrument, direction = self.scanner.scan_best_signal(
                            min_votes=min_votes,
                            payout_min_func=self._check_payout_min
                        )
                    else:
                        self.log(f"[Engine] REPETIR #{self._repeat_count}: {instrument} -> {direction.upper()}")
                else:
                    instrument, direction = self.scanner.scan_best_signal(
                        min_votes=min_votes,
                        payout_min_func=self._check_payout_min
                    )

                if not instrument or not direction:
                    self.log("[Engine] Sin senales. Esperando proxima vela...")
                    self._wait_for_next_candle()
                    continue

                self.log(f"[Engine] Senal encontrada: {instrument} {direction.upper()}")
                self._wait_for_candle_timing()

                if self._stop_flag:
                    break

                amount = self._get_trade_amount()
                self.current_instrument = instrument

                won, profit = self._execute_trade(instrument, direction, amount)

                if won is None:
                    continue

                self._advance_level(won)

                # Meta-learning feedback (OTCEspecializada V1)
                if use_otc:
                    try:
                        actual_direction = direction.lower() if won else ('put' if direction.lower() == 'call' else 'call')
                        meta_learner.record_result(actual_direction)
                    except Exception as e:
                        self.log(f"[Engine] Meta-learner feedback error: {e}")

                if self._check_stops():
                    break

                # Anti-Detection: Variable delay between operations (mimics human pauses)
                # Humans don't trade at fixed intervals - they take breaks, check charts, etc.
                delay = random.uniform(
                    self.config.get("delay_between_ops_min", 30),
                    self.config.get("delay_between_ops_max", 90)
                )
                # Anti-Detection: Occasionally take a longer break (15% chance)
                # This simulates a human stepping away from the computer
                human_action_pct = self.config.get("human_action_pct", 15)
                if random.randint(1, 100) <= human_action_pct:
                    extra_break = random.uniform(30, 120)
                    delay += extra_break
                    self.log(f"[AntiDetect] Pausa humana activada (+{extra_break:.0f}s)")
                
                # Anti-Detection: Noise browsing (30% chance)
                # Simulates a human checking charts/balance without trading
                if random.randint(1, 100) <= 30:
                    self._noise_browsing()
                
                # Anti-Detection: Entry hesitation (5% chance)
                # Sometimes a human hesitates and decides NOT to enter a trade
                # This makes the trading pattern less mechanical
                if random.randint(1, 100) <= 5:
                    hesitation = random.uniform(15, 45)
                    self.log(f"[AntiDetect] Hesitacion humana - saltando operacion (+{hesitation:.0f}s de espera)")
                    delay += hesitation
                
                self.log(f"[Engine] Esperando {delay:.0f}s antes de proxima operacion...")
                
                # Anti-Detection: Sleep in variable chunks, not one big sleep
                # Humans don't wait in precise intervals
                remaining = delay
                while remaining > 0 and not self._stop_flag:
                    chunk = min(remaining, random.uniform(5.0, 15.0))
                    time.sleep(chunk)
                    remaining -= chunk

            except Exception as e:
                self.log(f"[Engine] Error en loop principal: {e}")
                self.telegram.notify_error(f"Error en loop: {e}")
                self.save_state()
                # Anti-Detection: Random error recovery delay
                time.sleep(random.uniform(8, 25))

        self.running = False
        final_profit = self.balance - self.initial_balance
        win_rate = (self.total_wins / self.total_trades * 100) if self.total_trades > 0 else 0

        if self._end_reason is None:
            if self._stop_flag:
                self._end_reason = "manual"
            else:
                self._end_reason = "error"

        reason_labels = {
            "stopwin": "Stop Win",
            "stoploss": "Stop Loss",
            "max_trades": "Max Operaciones",
            "manual": "Detenido Manualmente",
            "error": "Error",
        }
        reason_label = reason_labels.get(self._end_reason, "Desconocido")

        self.log("[Engine] ========================================")
        self.log("[Engine]   SESION FINALIZADA")
        self.log(f"[Engine]   Razon: {reason_label}")
        self.log(f"[Engine]   Total operaciones: {self.total_trades}")
        self.log(f"[Engine]   Wins: {self.total_wins} | Losses: {self.total_losses}")
        self.log(f"[Engine]   Win rate: {win_rate:.1f}%")
        self.log(f"[Engine]   Profit final: ${final_profit:.2f}")
        self.log("[Engine] ========================================")
        self.status("Sesion finalizada")

        self.telegram.notify_session_end(
            total_trades=self.total_trades,
            total_wins=self.total_wins,
            total_losses=self.total_losses,
            balance=self.balance,
            initial_balance=self.initial_balance,
            current_profit=final_profit,
            end_reason=self._end_reason,
            max_trades_config=self.config.get("max_trades", 0)
        )
        self.telegram.stop()
        self.clear_state()

        if self._session_end_callback:
            try:
                summary = {
                    "reason": self._end_reason,
                    "reason_label": reason_label,
                    "total_trades": self.total_trades,
                    "total_wins": self.total_wins,
                    "total_losses": self.total_losses,
                    "win_rate": win_rate,
                    "profit": final_profit,
                    "balance": self.balance,
                    "initial_balance": self.initial_balance,
                }
                self._session_end_callback(summary)
            except Exception as e:
                self.log(f"[Engine] Error en session_end_callback: {e}")

    def _wait_for_next_candle(self):
        now = time.time()
        seconds_into_candle = now % 60
        wait = 60 - seconds_into_candle + random.uniform(1.0, 3.0)  # Anti-Detection: variable start
        self.log(f"[Timing] Esperando {wait:.0f}s hasta proxima vela...")
        while wait > 0 and not self._stop_flag:
            chunk = min(wait, random.uniform(2.0, 5.0))  # Anti-Detection: variable chunk
            time.sleep(chunk)
            wait -= chunk

    def stop(self):
        if self._end_reason is None:
            self._end_reason = "manual"
        self._stop_flag = True
        if self.scanner:
            self.scanner.stop()
        self.telegram.stop()
        self.save_state()
        self.log("[Engine] Deteniendo sesion...")

    def get_stats(self):
        profit = self.balance - self.initial_balance
        win_rate = (self.total_wins / self.total_trades * 100) if self.total_trades > 0 else 0
        return {
            "balance": self.balance,
            "initial_balance": self.initial_balance,
            "profit": profit,
            "total_trades": self.total_trades,
            "total_wins": self.total_wins,
            "total_losses": self.total_losses,
            "win_rate": win_rate,
            "current_level": self.current_level,
            "current_sublevel": self.current_sublevel,
            "current_instrument": self.current_instrument or "Ninguno",
            "running": self.running,
            "trade_in_progress": self._trade_in_progress,
            "sublevel_text": self._sublevel_text(),
        }
