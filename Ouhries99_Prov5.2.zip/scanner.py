"""
Sistema Ouhries V5 - Scanner OTC Secuencial
Escanea instrumentos uno por uno con delays anti-deteccion.
Reporta progreso del radar via callback para la GUI.
Payout 84+ automatico. Usa estrategia V2 con ADX y calidad.
"""

import time
import random
import threading
from instruments import get_otc_instruments
from strategies.strategies_v2 import analyze_candles_v2
from strategies.strategies_otc import analyze_candles_otc, STRONG_ONLY_PATTERNS


class OTCScanner:
    def __init__(self, api, config, log_callback=None, radar_callback=None):
        self.api = api
        self.config = config
        self.log = log_callback or (lambda x: None)
        self.radar_cb = radar_callback or (lambda asset, idx, total: None)
        self.operated_assets = set()
        self._stop_flag = False
        self._lock = threading.Lock()

    def stop(self):
        self._stop_flag = True

    def add_operated(self, instrument_name):
        with self._lock:
            self.operated_assets.add(instrument_name)

    def reset_operated(self):
        with self._lock:
            self.operated_assets.clear()

    def _get_candles(self, instrument_name, count=50):
        try:
            if hasattr(self.api, 'check_connect') and not self.api.check_connect():
                try:
                    if hasattr(self.api, '_ensure_connected'):
                        self.api._ensure_connected()
                    else:
                        self.api.connect()
                    time.sleep(2)
                except Exception:
                    pass
            endtime = int(time.time())
            candles = self.api.get_candles(instrument_name, 60, count, endtime)
            if candles and len(candles) > 5:
                return candles
        except Exception as e:
            self.log(f"[Scanner] Error velas {instrument_name}: {e}")
        return None

    def _is_asset_available(self, instrument_name):
        try:
            all_actives = self.api.get_all_ACTIVES_OPCODE()
            if all_actives and instrument_name in all_actives:
                return True
            from instruments import OTC_FALLBACK
            return instrument_name in OTC_FALLBACK
        except Exception:
            return False

    def _get_instrument_payout(self, instrument_name):
        try:
            all_profit = self.api.get_all_profit()
            if all_profit:
                for name in [instrument_name, instrument_name.upper(),
                             instrument_name.replace("-OTC", "_otc"),
                             instrument_name.replace("-OTC", "-otc")]:
                    if name in all_profit:
                        payout_info = all_profit[name]
                        if isinstance(payout_info, dict):
                            turbo = payout_info.get("turbo", 0)
                            if turbo:
                                return int(float(turbo) * 100)
                            binary = payout_info.get("binary", 0)
                            if binary:
                                return int(float(binary) * 100)
                        elif isinstance(payout_info, (int, float)):
                            return int(float(payout_info) * 100)
        except Exception:
            pass
        return 0

    def scan_best_signal(self, min_votes=None, payout_min_func=None):
        self._stop_flag = False
        if min_votes is None:
            min_votes = self.config.get("min_strategy_votes", 3)

        min_quality = self.config.get("min_signal_quality", 85)
        use_otc = self.config.get("use_strategy_otc", True)
        use_v2 = self.config.get("use_strategy_v2", False) if not use_otc else False

        if use_otc:
            strategy_label = "OTC V1"
        elif use_v2:
            strategy_label = "V2.1 Mejorada"
        else:
            strategy_label = "OTC V1"
            use_otc = True
        self.log(f"[Scanner] Obteniendo lista de instrumentos OTC (estrategia: {strategy_label}, votos min: {min_votes}, calidad min: {min_quality}%)...")
        instruments = get_otc_instruments(self.api)
        if not instruments:
            self.log("[Scanner] No se encontraron instrumentos OTC")
            return None, None

        total_instruments = len(instruments)
        self.log(f"[Scanner] Encontrados {total_instruments} instrumentos OTC")

        with self._lock:
            available = {k: v for k, v in instruments.items()
                        if k not in self.operated_assets}

        if not available:
            self.log("[Scanner] Todos los instrumentos ya operados, reiniciando lista...")
            self.reset_operated()
            available = instruments

        max_inst = self.config.get("scanner_max_instruments", 60)
        instrument_list = list(available.items())[:max_inst]

        best_signal = None
        best_instrument = None
        best_quality = 0
        best_strength = 0

        for idx, (name, active_id) in enumerate(instrument_list):
            if self._stop_flag:
                self.log("[Scanner] Escaneo detenido")
                return None, None

            self.radar_cb(name, idx + 1, len(instrument_list))

            scan_delay = random.uniform(
                self.config.get("delay_scanner_min", 0.5),
                self.config.get("delay_scanner_max", 1.0)
            )
            time.sleep(scan_delay)

            if not self._is_asset_available(name):
                continue

            if payout_min_func is not None:
                try:
                    if not payout_min_func(name):
                        continue
                except Exception:
                    pass

            candles_raw = self._get_candles(name, 50)
            if not candles_raw:
                continue

            try:
                candles = []
                for c in candles_raw:
                    if isinstance(c, dict):
                        candles.append([c["open"], c["max"], c["min"], c["close"]])
                    elif isinstance(c, (list, tuple)) and len(c) >= 4:
                        candles.append(list(c[:4]))
                if len(candles) < 5:
                    continue
            except Exception:
                continue

            if use_otc:
                # ============================================================
                # ESTRATEGIA OTCEspecializada V1 - Optimizada para OTC
                # ============================================================
                result_otc = analyze_candles_otc(candles, min_votes=min_votes)

                if result_otc is None:
                    continue

                quality = result_otc.get("quality", 0)
                direction = result_otc.get("direction", None)
                detail = result_otc.get("votes_detail", {})

                # Filtro de calidad
                if quality < min_quality:
                    self.log(f"[Scanner] {name}: {direction.upper()} RECHAZADO (calidad: {quality}% < {min_quality}%)")
                    continue

                payout = self._get_instrument_payout(name)
                signal_votes = result_otc.get("signal_votes", 0)
                self.log(f"[Scanner] {name}: {direction.upper()} (calidad: {quality}%, confluencia: {signal_votes}/7, payout: {payout}%)")

                # Mejor senal = mayor calidad, desempate por confluencia
                if quality > best_quality or (quality == best_quality and signal_votes > best_strength):
                    best_quality = quality
                    best_strength = signal_votes
                    best_signal = direction
                    best_instrument = name

            elif use_v2:
                # ============================================================
                # ESTRATEGIA V2 - Con ADX, calidad, tendencia
                # ============================================================
                result_v2 = analyze_candles_v2(candles, min_votes=min_votes)

                if result_v2 is None:
                    continue

                quality = result_v2.get("quality", 0)
                direction = result_v2.get("direction", None)
                detail = result_v2.get("votes_detail", {})
                adx = detail.get("adx", 0)

                # Filtro de calidad
                if quality < min_quality:
                    self.log(f"[Scanner] {name}: {direction.upper()} RECHAZADO (calidad: {quality}% < {min_quality}%, ADX: {adx:.1f})")
                    continue

                payout = self._get_instrument_payout(name)
                signal_votes = result_v2.get("signal_votes", 0)
                self.log(f"[Scanner] {name}: {direction.upper()} (calidad: {quality}%, ADX: {adx:.1f}, votos: {signal_votes}, payout: {payout}%)")

                # Mejor señal = mayor calidad, desempate por votos
                if quality > best_quality or (quality == best_quality and signal_votes > best_strength):
                    best_quality = quality
                    best_strength = signal_votes
                    best_signal = direction
                    best_instrument = name

            else:
                # Fallback: usar OTC V1 si ninguna estrategia esta seleccionada
                result_otc = analyze_candles_otc(candles, min_votes=min_votes)
                if result_otc is None:
                    continue
                quality = result_otc.get("quality", 0)
                direction = result_otc.get("direction", None)
                if quality < min_quality:
                    continue
                payout = self._get_instrument_payout(name)
                signal_votes = result_otc.get("signal_votes", 0)
                self.log(f"[Scanner] {name}: {direction.upper()} (calidad: {quality}%, confluencia: {signal_votes}/7, payout: {payout}%)")
                if quality > best_quality or (quality == best_quality and signal_votes > best_strength):
                    best_quality = quality
                    best_strength = signal_votes
                    best_signal = direction
                    best_instrument = name

            think_delay = random.uniform(
                self.config.get("delay_thinking_min", 2),
                self.config.get("delay_thinking_max", 5)
            )
            time.sleep(think_delay * 0.2)

        self.radar_cb("", 0, 0)

        if best_instrument and best_signal:
            payout = self._get_instrument_payout(best_instrument)
            self.log(f"[Scanner] Mejor senal: {best_instrument} -> {best_signal.upper()} (payout: {payout}%, calidad: {best_quality}%)")
            return best_instrument, best_signal

        self.log("[Scanner] No se encontraron senales validas")
        return None, None

    def analyze_single_instrument(self, instrument_name, min_votes=None, payout_min_func=None):
        """Analyze a single instrument and return direction only. Used for Repetir Win."""
        try:
            if payout_min_func and not payout_min_func(instrument_name):
                self.log(f"[Scanner] REPETIR: {instrument_name} no cumple payout minimo")
                return None
            
            # Get candles for this instrument
            candles_raw = self._get_candles(instrument_name, 50)
            if not candles_raw or len(candles_raw) < 5:
                return None

            # Parse candles
            try:
                candles = []
                for c in candles_raw:
                    if isinstance(c, dict):
                        candles.append([c["open"], c["max"], c["min"], c["close"]])
                    elif isinstance(c, (list, tuple)) and len(c) >= 4:
                        candles.append(list(c[:4]))
                if len(candles) < 5:
                    return None
            except Exception:
                return None

            min_quality = self.config.get("min_signal_quality", 85)
            use_otc = self.config.get("use_strategy_otc", True)

            if use_otc:
                result_otc = analyze_candles_otc(candles, min_votes=min_votes or self.config.get("min_strategy_votes", 3))
                if result_otc is None:
                    return None
                quality = result_otc.get("quality", 0)
                direction = result_otc.get("direction", None)
                if quality >= min_quality and direction:
                    return direction
            else:
                result_v2 = analyze_candles_v2(candles, min_votes=min_votes or self.config.get("min_strategy_votes", 3))
                if result_v2 is None:
                    return None
                quality = result_v2.get("quality", 0)
                direction = result_v2.get("direction", None)
                if quality >= min_quality and direction:
                    return direction

            return None
        except Exception as e:
            self.log(f"[Scanner] Error analizando {instrument_name}: {e}")
            return None
