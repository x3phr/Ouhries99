@echo off
title Sistema Ouhries V7 - 1-Click Deploy
color 0A

echo ================================================
echo   SISTEMA OUHRIES V7 - 1-CLICK DEPLOY
echo   Anti-Detection PRO v4 + Unlimited Sessions
echo ================================================
echo.

:: Change to the directory where this script is located
cd /d "%~dp0"

:: Step 1: Kill any residual processes on port 8585
echo [1/5] Limpiando puerto 8585...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :8585 ^| findstr LISTENING') do (
    taskkill /F /PID %%a >nul 2>nul
)
timeout /t 1 /nobreak >nul

:: Step 2: Check Python
echo [2/5] Verificando Python...
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python no esta instalado.
    echo Descargalo de: https://www.python.org/downloads/
    echo Asegurate de marcar "Add Python to PATH".
    echo.
    pause
    exit /b 1
)
echo       Python encontrado.

:: Step 3: Check Node.js (for Electron)
echo [3/5] Verificando Node.js...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [AVISO] Node.js no esta instalado - modo navegador web.
    echo       Descargalo de: https://nodejs.org/ para modo Electron.
    echo.
    set "USE_ELECTRON=0"
) else (
    echo       Node.js encontrado.
    set "USE_ELECTRON=1"
)

:: Step 4: Install Python dependencies if needed
echo [4/5] Verificando dependencias Python...
pip show fastapi >nul 2>nul
if %errorlevel% neq 0 (
    echo       Instalando dependencias de Python...
    pip install -r requirements.txt --quiet
    if %errorlevel% neq 0 (
        echo [ERROR] Fallo la instalacion de dependencias.
        echo Intenta manualmente: pip install -r requirements.txt
        pause
        exit /b 1
    )
)
echo       Dependencias OK.

:: Step 5: Clean Electron cache
echo [5/5] Limpiando cache...
set ELECTRON_DISABLE_CACHE=1
for %%N in ("Sistema Ouhries" "ouhries" "Ouhries" "OuhriesV6" "OuhriesV7") do (
    rd /s /q "%APPDATA%\%%~N\Cache" 2>nul
    rd /s /q "%APPDATA%\%%~N\Code Cache" 2>nul
    rd /s /q "%APPDATA%\%%~N\GPUCache" 2>nul
)
echo       Cache limpio.

echo.
echo ================================================
echo   INICIANDO SISTEMA OUHRIES V7
echo ================================================
echo.

:: Check if we should use Electron or Web mode
if "%USE_ELECTRON%"=="1" (
    :: Check if Electron is installed
    if not exist "electron\node_modules\electron\dist\electron.exe" (
        echo       Instalando Electron (solo la primera vez)...
        cd electron
        call npm install
        cd ..
        echo.
    )
    
    :: Start Electron app
    echo   Iniciando modo Electron...
    cd electron
    call npx electron .
    if %errorlevel% neq 0 (
        echo.
        echo [ERROR] Electron fallo. Iniciando modo navegador...
        cd ..
        goto :web_mode
    )
) else (
    goto :web_mode
)
goto :end

:web_mode
echo   Iniciando servidor web en http://localhost:8585 ...
echo   Presiona Ctrl+C para detener.
echo.
python server.py
goto :end

:end
echo.
echo   Sistema Ouhries V7 detenido.
pause
