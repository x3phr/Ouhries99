"""
Sistema Ouhries V6.2fixed - IQ Option API Patched Wrapper (Anti-Detection v4)
Parchea la libreria iqoptionapi para funcionar al 100%:
- TLS FINGERPRINT MASKING con curl_cffi (impersona Chrome real)
- User-Agent spoofing con rotacion de Chrome realista (2025/2026 versions)
- Headers de navegador real en TODAS las peticiones
- Session rotation periodica (30-60 min)
- WebSocket anti-detection headers con Origin
- Timeouts en TODAS las operaciones bloqueantes
- Auto-reconexion con backoff exponencial + jitter
- ACTIVES cache auto-actualizado
- check_win_v3 con timeout y fallback a balance
- get_candles con timeout y reintentos
- buy con reintento automatico + human jitter
- get_balance con retry
- get_all_profit cacheado con TTL
- Noise browsing: balance checks sin operar
- buy jitter: random delay antes de enviar orden
- FIX V6.2fixed: Connection is already closed - ROOT CAUSE FIX
  * Connection Generation Counter para prevenir stale callbacks
  * Monkey-patch IQOptionAPI.connect() para cerrar primer WS antes del segundo
  * Safe close con verificacion de thread terminado
  * Reset global_value antes de reconectar
  * Monitoreo de conexion con watchdog thread
  * check_connect confiable con verificacion de generacion
- Anti-Detection v4: Chrome UAs actualizados 2026, curl_cffi profiles actualizados
"""

import time
import logging
import threading
import random
import traceback
from datetime import datetime

from iqoptionapi.stable_api import IQ_Option
import iqoptionapi.global_value as global_value
import iqoptionapi.constants as OP_code

# ============================================================
# ANTI-DETECTION: curl_cffi for TLS fingerprint masking
# ============================================================
CURL_CFFI_AVAILABLE = False
try:
    from curl_cffi import requests as curl_requests
    CURL_CFFI_AVAILABLE = True
except ImportError:
    curl_requests = None

logger = logging.getLogger("iq_patched")

# ============================================================
# FIX V6.2fixed: Connection Generation Counter
# ROOT CAUSE: Los callbacks on_open/on_close del WebSocket viejo
# escriben a global_value.check_websocket_if_connect DESPUES de que
# una nueva conexion fue establecida, corrompiendo el estado.
# SOLUCION: Cada conexion tiene una generacion, y los callbacks
# solo escriben al global si su generacion coincide con la actual.
# ============================================================
_connection_generation = 0
_connection_lock = threading.Lock()

def _next_generation():
    """Incrementa el contador de generacion de conexion."""
    global _connection_generation
    with _connection_lock:
        _connection_generation += 1
        gen = _connection_generation
    return gen

def _current_generation():
    """Retorna la generacion actual."""
    with _connection_lock:
        return _connection_generation

# ============================================================
# FIX V6.2: Patch websocket._abnf para permitir RSV1 (permessage-deflate)
# El websocket-client 0.56 bundled con iqoptionapi lanza error
# "rsv is not implemented, yet" cuando el servidor IQ Option
# envía frames con compresión (RSV1 bit = 1).
# Este patch permite RSV1 sin crashear.
# ============================================================
_abnf_patched = False

def _patch_websocket_abnf():
    """Patch websocket._abnf.ABNF.validate() para permitir RSV1
    (permessage-deflate compression) sin lanzar excepcion."""
    global _abnf_patched
    if _abnf_patched:
        return
    try:
        import websocket._abnf as _abnf

        _original_validate = _abnf.ABNF.validate

        def _patched_validate(self, skip_utf8_validation=False):
            # Permitir RSV1 (permessage-deflate) pero rechazar RSV2/RSV3
            if self.rsv2 or self.rsv3:
                raise _abnf.WebSocketProtocolException("rsv is not implemented, yet")
            # RSV1 es OK - indica permessage-deflate compression
            # Continuar con la validacion normal del opcode y demas
            if self.opcode not in _abnf.ABNF.OPCODES:
                raise _abnf.WebSocketProtocolException("Invalid opcode %r", self.opcode)
            if self.opcode == _abnf.ABNF.OPCODE_PING and not self.fin:
                raise _abnf.WebSocketProtocolException("Invalid ping frame.")
            if self.opcode == _abnf.ABNF.OPCODE_CLOSE:
                l = len(self.data)
                if not l:
                    return
                if l == 1 or l >= 126:
                    raise _abnf.WebSocketProtocolException("Invalid close frame.")
                if l > 2 and not skip_utf8_validation:
                    try:
                        from websocket._utils import validate_utf8
                        if not validate_utf8(self.data[2:]):
                            raise _abnf.WebSocketProtocolException("Invalid close frame.")
                    except ImportError:
                        pass

        _abnf.ABNF.validate = _patched_validate
        _abnf_patched = True
        logger.info("[Patched] websocket._abnf.ABNF.validate() patched (RSV1/permessage-deflate OK)")
    except Exception as e:
        logger.warning(f"[Patched] Error patcheando websocket._abnf: {e}")

# Aplicar el patch de ABNF inmediatamente al importar
_patch_websocket_abnf()


def _patch_websocket_client_compat():
    """FIX V6.2fixed: Parchear iqoptionapi.ws.client.WebsocketClient para:
    1. Compatibilidad con websocket-client >= 1.0
    2. GENERATION-AWARE callbacks que previenen escrituras stale
    
    ROOT CAUSE FIX: on_open/on_close escriben a global_value.check_websocket_if_connect
    sin distinguir entre conexiones. Cuando el thread viejo muere despues de que una
    nueva conexion fue establecida, su on_close corrompe el estado global.
    
    SOLUCION: Cada WebsocketClient captura la generacion al crearse.
    Los callbacks solo escriben al global si su generacion coincide con la actual.
    """
    try:
        from iqoptionapi.ws.client import WebsocketClient

        # Patch on_open con generation-aware
        _original_on_open = WebsocketClient.on_open

        @staticmethod
        def _gen_on_open(wss):
            """on_open que solo escribe si la generacion coincide."""
            try:
                # Obtener la generacion del WebsocketClient asociado
                gen = getattr(wss, '_ouhries_generation', None)
                if gen is not None and gen != _current_generation():
                    logger.debug(f"[Patched] on_open STALE ignorado (gen={gen}, current={_current_generation()})")
                    return
            except Exception:
                pass
            # Llamar al original o escribir directamente
            try:
                global_value.check_websocket_if_connect = 1
                logger.debug(f"[Patched] on_open: conexion establecida (gen={gen})")
            except Exception:
                pass

        WebsocketClient.on_open = _gen_on_open

        # Patch on_close con generation-aware
        @staticmethod
        def _gen_on_close(*args, **kwargs):
            """on_close que solo escribe si la generacion coincide."""
            wss = args[0] if args else None
            try:
                gen = getattr(wss, '_ouhries_generation', None)
                if gen is not None and gen != _current_generation():
                    logger.debug(f"[Patched] on_close STALE ignorado (gen={gen}, current={_current_generation()})")
                    return
            except Exception:
                pass
            # Solo escribir si es la generacion actual
            try:
                global_value.check_websocket_if_connect = 0
                logger.debug(f"[Patched] on_close: conexion cerrada (gen={gen})")
            except Exception:
                pass

        WebsocketClient.on_close = _gen_on_close

        # Patch on_error con generation-aware
        _original_on_error = WebsocketClient.on_error

        @staticmethod
        def _gen_on_error(wss, error):
            """on_error que solo escribe si la generacion coincide."""
            try:
                gen = getattr(wss, '_ouhries_generation', None)
                if gen is not None and gen != _current_generation():
                    logger.debug(f"[Patched] on_error STALE ignorado (gen={gen})")
                    return
            except Exception:
                pass
            try:
                global_value.websocket_error_reason = str(error)
                global_value.check_websocket_if_error = True
                logger.debug(f"[Patched] on_error: {error} (gen={gen})")
            except Exception:
                pass

        WebsocketClient.on_error = _gen_on_error

        # Patch on_message para aceptar ws como primer argumento (1.x)
        _original_on_message = WebsocketClient.on_message

        def _compat_on_message(self, *args, **kwargs):
            if len(args) == 1:
                return _original_on_message(self, args[0])
            elif len(args) >= 2:
                return _original_on_message(self, args[1])
            return _original_on_message(self, *args, **kwargs)

        WebsocketClient.on_message = _compat_on_message

        logger.info("[Patched] WebsocketClient callbacks parcheados (generation-aware + compat 1.x)")
    except Exception as e:
        logger.warning(f"[Patched] Error parcheando WebsocketClient: {e}")


# Aplicar el patch de compatibilidad inmediatamente
_patch_websocket_client_compat()

# ============================================================
# FIX V6.2: Monkey-patch IQOptionAPI.close() para manejar
# "Connection is already closed" sin crashear
# ============================================================
_iqapi_close_patched = False
_iqapi_ws_patched = False
_iqapi_connect_patched = False

def _patch_iqoptionapi_close():
    """FIX V6.2fixed: Monkey-patch IQOptionAPI.close() para:
    1. Manejar 'Connection is already closed' sin crashear
    2. Esperar a que el thread termine realmente (hasta 10s)
    3. Invalidar callbacks stale del websocket cerrado"""
    global _iqapi_close_patched
    if _iqapi_close_patched:
        return
    try:
        from iqoptionapi.api import IQOptionAPI

        def _safe_close(self):
            """Close seguro que maneja 'Connection is already closed'
            y espera a que el thread viejo termine realmente."""
            # Paso 1: Invalidar callbacks del websocket actual
            # Esto previene que on_close/on_open escriban al global despues
            try:
                if hasattr(self, 'websocket_client') and self.websocket_client is not None:
                    if hasattr(self.websocket_client, 'wss') and self.websocket_client.wss is not None:
                        # Marcar como generacion invalida para que los callbacks sean no-ops
                        self.websocket_client.wss._ouhries_generation = -1
            except Exception:
                pass

            # Paso 2: Cerrar el websocket
            try:
                if hasattr(self, 'websocket_client') and self.websocket_client is not None:
                    try:
                        if hasattr(self.websocket_client, 'wss') and self.websocket_client.wss is not None:
                            self.websocket_client.wss.close()
                    except Exception as ws_err:
                        err_str = str(ws_err)
                        if "already closed" in err_str.lower() or "connection is already closed" in err_str.lower():
                            logger.debug("[Patched] WebSocket ya estaba cerrado - ignorando error")
                        else:
                            logger.debug(f"[Patched] WebSocket close error (ignorable): {ws_err}")
            except Exception as e:
                logger.debug(f"[Patched] Error en safe_close websocket: {e}")

            # Paso 3: Esperar a que el thread termine (hasta 10s con verificacion)
            try:
                if hasattr(self, 'websocket_thread') and self.websocket_thread is not None:
                    if self.websocket_thread.is_alive():
                        self.websocket_thread.join(timeout=10.0)
                        if self.websocket_thread.is_alive():
                            logger.debug("[Patched] WebSocket thread no termino en 10s (daemon, continuando)")
                        else:
                            logger.debug("[Patched] WebSocket thread termino correctamente")
            except Exception as e:
                logger.debug(f"[Patched] Error en safe_close thread join: {e}")

        IQOptionAPI.close = _safe_close
        _iqapi_close_patched = True
        logger.info("[Patched] IQOptionAPI.close() monkey-patched (safe close + stale invalidation)")
    except Exception as e:
        logger.warning(f"[Patched] Error monkey-patching IQOptionAPI.close(): {e}")


def _patch_iqoptionapi_connect():
    """FIX V6.2fixed: Monkey-patch IQOptionAPI.connect() para:
    ROOT CAUSE: Cuando el SSID expira, connect() llama start_websocket() DOS VECESS
    sin cerrar el primer websocket, creando un thread huerfano que corrompe
    global_value.check_websocket_if_connect via su callback on_close.
    
    SOLUCION: Cerrar el primer websocket antes de crear el segundo.
    """
    global _iqapi_connect_patched
    if _iqapi_connect_patched:
        return
    try:
        from iqoptionapi.api import IQOptionAPI

        _original_connect = IQOptionAPI.connect

        def _patched_connect(self):
            import iqoptionapi.global_value as gv
            gv.ssl_Mutual_exclusion = False
            gv.ssl_Mutual_exclusion_write = False

            try:
                self.close()
            except Exception:
                pass

            check_websocket, websocket_reason = self.start_websocket()

            if check_websocket == False:
                return check_websocket, websocket_reason

            # Doing temp ssid reconnect for speed up
            if gv.SSID != None:
                check_ssid = self.send_ssid()

                if check_ssid == False:
                    # SSID expired - need to re-login
                    # FIX V6.2fixed: Cerrar el PRIMER websocket ANTES de crear el segundo
                    # El codigo original NO hace close() antes del segundo start_websocket()
                    # lo que deja un thread huerfano que corrompe global_value
                    try:
                        logger.info("[Patched] SSID expirado, cerrando primer WS antes de reconectar...")
                        self.close()
                    except Exception as e:
                        logger.debug(f"[Patched] Error cerrando primer WS (ignorable): {e}")

                    response = self.get_ssid()
                    try:
                        gv.SSID = response.cookies["ssid"]
                    except Exception:
                        return False, response.text if hasattr(response, 'text') else "SSID get failed"
                    import atexit
                    atexit.register(self.logout)
                    self.start_websocket()
                    self.send_ssid()
            else:
                # The ssid is None, need get ssid
                response = self.get_ssid()
                try:
                    gv.SSID = response.cookies["ssid"]
                except Exception:
                    self.close()
                    return False, response.text if hasattr(response, 'text') else "SSID get failed"
                import atexit
                atexit.register(self.logout)
                self.send_ssid()

            # Set ssid cookie
            import requests
            requests.utils.add_dict_to_cookiejar(self.session.cookies, {"ssid": gv.SSID})

            self.timesync.server_timestamp = None
            # Wait for timeSync with timeout (prevent infinite loop)
            import time as _time
            start = _time.time()
            while True:
                try:
                    if self.timesync.server_timestamp != None:
                        break
                except Exception:
                    pass
                if _time.time() - start > 30:
                    logger.warning("[Patched] timeSync timeout (30s)")
                    break
                _time.sleep(0.1)
            return True, None

        IQOptionAPI.connect = _patched_connect
        _iqapi_connect_patched = True
        logger.info("[Patched] IQOptionAPI.connect() monkey-patched (double start_websocket fix + timeSync timeout)")
    except Exception as e:
        logger.warning(f"[Patched] Error monkey-patching IQOptionAPI.connect(): {e}")


def _patch_iqoptionapi_start_websocket():
    """FIX V6.2: Monkey-patch IQOptionAPI.start_websocket() para:
    1. Timeout para el thread de conexion (evitar colgar indefinidamente)
    Nota: El RSV1/permessage-deflate se maneja parcheando websocket._abnf directamente
    """
    global _iqapi_ws_patched
    if _iqapi_ws_patched:
        return
    try:
        from iqoptionapi.api import IQOptionAPI
        import ssl as _ssl

        def _patched_start_websocket(self):
            import iqoptionapi.global_value as gv
            import threading as _threading
            import time as _time

            gv.check_websocket_if_connect = None
            gv.check_websocket_if_error = False
            gv.websocket_error_reason = None

            # FIX V6.2fixed: Asignar nueva generacion a esta conexion
            gen = _next_generation()

            from iqoptionapi.ws.client import WebsocketClient
            self.websocket_client = WebsocketClient(self)

            # FIX V6.2fixed: Marcar el WebSocketApp con la generacion actual
            # Los callbacks generation-aware leen este atributo para decidir
            # si deben escribir al global o ignorarse (stale callback)
            if hasattr(self.websocket_client, 'wss') and self.websocket_client.wss is not None:
                self.websocket_client.wss._ouhries_generation = gen
                logger.debug(f"[Patched] WebSocket creado con generacion={gen}")

            self.websocket_thread = _threading.Thread(
                target=self.websocket_client.wss.run_forever,
                kwargs={
                    'sslopt': {
                        "check_hostname": False,
                        "cert_reqs": _ssl.CERT_NONE,
                        "ca_certs": "cacert.pem"
                    },
                },
                daemon=True
            )
            self.websocket_thread.start()

            # FIX: Timeout de 45s para la conexion WebSocket
            start = _time.time()
            while _time.time() - start < 45:
                try:
                    # FIX V6.2fixed: Solo confiar en check_websocket_if_connect
                    # si la generacion actual coincide (proteccion contra stale writes)
                    if gv.check_websocket_if_error:
                        # Verificar que el error es de nuestra generacion
                        if gen == _current_generation():
                            return False, gv.websocket_error_reason
                    if gv.check_websocket_if_connect == 0:
                        if gen == _current_generation():
                            return False, "Websocket connection closed."
                    elif gv.check_websocket_if_connect == 1:
                        if gen == _current_generation():
                            return True, None
                except Exception:
                    pass
                _time.sleep(0.1)

            # Timeout
            logger.warning("[Patched] start_websocket timeout (45s)")
            return False, "WebSocket connection timeout"

        IQOptionAPI.start_websocket = _patched_start_websocket
        _iqapi_ws_patched = True
        logger.info("[Patched] IQOptionAPI.start_websocket() monkey-patched (timeout fix)")
    except Exception as e:
        logger.warning(f"[Patched] Error monkey-patching start_websocket: {e}")


# ============================================================
# ANTI-DETECTION v3: WebSocket header patching (DEFERRED)
# ============================================================
_ws_patch_applied = False

def _apply_ws_patch_once():
    """Aplica el patch de WebSocket headers una sola vez, de forma diferida."""
    global _ws_patch_applied
    if _ws_patch_applied:
        return
    try:
        import websocket
        _original_websocket_init = websocket.WebSocketApp.__init__

        def _patched_ws_init(self, url, **kwargs):
            browser_ws_headers = {
                "User-Agent": _get_random_ua(),
                "Origin": "https://iqoption.com",
                "Sec-WebSocket-Version": "13",
                # FIX V6.2: REMOVIDO "Sec-WebSocket-Extensions: permessage-deflate"
                # El servidor IQ Option activa compresion si ve esta extension,
                # pero el websocket-client bundled (0.56) no soporta descompresion,
                # causando "cannot decode" y "rsv is not implemented".
                # Sin este header, el servidor envía frames sin comprimir.
            }
            if "header" in kwargs and kwargs["header"]:
                if isinstance(kwargs["header"], dict):
                    kwargs["header"].update(browser_ws_headers)
                elif isinstance(kwargs["header"], list):
                    for key, value in browser_ws_headers.items():
                        kwargs["header"].append(f"{key}: {value}")
            else:
                kwargs["header"] = browser_ws_headers
            _original_websocket_init(self, url, **kwargs)

        websocket.WebSocketApp.__init__ = _patched_ws_init
        _ws_patch_applied = True
        logger.info("[AntiDetect] WebSocket headers patched (diferido)")
    except Exception as e:
        logger.warning(f"[AntiDetect] Error patcheando WebSocket: {e}")

DEFAULT_TIMEOUT_CANDLE = 30
DEFAULT_TIMEOUT_BUY = 15
DEFAULT_TIMEOUT_CHECK_WIN = 120
DEFAULT_TIMEOUT_BALANCE = 15
DEFAULT_TIMEOUT_PROFIT = 60
DEFAULT_TIMEOUT_ACTIVES = 30
DEFAULT_TIMEOUT_CONNECT = 60
MAX_RECONNECT_ATTEMPTS = 10
RECONNECT_BACKOFF_BASE = 2
_active_name_cache = {}

# ============================================================
# ANTI-DETECTION v3: Realistic Chrome User-Agent rotation (2025/2026)
# ============================================================
CHROME_USER_AGENTS = [
    # Chrome 135 (Jun 2026)
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 Edg/135.0.0.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
]

BROWSER_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Accept-Language": "en-US,en;q=0.9,es;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Cache-Control": "max-age=0",
    "sec-ch-ua": '"Not A(Brand";v="99", "Google Chrome";v="135", "Chromium";v="135"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
}

SESSION_ROTATION_MIN = 1800
SESSION_ROTATION_MAX = 3600


def _get_random_ua():
    return random.choice(CHROME_USER_AGENTS)


def _inject_browser_headers(session):
    if session is None:
        return
    session.headers["User-Agent"] = _get_random_ua()
    for key, value in BROWSER_HEADERS.items():
        session.headers[key] = value


def _patch_api_session(api):
    try:
        if hasattr(api, 'session') and api.session is not None:
            if CURL_CFFI_AVAILABLE and api.session is not None:
                try:
                    old_session = api.session
                    ua = old_session.headers.get("User-Agent", _get_random_ua())
                    cookies = dict(old_session.cookies)

                    impersonate_profiles = ["chrome131", "chrome130", "chrome124", "chrome120"]
                    chosen_profile = random.choice(impersonate_profiles)
                    new_session = curl_requests.Session(impersonate=chosen_profile)

                    new_session.headers["User-Agent"] = ua
                    for key, value in BROWSER_HEADERS.items():
                        new_session.headers[key] = value

                    for name, value in cookies.items():
                        new_session.cookies.set(name, value)

                    api.session = new_session
                    logger.info(f"[AntiDetect] TLS FINGERPRINT MASKING ACTIVO - curl_cffi ({chosen_profile})")
                except Exception as e:
                    logger.warning(f"[AntiDetect] curl_cffi session fallo: {e}")
                    _inject_browser_headers(api.session)
            else:
                _inject_browser_headers(api.session)
                if not CURL_CFFI_AVAILABLE:
                    logger.warning("[AntiDetect] curl_cffi NO disponible - TLS fingerprint NO enmascarado")
    except Exception as e:
        logger.warning(f"[AntiDetect] Error patcheando session: {e}")


def _safe_close_api(api):
    """Cierra una instancia de IQ_Option de forma segura.
    FIX V6.2: Maneja 'Connection is already closed' en todos los niveles."""
    if api is None:
        return
    try:
        # Intentar cerrar el IQOptionAPI interno si existe
        if hasattr(api, 'api') and api.api is not None:
            inner_api = api.api
            # Cerrar websocket de forma segura
            try:
                if hasattr(inner_api, 'websocket_client') and inner_api.websocket_client is not None:
                    try:
                        if hasattr(inner_api.websocket_client, 'wss') and inner_api.websocket_client.wss is not None:
                            inner_api.websocket_client.wss.close()
                    except Exception as ws_err:
                        err_str = str(ws_err).lower()
                        if "already closed" in err_str:
                            logger.debug("[Patched] WebSocket ya cerrado al hacer safe_close (esperado)")
                        else:
                            logger.debug(f"[Patched] WebSocket close error (ignorable): {ws_err}")
            except Exception as e:
                logger.debug(f"[Patched] Error cerrando websocket: {e}")

            # Hacer join del thread con timeout
            try:
                if hasattr(inner_api, 'websocket_thread') and inner_api.websocket_thread is not None:
                    if inner_api.websocket_thread.is_alive():
                        inner_api.websocket_thread.join(timeout=5.0)
            except Exception as e:
                logger.debug(f"[Patched] Error join thread: {e}")
    except Exception as e:
        logger.debug(f"[Patched] Error en safe_close_api: {e}")


def _reset_global_value():
    """FIX V6.2: Resetear global_value antes de reconectar.
    El estado residual de una conexion previa puede causar problemas:
    - check_websocket_if_connect puede estar en 0 (cerrado) o 1 (abierto)
    - check_websocket_if_error puede estar en True
    - ssl_Mutual_exclusion puede estar en True (deadlock potencial)
    
    Se preservan SSID y balance_id para permitir reconexion rapida.
    """
    # Guardar valores que queremos preservar
    saved_ssid = global_value.SSID
    saved_balance_id = global_value.balance_id

    # Resetear estados de conexion
    global_value.check_websocket_if_connect = None
    global_value.check_websocket_if_error = False
    global_value.websocket_error_reason = None

    # FIX CRITICO: Resetear mutex de SSL para evitar deadlock
    # Si un hilo se muere mientras ssl_Mutual_exclusion es True,
    # todos los demas hilos se quedan esperando indefinidamente
    global_value.ssl_Mutual_exclusion = False
    global_value.ssl_Mutual_exclusion_write = False

    # Restaurar valores preservados
    global_value.SSID = saved_ssid
    global_value.balance_id = saved_balance_id

    logger.debug("[Patched] global_value reseteado para reconexion")


class IQ_Option_Patched:
    def __init__(self, email, password):
        self._email = email
        self._password = password

        # FIX V6.2fixed: Aplicar todos los patches ANTES de crear la API
        _patch_iqoptionapi_close()          # Monkey-patch close() para safe close
        _patch_iqoptionapi_connect()        # FIX ROOT CAUSE: double start_websocket
        _patch_iqoptionapi_start_websocket()  # Monkey-patch start_websocket (generation-aware)
        _apply_ws_patch_once()               # WebSocket anti-detection headers

        self._api = IQ_Option(email, password)
        self._lock = threading.Lock()
        self._connected = False
        self._actives_cache = {}
        self._actives_cache_time = 0
        self._profit_cache = None
        self._profit_cache_time = 0
        self._profit_cache_ttl = 300
        self._reconnect_count = 0
        self._last_connect_time = 0
        self._last_session_refresh = 0
        self._next_rotation = random.uniform(SESSION_ROTATION_MIN, SESSION_ROTATION_MAX)
        self._watchdog_stop = threading.Event()
        self._watchdog_thread = None
        _patch_api_session(self._api)

    def __getattr__(self, name):
        return getattr(self._api, name)

    def _maybe_rotate_session(self):
        now = time.time()
        if (now - self._last_session_refresh) > self._next_rotation:
            try:
                if hasattr(self._api, 'session') and self._api.session is not None:
                    new_ua = _get_random_ua()
                    self._api.session.headers["User-Agent"] = new_ua
                    chrome_version = new_ua.split("Chrome/")[1].split(" ")[0] if "Chrome/" in new_ua else "122"
                    self._api.session.headers["sec-ch-ua"] = f'"Not A(Brand";v="99", "Google Chrome";v="{chrome_version}", "Chromium";v="{chrome_version}"'
                    languages = [
                        "en-US,en;q=0.9,es;q=0.8",
                        "en-US,en;q=0.9",
                        "en-US,en;q=0.9,es;q=0.8,pt;q=0.7",
                        "en,en-US;q=0.9,es;q=0.8",
                    ]
                    self._api.session.headers["Accept-Language"] = random.choice(languages)

                    if CURL_CFFI_AVAILABLE and isinstance(self._api.session, curl_requests.Session):
                        try:
                            profiles = ["chrome131", "chrome130", "chrome124", "chrome120"]
                            new_profile = random.choice(profiles)
                            old_session = self._api.session
                            new_session = curl_requests.Session(impersonate=new_profile)
                            for key, value in old_session.headers.items():
                                new_session.headers[key] = value
                            for cookie in old_session.cookies.jar:
                                new_session.cookies.set(cookie.name, cookie.value)
                            self._api.session = new_session
                            logger.info(f"[AntiDetect] TLS fingerprint rotado -> {new_profile}")
                        except Exception as e:
                            logger.warning(f"[AntiDetect] Error rotando TLS fingerprint: {e}")

                    logger.info(f"[AntiDetect] Session rotada - Chrome/{chrome_version}")
                self._last_session_refresh = now
                self._next_rotation = random.uniform(SESSION_ROTATION_MIN, SESSION_ROTATION_MAX)
            except Exception as e:
                logger.warning(f"[AntiDetect] Error rotando session: {e}")

    def _start_watchdog(self):
        """FIX V6.2: Watchdog thread que monitorea la conexion y
        detecta caidas silenciosas del WebSocket."""
        if self._watchdog_thread is not None and self._watchdog_thread.is_alive():
            return

        self._watchdog_stop.clear()

        def _watchdog_loop():
            logger.info("[Watchdog] Iniciado - monitoreando conexion")
            last_ts_check = time.time()
            while not self._watchdog_stop.is_set():
                try:
                    self._watchdog_stop.wait(timeout=30.0)
                    if self._watchdog_stop.is_set():
                        break

                    if not self._connected:
                        continue

                    # Verificar que el websocket sigue vivo
                    try:
                        ts = self._api.get_server_timestamp()
                        if ts and ts > 0:
                            last_ts_check = time.time()
                        else:
                            # Timestamp invalido
                            elapsed = time.time() - last_ts_check
                            if elapsed > 90:
                                logger.warning(f"[Watchdog] Sin timestamp valido por {elapsed:.0f}s - reconectando")
                                self._connected = False
                                global_value.check_websocket_if_connect = 0
                    except Exception as e:
                        elapsed = time.time() - last_ts_check
                        if elapsed > 90:
                            logger.warning(f"[Watchdog] Error obteniendo timestamp por {elapsed:.0f}s: {e}")
                            self._connected = False
                            global_value.check_websocket_if_connect = 0

                except Exception as e:
                    logger.warning(f"[Watchdog] Error: {e}")

            logger.info("[Watchdog] Detenido")

        self._watchdog_thread = threading.Thread(target=_watchdog_loop, daemon=True)
        self._watchdog_thread.start()

    def _stop_watchdog(self):
        """Detiene el watchdog thread."""
        self._watchdog_stop.set()
        if self._watchdog_thread is not None:
            try:
                self._watchdog_thread.join(timeout=5.0)
            except Exception:
                pass
            self._watchdog_thread = None

    def connect(self):
        """Connect con TIMEOUT mejorado y ANTI-DETECTION headers.
        FIX V6.2: Reconexion robusta con reset de global_value,
        safe close de conexiones previas, y monkey-patch de close()."""
        for attempt in range(MAX_RECONNECT_ATTEMPTS):
            try:
                logger.info(f"[Patched] Connect intento {attempt + 1}/{MAX_RECONNECT_ATTEMPTS}")

                # FIX V6.2: Cerrar API anterior de forma segura
                _safe_close_api(self._api)

                # FIX V6.2: Resetear global_value ANTES de crear nueva API
                # Esto previene estados corruptos que causan "Connection is already closed"
                _reset_global_value()

                # Asegurar que los patches estan aplicados
                _patch_iqoptionapi_close()
                _patch_iqoptionapi_start_websocket()
                _apply_ws_patch_once()

                # Crear nueva instancia de IQ_Option
                api_instance = IQ_Option(self._email, self._password)
                _patch_api_session(api_instance)

                connect_result = [False, "Timeout"]
                connect_error = [None]

                def _do_connect(api_inst, result, error):
                    try:
                        check, reason = api_inst.connect()
                        result[0] = check
                        result[1] = reason
                    except Exception as e:
                        error[0] = e
                        result[0] = False
                        result[1] = str(e)

                t = threading.Thread(target=_do_connect, args=(api_instance, connect_result, connect_error), daemon=True)
                t.start()
                t.join(timeout=DEFAULT_TIMEOUT_CONNECT)

                if t.is_alive():
                    logger.warning(f"[Patched] Connect TIMEOUT ({DEFAULT_TIMEOUT_CONNECT}s) en intento {attempt + 1}")
                    # FIX V6.2: Safe close de la instancia que se colgo
                    _safe_close_api(api_instance)
                    if attempt < MAX_RECONNECT_ATTEMPTS - 1:
                        backoff = min(RECONNECT_BACKOFF_BASE ** attempt, 10)
                        backoff += random.uniform(1.0, 3.0)
                        logger.info(f"[Patched] Reintentando en {backoff:.1f}s...")
                        time.sleep(backoff)
                    continue

                if connect_error[0]:
                    err_str = str(connect_error[0])
                    # FIX V6.2: Si el error es "Connection is already closed", es recuperable
                    if "already closed" in err_str.lower():
                        logger.warning(f"[Patched] Error recuperable en intento {attempt + 1}: {err_str}")
                        if attempt < MAX_RECONNECT_ATTEMPTS - 1:
                            _safe_close_api(api_instance)
                            _reset_global_value()
                            backoff = min(RECONNECT_BACKOFF_BASE ** attempt, 10)
                            backoff += random.uniform(2.0, 5.0)
                            logger.info(f"[Patched] Reintentando en {backoff:.1f}s...")
                            time.sleep(backoff)
                        continue
                    raise connect_error[0]

                if connect_result[0]:
                    self._api = api_instance
                    self._connected = True
                    self._reconnect_count = 0
                    self._last_connect_time = time.time()
                    self._last_session_refresh = time.time()
                    # Re-apply browser headers after successful connect
                    _patch_api_session(self._api)
                    try:
                        self._update_actives_safe()
                    except Exception as e:
                        logger.warning(f"[Patched] Error actualizando ACTIVES: {e}")

                    # Esperar a que el WebSocket este realmente conectado
                    for wait_i in range(10):
                        if self.check_connect():
                            break
                        time.sleep(1.0)
                    else:
                        logger.warning("[Patched] WebSocket no confirmado tras 10s, pero proceediendo")

                    # FIX V6.2: Iniciar watchdog para monitorear conexion
                    self._start_watchdog()

                    logger.info("[Patched] Conexion exitosa (Anti-Detection activo)")
                    return True, None
                else:
                    self._api = api_instance
                    logger.warning(f"[Patched] Connect fallo: {connect_result[1]}")
                    if attempt < MAX_RECONNECT_ATTEMPTS - 1:
                        backoff = min(RECONNECT_BACKOFF_BASE ** attempt, 10)
                        backoff += random.uniform(1.0, 3.0)
                        logger.info(f"[Patched] Reintentando en {backoff:.1f}s...")
                        time.sleep(backoff)
            except Exception as e:
                err_str = str(e)
                logger.error(f"[Patched] Connect excepcion: {e}")
                # FIX V6.2: Si es error de conexion ya cerrada, no es fatal
                if "already closed" in err_str.lower():
                    logger.info("[Patched] Error 'already closed' detectado - limpiando estado y reintentando")
                    _reset_global_value()
                if attempt < MAX_RECONNECT_ATTEMPTS - 1:
                    backoff = min(RECONNECT_BACKOFF_BASE ** attempt, 10)
                    backoff += random.uniform(1.0, 3.0)
                    time.sleep(backoff)

        self._connected = False
        return False, "Max reintentos alcanzado"

    def check_connect(self):
        """FIX V6.2fixed: check_connect generation-aware con verificacion multiple.
        Ya no se confia ciegamente en global_value.check_websocket_if_connect
        porque callbacks stale pueden haberlo corrompido."""
        try:
            # Metodo 1: Verificar con timestamp real del servidor
            # Este es el metodo mas confiable porque no depende de global_value
            try:
                ts = self._api.get_server_timestamp()
                if ts and ts > 0:
                    # El servidor responde, la conexion esta viva
                    # Corregir global_value si estaba en 0 (stale callback)
                    if global_value.check_websocket_if_connect != 1:
                        global_value.check_websocket_if_connect = 1
                    return True
            except Exception:
                pass

            # Metodo 2: Verificar global_value como fallback
            ws_state = global_value.check_websocket_if_connect
            if ws_state == 1:
                # El global dice conectado, pero el timestamp fallo
                # Dar el beneficio de la duda (podria ser un glitch temporal)
                return True
            elif ws_state == 0:
                # El global dice cerrado - verificar si es un stale callback
                # Intentar un ultimo timestamp antes de declarar desconectado
                try:
                    ts = self._api.get_server_timestamp()
                    if ts and ts > 0:
                        # Stale callback! La conexion esta viva
                        global_value.check_websocket_if_connect = 1
                        return True
                except Exception:
                    pass
                return False
            # ws_state es None - conexion no inicializada
            return False
        except Exception:
            return False

    def _ensure_connected(self, max_attempts=3):
        """FIX V6.2: Ensure connected con manejo robusto de 'Connection is already closed'.
        Calls self.connect() instead of self._api.connect() to ensure full reconnection
        with watchdog, global_value reset, and fresh IQ_Option instance."""
        if self.check_connect():
            self._connected = True
            self._maybe_rotate_session()
            return True
        logger.warning("[Patched] Conexion perdida, reconectando...")
        # Stop the watchdog before reconnecting
        self._stop_watchdog()
        for attempt in range(max_attempts):
            try:
                # Reset global_value fully before reconnection
                _reset_global_value()
                # Call self.connect() which creates a completely new IQ_Option instance
                check, reason = self.connect()
                if check:
                    try:
                        if hasattr(self, '_last_balance_mode'):
                            self._api.change_balance(self._last_balance_mode)
                    except Exception:
                        pass
                    return True
            except Exception as e:
                err_str = str(e)
                if "already closed" in err_str.lower():
                    logger.info(f"[Patched] Reconexion: error 'already closed' en intento {attempt + 1} - reintentando")
                    _reset_global_value()
                else:
                    logger.error(f"[Patched] Reconexion intento {attempt + 1}: {e}")
            backoff = RECONNECT_BACKOFF_BASE ** attempt
            backoff += random.uniform(0.5, 1.5)
            time.sleep(backoff)
        logger.error("[Patched] No se pudo reconectar")
        return False

    def _update_actives_safe(self):
        try:
            old_actives = dict(OP_code.ACTIVES)
            def _do_update():
                try:
                    self._api.update_ACTIVES_OPCODE()
                except Exception as e:
                    logger.warning(f"[Patched] update_ACTIVES_OPCODE fallo: {e}")
            t = threading.Thread(target=_do_update, daemon=True)
            t.start()
            t.join(timeout=DEFAULT_TIMEOUT_ACTIVES)
            if len(OP_code.ACTIVES) > len(old_actives):
                self._actives_cache = dict(OP_code.ACTIVES)
                self._actives_cache_time = time.time()
                logger.info(f"[Patched] ACTIVES actualizado: {len(OP_code.ACTIVES)} instrumentos")
            elif len(OP_code.ACTIVES) > 0:
                self._actives_cache = dict(OP_code.ACTIVES)
                self._actives_cache_time = time.time()
        except Exception as e:
            logger.warning(f"[Patched] Error actualizando ACTIVES: {e}")

    def get_all_ACTIVES_OPCODE(self):
        if self._actives_cache and (time.time() - self._actives_cache_time) < 600:
            return self._actives_cache
        try:
            actives = self._api.get_all_ACTIVES_OPCODE()
            if actives and len(actives) > 0:
                self._actives_cache = actives
                self._actives_cache_time = time.time()
                return actives
        except Exception as e:
            logger.warning(f"[Patched] get_all_ACTIVES_OPCODE fallo: {e}")
        try:
            all_profit = self.get_all_profit()
            if all_profit:
                actives_from_profit = {}
                for name in all_profit.keys():
                    actives_from_profit[name] = name
                if actives_from_profit:
                    self._actives_cache = actives_from_profit
                    self._actives_cache_time = time.time()
                    logger.info(f"[Patched] ACTIVES desde profit: {len(actives_from_profit)} instrumentos")
                    return actives_from_profit
        except Exception as e:
            logger.warning(f"[Patched] get_all_profit fallback fallo: {e}")
        if self._actives_cache:
            return self._actives_cache
        return OP_code.ACTIVES

    def get_candles(self, ACTIVES, interval, count, endtime):
        self._maybe_rotate_session()

        norm = ACTIVES.upper().replace("-", "").replace("_", "")
        name_variations = [ACTIVES]
        if norm in _active_name_cache:
            name_variations.insert(0, _active_name_cache[norm])
        name_variations.extend([
            ACTIVES.upper(), ACTIVES.lower(),
            ACTIVES.replace("-OTC", "_otc"), ACTIVES.replace("-otc", "_otc"),
            ACTIVES.replace("_otc", "-OTC"), ACTIVES.replace("-OTC", "otc"),
        ])
        seen = set(); unique_variations = []
        for n in name_variations:
            if n not in seen: seen.add(n); unique_variations.append(n)

        for name in unique_variations:
            for attempt in range(3):
                try:
                    if not self._ensure_connected():
                        time.sleep(1)
                        continue
                    result = [None]
                    error = [None]
                    def _worker(n=name):
                        try:
                            result[0] = self._api.get_candles(n, interval, count, endtime)
                        except Exception as e:
                            error[0] = e
                    t = threading.Thread(target=_worker, daemon=True)
                    t.start()
                    t.join(timeout=DEFAULT_TIMEOUT_CANDLE)
                    if t.is_alive():
                        logger.warning(f"[Patched] get_candles TIMEOUT para {name}")
                        self._ensure_connected()
                        continue
                    if error[0]:
                        raise error[0]
                    if result[0] is not None and len(result[0]) > 0:
                        if name != ACTIVES:
                            _active_name_cache[norm] = name
                        return result[0]
                except KeyError:
                    self._update_actives_safe()
                    break
                except Exception as e:
                    err_str = str(e)
                    if "already closed" in err_str.lower():
                        logger.warning(f"[Patched] get_candles 'already closed' para {name} - reconectando")
                        self._connected = False
                        _reset_global_value()
                        break
                    logger.warning(f"[Patched] get_candles error para {name}: {e}")
                    break
        logger.error(f"[Patched] get_candles FALLO para {ACTIVES} despues de todos los intentos")
        return None

    def buy(self, price, ACTIVES, ACTION, expirations):
        self._maybe_rotate_session()

        # Anti-detection jitter (0.05-0.6s)
        jitter = random.uniform(0.05, 0.6)
        time.sleep(jitter)

        try:
            if ACTIVES not in OP_code.ACTIVES:
                self._update_actives_safe()
        except Exception:
            pass
        for attempt in range(3):
            try:
                if not self._ensure_connected():
                    logger.warning(f"[Patched] Sin conexion para buy (intento {attempt + 1})")
                    time.sleep(2)
                    continue
                result = [None, None]
                error = [None]
                def _worker():
                    try:
                        result[0], result[1] = self._api.buy(price, ACTIVES, ACTION, expirations)
                    except Exception as e:
                        error[0] = e
                t = threading.Thread(target=_worker, daemon=True)
                t.start()
                t.join(timeout=DEFAULT_TIMEOUT_BUY)
                if t.is_alive():
                    logger.warning(f"[Patched] buy TIMEOUT ({DEFAULT_TIMEOUT_BUY}s)")
                    self._ensure_connected()
                    continue
                if error[0]:
                    raise error[0]
                if result[0] is not None:
                    return result[0], result[1]
            except KeyError as e:
                logger.warning(f"[Patched] buy KeyError para {ACTIVES}: {e}")
                self._update_actives_safe()
                time.sleep(2)
            except Exception as e:
                err_str = str(e)
                if "already closed" in err_str.lower():
                    logger.warning(f"[Patched] buy 'already closed' - reconectando")
                    self._connected = False
                    _reset_global_value()
                    self._ensure_connected()
                else:
                    logger.warning(f"[Patched] buy error (intento {attempt + 1}): {e}")
                    self._ensure_connected()
                time.sleep(2)
        return False, "Buy fallo despues de 3 intentos"

    def check_win_v3(self, id_number, timeout=None):
        if timeout is None:
            timeout = 90  # Reduced from 120s
        start_time = time.time()
        balance_before = None
        try:
            balance_before = self.get_balance_safe()
        except Exception:
            pass

        # TIER 1: Wait for WS option-closed event (up to 60s)
        tier1_end = start_time + min(timeout, 60)
        while time.time() < tier1_end:
            try:
                if not self.check_connect():
                    self._ensure_connected()
                    time.sleep(2)
                    continue
                # Try get_async_order for option-closed
                try:
                    async_order = self._api.get_async_order(id_number)
                    if async_order and isinstance(async_order, dict):
                        option_closed = async_order.get("option-closed")
                        if option_closed:
                            msg = option_closed.get("msg", option_closed)
                            if isinstance(msg, dict):
                                profit = msg.get("profit_amount", 0) - msg.get("amount", 0)
                                return profit
                except Exception:
                    pass
                # Try the underlying API directly
                try:
                    result = self._api.check_win_v3(id_number)
                    if result is not None:
                        return result
                except Exception:
                    pass
                time.sleep(random.uniform(0.8, 1.5))
            except Exception as e:
                logger.warning(f"[Patched] check_win_v3 tier1 error: {e}")
                time.sleep(random.uniform(1.5, 3.0))

        # TIER 2: HTTP fallback - try /api/getoption (3 retries)
        for http_attempt in range(3):
            try:
                if hasattr(self._api, 'api') and hasattr(self._api.api, 'session'):
                    session = self._api.api.session
                    ssid = global_value.SSID
                    if ssid:
                        url = f"https://iqoption.com/api/getoption?id={id_number}"
                        headers = {"Cookie": f"ssid={ssid}"}
                        try:
                            resp = session.get(url, headers=headers, timeout=10)
                            if resp.status_code == 200:
                                data = resp.json()
                                if isinstance(data, dict):
                                    result_data = data.get("result", data)
                                    if isinstance(result_data, dict):
                                        # Try profit_amount - amount first
                                        if "profit_amount" in result_data and "amount" in result_data:
                                            return result_data.get("profit_amount", 0) - result_data.get("amount", 0)
                                        # Try direct profit field
                                        if "profit" in result_data:
                                            return result_data.get("profit", 0)
                        except Exception as e:
                            logger.debug(f"[Patched] HTTP getoption attempt {http_attempt+1} failed: {e}")
            except Exception:
                pass
            time.sleep(2)

        # TIER 3: Balance comparison fallback
        if balance_before is not None:
            try:
                time.sleep(3)
                balance_after = self.get_balance_safe()
                diff = balance_after - balance_before
                if abs(diff) > 0.01:
                    return diff
            except Exception:
                pass

        logger.error(f"[Patched] check_win_v3 ALL TIERS FAILED for order {id_number}")
        return None

    def get_balance_safe(self):
        # Primary: Direct WS get_balance (most reliable, returns correct balance for active account)
        for attempt in range(3):
            try:
                if not self._connected or not self.check_connect():
                    self._ensure_connected()
                    continue
                result = [None]
                error = [None]
                def _worker():
                    try:
                        result[0] = self._api.get_balance()
                    except Exception as e:
                        error[0] = e
                t = threading.Thread(target=_worker, daemon=True)
                t.start()
                t.join(timeout=DEFAULT_TIMEOUT_BALANCE)
                if t.is_alive():
                    logger.warning("[Patched] get_balance TIMEOUT")
                    continue
                if error[0]:
                    err_str = str(error[0]).lower()
                    if "already closed" in err_str:
                        self._connected = False
                        _reset_global_value()
                    raise error[0]
                if result[0] is not None:
                    return result[0]
            except Exception as e:
                logger.warning(f"[Patched] get_balance error (intento {attempt + 1}): {e}")
                time.sleep(2)

        # Fallback: HTTP getprofile
        for attempt in range(2):
            try:
                if hasattr(self._api, 'api') and hasattr(self._api.api, 'session'):
                    session = self._api.api.session
                    ssid = global_value.SSID
                    if ssid:
                        url = "https://iqoption.com/api/getprofile"
                        headers = {"Cookie": f"ssid={ssid}"}
                        try:
                            resp = session.get(url, headers=headers, timeout=10)
                            if resp.status_code == 200:
                                data = resp.json()
                                if isinstance(data, dict):
                                    result = data.get("result", data)
                                    if isinstance(result, dict):
                                        # Try balance first, then look for active balance in balances list
                                        balance_val = result.get("balance")
                                        if balance_val is not None and balance_val > 0:
                                            return float(balance_val)
                                        # Try balances list matching our balance_id
                                        balances_list = result.get("balances", [])
                                        if isinstance(balances_list, list):
                                            for b in balances_list:
                                                if isinstance(b, dict) and b.get("id") == global_value.balance_id:
                                                    amount = b.get("amount")
                                                    if amount is not None:
                                                        return float(amount)
                        except Exception as e:
                            logger.debug(f"[Patched] get_balance HTTP attempt {attempt+1} failed: {e}")
            except Exception:
                pass

        # Last resort: try balances dict from WS
        try:
            balances = self._api.get_balances()
            if balances and "msg" in balances:
                for balance in balances["msg"]:
                    if balance.get("id") == global_value.balance_id:
                        return balance.get("amount", 0)
        except Exception:
            pass

        raise Exception("get_balance fallo despues de todos los intentos")

    def get_all_profit(self, force_refresh=False):
        now = time.time()
        if not force_refresh and self._profit_cache and (now - self._profit_cache_time) < self._profit_cache_ttl:
            return self._profit_cache
        for attempt in range(2):
            try:
                if not self._ensure_connected():
                    continue
                result = [None]
                error = [None]
                def _worker():
                    try:
                        result[0] = self._api.get_all_profit()
                    except Exception as e:
                        error[0] = e
                t = threading.Thread(target=_worker, daemon=True)
                t.start()
                t.join(timeout=DEFAULT_TIMEOUT_PROFIT)
                if t.is_alive():
                    logger.warning("[Patched] get_all_profit TIMEOUT")
                    continue
                if error[0]:
                    raise error[0]
                if result[0] is not None:
                    self._profit_cache = result[0]
                    self._profit_cache_time = time.time()
                    return result[0]
            except Exception as e:
                logger.warning(f"[Patched] get_all_profit error (intento {attempt + 1}): {e}")
                time.sleep(3)
        if self._profit_cache:
            logger.warning("[Patched] get_all_profit usando cache expirado como fallback")
            return self._profit_cache
        return None

    def change_balance(self, Balance_MODE):
        try:
            self._api.change_balance(Balance_MODE)
            self._last_balance_mode = Balance_MODE
        except Exception as e:
            logger.warning(f"[Patched] change_balance error: {e}")
            if self._ensure_connected():
                self._api.change_balance(Balance_MODE)
                self._last_balance_mode = Balance_MODE

    def get_server_timestamp(self):
        try:
            return self._api.get_server_timestamp()
        except Exception:
            return time.time()

    def close(self):
        """FIX V6.2: Close seguro que maneja 'Connection is already closed'."""
        self._stop_watchdog()
        _safe_close_api(self._api)
        self._connected = False

    def get_async_order(self, id_number):
        try:
            result = [None]
            error = [None]
            def _worker():
                try:
                    result[0] = self._api.get_async_order(id_number)
                except Exception as e:
                    error[0] = e
            t = threading.Thread(target=_worker, daemon=True)
            t.start()
            t.join(timeout=10)
            if error[0]:
                raise error[0]
            return result[0]
        except Exception:
            return {}

    def get_balance(self):
        try:
            return self.get_balance_safe()
        except Exception:
            try:
                return self._api.get_balance()
            except Exception:
                return 0.0
